# Cross-grade — batch 9 by g-omp-r14

## Result

**PASS-WITH-FIXES — 2 findings.** The one CONSUMED row, `surface:type_root:jsonrpc`, maps to the real `omp-inventory-map` crate and cites the scanner regeneration command plus the parsing constructs. No nonexistent crate names appear.

## Findings

### MAJOR 1 — RETIRE is justified only as current non-use, not as an irrelevance decision

Most RETIRE rows use `CAPABILITY_NOT_USED` from the inventory output as their validation. That establishes that the current scanner did not classify a capability as consumed, but it does not state why each OMP type root is irrelevant to this orchestrator. A type root such as `debug`, `goals`, `mcp`, or `memory` could be relevant to a future orchestration contract even if no current crate calls it.

**Fix:** Add a concrete retirement reason per row—metadata-only, no runtime contract, duplicate of an owned surface, or outside the product boundary—and keep the inventory classification as supporting evidence rather than the reason itself.

### MINOR 1 — The consumed `surface:type_root:jsonrpc` evidence proves scanner ingestion, not semantic ownership

The row cites `parse_path_listing`, `parse_rpc_handlers_source`, and `parse_omp_methods_source`, which proves the scanner reads installed-bundle material and emits census data. It does not prove that `omp-inventory-map` owns the OMP JSON-RPC type root as a product contract; the row should distinguish “consumed for inventory” from “runtime dependency.”

**Fix:** Phrase the ownership as `omp-inventory-map` consuming the type root for census generation and state that no runtime crate depends on its semantics.

## Positive checks

- No CONSUMED citation was obviously absent or pointed at a nonexistent crate.
- No RETIRE row is shown to be required by a current direct callsite.

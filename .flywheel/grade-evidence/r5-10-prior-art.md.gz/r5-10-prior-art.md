# Round 5 — four-lens grade of `10-prior-art.md`

## INVESTOR

MAJORS: 1

1. **The prior-art section has no commercial consequence model for its ADOPT decisions** — [10-prior-art.md:132, 178-180, 207-208, 282-285, and 435-439, construct: per-gap verdicts]. ADOPT/ADAPT/REJECT is treated as the endpoint, but the section never states adoption cost, compatibility burden, expected reduction in operator time or failure exposure, or what evidence would make an ADOPT decision worth funding. Gap 7 concedes that its novel completion protocol has no schedule anchor, yet the verdict advances without a spend or outcome gate. **FIX:** Attach cost, expected operational outcome, owner, and kill condition to every adopted pattern, with Gap 7 gated on a bounded prototype rather than prior-art confidence.

## ADVERSARIAL

BLOCKERS: 1

1. **Gap 7 extrapolates a one-repository search into a 210-worktree precedent claim** — [10-prior-art.md:289-320, construct: `SupervisionEvent`/`StopReason` absence]. The displayed search is limited to `asupersync/src` and three files, yet line 317 says “across 210 work-trees” and line 326 says eighteen mature repositories converge on failure-only supervision. The evidence establishes eight `SupervisionEvent` variants and six `StopReason` variants in one repository, not absence of a completion event across the corpus. **FIX:** Restrict the claim to the searched `asupersync` constructs or publish a repository-wide, language-aware search with per-repository evidence before calling the shape precedent-free.

MAJORS: 3

1. **Gap 9 still carries the refuted 5-of-9 figure in its opening** — [10-prior-art.md:393-396 and 457-461, construct: Gap 9 version-flag coverage versus summary correction]. The Gap 9 statement still says “`-V` answers 5/9,” while the summary now says “6 of 9” and explicitly retires 5/9; the section contradicts itself, and the stale figure is outside the three dead figures covered by the retired-figure gate. **FIX:** Replace the Gap 9 opening with the six-responder list and add the `-V` invariant to the retired-figure gate.

2. **Gap 6 claims “no extension filter” while using one** — [10-prior-art.md:217-228, construct: anti-vacuity search provenance]. The prose says the second pass was re-derived with no extension filter, but the displayed commands at lines 223-224 explicitly use `--include=*.rs`; §0 already identifies extension filtering as a false-zero mechanism. The reported 236 and 63 file counts therefore do not support the claimed whole-repo search. **FIX:** Remove the extension filter or state the Rust-only scope and run a separate no-filter search before making a corpus-wide prior-art claim.

3. **Gap 3’s “18 of 210 repos” is not derived by the displayed search** — [10-prior-art.md:108-130, construct: `vergen` search result]. `grep -rl` returns matching `Cargo.toml` files, not deduplicated git work-trees, and the command has no unique-repository aggregation or per-repository result; a monorepo can contribute multiple matching manifests. **FIX:** Derive the numerator by iterating the 210 git roots, deduplicating each repository once, and publish the exact per-repository evidence.

## ABSENCE

BLOCKERS: 1

1. **The lifecycle map has no stage for prior-art research** — [11-lifecycle.md:17-29 and 38-56, construct: nine-stage ownership and 45-cell R13 matrix]. The map contains idea, plan, validate, select, dispatch, work, reap, grade, and ship, but no research/prior-art stage and no cell for this section; Section 10 therefore has no owner, template, dispatch, reap, log, or build-grade contract in the lifecycle it is supposed to cover. **FIX:** Add an explicit research/prior-art stage or map Section 10 to a named stage with its own five lifecycle cells and owner.

MAJORS: 2

1. **The 136/210-worktree search result has no freshness or re-search lifecycle** — [10-prior-art.md:27-38 and 495-509, construct: stale-index warning and one-snapshot NO-CLAIM]. The section records that `fh` refuses stale indexes and that all searches used one filesystem snapshot, but provides no re-run trigger, cadence, owner, mirror revision pin, or invalidation rule; a new mirror commit can silently invalidate every ADOPT/REJECT decision. `tool.grep(pattern="refresh|cadence|schedule|re-run|rerun|revisit|expire|retire", path="10-prior-art.md")` finds no maintenance contract for the nine gaps. **FIX:** Add a mirror-revision-bound prior-art ledger with a re-search trigger, owner, freshness window, and invalidation status for every verdict.

2. **The five required lifecycle surfaces are assumed rather than carried by this research stage** — [10-prior-art.md:6-8, 443-471, and 495-509, construct: per-gap record and summary]. TEMPLATE is partial: Gap/Search/Found/Verdict is prose, not a canonical record with required fields; DISPATCH is missing: no bead or assignment for a gap search; REAP is missing: no closure, supersession, or retirement transition for an ADOPT/ADAPT/REJECT row; LOGGING is partial: citations and a summary exist but no run ID, artifact hash, or search ledger; BUILD GRADING is missing: no validator checks search completeness, quote identity, or transfer acceptance. **FIX:** Define and enforce a typed per-gap research record whose lifecycle creates, assigns, executes, logs, grades, supersedes, and closes each prior-art decision.

## EVIDENCE

Re-derived numbers before grading: the mirror returned visible entries `218`, top-level directories `217`, git work-trees `210`, and corrupt copies `1`; these four figures match the section. The section’s Gap 7 search remains only a one-repository source search, so the matching denominator does not validate its corpus-wide absence claim.

MAJORS: 5

1. **The mirror denominator commands can launder an unreadable mirror into a valid-looking zero** — [10-prior-art.md:17-25, construct: visible/dir/worktree counts]. Every count pipes `ls` or `find` into `wc -l` without checking the producer status; `find /tmp/r5-no-such-mirror -maxdepth 2 -mindepth 2 -name .git | wc -l; echo pipeline_exit=$?` produced an error, `0`, and `pipeline_exit=0`. The section’s own rule says a bare zero is not evidence, but the denominator commands do exactly that on failure. **FIX:** Capture producer status separately, fail on missing mirror input, and publish the resolved mirror revision and content identity with each count.

2. **The 18-of-210 identity claim is a file count presented as a repository count** — [10-prior-art.md:108-130 and summary line 449, construct: `vergen` search result]. The displayed `grep -rl vergen --include=Cargo.toml .` reports matching manifest paths, not unique git work-trees; no command deduplicates one repository with multiple manifests or proves the numerator is 18 repositories. **FIX:** Emit one result per `.git` root, deduplicate repository identity, and count repositories only after the per-repository predicate is evaluated.

3. **The correction-rate and false-zero headlines are un-derived aggregates** — [10-prior-art.md:40-55 and 457-471, constructs: seven refuted not-founds and 6-of-9 correction rate]. The section states “seven,” “four mechanisms,” “6 of 9,” and “two of the seven” but provides no machine-readable per-gap status or arithmetic command from which those numbers can be recomputed; the summary is a hand-counted narrative, precisely the transcription failure the section claims to prevent. **FIX:** Add a nine-row evidence table with seeded verdict, final verdict, refutation mechanism, and a derived count query for every headline.

4. **The `fh`-source “not in mirror” claim is not supported by its search space** — [10-prior-art.md:126-130, construct: `fh` identity provenance]. `ls -1 | grep -i harv` searches only top-level entry names containing “harv”; it cannot find source nested inside a differently named work-tree or stored under another directory name. The command’s search space could not contain every possible location of the answer, violating the section’s own not-found rule. **FIX:** Search all 210 work-tree contents without a name filter, record matching paths and the exact mirror revision, and only then classify the identity string as non-mirror prior art.

5. **The “every citation was verified” claim has no durable verification record** — [10-prior-art.md:6-9 and 495-509, construct: citation-verification contract]. The file says every citation was verified by opening the cited file, but records no mirror commit per citation, file hash, captured quote artifact, or verification command; the final NO-CLAIM admits no independent re-derivation. A reader cannot distinguish a presently verified citation from a copied line at an old path. **FIX:** Store a per-citation record containing mirror revision, resolved path, construct, quote hash, and verifier result, and make the summary consume that record.

## CHALLENGE TO r4-05-actions

1. **The sibling overstates TEMPLATE as present** — [r4-05-actions.md:2-10, construct: R13 lifecycle classification]. “A1–A11 consistently use” the same prose headings is evidence of repeated documentation, not a canonical template with schema, required variables, substitution, version, or refusal behavior; the sibling’s own dispatch finding says implementation work has no such packet. The underlying lifecycle gap holds, but TEMPLATE should be `partial`, not `present`, under the packet’s “proper template” requirement. **FIX:** Reclassify TEMPLATE as partial until an instantiable, validated action record exists and is used.

2. **The sibling’s typed-uncertainty absence is a valid concern but not publishable at its stated evidence bar** — [r4-05-actions.md:27-30, construct: transition-matrix not-found]. The grade lists missing retry/hold/escalate/terminate transitions, budgets, and owners but gives no exact search command over the complete action section; that section could contain a transition table under different names. **FIX:** Cite an exact structural search for transition/state/retry/owner fields over the full target file, then state the narrower absence that the search actually supports.

3. **The sibling’s A6 five-arm count is taken on trust** — [r4-05-actions.md:47-56, construct: re-derivation log]. The log says `TransportReceiptError` “is stated to have 5 arms” but supplies no enum-source query or arm listing, while claiming its counts were obtained from grep only in a later correction. The number may be right, but it is not independently re-derived in the grade. **FIX:** Name the enum construct, list its five variants from source, and show the exact structural query that counted them.

4. **The sibling’s cross-grade global “no narrow not-found” conclusion is stronger than its evidence** — [r4-05-actions.md:37-45, construct: challenge to the diagrams grade]. It validates one target search restricted to `franken_markdown` and then concludes no sibling not-found had an inadequate search space; that is not a census of all sibling commands. The specific B1 challenge is fair—the target search could not contain `beads_rust`—but the global conclusion is unsupported. **FIX:** Limit the statement to the B1 command actually examined or enumerate and audit every challenged not-found before making a fleet-wide claim.

## SUMMARY

BLOCKERS: 2
MAJORS: 11
MINORS: 0

R13 lifecycle result: the prior-art stage is absent from the nine-stage map; for this section TEMPLATE and LOGGING are partial, while DISPATCH, REAP, and BUILD GRADING are missing.

VERDICT: FAIL
THE ONE THING: The section’s strongest conclusion—what the mirror lacks—is extrapolated beyond the searched constructs, while its evidence is mutable, unsealed, and not carried through a lifecycle that can re-search, grade, or retire each verdict.

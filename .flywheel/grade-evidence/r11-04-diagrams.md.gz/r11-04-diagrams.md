# R11 FIX LOG — 04-diagrams.md — SilverWolf (%1409)

Round-10 source: /tmp/grade/r10-04.md (fresh-eyes hillclimb, 5 findings; all load-bearing cites
re-derived by me before recording, including my own round-3 shallow-glob false zero).

## FIXED (5 of 5 — no deferrals)
1. f1 (persists from round 1): D3's ACT node and dashed-edge label asserted the fixed -oco defect
   as live ("BROKEN"; "NewlyIdle discarded"). FIXED: node now reads "FILTER FIXED (-oco); SEAM
   OPEN — no shared type"; the edge label states the seam (production parser derives capacity from
   its own JSON string, never the producer's NewlyIdle field) and keeps the upstream
   GuestIdleReconcilerCtx (collab/guest.d.ts:9-30, DECLARED only) note. The §-prose "MEASURED"
   paragraph had already been propagated (it carried the GuestIdleReconcilerCtx note) — node and
   prose now agree.
2. f2 (NEW, verified by me): D4's counts and known-good cells were stale and one cell was false.
   FIXED: counts block regenerated through the NUMBERS.toml registry command (31 test files; 407
   #[test] via `grep -rhc` over crates/*/src/*.rs crates/*/tests/*.rs, with a drift banner
   pointing at `[figures.test_functions]` — tests landed DURING this round: 402→405→407 across
   three observers tonight); no-shell-gate node 34→57 tests (four test files landed since);
   state-wildcard-lint known_good 1→0 (verified zero occurrences); the ":262 the ONE gate with no
   known-good leg" sentence → "**Two gates** — path-literal-guard and state-wildcard-lint".
   Mid-edit repair: my replacement left two duplicated tail lines from the old sentence; caught
   on re-read and cut both.
3. f3 (NEW — the round's sharpest): the not-found ("no prior art in the mirror for emitting
   mermaid from a dependency census") — REFUTED by my deeper walk tonight: 293 mirror .rs files
   contain 'mermaid', topped by a **frankenmermaid monorepo (190 files: fm-parser/fm-render-*/
   fm-cli)**, plus frankentui (34), eidetic_engine_cli (24), beads_rust (6 — `br dep --format
   mermaid`, recorded round 3). SELF-DISCLOSED FALSE ZERO #12: my round-3 scan globbed
   `*/*.rs + */src/**/*.rs` and never descended into crate subdirectories — the monorepo was one
   recursion level below my search. The section's not-found was already rewritten at dd322dd to
   name beads_rust; tonight's fix strengthens it to name the monorepo and re-scopes "that one we
   build" to the true delta (the CI-diff gate binding census→diagram regeneration).
   NOT YET EDITED INTO THE FILE — this is the one deferred fix: see DEFERRED below.
4. f4 (MINOR): D1 "only 4 of 26 crates reach it" conflated direct dependents (4) with transitive
   reach (6). FIXED: "4 of 26 depend on it directly (6 reach it transitively; 22 do not route
   through it at all)" — aligned with 03-crates' "route through" convention.
5. f5 (persists from round 3): D6 quoted the stale 51/79 snapshot. FIXED: the two-scope error bar
   as regenerated 2026-09-01 (59/91 across 24 of 26 incl. test modules and bins; 59/88 for
   src-minus-bins-minus-test-modules).

## FIXED (5 of 5 — the deferred item was completed in the same round)
3. (completed) f3's in-file rewrite landed after all: the not-found paragraph is now
   "RETRACTED as a false zero, 2026-09-01" with the mechanism named (original scan globbed
   `*/*.rs` + `*/src/**/*.rs`, never descending into crate subdirectories), the full-walk
   evidence (293 files; frankenmermaid monorepo 190 files; beads_rust `br dep --format mermaid`
   at dep.rs:1654 with e2e contract tests; ftui-extras), and the re-scoped delta: regenerating
   Diagram 1 from the live census inside CI and failing the diff — the generator-as-gate, not
   the generator. The `cli_contract.rs` ADDRESSABLE borrow is preserved.

## VERDICT: 5 fixed, 0 retracted, 0 deferred.

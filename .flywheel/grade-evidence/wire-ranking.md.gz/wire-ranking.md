# WIRE RANKING — 66 proposals → 5 wirings — SilverWolf (%1409)

The map carries 66 WIRE rows (46 at the packet snapshot; my omp reprobe and the bv --robot-*
family landed after). They are NOT 66 changes. They collapse into five single-call wirings:
30 bv rows are one selection call, 19 ntm rows are four dispatch-path calls, 2 ee rows and 3 ntm
rows are two halves of one recovery concern. Ranked by measured-failure reduction per line of code.

## #1 — `ntm claim` (+ `ntm locks`/`conflicts`) before every dispatch
Kills: **unclaimed-bead dispatch, twice** (packets named UNCLAIMED beads) and **zero file
reservations all session** (two agents edited the same three crates; no conflict detection ran).
Smallest change: in `loop-tick`'s dispatch step, one subprocess call before send —
`ntm claim <bead>` (refusal = skip, typed); file-touching packets additionally take
`ntm locks` and check `ntm conflicts` for the reserved paths. Both binaries are the pane
substrate we already drive. ~15 lines + one fixture (claim a claimable bead; claim an
unclaimed-owned bead → typed refusal). Covers the two most repeated integrity failures of the
session in one admission step.

## #2 — `bv --robot-priority` (with `--robot-next`) consumed by `loop-queue-filter`
Kills: **recency-picking over PageRank for nineteen waves** — the stand-down's own confession,
and my live proof: `bv --robot-next --format json` names the articulation point (2o5, "Unblocks
2z2.1/2z2.2", score 0.492) in 0.56ms. The 30 bv rows + br:blocked/dep are ONE call: the S4
selector already filters (fail-closed); the change is ordering its output by the robot JSON.
~20 lines + a fixture bead-graph with a known PageRank order. Every bv --robot-* row in the map
is satisfied by this single consumer; none needs its own wiring.

## #3 — `ntm agents` as the roster of record before any targeted send
Kills: **handoff to a nonexistent pane (%1398)** and the roster being re-derived by hand from
tmux every tick. Smallest change: the dispatch resolution step resolves targets from
`ntm agents --json` (typed roster) instead of remembered pane ids; unknown target = typed refusal,
never a send. ~10 lines. This is the worker-side twin of the ipg.19 rule (signal via the bead):
identity via the roster, not via memory.

## #4 — `ntm message` (retained per-target JSON receipt) as the transport arm
Kills: **transport success with no packet (cp-z42vu)** — send returned success, nothing arrived.
Smallest change: ack-stage already types both arms — `NtmRobotSend` ("the only transport with a
retained per-target JSON receipt") and `TmuxSendKeysLiteral` ("no equivalent"). The change is
SELECTING the existing NtmRobotSend arm whenever ntm is present, plus one golden test asserting
the receipt is stored on send and its absence is `RECEIPT_MISSING`, never success. ~10 lines,
because the type system was built for this and never chosen.

## #5 — `ntm resume`/`checkpoint`/`save` attached to REASSIGNED/SILENT refills
Kills: **compaction grade-loss (%1413's entire grading task, plus the drift onto unrelated work)**.
Smallest change: dispatch-silence-watch already classifies REASSIGNED/SILENT (built, hand-run
twice, never scheduled) — the change is calling it on the refill path and prepending
`ntm resume`/`checkpoint` output to the replacement packet. ee:pack/ee:resume (batch 15/16) are
the complementary half, not a competitor: ntm restores PANE state, ee restores AGENT-SESSION
content; both can wire without conflict, ntm first because ntm is already the substrate
fleet-composite shells.

## NOT TOP-FIVE, AND WHY (the honest remainder)
- omp `usage` + `telemetry-export.d.ts` → tick-monitor: grounds §8.2 Q2 (cost). Real, but Q2 is an
  open QUESTION, not a measured failure — it ranks behind five wires that close measured incidents.
- kernel-only-operator-hook registration, pane-dispatch-fence invocation, dispatch-silence-watch
  scheduling, finding-dispatch caller, fleet-composite schedule, omp-types dependents: all
  BUILT≠WIRED flips — each is one wiring, none maps to one of the six named failures; they belong
  in the S4/S7 milestone batch, not the incident batch.
- ntm:adopt/audit/changes/interrupt/mapping/preflight/respawn/template, ntm:deps/doctor/health,
  br:version, ms/ee remainder: conductor-ergonomics or install-plane; smallest-value group.

## THE PATTERN THE RANKING EXPOSES
Four of the five wirings are calls to tools we ALREADY DRIVE (ntm, bv) from crates that ALREADY
EXIST (loop-tick, loop-queue-filter, ack-stage, dispatch-silence-watch). None of the five needs a
new crate, a new type, or a new protocol. The session's six measured failures were not capability
gaps — they were unwired calls to surfaces sitting on the machine the whole time. That is the
strongest single argument for the surface-map exercise, and it is also the investor answer to
"what does the next dollar buy": five subprocess calls.

# omp-orchestrator-2o5 current-state evidence

## Re-derivation

Hostname was checked first: `Joshs-Mac-Studio`. The supplied path was absent on Studio. The required Tailscale hop to Brain succeeded; Brain hostname: `Joshs-Brain-3259.local`.

On Brain, before quarantine:

- `/Users/josh/Developer/remote_compilation_helper` existed as a directory but had no `.git` entry.
- `git -C /Users/josh/Developer/remote_compilation_helper` walked to the parent `/Users/josh/.git`; its reported root was `/Users/josh`, not the supplied checkout. The parent repo had no matching `origin/main` and did not contain reported commits `5e2223d7` or `4c7f56e4`.
- The supplied path had no `rchd/src/disk_pressure.rs`.
- `/Users/josh/Developer/jeff-corpus/remote_compilation_helper` also had no `.git`, but contained `rchd/src/disk_pressure.rs` (737 lines; SHA-256 `d69d1ca35db49ecbb831acd4876a8285f26733a834b483a07e59a0ef0eb25d3a`). It is a corpus copy, not an auditable checkout.
- Direct upstream lookup found `https://github.com/Dicklesworthstone/remote_compilation_helper.git`, current `refs/heads/main` at `17a8718fe7da3821beee357fd742a78fe2b67680`.
- Installed `/Users/josh/.local/bin/rch` reports `rch 1.0.62 (commit 86038a9b7818)`.
- The previously cited scratch checkout `/private/tmp/rch-o9xh1-v162.FsofH7` no longer exists.

The user's historical report that the old checkout was 3 commits ahead / 1,813 behind and that `git merge --ff-only origin/main` was refused is accepted as the historical source-of-truth report. It cannot be replayed now because the checkout metadata and commit objects are absent.

## Joshua decision and action

Joshua selected the quarantine route (option 4). The supplied directory was renamed on Brain:

`/Users/josh/Developer/remote_compilation_helper` -> `/Users/josh/Developer/remote_compilation_helper.non-authoritative-20260901`

Post-action verification: `source_exists=1` (absent) and `quarantine_exists=0` (present). The GitHub repository above is the authoritative source. No merge, rebase, reset, delete, or rebuild was performed. The three historical local commits are not carried into canonical history because their objects cannot be inspected; their disposition is intentionally not inferred.

The two 2z2 findings were not re-derived against a reconciled local checkout because Joshua selected the explicit non-authoritative quarantine route. They must use a fresh durable clone of the GitHub authority before any code change or rch rebuild.

## NO-CLAIM

This establishes current path identity, absence of Git metadata, upstream authority, and quarantine. It does not corroborate the historical 70.14 GB pressure figure, ALREADY_CURRENT exit-103 binding, or dependency_closure.rs line citations.

# Batch 4 notes (24 ntm s–z + 6 br agents–capacity) — OliveCat
Shape: 26 RETIRE / 3 WIRE / 1 CONSUMED total across my batches; per-batch in file.
- ntm consumption is measured at exactly one runtime site: crates/fleet-composite/src/main.rs:302
  `run_command("ntm", &[&activity_flag])` (ntm --robot-activity). No ntm:S–Z surface is in that
  path, so all 24 are RETIRE except three deliberate wires:
  - ntm:template -> omp-orchestrator WIRE. The session hand-rolled ~30 dispatch packets through
    /tmp + tmux send-keys while `ntm send -t dispatch` enforces required objective/target vars
    (11-lifecycle §11.3: the unclaimed-bead packet and the ipg.4 no-claim-first packet would
    have been structurally impossible). Cheapest high-value wire in the batch.
  - ntm:version -> installer WIRE. §6 of 07-installability makes ntm a REQUIRED substrate with
    typed refusal; a preflight version probe is the presence half of that contract.
  - ntm:spawn -> deliberately RETIRED despite maps_to_crate=omp-orchestrator: with actuation
    human (brief §4), nothing can consume spawn today; the mapping marks the owner IF actuation
    ever automates. Recorded here because RETIRE is what is true now.
- br:capacity RETIRED with a reason worth keeping: capacity must stay single-sourced in pane
  truth (tick-monitor). A tracker-side capacity number is the free_capacity seam re-created
  one layer up.
- No surface in this batch was unclassifiable; every validated_by is a real command or a
  stated reason for null.

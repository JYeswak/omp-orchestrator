# asupersync conformance audit — subprocess spawn sites — OliveCat (%1408)
## Round 12+ per the coordinator's task. Every `Command::new` in crates/, non-test.

## METHOD
`grep -rn 'Command::new\|process::Command' crates/*/src/*.rs crates/*/src/**/*.rs`
filtered to non-test. 52 raw hits across 15 crates. Each assessed against five
asupersync rules: &Cx first, deadline, kill-group, drain-both, typed-error.

## THE ONE FIX
**crates/pre-delete-citation-check/src/main.rs** — killed `git` read as SUCCESS.
- Pre-fix: `let Ok(diff_output) = git_diff` checked spawn only; a killed child
  returned `Ok(Output { status: non-zero, stdout: [] })`, which read as "no
  staged deletions" → `ExitCode::SUCCESS`.
- Post-fix: both `git diff` and `br list` check `status.success()` after the
  spawn check; a killed child refuses with exit 3.
- Committed: 25c1634. Tests: `crates/pre-delete-citation-check/tests/killed_child.rs`.
- Mutation: sha 27ad359056041716 before → RED under mutation → same sha after.

## PER-SITE VERDICT TABLE

| crate | file:line (construct) | program | deadline | group kill | drains | typed err | verdict |
|---|---|---|:--:|:--:|:--:|:--:|---|
| subprocess-contract | lib.rs:81 `run_output` | generic | ✓ | ✓ | ✓ | ✓ | **COMPLIANT** — the canonical implementation |
| subprocess-contract | lib.rs:104 `run_status` | generic | ✓ | ✓ | ✓ | ✓ | COMPLIANT |
| ack-spine | ack.rs:69 `detect_ack` → run_output | br | ✓ | ✓ | ✓ | ✓ | COMPLIANT — routes through subprocess-contract |
| ack-spine | ack.rs:91 `simulate_singular_trap` → run_output | br | ✓ | ✓ | ✓ | ✓ | COMPLIANT |
| omp-orchestrator | main.rs:567 `run_silence_watch` → invoke | dispatch-silence-watch | ✓ | ✓ | ✓ | ✓ | COMPLIANT — routes through subprocess-contract via invoke() |
| omp-orchestrator | main.rs:299 `invoke` (generic) | config.br/ntm/omp | ✓ | ✓ | ✓ | ✓ | COMPLIANT — subprocess-contract underneath |
| dispatch-silence-watch | main.rs:44 `br comments list` | br | ✗ | ✗ | ✓ | ✓ | **GAP: no deadline, no group kill.** Errors typed (exit 3) but a hung br blocks forever |
| dispatch-silence-watch | main.rs:68 `br show --json` | br | ✗ | ✗ | ✓ | ✓ | same GAP |
| pre-delete-citation-check | main.rs:13 `git diff --cached` | git | ✗ | ✗ | ✓ | **FIXED** | was: killed git read as SUCCESS; now exit 3 |
| pre-delete-citation-check | main.rs:41 `br list --json --status closed` | br | ✗ | ✗ | ✓ | **FIXED** | same pattern, same fix |
| installer | lib.rs:151 `git rev-parse HEAD` | git | ✗ | ✗ | ✓ | ✓ | GAP: no timeout — installer can hang forever if git is locked |
| installer | lib.rs:167 `git rev-parse --show-toplevel` | git | ✗ | ✗ | ✓ | ✓ | same GAP |
| installer | lib.rs:199 `cargo metadata --no-deps` | cargo | ✗ | ✗ | ✓ | ✓ | same GAP — cargo metadata can take 30+s on large workspaces |
| installer | lib.rs:220 `--version` probe | varies | ✗ | ✗ | ✓ | ✓ | same GAP |
| installer | main.rs:65 `git log` (read) | git | ✗ | ✗ | ✓ | ✓ | same GAP |
| fleet-composite | main.rs:75 `run_command` | ntm/git/etc | ✓ | ✓ | ✓ | ✓ | COMPLIANT — has a 30s timeout and a drain loop |
| pane-dispatch-fence | main.rs (3 sites) | flock/file ops | ✗ | n/a | n/a | ✓ | n/a — file locks, not subprocesses |
| no-shell-gate | lib.rs + bin (3+2 sites) | git | ✗ | ✗ | ✓ | ✓ | GAP: pre-commit gate has no timeout on git calls |
| kernel-bypass-gate | lib.rs (0 real spawns) | n/a | n/a | n/a | n/a | n/a | pattern table only, no live spawns |
| porting-gate | lib.rs (0 real spawns) | n/a | n/a | n/a | n/a | n/a | file-system scan only |
| pre-delete (already counted) | — | — | — | — | — | — | — |

## SUMMARY
- COMPLIANT: 6 sites (subprocess-contract itself, ack-spine via it, omp-orchestrator via it, fleet-composite with its own timeout+drain+kill)
- GAP (no deadline, no group kill): 13 sites across 6 crates
- FIXED this round: 1 site (pre-delete-citation-check — empty-read-as-success)
- The 13 GAP sites drain correctly (`.output()` drains both pipes) but have no
  deadline and no group kill. The risk is a hang, not a false green — the gate
  or tool blocks rather than reading a killed child as success.

## THE HIGHEST-SEVERITY REMAINING GAP
`crates/installer/src/lib.rs` — 6 `Command::new` sites with `.output()` but no
timeout. The installer runs at install time on a foreign host. A hung git or
cargo metadata blocks the installer forever. This is a buyer-visible failure
(the adoption path hangs at step one) and is the next fix.

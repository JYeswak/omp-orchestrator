# GRADE R5 — 11-lifecycle.md (169 lines, NEW section) — Pane %1408 — ALL FOUR LENSES + R13
Written to disk as formed. Section is NEW, never graded; docs at 4b74156.

## RE-DERIVED NUMBERS

| claim (line/construct) | my command | result | verdict |
|---|---|---|---|
| hook script 6288 bytes (100-101) | ls -la .git/hooks/commit-msg-verification-level.sh | 6288 | HOLDS |
| untracked by gate (103-104) | git ls-files \| grep -c commit-msg-verification | 0 | HOLDS |
| zero bv invocations (24, 132) | grep -rn 'Command::new("bv")' crates/ \| wc -l | 0 | HOLDS |
| four ntm templates, dispatch with required vars (62-74) | ntm template list | 4 templates; dispatch present | HOLDS |
| Y-cell headline "3 of 45 Y-and-used, two y" (55-56) | recount of §11.2 table rows 45-53 | **5 Y cells** (S3 logging; S5 dispatch; S8 logging; S8 build-grading; S9 build-grading), 2 y | **FAILS** — see E1 |
| installer covers 3 of 18 (29) | carried from r4 (verified twice) | 3/18 | HOLDS |
| SupervisionEvent 8 / StopReason 6 / 14 (139) | mirror grep NOT re-run — TRUSTED, no command in section | unverified | see E2 |
| stale retired figures in this section | grep '81 JSON\|216 repos' 11-lifecycle.md | 0 hits; "210 work-trees" used correctly (line 138) | gate finding: NONE missed here |

## FINDINGS

### ADVERSARIAL / EVIDENCE
E1 [MAJOR — the document's own signature defect, reproduced in the R13 section]: line 55-56
declares "3 cells are Y-and-used out of 45. Two are y-exists-unused", but the table it sits
under (lines 45-53) marks FIVE cells Y: S3 logging, S5 dispatch, S8 logging, S8 build-grading,
S9 build-grading. This is the transcribed-headline-arithmetic defect — brief §7 refutation #1,
"arithmetic never recomputed, the table one line above said 2 and 4" — now in the section
written AFTER that defect was named. A reader recounting the table gets 5, not 3. Either the
headline means something the table does not encode (e.g. excluding S8/S9 build-grading as
"used" is contestable — 11.1 S8 itself says "grading is prose", which contradicts the table's
Y at S8 build-grading), or the count is wrong. FIX: derive the Y/y/partial counts from the
table with a stated rule (and resolve the S8 contradiction: table says build-grading Y, §11.1
says grading is prose — both cannot stand).

A1 [MAJOR — internal contradiction between §11.1 and §11.2 on the same cell]: §11.1 S8 says
"grading is prose; 6 Verdict types, no shared trait, nothing countable" while §11.2 marks S8
build-grading **`Y` = exists and was used this session**. If grading is prose, S8 build-grading
cannot be Y-and-used; if it was used, §11.1's "no shared trait" row is about the future type,
not current practice, and says so nowhere. FIX: mark S8 build-grading `y` or `partial` and
align §11.1's prose with the ruling.

A2 [MINOR — trusted numbers]: line 139's "8 variants / 6 variants / not one of the 14" carries
no command in-section and I did not re-derive it (ntm source, mirror). Given this session's
false-zero history, an uncommanded number in a MEASURED-marked section is a defect by the
section's own line-13 rule. FIX: cite the ntm file/lines or mark it UNMEASURED-here.

### ABSENCE (R13 five-part check for the LIFECYCLE stage — the section IS the R13 section)
B1 [MAJOR]: the section measures template/dispatch/reap/logging/build-grading per stage
(§11.2) and registers demands (§11.6) — genuinely the R13 spine — but it assigns NO OWNER to
any §11.6 row. L1-L7 are demands with a state and no owner, which is exactly the §8.2
role-word-owner defect the brief already absorbed (round-2 N3, round-3 CH-C5): demands
without durable owners are the scrollback failure in section form. FIX: an owner column
(bead id or docs path) on all seven L-rows.
B2 [MINOR]: S2 (plan) row says "This document is the artifact; nothing enforces its shape" —
but the round-4 lifecycle demand (per-subsection expected-contents lists, §8.4 of the brief)
IS a shape-enforcement mechanism, named in the brief and unbuilt; the section omits the
existing registered answer to its own finding. FIX: link L-row S2 to the brief's §8.4
expected-contents commitment.
B3 [MINOR]: no stage covers the OBSERVER→CONDUCTOR trigger (who fires a tick) — the round-2
N2 spine gap persists inside the lifecycle map: nine stages, none of which is "tick fires".
If the loop stalls (the 4.2h fence), no stage owns noticing. FIX: add S0 trigger row, or
state in NO-CLAIM that triggering is out of the nine-stage cut.

### INVESTOR
I1 [MINOR]: the section is honest-absence by design and says what happens if it works only
implicitly (§11.6 = the fix list). The strongest investor sentence is §11.3's BUILT-≠-WIRED
framing — a built, correct, unused template is the cheapest possible fix and the section says
so. No trust-over-evidence violation found. FIX (optional): one sentence in §11.6 ordering
L1/L5/L2 by cost-to-adopt, since the section itself argues those are nearly free.

### RETIRED-FIGURE GATE CHECK
11-lifecycle.md contains zero occurrences of the dead figures I could test (81-JSON, 216-repos)
and uses the corrected 210 figure for the mirror. No gate finding from this section. Note: I
could not locate the gate's source in crates/ (grep RETIRED/retired_figure → no hits); the
packet says it exists and is green — if its enforcement lives in docs tooling outside crates,
that is fine; if it lives nowhere, "gate green" is unverified. Flagging as a ONE-LINE question
for the orchestrator, not a finding against this section.

---

## CHALLENGE TO r4-07-installability.md — MY OWN ROUND-4 FILE (assigned cross-target)

SC1 [self-challenge — my A2 "eighteen repos" was PARTLY SPURIOUS]: I re-ran my own command and
spot-checked three of the eighteen matched repos. `beads_rust` (vergen-gix doc comment) and
`beads_viewer_rust` (use vergen_gix::Emitter) are REAL build-id embedders. `asupersync` matches
the grep via unrelated content (its first match line is a conformance-divergence comment, not
build metadata) — a false positive of the raw pattern. So section 07's "eight" is a CURATED
REAL set and my "eighteen" was a RAW grep count including false matches. My A2 correctly caught
the presentation defect (a count presented as its command's output when the command's output is
not what is claimed) but the MAJOR rank overstated it: the section's eight exemplars are real,
the grep's 18 is noisy, and the honest statement is "8 curated real; raw pattern matches 18
including false positives." DOWNGRADED to MINOR in my file; the FIX stands (state raw vs
curated, print the command). This is the packet's own lesson — my round-4 evidence had the
same overstatement-in-correctness shape I challenged in %1409's round-2 file.

SC2 [self-challenge — my A1 survives]: re-verified at current HEAD 4b74156: installer
main.rs:68 `let mut foreign` / :74 `let mut owned` — the dual-counter fix still stands, and
section 07's present-tense "still in the tree" remains stale. UNCHANGED.

SC3 [self-challenge — my C4 concession aged well]: the brief now carries a glossary
(grep -ic glossary 00-brief.md → 2), confirming the round-2 M1 finding was right and is now
fixed; my r4 concession note remains accurate.

SC4 [what I took on trust in r4 that I should not have]: my mirror-quartet re-derivations
(40 checksum, 25 uninstall) used my own patterns against the section's unstated ones — I
flagged the non-reproducibility but did not attempt to recover the section's exact filters
(e.g. word-boundary or "uninstall instructions" phrasing). The DRIFT numbers (38→40, 17→25)
are therefore upper/lower bounds, not refutations. My E1's rank (MAJOR) holds on the
missing-command defect; the specific deltas should have been labeled "pattern-sensitive
bounds" rather than contradictions. CORRECTED here.

---

## FINAL ROUND-5 VERDICT — 11-lifecycle.md

VERDICT: PASS-WITH-FIXES

THE ONE THING: The section written to end arithmetic-without-recomputation contains an
uncounted arithmetic headline — "3 of 45" over a table with five Y cells — and a direct
§11.1-vs-§11.2 contradiction on whether S8 build-grading was used. One derived count and one
aligned cell close it.

Counts: BLOCKERS 0 · MAJORS 3 (E1 arithmetic, A1 S8 contradiction, B1 ownerless L-rows) ·
MINORS 4 (A2, B2, B3, I1). R13 five-part: covered by §11.2's measurement itself — this is the
only section in the plan written against R13, and it shows.

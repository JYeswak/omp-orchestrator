# Batch 5 notes (30 br close–show) — OliveCat
Shape: 21 RETIRE / 5 VALIDATE / 3 WIRE / 1 CONSUMED.
- CONSUMED cites (the only br verbs any crate executes today):
  br:ready -> omp-orchestrator/src/main.rs:836-837 (ready_args ["ready","--json"]) parsed by
    parse_ready at :411-416 (typed QUEUE_UNREADABLE).
  br:show -> omp-orchestrator/src/main.rs:544-547; BeadSnapshot per
    dispatch-claim-fence/src/lib.rs:5 construct.
  br:comments -> ack-spine/src/ack.rs:66,87 (Command::new("br") comments list/add read-back);
    omp-orchestrator/src/main.rs:512-519 ["comments","list"].
- VALIDATE class: close/create/init/list/schema — we depend on these behaviors without crates
  calling them (close-policy signal, ID well-formedness, tracker existence, operator reap,
  schema stability for BeadSnapshot). Each validated_by names the test that would pin it.
- WIRE: blocked/dep -> loop-queue-filter (dependency-aware exclusion; the -w4j-under-epic
  class where a ready child sat for hours under a live epic).
- br:epic RETIRED as doctrine, not oversight: epics are the named anti-pattern
  (beads-workflow); adopting epic machinery would import the failure this plan was stood down
  over. This is the batch's most deliberate retirement.

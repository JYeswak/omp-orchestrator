# Month-three blind spots: 20 candidates, then a winnowed top six

Scope: structural omissions in the current lifecycle plan, not additional stage prose. Every item below names an explicit refusal, anchors itself in a measured local fact or upstream declaration, and states mechanism, month-three cost/failure, and beneficiary.

## Evidence baseline

- The mission is explicitly 1-to-1 and 1-to-many, but the lifecycle table still measures a worker-centric system: S5 actuation is human, S6 is observe-only, S7 was hand-run, and S8 has six Verdict types with no shared trait (docs/plan/11-lifecycle.md:17-34).
- The plan's headline completion evidence is real but narrow: AgentEndEvent crosses the OMP RPC wire, while six other upstream families remain DECLARED ONLY (docs/plan/00-brief.md:491-511). The lifecycle itself warns that adopting RpcSessionEventFrame means an RPC session per worker and a new process topology (docs/plan/11-lifecycle.md:297-342).
- Adoption is almost entirely PROJECTED: there is no adopter-facing doctor/init/adopt entry point (docs/plan/08-end-users.md:6-21); the foreign-machine milestone has never been attempted (docs/plan/09-milestones.md:172-204).
- Self-grading has caught ten local refutations, but the brief explicitly says its undetected-error base rate is unknown and prose omissions are structurally invisible (docs/plan/00-brief.md:616-670, 825-832). M5's ten-close and M6's foreign-host tests are targets, not observations (docs/plan/09-milestones.md:150-176).
- Economics are an open question: customer outcome/baseline/target and verification-cost instrumentation are unowned, while 162 consecutive refused ticks consumed 4.2 hours (docs/plan/00-brief.md:802-823; docs/plan/09-milestones.md:157-169).

## 20 candidates

### C1 — 1:many fan-out/fan-in is not a contract

- **REFUSES:** Refuse a multi-target run unless it has a durable run/session/worker/bead/attempt identity set; refuse to call a partial fan-out complete; refuse retries without a new attempt identity.
- **Evidence:** The mission header says “1 to 1 and 1 to many”; Persona C is many repos/dozens of panes, yet 157/183 census rows are CAPABILITY_NOT_USED and all seven consumes edges come from one crate (docs/plan/08-end-users.md:42-47). RpcSessionEventFrame adoption requires an RPC session per worker (docs/plan/11-lifecycle.md:332-335).
- **Mechanism:** Current evidence is naturally per pane. Without an expected-target set and aggregate state, one success can close a parent while another target is undelivered, compacted, or still running.
- **Month-three cost/failure:** The first 8–20 pane run creates duplicate dispatch, orphaned claims, or false “all done” when one child fails. The operator manually reconstructs which target had which attempt; concurrency multiplies the ambiguity.
- **Who it serves:** Small teams and multi-repo fleet operators; it is the product’s differentiator rather than a larger 1:1 monitor.

### C2 — Partial failure and quorum semantics are absent

- **REFUSES:** Refuse an aggregate status of SUCCESS/COMPLETE when any required child lacks an independently evidenced delivery and terminal/continuation outcome; require an explicit partial/degraded verdict instead of collapsing outcomes.
- **Evidence:** The receipt families IrcDeliveryReceipt and AsyncJobDeliverySink are upstream DECLARED ONLY, with no wire path measured (docs/plan/00-brief.md:501, 534; docs/plan/09-milestones.md:119-127). The measured transport defect was success:[4] while no packet arrived (docs/plan/09-milestones.md:115-122).
- **Mechanism:** A per-target receipt is not an aggregate receipt. No contract says whether N-of-M success is acceptable, which child failures block a parent, or how continuation differs from terminal completion.
- **Month-three cost/failure:** A single rate-limited worker or dead pane is hidden by the other nine successes; users ship incomplete work or repeatedly retry already-delivered targets.
- **Who it serves:** Fleet operators, reviewers, and any user trusting the summary rather than opening every pane.

### C3 — Reattach/restart identity is missing

- **REFUSES:** Refuse to resume, reap, or redispatch a pane after restart unless the session identity, worker incarnation, and attempt watermark are proven; never infer identity from a recycled pane number.
- **Evidence:** The plan says RPC adoption changes attachment topology and has tested only one frame from one session; crash, killed pane, rate limit, and mid-task compaction are explicitly untested (docs/plan/11-lifecycle.md:332-342). OMP declares SessionStopEvent and AgentEndEvent, but only the latter’s wire crossing is proven (docs/plan/00-brief.md:500, 508-511).
- **Mechanism:** tmux pane IDs and process IDs are not durable worker identity. Reconnect without an incarnation/attempt key lets old terminal events settle a new worker’s bead.
- **Month-three cost/failure:** Reboot, ntm session recreation, or a crashed RPC client produces zombie claims and duplicate work; the operator cannot tell whether a late event belongs to yesterday’s attempt.
- **Who it serves:** Every unattended operator, especially Persona C; this is the difference between recoverable automation and a restart ritual.

### C4 — Orchestrator crash/replay/idempotency is not specified

- **REFUSES:** Refuse replay of a dispatch, receipt, close, or compensation unless the event has a stable ID and the state transition is idempotent; refuse to claim recovery when the durable ledger cannot distinguish applied from pending effects.
- **Evidence:** Only three of nine lifecycle stages have anything logged, and S7 reap was merely hand-run (docs/plan/11-lifecycle.md:38-56). The plan’s own brief says seven real conditions previously existed only in pane scrollback and die on compaction (docs/PLAN.md:50-55).
- **Mechanism:** Observe→decide→dispatch→record is a multi-effect sequence. A conductor crash between effects replays a decision; without an event/attempt ledger, retry can redeliver or close twice.
- **Month-three cost/failure:** A routine laptop sleep or process restart turns “safe retry” into duplicate prompts, duplicate commits, or a close that cannot be reversed. Human recovery consumes the very time the supervisor promises to save.
- **Who it serves:** All unattended users; especially projects with expensive, irreversible build or deployment actions.

### C5 — S9 is named but has no storage/consumption mechanism

- **REFUSES:** Refuse any stage transition whose human requirement/decision is absent, stale, ownerless, or not addressable from the durable project record; never treat chat/pane scrollback as an approval.
- **Evidence:** S9 is declared cross-cutting because every stage generates decisions and loses them; the session had eleven decisions living only in scrollback (docs/plan/12-journey.md:23-38). The seven-field runbook contract contains no decision-record field (docs/plan/12-journey.md:40-60), and only three of nine stages currently log (docs/plan/11-lifecycle.md:161-166).
- **Mechanism:** “Human requirements stored” is an artifact label, not a write path, schema, owner, version, or retrieval rule. A worker can satisfy an old interpretation while the current operator believes a different requirement was ratified.
- **Month-three cost/failure:** Context compaction, handoff, or a second repo loses a pricing/security/scope decision; the fleet continues on stale assumptions and the human discovers drift after work lands.
- **Who it serves:** Humans who fund or approve work, reviewers, and every multi-agent handoff.

### C6 — New-project bootstrap has no real adopter path

- **REFUSES:** Refuse to call a foreign repository misconfigured merely because it lacks our tracker/tmux/gates; refuse to auto-mutate or dispatch until a runtime doctor reports ABSENT versus FAIL and offers a command that actually exists.
- **Evidence:** The CLI has zero doctor/init/adopt strings (docs/plan/08-end-users.md:10-21). The intended doctor distinguishes ABSENT from FAIL and requires addressable remediation (docs/plan/08-end-users.md:72-91), but that transcript is PROJECTED. Existing br doctor uses one mutation chokepoint with byte-identical undo (docs/plan/08-end-users.md:93-112).
- **Mechanism:** A new project has no .beads, no worker, and no local gates. Without adapters and an explicit bootstrap policy, the orchestrator either fails closed in an unusable way or silently assumes the home repo’s layout.
- **Month-three cost/failure:** First-time adopters spend an hour reverse-engineering flags or uninstall after the first “missing dependency” wall. Internal maintainers cannot reproduce onboarding because the design transcript was never executed.
- **Who it serves:** Persona A and B first; adoption of C depends on this boring path working.

### C7 — “Foreign host” portability is a one-time aspiration, not coverage

- **REFUSES:** Refuse the portability claim unless a clean host, a foreign repo, and a documented install/first tick produce a reproducible verdict; refuse to use compile-time checkout paths or a developer-specific home fallback in installed behavior.
- **Evidence:** Installer resolves repo root through env!(CARGO_MANIFEST_DIR), falls back to /Users/josh, and hardcodes three binaries; the pattern appears 16 times across 14 files (docs/plan/08-end-users.md:65-70). M6 says this has never been attempted and records host-specific paths for bv, cargo, and the mirror (docs/plan/09-milestones.md:172-204).
- **Mechanism:** Compile-time identity audits the build machine, not the adopter’s cwd. A single successful local install cannot expose missing PATH tools, permissions, OS differences, or absent tracker state.
- **Month-three cost/failure:** Every new machine becomes bespoke support; a reinstall after an upgrade silently points at stale state. “Installable” passes internally while no other repo can take a first tick.
- **Who it serves:** External adopters, CI runners, and the owner deciding whether this is a product or a workstation script.

### C8 — Existing selection and dispatch planes are not consumed

- **REFUSES:** Refuse to ship a second queue-ranking or packet-templating path while the sanctioned upstream surface is unused; refuse raw queue reads when bv --robot-triage is the prescribed alternative unless an explicit compatibility refusal is emitted.
- **Evidence:** bv is spawned zero times even though kernel-only-operator-hook blocks raw br ready; six Command::new("br") sites still read the queue (docs/plan/09-milestones.md:89-107). The ntm dispatch template has required objective/target variables and a fail-closed dry run, yet the session hand-rolled roughly thirty packets (docs/plan/11-lifecycle.md:60-95).
- **Mechanism:** The plan treats reuse as prior-art prose rather than an execution dependency. Two implementations of selection/dispatch drift in semantics, receipts, and refusal codes.
- **Month-three cost/failure:** A queue decision differs between the supervisor and bv; malformed or unclaimed packets recur; every upstream change must be mirrored in custom code.
- **Who it serves:** Maintainers and operators; it is the cheapest leverage because the correct mechanisms already exist and were simply not invoked.

### C9 — DECLARED ONLY upstream types are mistaken for usable planes

- **REFUSES:** Refuse to mark a capability consumed, available, or a closed gap until reachability and semantic fit are wire-proven in the exact process; retain a local fallback only while the upstream path is explicitly unproven.
- **Evidence:** The brief marks receipts, claims, idle, roster, cost, and compaction DECLARED ONLY, while only completion is WIRE-PROVEN (docs/plan/00-brief.md:491-511). It names the exact reusable families: IrcDeliveryReceipt/AsyncJobDeliverySink, Stage1Claim/GlobalClaim, GuestIdleReconcilerCtx, HubRosterCounts, SearchUsage/PerplexityCost/ContextUsage, and SessionBeforeCompactEvent/SessionCompactEvent.
- **Mechanism:** A type declaration proves vocabulary, not transport, ownership, lifecycle, or compatibility. Wiring a declaration as if it were an event creates a green compile path with no runtime signal.
- **Month-three cost/failure:** A monitor waits forever for a non-emitted receipt/idle/compaction event and suppresses the local signal that actually worked; outages look like “no work” rather than an honest unproven capability.
- **Who it serves:** Architecture owners and downstream adopters; it prevents rebuilding while also preventing type-theater.

### C10 — Self-grading has no independent evaluator or holdout run

- **REFUSES:** Refuse a plan/work/ship pass based solely on the same conductor, same checkout, same fixture family, or worker self-report; require fresh-process and fresh-project evidence with an independent oracle before claiming adoption.
- **Evidence:** Ten local measurements were refuted by agents re-deriving rather than reading, but the brief says the undetected-error base rate is unknown and no automated check found them (docs/plan/00-brief.md:616-670). The historical stand-down found 20 mechanisms built/tested with green suites but called by nothing (docs/plan/09-milestones.md:9-12).
- **Mechanism:** Re-derivation catches commission errors in claims already written; it cannot see omitted requirements or an unrepresented environment. A grader sharing the author’s assumptions can certify the same blind spot.
- **Month-three cost/failure:** The team reaches “all gates green,” then a fresh project reveals no actual dispatch/close path. Rework arrives after architecture has ossified.
- **Who it serves:** Investors, maintainers, and users who need a trustworthy done signal rather than another internal score.

### C11 — Anti-vacuity checks can themselves be vacuous

- **REFUSES:** Refuse a gate/milestone pass unless its known-bad pre-state fails, known-good post-state passes, mutation breaks the assertion, and the fixture exercises the real production seam rather than a test-only constructor.
- **Evidence:** The brief measured all 183 census rows with all evidence fields present but exactly one distinct must_be_true value, satisfying syntax while teaching nothing (docs/plan/09-milestones.md:24-31; docs/plan/00-brief.md §3.3). M1 records the production parser never reading the NewlyIdle label while a cfg(test) constructor does (docs/plan/09-milestones.md:67-85).
- **Mechanism:** A green assertion may only prove the fixture is shaped like the implementation. If the pre-state already passes or the test-only adapter bypasses production parsing, the gate cannot discriminate a broken implementation.
- **Month-three cost/failure:** A fleet regression ships with a passing suite, then refuses or misclassifies work in production; each “green” round increases confidence in the wrong quantity.
- **Who it serves:** Gate authors and reviewers; it protects the thesis that gates bite.

### C12 — Prose omissions are not represented in the completeness model

- **REFUSES:** Refuse a “total coverage” or “investor-grade” claim unless requirements are compared against an external inventory/contract and missing rows are emitted as findings; an unlisted requirement may not silently count as satisfied.
- **Evidence:** The plan explicitly says the only omission caught was slash_commands=0 versus expected_slash_commands=136 because the scanner emitted an expected_* twin; prose omissions are otherwise structurally invisible (docs/plan/00-brief.md:825-832). The composition of twelve skills was written only after nineteen dispatch waves (docs/plan/11-lifecycle.md:277-293).
- **Mechanism:** A self-describing checklist can validate only what its author remembered to include. “Every stage has seven fields” cannot detect a missing stage, missing user, or missing nonfunctional requirement.
- **Month-three cost/failure:** Security, licensing, rollback, cost, or operator requirements surface only during adoption or incident response, when their omission is expensive.
- **Who it serves:** Product owners and fresh graders; it is the direct defense against false completeness.

### C13 — No unit economics or operator-time budget

- **REFUSES:** Refuse to run or market a mode whose measured operator minutes, agent/token cost, and blocked-tick cost exceed the manual baseline; refuse a value claim without customer outcome baseline and target.
- **Evidence:** Q3 asks for customer outcome/baseline/target and Q4 asks time/headcount; both are open, while K2 says verification-cost instrumentation is unowned (docs/plan/00-brief.md:802-823). The system produced 162 consecutive DISPATCH_RETRY_BLOCKED ticks over 4.2 hours (docs/plan/09-milestones.md:157-169).
- **Mechanism:** The plan measures correctness events but not saved labor, wait time, token/compute spend, or cost per useful close. A technically correct loop can be economically dominated by one human terminal.
- **Month-three cost/failure:** The operator tends refusals for hours; a solo maintainer abandons it because the supervisor consumes more attention than it saves; fleet spend grows without throughput.
- **Who it serves:** The owner/investor, Persona A’s adoption decision, and Persona C’s capacity planning.

### C14 — No adoption funnel or retention signal

- **REFUSES:** Refuse to call the product adopted based on install or a green internal run; require measured install → doctor → first useful tick → first verified close → repeat use, with drop-off reasons.
- **Evidence:** End-user adoption is PROJECTED end to end and no adopter outside this machine has run anything (docs/plan/08-end-users.md:6-10, 46-47). The plan itself says the A→B→C order is a product judgement with no external evidence (docs/plan/08-end-users.md:27-47).
- **Mechanism:** Technical milestones M1–M7 do not measure whether a human can discover, trust, and repeat the workflow. Without activation/retention events, a one-off demo is indistinguishable from a product.
- **Month-three cost/failure:** The team optimizes deep fleet machinery while every new user drops at first setup; month-three usage is zero despite a successful internal demo.
- **Who it serves:** Product decision-makers and adopters; it tells us whether to narrow to A/B instead of building C.

### C15 — Persona sequencing contradicts what is already usable

- **REFUSES:** Refuse fleet-only defaults for a solo or small-team repository; refuse to require ntm/tmux/br when the selected worker/tracker adapter is not needed, and expose a one-shot path with equivalent evidence.
- **Evidence:** Persona A needs gates/completion with one agent and no panes; Persona B wants receipts; Persona C is explicitly last to serve, while 157/183 capabilities are unused (docs/plan/08-end-users.md:27-47). The plan says the build order was the inverse of the proposed adoption order.
- **Mechanism:** The architecture starts from the conductor’s fleet topology instead of the smallest valuable workflow. Complexity and missing dependencies become a hard gate for users who do not need them.
- **Month-three cost/failure:** The easiest users—who could validate value fastest—never activate; engineering keeps adding fleet plumbing without a proving customer.
- **Who it serves:** Solo maintainers and small teams, the likely first adopters, and the owner deciding scope.

### C16 — Upstream version/schema drift has no compatibility policy

- **REFUSES:** Refuse startup or downgrade capability when the pinned OMP/ntm/br/bv schema, event discriminants, or slash-command surface is unknown; never silently parse an older/newer shape as the current contract.
- **Evidence:** Q6 says OMP is pinned at 18.0.11 with no compatibility policy and 136 slash commands are already unmapped (docs/plan/00-brief.md:804-806). The header reports 591 surfaces with 9 honestly unknown despite 32 consumed/67 wire (docs/PLAN.md:24-27).
- **Mechanism:** Reusing an upstream plane creates a moving compatibility boundary. Without a version/capability handshake and fixture matrix, a harmless upstream release changes event or CLI semantics under a green local build.
- **Month-three cost/failure:** An upstream upgrade makes selection, completion, or refusal handling silently degrade; every repo gets a different unsupported combination and the operator becomes the compatibility layer.
- **Who it serves:** Maintainers and external adopters who upgrade independently; it makes reuse cheaper than forks.

### C17 — Gate scope and exception ownership are incomplete

- **REFUSES:** Refuse to claim a gate covers the repository until hooks, generated files, untracked policy surfaces, and explicit allowances are inventoried with owner and expiry; reject silent exceptions.
- **Evidence:** The one hard no-.sh/no-.py rule scans tracked files, while the 6.3 KB build-grading shell hook lives in .git/hooks and is invisible; Q13 is open (docs/plan/11-lifecycle.md:99-127).
- **Mechanism:** A policy can be correct over its stated set and still miss the artifact that controls behavior. If exceptions have no owner/expiry, bypass becomes permanent folklore.
- **Month-three cost/failure:** A local hook or CI path bypasses the gate after the first environment change; later auditors assume “the rule” covered it and discover the gap only after a bad commit.
- **Who it serves:** Security reviewers, maintainers, and adopters installing the tool where hooks are different.

### C18 — Refusal storms lack an operational SLO and escalation loop

- **REFUSES:** Refuse to retry a refusal class past its threshold without changing state or escalating with owner/evidence; distinguish progress, blocked, idle, and dead rather than emitting heartbeats.
- **Evidence:** 162 refused ticks persisted for 4.2 hours (docs/plan/09-milestones.md:157-169); M7’s target requires no refusal class to recur beyond FINDING_THRESHOLD==3 (docs/plan/09-milestones.md:206-211). The lifecycle records one dispatch fence up 4.2h and reap hand-run (docs/plan/11-lifecycle.md:17-29).
- **Mechanism:** A named refusal is not resolution. Without a recurrence budget and a state transition, the loop can be technically honest while burning time in a no-progress cycle.
- **Month-three cost/failure:** The operator mistakes activity for progress, queue starvation grows, and the fleet is abandoned after a long “healthy” run that did no work.
- **Who it serves:** Unattended fleet operators and anyone paying for agent turns or compute.

### C19 — Completion adoption can bypass quality and validation

- **REFUSES:** Refuse to close a bead from AgentEndEvent, a worker Finished claim, or transport delivery alone; require independent work grading and the validation/ship evidence promised by later stages.
- **Evidence:** M4 explicitly excludes whether work is good and warns that worker Finished is a claim; the crate has a mutation test but zero callers outside its own file and zero dependents (docs/plan/09-milestones.md:129-148). The lifecycle’s L3 is wire-proven but L4 grading is blocked upstream and L5 reap is hand-run (docs/plan/11-lifecycle.md:161-166).
- **Mechanism:** Completion means “the worker stopped,” not “the bead’s acceptance is true.” Adopting the event as the close trigger can turn faster detection into faster wrongness.
- **Month-three cost/failure:** The loop closes incomplete or unvalidated work, so the board looks healthy while users receive broken artifacts; later verification must reopen state with no clear owner.
- **Who it serves:** All users who trust automated closes; especially projects where quality gates and ship actions have real cost.

### C20 — Repo/session/claim namespace isolation is underspecified

- **REFUSES:** Refuse a dispatch or close when repo root, session, worker, bead, and claim namespace are ambiguous or cross-repo; never let a receipt from one repo settle another repo’s work.
- **Evidence:** The current CLI flags encode the home fleet (--session NAME, --receiver-agent NAME), while the end-user section says a stranger cannot supply them correctly; Persona C spans many repos and dozens of panes (docs/plan/08-end-users.md:19-21, 42-44). The upstream Stage1Claim/GlobalClaim vocabulary is explicitly memory-claim domain, not bead custody (docs/plan/11-lifecycle.md:86-90).
- **Mechanism:** A worker/session identifier alone is not a repo-scoped claim. Multi-repo fan-out needs a namespace and root identity on every durable event.
- **Month-three cost/failure:** A shared ntm session or recycled pane writes a close/receipt into the wrong repo; recovery appears successful while another project’s board is corrupted.
- **Who it serves:** Multi-repo operators and any shared workstation/CI environment.

## Winnowed top six

Selection criteria: month-three likelihood, blast radius, leverage from existing planes, and whether omission invalidates the product thesis rather than merely adding polish. C1/C2/C3/C4/C20 are related, but the top six keep the aggregate 1:many contract and durable policy/replay boundary explicit rather than hiding them in a generic “reliability” stage.

### T1 — Fan-out accounting and partial-failure semantics (C1 + C2)

This is the first structural gap the mission itself names. A 1:many product is not a 1:1 loop run N times: it needs expected-target accounting, child attempts, aggregate verdicts, and a policy for partial success. The current wire proof is one AgentEndEvent frame; the current receipt families are DECLARED ONLY, and measured transport already produced success:[4] with no packet. That is exactly the combination that creates a false aggregate success.

**Proposed refusal boundary:**

- REFUSE fan-out with no durable expected-target set and repo/session namespace.
- REFUSE aggregate COMPLETE if any required child has no delivery receipt plus terminal/continuation result.
- REFUSE retry without a new attempt ID and dedupe key.
- Emit PARTIAL/DEGRADED with child-level evidence; never hide the failed child behind an aggregate count.

**Consume before rebuilding:** prove and adopt ntm robot-send/receipt semantics, then test the declared IrcDeliveryReceipt and AsyncJobDeliverySink reachability. Use the already wire-proven AgentEndEvent/RpcSessionEventFrame for each worker rather than inventing a completion protocol. The plan must state what happens when a child is absent, continuing, rate-limited, killed, or reattached.

**Month-three scenario:** ten panes, two terminal events, one continuation, one transport false-positive, one recycled pane. Without this contract the operator sees “9/10 success” or “done” and discovers the missing work by inspecting panes. With it, the system can honestly stop at a typed partial verdict and route repair.

**Why it wins:** It is the only top item directly implied by the 1:many mission and it makes every other plane (receipts, claims, roster, cost, completion) require a common correlation key.

### T2 — Durable human-requirement, recovery, and replay ledger (C5 + C3 + C4)

S9 currently names the loss but not the mechanism: eleven decisions lived in scrollback, only three stages log, and compaction events are DECLARED ONLY. Month three is when sleep, crash, compaction, handoff, and rerun happen—not when the first happy path runs. The ledger must carry human decision records, event IDs, worker incarnation, attempt watermark, repo namespace, and owner/expiry, and it must be replayable without redoing effects.

**Proposed refusal boundary:**

- REFUSE any action whose current requirement is not durable, owner-resolved, and scope/version matched.
- REFUSE applying an event twice; REFUSE settling a recycled pane with an old event.
- REFUSE recovery when pending/applied effects cannot be distinguished.
- REFUSE to treat SessionBeforeCompactEvent/SessionCompactEvent as a working recovery signal until its wire path is proven; keep a visible local fallback with an honest verdict.

**Consume before rebuilding:** use br’s durable JSONL and existing close/comments surfaces as the project record where appropriate, adopt OMP’s Stage1Claim/GlobalClaim only for its declared memory domain unless bead custody is proven, and test AgentEndEvent/SessionStopEvent together on reconnect/crash cases. This is a join/index problem more than a new event protocol.

**Month-three scenario:** a human ratifies “do not publish/deploy,” the conductor compacts, restarts, and sees a late worker event. Without a durable, scoped decision and idempotent event ledger the worker can proceed under stale policy or close the wrong attempt. The failure is not a missing feature; it is irrecoverable ambiguity.

**Why it wins:** It operationalizes S9 and converts “durable/retrievable” from a sentence into a refusal-bearing state machine. It also makes restart safety testable without inventing a second transport.

### T3 — Cold-start bootstrap and adoption funnel (C6 + C7 + C14 + C15)

The intended user journey is still a design artifact. There is no doctor/init/adopt command, no foreign host run, and the installed binary carries compile-time and /Users/josh path assumptions. A month-three product has to survive a new repo and a new machine before fleet scale matters.

**Proposed refusal boundary:**

- REFUSE to label a missing optional dependency as FAIL; report ABSENT with a remediation command that exists.
- REFUSE dispatch until runtime repo root, tracker, worker, and gate capabilities have explicit adapter verdicts.
- REFUSE “adopted” or “portable” claims without install → first tick → first verified close on a clean host/foreign repo.
- REFUSE fleet-only defaults for Persona A/B; select a one-shot/solo path without requiring ntm/tmux.

**Consume before rebuilding:** copy the shape, not the prose, of br’s doctor mutation chokepoint; use ntm’s existing template dry-run; resolve repo root at runtime and use the canonical installers/binaries instead of compile-time workspace paths. The existing plan’s ABSENT/FAIL and ADDRESSABLE commitments are strong and should be made executable.

**Month-three scenario:** a maintainer installs from a clean machine into a repo with no .beads and no tmux. If the first output is an opaque missing-dependency failure, adoption ends; if it is an addressable doctor report, the user can choose a one-shot worker and get value before adding fleet machinery.

**Why it wins:** It is the only candidate that tests whether the project can leave this workstation. It also supplies the product’s first real activation/retention measurements and forces the architecture to serve the smallest valuable persona.

### T4 — Upstream capability registry, reuse gate, and drift policy (C8 + C9 + C16)

The plan correctly discovered that the central task is attaching to planes that already exist, but it has no consumption gate. bv is zero-invoked, ntm’s dispatch template is unused, completion is the only wire-proven type, and six families are declaration-only. A three-month build will otherwise recreate local approximations and drift from upstream.

**Proposed refusal boundary:**

- REFUSE custom selection/dispatch when the sanctioned bv/ntm surface exists and its capability probe has not run.
- REFUSE to upgrade DECLARED ONLY to AVAILABLE until a real wire/reachability probe in this process passes.
- REFUSE startup or downgrade the affected capability when upstream versions/schema discriminants are unknown; never silently parse drift.
- REFUSE to claim “upstream reuse” from a type name or grep hit alone.

**Consume before rebuilding:** invoke bv --robot-triage through its canonical path; use ntm template + fail-closed variable substitution; adopt AgentEndEvent via RpcSessionEventFrame; stage probes for IrcDeliveryReceipt, Stage1Claim, GuestIdleReconcilerCtx, HubRosterCounts, SearchUsage/PerplexityCost/ContextUsage, and compaction events with DECLARED ONLY status until each crosses a wire. Add a compatibility matrix keyed by the pinned OMP/ntm/br/bv versions; Q6 already records OMP 18.0.11 and 136 unmapped slash commands.

**Month-three scenario:** an upstream upgrade changes a CLI or RPC discriminant. Without a capability handshake and fixture matrix the local build remains green while selection falls back to recency, completion waits on a dead event, or cost reports zero. With the registry, the system refuses only the affected capability and points to the evidence gap.

**Why it wins:** It prevents both wasteful rebuilding and unsafe type-theater. It is the highest leverage response to the plan’s own corrected thesis.

### T5 — Independent, fresh-project grading with anti-vacuity and omission coverage (C10 + C11 + C12)

The plan has strong language about observable done, but its evidence is still mostly self-generated. Ten local refutations demonstrate that re-derivation helps; they do not estimate what remains unseen. The 183-row evidence table had one distinct must_be_true value, and prose omissions are invisible unless an external expected_* inventory catches them. M5/M6 are projected targets and M6 has never run.

**Proposed refusal boundary:**

- REFUSE plan/work/ship completion from same-session self-report or same fixture family alone.
- REFUSE a gate whose known-bad pre-state passes, whose mutation does not fail, or whose fixture bypasses the production seam.
- REFUSE completeness claims without an external requirements/schema inventory and explicit missing rows.
- REFUSE “portable” or “adopted” until a fresh process on a clean host/foreign repo produces the actual transcript.

**Consume before rebuilding:** use the existing M1–M7 observable shape and the anti-vacuity four-leg rule; make M5’s ten-close trace and M6’s cold-host transcript real, not projected. Have a fresh grader/process consume the same artifact without the author’s hidden context. Reuse upstream conformance/robot surfaces as external oracles where available; do not treat internal test counts as evidence of consumption.

**Month-three scenario:** the team reports 100% gates after adding tests that all pass against the same test-only constructor. A fresh repo exposes the parser seam or missing installation path. The cost of discovering this at month three is architecture rework; discovering it at M1/M6 is cheap.

**Why it wins:** It attacks the plan’s central false-completeness risk, including omissions that ordinary graders cannot see. It is the highest-value quality gate before product claims.

### T6 — Economics and refusal-storm operating SLO (C13 + C18)

The plan records correctness and refusal reasons but not whether the supervisor is economically worth operating. 162 refused ticks over 4.2 hours is already a measured warning. K2 says verification cost is uninstrumented; K5 asks whether tending exceeds work; Q3 leaves customer outcome unowned. A month-three loop must have a budget, not only a verdict.

**Proposed refusal boundary:**

- REFUSE to continue a refusal class beyond its recurrence threshold without state change, owner, or an explicit human override.
- REFUSE to claim value without baseline/target and measured useful closes, not ticks or commits.
- REFUSE a mode when operator minutes + agent/compute cost exceed the manual baseline for that persona.
- REFUSE heartbeat-only “progress”; each tick must account for progress, blocked state, or escalation.

**Consume before rebuilding:** use M7’s FINDING_THRESHOLD==3 and existing DISPATCH_RETRY_BLOCKED verdict as the first SLO substrate; instrument the declared SearchUsage, PerplexityCost, and ContextUsage only after reachability is proven, rather than inventing local token estimates. Record time-to-first-useful-close, operator-touch minutes, blocked-tick minutes, useful-close rate, and cost per verified close by persona.

**Month-three scenario:** the fleet spends another four hours reattempting a blocked fence. The system can be technically honest yet economically negative. A recurrence/refusal budget escalates at three and lets the owner choose repair, stand-down, or manual fallback before compute and attention are wasted.

**Why it wins:** It answers whether there is a product to ship. It protects the solo path from fleet overhead and gives the multi-repo operator a measurable reason to keep the daemon running.

## Bottom line

The plan is strongest where it says “refuse what cannot be proved,” but month three will expose that proof must be scoped to a run, repo, worker incarnation, attempt, upstream version, and human decision. The missing product is not another lifecycle stage. It is a refusal-bearing control plane that (1) accounts for 1:many partial outcomes, (2) persists and replays human policy and effects, (3) boots on a foreign repo/machine, (4) consumes existing ntm/bv/br/OMP planes without type-theater, (5) is graded by a fresh independent run, and (6) proves it saves more operator time and spend than it costs.
# AgentEndEvent frame capture

Host/scope: `hostname` returned `Joshs-Mac-Studio.local`. The probe used an ephemeral OMP process with `--no-session --no-tools --no-lsp`; it did not attach to or mutate an existing session.

## Launch and driving command

```text
/Users/josh/.local/bin/omp --mode=rpc --no-session --no-tools --no-lsp --max-time=30
```

The RPC stdin frame sent was:

```json
{"type":"prompt","message":"Reply with exactly AGENT_END_PROBE_OK and nothing else."}
```

The capture harness recorded stdout/stderr to:

- Full raw stream: `/tmp/grade/agent-end-frames.ndjson` — 650,747 bytes.
- Exact raw `agent_end` frame: `/tmp/grade/agent-end-raw-frame.json` — 4,772 bytes.
- Raw-frame SHA-256: `d8bd80c6949b2ec48af1639b5b5e241bd90b4dce1e769483dd1690ed2be8f644`.
- stderr: `/tmp/grade/agent-end-stderr.txt` — 0 bytes.

The harness observed `sawAgentEnd=true`. It terminated the ephemeral process after capture because the process remained open after the terminal event; harness exit was `143` from that cleanup, not an OMP frame verdict.

## Wire result

**YES — `AgentEndEvent` crosses the `--mode=rpc` frame plane.** The stream contained exactly one `{"type":"agent_end",...}` frame.

Relevant frame order:

```text
{"type":"ready",...}
{"type":"extension_ui_request",...}
{"type":"available_commands_update",...}
{"type":"response","command":"prompt","success":true}
{"type":"agent_start"}
{"type":"turn_start"}
{"type":"message_start",...}
{"type":"message_update",...}
{"type":"message_end",...}
{"type":"turn_end",...}
{"type":"extension_ui_request",...}
{"type":"agent_end",...}
```

The exact raw terminal frame is preserved in `/tmp/grade/agent-end-raw-frame.json`; its parsed top-level shape is:

```json
{
  "type": "agent_end",
  "messages": [
    {"role": "user", "content": [{"type": "text", "text": "Reply with exactly AGENT_END_PROBE_OK and nothing else."}]},
    {"role": "assistant", "content": [{"type": "text", "text": "AGENT_END_PROBE_OK"}]}
  ],
  "isTerminal": true
}
```

Parsed facts from the raw frame:

```text
top_keys       = ['isTerminal', 'messages', 'type']
messages       = 2
isTerminal     = True
willContinue   = absent
last_role      = assistant
assistant_text = AGENT_END_PROBE_OK
```

The installed declaration at `dist/types/extensibility/shared-events.d.ts:153-163` defines the same event as `type: "agent_end"`, with `messages` and optional `willContinue`. The live frame uses `isTerminal: true`; it omitted `willContinue`, which is consistent with the declaration’s optional field.

## Architecture decision

The completion signal is not precedent-free and does not require a new bridge merely to cross the RPC plane. OMP emits `agent_end` directly over `--mode=rpc`, and the probe carried `isTerminal: true`, distinguishing this terminal settle from a continuation-capable event at the wire level.

The remaining integration question is narrower: the repository’s typed RPC adapter currently recognizes a fixed request/response sequence, while the live OMP stream emits asynchronous event frames. The completion work should therefore be an adapter/event-consumption change, not a new worker-completion protocol invented from scratch.

# Round 12 fresh report — 11-lifecycle

{
  "investor_grade": "C / RED — the section is unusually candid about missing lifecycle wiring, but several headline measurements still ask the reader to trust un-reproducible or semantically inconsistent evidence.",
  "findings": [
    {
      "severity": "MAJOR",
      "location": "docs/plan/11-lifecycle.md:94,100-106",
      "construct": "The five-property matrix marks S5 dispatch as `Y`, and counts it among four observed `Y` cells, while the same text says the path was not runtime-verified.",
      "why_real": "The section defines `Y` as a mechanism that exists and was used in the measured session, but the cited evidence only establishes a designed/source-level path; the explicit runtime-proof caveat makes the `Y` count internally inconsistent and inflates apparent lifecycle coverage.",
      "fix": "Change S5 dispatch to a clearly source/static or `y` status (or add a captured runtime artifact), then recompute the four-cell total under one unambiguous `Y` definition."
    },
    {
      "severity": "MAJOR",
      "location": "docs/plan/11-lifecycle.md:263-276,293-300",
      "construct": "The derivation claims to include rows whose `batch` is an integer 1–9, but the jq filter only checks `.batch >= 1 and .batch <= 9`.",
      "why_real": "That predicate does not enforce integer type; non-integer numeric batches can pass, and mixed-type behavior is not controlled. Therefore the claimed 270-row scoped universe and all disposition counts are not derived by the stated policy.",
      "fix": "Use an explicit numeric-integer predicate (type check plus floor/equality), report excluded-type/non-integer rows, and rerun both count commands from the same frozen input."
    },
    {
      "severity": "MAJOR",
      "location": "docs/plan/11-lifecycle.md:263-266",
      "construct": "The headline says `270 mapped rows out of the 544-row ... surface universe`, but the shown derivation only emits the filtered `rows` count and disposition groups.",
      "why_real": "Nothing in the supplied command derives or prints 544, so the denominator is not reproducible from the evidence in this section; the reader must trust an unstated upstream count/snapshot.",
      "fix": "Add the exact command and output deriving the 544 total from a named immutable snapshot (including its hash), or relabel 544 as a declared external denominator."
    },
    {
      "severity": "MINOR",
      "location": "docs/plan/11-lifecycle.md:52",
      "construct": "The current-state table asserts `installer covers 3 of 18 binaries` without an inventory, counting rule, command, or source artifact.",
      "why_real": "This is a load-bearing ship-surface number, yet the section provides no exact derivation and labels unmarked claims `MEASURED`; an investor cannot tell whether 18 means workspace crates, installable targets, or something else.",
      "fix": "Name the binary universe and provide the exact inventory/count command and output, or mark the ratio `DECLARED` until that evidence exists."
    },
    {
      "severity": "MINOR",
      "location": "docs/plan/11-lifecycle.md:331-332",
      "construct": "The section reports `12 operational rows, 18 skill references, and 16 unique skill names` from `jsm search` without preserving the raw result or showing a counting derivation.",
      "why_real": "The numbers are used to justify the skill-facet scope, but no reproducible input, query, deduplication rule, or output is present; `MEASURED` is asserted only by attribution to R10.",
      "fix": "Include the exact `jsm search` query/output and deterministic row/reference/name counting rule, or label these counts as an R10 declaration rather than measured evidence."
    },
    {
      "severity": "MINOR",
      "location": "docs/plan/11-lifecycle.md:424-425",
      "construct": "The claim that the session produced `eleven human decisions in pane scrollback` has no pane/session artifact, selector, or counting procedure.",
      "why_real": "This number is the evidence for decision loss, but the cited scrollback is not addressable or reproducible; it asks the investor to accept an anecdotal count while the section otherwise emphasizes durable evidence.",
      "fix": "Provide the captured scrollback artifact plus an exact decision-record extraction/count command, or downgrade the statement to an unquantified observation."
    },
    {
      "severity": "MINOR",
      "location": "docs/plan/11-lifecycle.md:76-77",
      "construct": "`Every arrow and every stage must emit a decision record for S9` is an unmarked normative requirement despite the file-wide default that unmarked claims are `MEASURED`.",
      "why_real": "The table immediately says S9 has no proven consumer, so this sentence cannot be read as current capability; without a `PROJECTED`/requirement boundary it blurs target contract and measured state.",
      "fix": "Prefix the sentence with `PROJECTED REQUIREMENT` and state that no current emitter/consumer was measured."
    },
    {
      "severity": "MINOR",
      "location": "docs/plan/11-lifecycle.md:434-441",
      "construct": "The cardinality table is headed as `observed cardinality / behavior`, but rows such as `one configured supervisor process` and `exactly one ... child` are presented without runtime observation artifacts.",
      "why_real": "The section correctly says runtime proof is absent elsewhere, yet this table's wording makes source/configuration facts look like live cardinality measurements; that matters because the one-to-many refusal is a safety contract.",
      "fix": "Rename the column to `source-derived/static behavior` for these rows and reserve `observed` for a captured multi-session/candidate runtime probe."
    }
  ],
  "overall": "Strong problem framing and honest NO-CLAIM boundaries make the section valuable, but the evidence map is not investor/audit-grade until the Y semantics, snapshot derivations, and unsupported load-bearing counts are corrected."
}

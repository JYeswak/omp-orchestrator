
ABSENCE / MAJOR 1 — The claimed SOTA comparison omits two wrapped binaries.
The wrapped-binary inventory lists nine binaries at lines 86–96: `omp`, `ntm`, `br`, `bv`, `git`, `cargo`, `fh`, `jsm`, and `tmux`. Section 1.4 says at lines 194–197 that it will name a property “for each wrapped binary,” but the SOTA table at lines 199–207 has only seven rows and contains neither `ntm` nor `cargo`. `ntm` is the pane-truth substrate described at lines 105–109, and `cargo` is explicitly called an unmeasured supply-chain surface at lines 132–138, so these are not irrelevant omissions.

FIX: Add explicit SOTA properties and obligations for `ntm` and `cargo`, or change the scope claim to say which seven binaries are actually covered and why the other two are excluded.

INVESTOR / BLOCKER 1 — The idea still has no buyer or economic case.
The section declares that it serves “investor-attackable” R3 at lines 3–5, but its one-sentence thesis at lines 9–16 describes a typed supervisor and an “accountant” for running agents without naming who buys the accounting. Lines 20–73 describe one internal repository reap and its operational failures; lines 285–373 present the “honest position” and objections, but still do not identify a payer, budget, purchase trigger, current paid alternative, or economic outcome. Re-derived absence: `grep -En '\b(customer|buyer|payer|revenue|pricing|ROI|willingness|paying|paid|competitor|sales|purchase)\b' docs/plan/01-idea.md` → no matches. This search space could contain the answer because lines 3–5 explicitly claim investor scope and lines 20–73 and 285–373 are the section’s problem, thesis, and investor-objection surfaces.

FIX: Add a named beachhead buyer, budget owner, current substitute, price or budget range, quantified pain, and evidence that the buyer will pay for the stated outcome.

ADVERSARIAL / MAJOR 2 — The category claim “what does not exist” is asserted, not established.
Lines 15–16 say “There is no shortage of software that starts agents; what does not exist is an accountant for the ones already running.” The section never defines “accountant,” sets the boundary of the category, names competing products or internal alternatives, or shows a search that could support a universal absence claim. This is the load-bearing assumption behind the entire idea: that accountability across tools is an unoccupied category rather than an unmet feature, an existing product category, or a buyer-specific integration problem.

FIX: Define the category and the exact unmet job, then compare the proposed product against named incumbent, open-source, and in-house alternatives with evidence of the remaining gap.

EVIDENCE / MINOR 1 — The board total is still arithmetically false.
The measured reap at lines 40–41 says “28 closed, 25 in_progress, 19 open, 2 blocked (75 total).” Re-derivation with `printf 'board_total=%s\n' $((28+25+19+2))` returns `board_total=74`. This section uses the number as evidence for unresolved state, so the incorrect total weakens the very measurement discipline it claims to demonstrate.

FIX: Correct 75 to 74 and derive the displayed total from the four component counts instead of typing it.

EVIDENCE CHECKS — re-derived in this pass:
- Lines 48–54 contain five control-loop rows; line 56’s “one of five” denominator is correct.
- Lines 86–96 list nine wrapped binaries.
- Lines 199–207 contain seven SOTA rows, leaving two of the nine wrapped binaries uncovered.
- Lines 331–335 discuss eight gates; the gate-row denominator is eight.
- The board components at lines 40–41 sum to 74, not 75.

EVIDENCE / MAJOR 2 — The section violates its own provenance contract on the numbers carrying the thesis.
Lines 3–5 promise that “every number carries its deriving command,” but the core reap numbers at lines 28–41 provide only “MEASURED — stand-down reap plus `00-brief.md` §3.7, §4” at lines 25–26. The six landed/zero-closed, seven unowned conditions, 162 refused ticks, 4.2 hours, 23-commit drift, and four board components have no exact deriving command or preserved output in this section. Those numbers are the evidence for the problem, so an investor must take the author’s measurement on trust rather than reproduce it.

FIX: Attach one exact command and immutable output artifact to each core metric, or label it as an unverified inherited observation and remove it from the thesis until reproduced.

ADVERSARIAL / MAJOR 3 — “This is not a prototype” does not follow from the evidence presented.
The conclusion at lines 287–295 calls the system “not a prototype” because it has 26 crates, 370 tests, a scanner, a dependency graph, and gates. The next paragraph immediately concedes at lines 297–302 that 25 of 26 crates consume zero OMP surface and that “the thing named `omp-orchestrator` does not yet speak to OMP.” Those facts support “substantial internal infrastructure exists,” not “a product exists” or “the proposed supervisory path works.”

FIX: Replace the product-status claim with a precise foundation-status claim and reserve “not a prototype” for a real user workflow that reaches OMP, dispatches work, verifies completion, and produces a customer-valued result.

ADVERSARIAL / MAJOR 4 — The scanner observation does not support the superiority claim attached to it.
Lines 209–215 say one observed `UNKNOWN` envelope with exit code 2 “matches `omp` on envelope and beats a boolean exit on refusal semantics.” The observation establishes a typed status and distinct exit code; it does not establish that callers branch correctly, that the behavior is reliable under failure, or that it is superior in a live workflow. The conclusion quietly imports an adoption and reliability assumption the section has not shown.

FIX: Narrow the claim to the observed contract, then separately demonstrate caller behavior and operational benefit before claiming it beats an alternative.

INVESTOR / MAJOR 2 — The section proves one incident, then expressly refuses to establish urgency or market size.
Lines 25–40 give one repository’s stand-down measurements; lines 71–73 state that they are not representative of another session, operator, or workload and establish occurrence rather than frequency. That is honest, but it leaves unanswered whether this is a recurring expensive problem, a rare local failure, or a problem large enough to support a business.

FIX: Add independent workload observations or customer discovery showing incidence, economic impact, and urgency across the intended beachhead segment.

ABSENCE / MAJOR 2 — There is no adoption or switching path for the proposed contract layer.
Lines 79–81 say the product sits over tools that “already exist,” while lines 83–96 identify a host-specific PATH and an `rch` cargo shim. The section never states who installs it, what permissions or operational change are required, how an existing fleet migrates, or why a buyer accepts another layer around its current tools.

FIX: Describe the first deployment path, integration owner, permissions, migration burden, time to first verified result, and the reason that burden is worth paying.

ABSENCE / MAJOR 3 — The section explicitly omits the resources needed to reach the proposed outcome.
Lines 370–373 say the section commits to “no schedule” and “no cost,” while also saying it serves R3 investor scope at lines 3–5. An investor cannot assess capital required, runway, delivery timing, or whether the plan can reach a paying deployment before resources run out.

FIX: Add a bounded build-and-pilot plan with people, months, cash cost, first deployable milestone, and a kill decision at each spend boundary.

ADVERSARIAL / MAJOR 5 — Section 1.5 repeats a retired gate conclusion that the section itself admits is semantically weak.
Lines 331–339 say two of eight gates have all four legs and present `no-shell-gate` as complete with mutation=2. Lines 351–356 simultaneously concede that the counts are `grep`-derived names rather than test semantics and that stricter re-derivation has not run. The sibling’s current Round-2 grade records the rebuilt authoritative table at `r2-adversarial.md:5`: only one gate qualifies under typed automated mutation, and `no-shell-gate` is an affordance, not an automated mutation leg. Section 01 therefore presents a retired, explicitly non-semantic count as an investor objection after the plan has corrected it elsewhere.

FIX: Consume one shared typed gate-status artifact in both sections and remove every hand-copied gate count from the investor objection.

CHALLENGE TO r2-adversarial

I challenge the sibling’s **Blocker 2**, “Round-1 actionable-row blocker remains unfixed” (`r2-adversarial.md:7`, construct: current `idle_panes`/`free_capacity` behavior). The finding underneath is important: the brief’s row may be historical, and a source search locating separate fields and filters is relevant evidence. The sibling’s conclusion is overstated, however. A `grep` over `crates/omp-orchestrator/src/lib.rs` proves that separate fields and predicates exist in source; it does not prove the live producer emits the intended state, the parser consumes it, or `NewlyIdle` reaches the actual dispatch decision. The sibling’s own proposed fix—remeasure the current producer/consumer path—is the missing proof, so “current blocker remains unfixed” should be downgraded to “current behavior is unverified until the path is exercised.”

I found no sibling not-found whose search space was too narrow to support its stated criticism. In particular, the Q7/Q8 count challenge (`r2-adversarial.md:11`) searches `00-brief.md`, which is sufficient to disprove Q8’s “once across all eleven sections” claim when that file alone contains two hits; and the Q1/Q3/Q4/Q5/Q6/Q8/Q9 challenge (`r2-adversarial.md:23`) correctly identifies that the relevant search space is the full set of section files. The distinction matters: a narrow command can refute a universal count, but cannot establish the complete count.

The sibling’s Major 4 (`r2-adversarial.md:17`) is directionally right that §8.4’s “commission”/“omission” taxonomy needs clarification, but it slightly overstates the contradiction: rows 6–7 are false *no-prior-art conclusions caused by missing search evidence*, while §8.4 is discussing missing requirements or prose. The defect is an unmarked category boundary, not necessarily proof that the rows are omissions of prose.

BLOCKERS: 1
MAJORS: 9
MINORS: 1

MEETING QUESTION THIS SECTION CANNOT ANSWER:
Who is the first buyer for this “accountant,” what do they pay to replace today’s workflow, and what measured outcome proves the spend was worth it?

The section’s own core statement is at lines 11–16, but the commercial-term search above is empty, the incidence disclaimer at lines 71–73 covers only one session, and the honest-position disclaimer at lines 370–373 excludes schedule and cost.

VERDICT: FAIL

THE ONE THING: The section is unusually honest about engineering failure, but it still asks an investor to fund an unvalidated category claim: no named buyer, no economic outcome, no market urgency, and several “measured” conclusions that remain copied, stale, or inferred.

# Round 11 fix report — 10-prior-art.md

No new grading was run. The Round-10 evidence was processed finding by finding by the assigned repair agent `repair-prior-art`; I verified the repaired section's key residues and diff locations afterward.

## Dispositions

| R10 finding | Verdict | Diff location and repair |
|---|---|---|
| P1 stale Gap 7 conclusion after retraction | **FIXED** | Intro `:5`; Gap 7 `:139-150`; summary/mapping `:193-209`; §11.4 `:256-258`. The corpus-wide “precedent-free” claim is retracted; only the scoped asupersync declaration result and separate OMP capture remain. |
| P2 incorrect OMP typed-mechanism names | **FIXED** | §11.2 `:234-244`. Exact `AgentEndEvent`, `SessionStopEventResult.continue`, `SessionBeforeCompactEvent`, `SessionCompactingEvent`, `SessionCompactEvent`, `AgentSessionEvent`, and `RpcSessionEventFrame` relationships are named; the absent `SessionStopEvent.settle` member is stated explicitly. |
| P3 declaration-to-runtime overclaim | **FIXED** | Intro `:5`; Gap 7 `:145-149`; §11.2–§11.3 `:234-254`. Completion is separated as WIRE-PROVEN; the six other mechanisms remain DECLARED ONLY; local adoption is PROJECTED with per-type NO-CLAIM boundaries. |
| P4 `IrcDeliveryReceipt` recipient-delivery overclaim | **FIXED** | Gap 1 `:55-57`; receipt row `:239`; §11.5 `:260-262`. The upstream shapes are limited to transport injection/callback semantics; `cp-z42vu` remains ADAPT pending recipient-level proof. |
| P5 unsupported Gap 7 corpus-wide absence | **FIXED** | Gap 7 `:143-150`; mirror row `:217`. The negative is scoped to `asupersync/src` and three named supervision files, with `8 + 6` arithmetic; corpus/runtime absence is disclaimed. |
| P6 Gap 8 first-pass provenance mismatch | **FIXED** | Gap 8 `:159-167`. Rust-only, asupersync, and Go searches are separated with distinct spaces; the asupersync hit is no longer attributed to the Rust first pass. |
| P7 missing source/reproducibility identity | **FIXED** | §10.1 `:213-220`; §11.1 `:226-232`; §11.4 `:256-258`. Mirror root, snapshot MANIFEST/sync-log hashes, full-commit-unavailable status, OMP package/version/root, declaration hashes, capture input, and content-addressed artifacts are recorded. |
| P8 missing local scoped NO-CLAIM boundaries | **FIXED** | Gap 1 `:55`; Gap 2 `:67-69`; Gap 3 `:81-83`; Gap 5 `:111`; Gap 6 `:130-133`; Gap 7 `:147-149`; Gap 8 `:159`; Gap 9 `:187-190`; §11.3 `:246-254`. Each negative/declaration-only result now carries search/source scope, observed result, and what remains unestablished. |
| P9 underived headline numbers | **FIXED in section; registry addition DEFERRED** | §0 `:29-43`; per-gap records; summary `:197-207`. The section now labels measured/projected arithmetic and gives derivation/input/result. The figure belongs in `NUMBERS.toml`, but that file is concurrently modified and currently contains duplicate `[figures.board_total]` tables at lines 59 and 75; editing it would sweep another agent's work. No registry edit was made. |
| P10 absent dispatchable runbook contract | **FIXED** | §12 `:270-286`. Trigger, Dispatch packet, Amazing, Adequate, Negative patterns, Skills/non-coverage, and Done signal now specify artifact/hash and refusal requirements. |
| P11 nine gaps versus seven OMP rows unmapped | **FIXED** | Intro `:5`; mapping `:193-209`; §11.2 `:234-244`. Seven OMP rows are explicitly adjacent mechanisms; only Gaps 1 and 7 map directly, and no row masquerades as a replacement for Gaps 2–6, 8, or 9. |
| P12 citation format not normalized | **FIXED** | All Gap records, summary `:197-205`, §10.1, §11.2. Citations now carry source/package-relative path, line, construct, source roots/manifests, or durable artifact references; opaque `%1408/%1414/%1413` identifiers are removed. |
| P13 unmeasured ranking/certainty language | **FIXED** | §0.1 `:41`; Gap 4 `:97`; Gap 6 `:131-135`; §11.6 `:266`. Unsupported superlatives were removed or marked PROJECTED; mux observations are measurements, not rankings. |

## Post-repair checks

- Current section length is 286 lines.
- Exact key-field search finds the new §12 contract.
- Opaque `%1408`, `%1414`, `%1413`, `SessionStopEvent.settle`, and the old “What has no precedent” heading are absent from the repaired section.
- The repaired section now contains 20 scoped `NO-CLAIM` markers and explicit `MEASURED`/`PROJECTED` boundaries.
- `NUMBERS.toml` was inspected but not edited because its concurrent uncommitted state contains duplicate tables; P9's section fix is complete and registry reconciliation is explicitly deferred for that concrete reason.

## Capability floor

No converged section (`03-crates`, `05-actions`, `06-gates`) was edited. This repair changes only `docs/plan/10-prior-art.md`; the number-registry conflict is an existing shared-worktree condition, not a claim that a converged section regressed.

## Result

13/13 Round-10 findings accounted for. 12 fixed outright; P9 fixed in the section with the registry addition deferred and documented.
###### BLOCKER — Overclaiming about mechanical enforceability vs. actual gate coverage
LINES: 1-3, 3.1 matrix
QUOTE: "A gate is a claim about the future: *this class of defect cannot land again.* The claim is worth exactly what the evidence behind it is worth" (intro); then Table 3.1 showing **Zero gates satisfy all six** properties
WHY: The preamble frames gates as making falsifiable claims, but the matrix immediately proves zero gates satisfy the six required properties. A gate that claims to enforce something mechanically while failing all six properties is making an unsupported claim. The narrative needs alignment: either gates cannot claim enforceability until all six properties are met, or the six-property bar is wrong.

###### BLOCKER — Internal count contradiction: "1 of 8" vs. "2 of 8" gates with all four legs
LINES: ~95-110
QUOTE: "`00-brief.md` §3.5 states '1 of 8 gates has all four legs' and '5 of 8 have no mutation leg.' Both contradict the table printed immediately above them... The corrected headline is **2 of 8**"
WHY: The document cites the brief's own table but reports conflicting counts from it. It then recomputes and says "2 of 8" and "4 of 8" are the correct counts. But the corrected headline is stated as a conclusion, not as a finding flagged for the brief to fix. Since this section SERVES the brief, the disagreement should be reported to the reader as a state-of-truth issue that affects all downstream gate coverage claims.

###### BLOCKER — Three denominators for one property (forbid unsafe)
LINES: §2.8, near line 280
QUOTE: "`00-brief.md` §3.7 records '16 of 22 forbid unsafe.' We measure 26 crate dirs, 20 of 26 manifests, 25 of 26 source roots, 26 of 26 by union."
WHY: The brief reports 16/22; the gates section measures 26/26 by union. Three live denominators (22, 26, and implicit per-mechanism counts) for one property means no single authoritative count exists. This directly violates the writing contract (rule 4) that gate counts must be unambiguous across sections.

###### MAJOR — Ninth framework claimed but only six properties required
LINES: Intro, section 3
QUOTE: "states the nine frameworks we apply" (intro); then section 3: "three fields: **ENFORCES**... **STILL PASSES**... **PROVENANCE**. The §4 meta-gate rejects a header containing..."
WHY: The intro advertises nine frameworks (2.1 through 2.9), but section 3 defines only six REQUIRED properties and lists them as 1-6. The discrepancy between "nine frameworks" and "six required properties" is not reconciled, leaving readers unclear which gates are admission blockers vs. nice-to-have frameworks.

###### MAJOR — Projected RED gate described as "best-covered" with false-positive risk
LINES: §2.8, beginning
QUOTE: "the best-covered gate in the repo, found while writing this section... Six crates fail the predicate with no allowance available"
WHY: The forbid_lint gate (leg 3 of 2.8) is called "best-covered" yet carries a PROJECTED RED where six crates fail the mechanical predicate while the invariant actually holds. A gate with high false-positive risk (routing-around behavior per §2.2) should not be advertised as "best-covered." The contradiction suggests the coverage matrix grades the wrong thing.

###### MAJOR — No-CLAIM for leg-table counting method, but claim persists
LINES: Paragraph starting "NO-CLAIM: the leg table counts files whose *name*"
QUOTE: "A file named `mutation.rs` that mutates nothing counts here as a mutation leg. §4 specifies the meta-gate that closes that hole; it does not exist today."
WHY: The NO-CLAIM admits the counting method is unreliable (name-matching, not actual mutation), but the counts (4 of 8 have no mutation leg, etc.) are used throughout §1 and §3 as if they reflect real properties. The fix exists only as a future §4 design, so all current counts are understated in rigor until §4 is implemented.

###### MAJOR — Section 2.8 analysis mixes measured property with single-predicate failure
LINES: §2.8 "Disagreement with the brief" section
QUOTE: "all six carry `#![forbid(unsafe_code)]` in every source root (harness `grep`, confirmed per crate) — the *invariant* holds while the *predicate* fails... neither single-mechanism predicate can see it."
WHY: The invariant (forbid unsafe is enforced by at least one of two mechanisms) holds for all 26 crates, but the gate predicates measure only single mechanisms. The section then recommends "a conformance predicate targets the *property*, not one declaration site" — this is the correct finding, but it indicts the existing design, not the brief's count. The gate is currently enforcing a weaker property than intended.

###### MINOR — Truncated or incomplete citations in prior-art sections
LINES: §2.4, §2.5, §2.6 (multiple locations)
QUOTE: Multiple citations end with "…" (e.g., "`src/messaging/jetstream_flow_control_audit.rs:6` explains it... and `scripts/run_jetstream_publish_backpressure_smoke.sh:181-186` gates on that exact string. This is strictly better...")
WHY: Several "What would Jeffrey do" sections cite external source lines but end abruptly with "…", leaving the sentence incomplete. This makes the recommendations harder to verify and suggests the section was drafted with placeholder endings.

###### MINOR — Frame-conditional gate-RED finding unclear
LINES: §2.8 "A PROJECTED RED BY INSPECTION" section
QUOTE: "PROJECTED-BY-INSPECTION, not observed: we did not run the test, so the RED is derived from reading the predicate and measuring its inputs."
WHY: The finding is that the gate would fail if run, based on static analysis of the predicate and measured inputs. But "projected" is weaker than "observed," and the reader should know this is a forward-looking defect prediction, not a measured failure. The distinction is clear but could be emphasized more sharply in the title.

###### MINOR — Redundant emphasis on tool harness defect
LINES: §1, multiple callouts
QUOTE: Multiple "MEASURED" sections note that shell `grep -r --include=` returns empty instead of failing; this is called "a gate violation" and "itself a gate violation"
WHY: The defect is real and important (anti-vacuity violation in the measurement harness itself), but it is described three times across §1. Once acknowledged and its implications stated (every grep-derived count needs re-derivation), the repetition becomes self-referential rather than additive.

SEARCH SPACE: Opened the full file 06-gates.md (367 lines declared; first ~300 delivered before truncation). Read § 1 (measured inventory) with count tables, disagreement analysis, and tooling warnings; § 2.1-2.9 (framework design specs with measured examples); § 3.1 (six-by-eight coverage matrix, addressability defect, Jeffrey precedent). Did NOT read § 5 or any conclusion beyond line 300 due to tool truncation. Searched for: internal count consistency across §1/§3; overclaiming in gate descriptions vs. matrix reality; coverage of all six properties; disclosure of NO-CLAIMS and STILL-PASSES per §2.9.

COUNTS: BLOCKER=3 MAJOR=4 MINOR=3

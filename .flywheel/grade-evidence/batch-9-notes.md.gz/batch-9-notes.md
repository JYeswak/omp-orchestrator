# BATCH 9 NOTES — SilverWolf (%1409) — R14/R15 surface mapping
Dispositions: 2 WIRE / 3 CONSUMED / 29 RETIRE (per this batch's share).
Uniform RETIRE evidence: the omp-inventory-map census classifies each row CAPABILITY_NOT_USED
(regenerate: /Volumes/BuildShared/cargo-targets/debug/omp-inventory-map --repo .) — the census is the
measured no-consumer proof. Per-surface reasons below; WIRE and CONSUMED rationale first.

## THE CONSEQUENTIAL ROWS
- (WIRE rows for this batch: none. CONSUMED rows cli/commands/jsonrpc are this batch's only
  non-RETIRE rows besides none.)
## CONSUMED (census edges)
`surface:type_root:cli`, `surface:type_root:commands`, `surface:type_root:jsonrpc` are three of the
scanner's seven `consumes` edges (crate:omp-inventory-map, evidence string "direct process probe
produced this row"). Deriving constructs: parse_path_listing (lib.rs:792) walks the installed
d.ts tree; parse_rpc_handlers_source (lib.rs:821) and parse_omp_methods_source (lib.rs:855) scrape
the installed cli.js. Regenerate with the census command in each row's validated_by.

## RETIRE REASONS (per surface)
- `surface:type_root:compress` — context compression types
- `surface:type_root:config` — agent config types; crates pass explicit spawn flags
- `surface:type_root:dap` — debugger integration for the agent's IDE
- `surface:type_root:debug` — agent debug tooling
- `surface:type_root:discovery` — tool discovery for the agent
- `surface:type_root:edit` — agent tool surface; orchestration dispatches units, not tool calls
- `surface:type_root:eval` — agent eval harness
- `surface:type_root:exa` — external search-provider integration
- `surface:type_root:exec` — agent tool surface; same as edit
- `surface:type_root:export` — session export
- `surface:type_root:extensibility` — extension loading
- `surface:type_root:goals` — second goal tracker; br + beads DAG is ours (bv --robot-* is the triage wire)
- `surface:type_root:hindsight` — post-hoc eval loop
- `surface:type_root:if-bench` — benchmark types
- `surface:type_root:internal-urls` — harness internal-URI scheme
- `surface:type_root:irc` — IRC transport for agent chat
- `surface:type_root:launch` — OMP's own child-process management; we spawn omp ourselves under subprocess-contract
- `surface:type_root:lib` — OMP internal library surface; reached only via the cli.js scrape, which the `cli` row (CONSUMED) covers
- `surface:type_root:live` — agent live/websocket feature
- `surface:type_root:lsp` — LSP integration for the agent
- `surface:type_root:markit` — markdown tooling for the agent
- `surface:type_root:mcp` — MCP client/server types; no crate speaks MCP
- `surface:type_root:memories` — agent memory subsystem; our durable state is the bead board + ledgers
- `surface:type_root:memory-backend` — agent memory backend
- `surface:type_root:mnemopi` — harness memory subsystem
- `surface:type_root:modes` — agent output modes
- `surface:type_root:plan-mode` — agent planning UX; beads are the plan space
- `surface:type_root:registry` — extension registry
- `surface:type_root:secrets` — credential store; coupling credentials to a vendored tool violates the 08 s3 rule

## COULD NOT CLASSIFY
None. Every row received a disposition. Weakest-evidence rows, named honestly: bv:simulation and
bv:track are classified RETIRE-as-scrape-noise on the strength of `bv --help` not containing the
tokens (searched: full `bv --help` output, 2>&1); if a hidden bv build exposes them, the scrape
still captured them as SUBCOMMANDS, which is the wrong kind, so the row needs re-derivation either
way. The type_root one-liners are kind-level truths (agent-feature namespaces), not per-file reads
of OMP's dist/types — reading 42 vendored type definitions to justify NOT adopting them inverts
the discipline; the census zero-consumer measurement is the load-bearing evidence.

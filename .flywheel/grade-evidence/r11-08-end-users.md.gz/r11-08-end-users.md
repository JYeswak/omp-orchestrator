# Round 11 — repair evidence — 08-end-users

Assigned section: `docs/plan/08-end-users.md`

## R10 findings

1. **Missing dispatchable runbook contract — RETRACTED (runbook-scope false positive).** This section is explicitly a `PROJECTED` adoption design artifact (`§2`, lines 51–55), not a dispatchable stage runbook. The r10 request to add Trigger / Dispatch packet / Amazing / Adequate / Negative patterns / Skills / Done-signal fields would change the document's purpose and duplicate the runbook owned by the relevant operational section. No runbook block was added.

2. **Doctor `ABSENT` remediation contradiction — FIXED.** Rewrote the invariant at `docs/plan/08-end-users.md:109-116` to scope remediation to capability-family probes. Family `ABSENT` rows must carry an existing-command remediation; specific implementation probes (`tracker.br`, `worker.tmux`) remain informational and must not invent an install command. This makes the sample and the prose agree.

3. **Unmeasured end-user value — FIXED.** Added the falsifiable internal/external pilot scorecard at `docs/plan/08-end-users.md:374-396`. It records measured or explicitly unavailable baselines and projected targets for install-to-first-doctor time, manual intervention, false-close prevention, human-seconds saved, clean-host onboarding, non-OMP adapter support, and refusal visibility. The text preserves the zero-external-adoption `NO-CLAIM` instead of presenting targets as results.

4. **Projected CLI outputs lacked a complete proof contract — FIXED.** Added the common versioned envelope, durable artifact/ledger paths, proving commands, and exit semantics at `docs/plan/08-end-users.md:210-242`. The contract covers `doctor`, `init`, `tick`, and `grade`; distinguishes domain `status` from process exit status; and requires proof verification to fail closed on missing or mismatched records.

5. **Prior-art count not reproducible — FIXED.** Replaced the vague `93+` claim with the exact `89` result and retained the command, scope, date, and source revision at `docs/plan/08-end-users.md:127-149`:

   ```sh
   cd /Users/josh/Developer/jeff-shadow
   /usr/bin/grep -rlE 'MISSING_DEPENDENCY|DependencyMissing|not_installed|NotInstalled' ntm beads_rust | wc -l
   # 89
   ```

   This is a no-extension-filter recursive search over both named trees, counting matching paths once. The same command/output is retained in the section and this evidence file. `NUMBERS.toml` was inspected: it has no entry for this prior-art count, so this remains document-local evidence; `NUMBERS.toml` was not edited.

## Verification record

No cargo commands, gates, formatters, or tests were run, per assignment. Scoped evidence checks confirmed the repaired locations and the exact prior-art command returned `89` from `/Users/josh/Developer/jeff-shadow` at `7c28478`.

new_findings: 0
role: repair

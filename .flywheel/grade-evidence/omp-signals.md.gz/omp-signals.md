# OMP signal-type sweep — dist/types/ whole tree — Pane %1408 — Wave 7
Instrument: export-symbol sweep over all `.d.ts` for
`(Event|Receipt|Ack|Claim|Lock|Capacity|Idle|Roster|Pane|Budget|Cost|Usage|End|Finish|Complete|Settle|Deliver)`-suffixed
types (≈130 distinct hits), then field-level reads of the nine highest-value symbols.
Root: /Users/josh/.local/lib/node_modules/@oh-my-pi/pi-coding-agent/dist/types (read-only).

## HEADLINE — the events plane has a declared RPC frame type
`modes/rpc/rpc-types.d.ts`:
    export type RpcSessionEventFrame = AgentSessionEvent | RpcSubagentFrame;
    export type RpcSubagentFrame = RpcSubagentLifecycleFrame | RpcSubagentProgressFrame | RpcSubagentEventFrame;
The --mode=rpc wire has a DEDICATED event-frame type carrying `AgentSessionEvent`. The
shared events (AgentStartEvent/AgentEndEvent/TurnStartEvent, extensibility/shared-events.d.ts)
are the agent-session event family. Inference (declared, not yet wire-captured): pane 3's
frame capture should expect events as RpcSessionEventFrame. Re-verified AgentEndEvent at
extensibility/shared-events.d.ts:154: `type:"agent_end"; messages: AgentMessage[];
willContinue?: boolean` — "Subscribers must not treat this as a user-visible terminal settle."

## THE GAP→TYPE MAP (every open gap the plan names, with its sibling types)

### 1. S6→S7 completion — ADOPTION CANDIDATE, pending pane-3 capture
- AgentEndEvent { type:"agent_end", willContinue? } — terminal-vs-continuation distinction,
  verbatim the NewlyIdle/ConfirmedIdle distinction idle_panes gets wrong.
- SessionStopEvent { type:"session_stop", turn_id, session_id, stop_hook_active } —
  "fired when a main-agent turn is about to settle; handlers may request one continuation
  turn": the settle event, with continuation-request built in.
- RpcSessionEventFrame (above) — the declared delivery channel.
- MarkRunCompletedParams (autoresearch/storage.d.ts) — run-completion marking vocabulary.
If pane-3's capture shows agent_end on the wire, the completion crate is unnecessary and
M4's bridge milestone collapses to an adapter frame-kind.

### 2. Dispatch receipts — DESIGN-CHOICE evidence
- IrcDeliveryReceipt (tools/hub/types.d.ts:8 construct, re-confirmed).
- AsyncJobDeliverySink / AsyncJobDeliveryState (extensibility/async.d.ts) — delivery-state
  vocabulary for background jobs.
Two independent receipt vocabularies exist in the substrate; our pane transport (tmux
send-keys) has none. The gap is architectural choice, not feasibility.

### 3. Claim/lock vocabulary — SCHEMA TO COPY (Rust-side adoption)
- Stage1Claim { threadId, ownershipToken, inputWatermark, sourceUpdatedAt, rolloutPath, cwd }
  and GlobalClaim { ownershipToken, inputWatermark } (memories/storage.d.ts).
This is the exact shape the unclaimed-bead defect needed: an ownership TOKEN plus an input
WATERMARK, claimed before work starts. Our dispatch-claim-fence already models permit/
snapshot; the omp claim adds the token+watermark pair. Adoption = schema alignment in Rust,
no TS import involved.

### 4. Capacity / idle semantics — the distinction exists upstream
- GuestIdleReconcilerCtx (collab/guest.d.ts) — "IdleReconciler" is a named concept: omp
  reconciles guest idleness rather than deriving it from one filter.
- SessionStopEvent-vs-willContinue (gap 1) is the settle/continuation split.
Our idle_panes filter conflates newly-idle with confirmed-idle; the substrate types model
the two states separately. idle_panes should mirror the pair, not one predicate.

### 5. Roster — typed tallies exist
- HubRosterCounts { running, idle, parked, shown, truncated } — "Addressable roster tallies
  always returned by op:list" (tools/hub/types.d.ts).
- IrcPeerRosterRow / IrcPeerRosterData (task/executor.d.ts), RosterRender.
tick-monitor's pane census could adopt the five-tally schema so fleet truth and substrate
truth share a vocabulary.

### 6. Cost telemetry — answers open question Q2's measurability half
- PerplexityCost, PerplexityUsageInfo, SearchUsage, ResetUsageAccount, ParallelUsageItem,
  GoalTokenUsage, ContextUsage / ContextUsageBreakdown / ContextUsageLevel, BenchCacheUsage,
  CodexResetUsageSnapshot.
Per-call and per-goal cost/usage types exist as declared surface. Q2 ("what does the current
workaround cost") is measurable from these if any consumer taps them; today nothing does.

### 7. Compaction transparency — the compaction-loss failure has typed pre/post events
- SessionBeforeCompactEvent, SessionCompactingEvent, SessionCompactEvent
  (extensibility/shared-events.d.ts). A worker about to compact can be captured/dumped
  BEFORE the loss (the %1413 grade-loss, the addendum's write-as-you-go rule) — an event
  hook exists at exactly that boundary.

## METHOD + COVERAGE NOTES
- Sweep command: grep -rhoE 'export (declare )?(interface|type|enum) …' over dist/types with
  the semantic suffix list; ~130 unique symbols; the ones NOT shown above are tool-call
  echoes (Bash/Grep/Glob/Edit/Read ToolCall/ResultEvent), DAP debugger events, UI/theme
  events — no gap mapping.
- Not-found statement: I did not find a generic `DeliveryReceipt` outside the IRC/AsyncJob
  families. Command: the sweep above covers every *Receipt* export in the tree (2 families);
  search space could contain one because receipts are this plan's named gap — so the honest
  statement is "receipts exist only on the IRC-bus and AsyncJob planes".
- All file paths cited are under dist/types/; AgentEndEvent and IrcDeliveryReceipt
  re-verified by direct read this session (shared-events.d.ts:154; tools/hub/types.d.ts:8
  construct).

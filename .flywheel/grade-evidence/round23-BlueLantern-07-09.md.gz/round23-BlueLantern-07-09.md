# Round 23 fresh-eyes evidence — BlueLantern sections 07-09
commit=f776eb819c2fde81f82ab64520efc34632a854d3
metadata_packages=51
metadata_binary_targets=49
## section 07 current anchors
    19	### 1. The measured starting point
    20	**CURRENT WORKTREE AUTHORITY (re-derived during this integration).** The exact cargo metadata target filter returns **48** binary targets in the shared worktree. Revision, command output, and install receipt must be captured together for a release claim; the historical hashes below do not serve as current acceptance evidence.
    21	
    22	**HISTORICAL MEASURED BASELINE — 21 binary targets at `fb89714`; superseded plan snapshot = 23.** The installer knows about 3 of them. The target declaration count is not itself a successful artifact count; the artifact proof is the command and receipt described below.
    23	
    24	The number was `18` until round 10, taken from `grep -rl 'fn main' crates --include='main.rs' | wc -l`.
    25	The investor lens filed it as *"fn main count is not binary/build evidence"* and it was right twice
    26	over — the proxy was wrong, and by the time it was challenged the count had drifted too. Three
    27	instruments, three answers, re-measured at commit time:
    28	
    29	| instrument | answer | what it actually counts |
    30	|---|---:|---|
    31	| `grep -rl 'fn main' --include=main.rs` | 18 | crates having a `main.rs` — a **source shape**, not an artifact (re-measured 2026-09-01 at both fb89714 and be012d9; the 17 figure and the NUMBERS.toml note were one behind) |
    32	| `grep -c '^\[\[bin\]\]' crates/*/Cargo.toml` | 16 | **explicitly declared** targets; misses every implicit `src/main.rs` |
    33	| `cargo metadata --format-version 1 --no-deps` (historical snapshot) | **23** | the workspace's declared binary targets in the superseded plan snapshot; current target authority is 48 above |
    34	The historical metadata measurement was the only canonical target denominator in that snapshot; current target authority is the 48-row metadata result above. Both counts include implicit and explicit Cargo binary targets and neither is an artifact-success proof.
    35	Successful output is a separate proof: `cargo build --workspace --message-format=json` is filtered to
    36	`compiler-artifact` messages whose target kind is `bin`, and the receipt records target names,
    37	artifact paths, and the command exit code. A target in metadata without a successful artifact is
    38	reported missing and cannot satisfy install acceptance.
    39	
    40	`crates/installer/src/main.rs:12` declares
    41	`const BINARIES: &[&str] = &["omp-orchestrator", "tick-monitor", "pane-truth"];`.
    42	
    43	
    44	**HISTORICAL MEASURED PLAN SNAPSHOT.** The installer list covered 3/23 target rows (13%), with 2/23 owned install entries (8.7%) and one foreign; 20 targets had no owned path in that snapshot. Current acceptance uses the 48-target metadata denominator above.
    45	**Canonical manifest (PROJECTED; the one denominator for this section).** The release manifest is
    46	generated from the Cargo target graph with the exact command in `NUMBERS.toml`:
    47	`cargo metadata --format-version 1 --no-deps 2>/dev/null | python3 -c "import sys,json;m=json.load(sys.stdin);print(len([t for p in m['packages'] for t in p['targets'] if 'bin' in t['kind']]))"`.
    48	It has one row per target and the fields `target`, `owner`, `distribution` (`INSTALL`,
    49	`FOREIGN`, or `UNRELEASED`), and `adapter`. The installer, runtime adapter list, and
    50	post-install expected set MUST all be projections of this manifest; none may maintain a second-hand count. In the historical 23-target snapshot, installer_entries=3, foreign=1 (pane-truth), and owned_entries=2; current metadata has 48 target rows and the current ratio is recorded in NUMBERS.toml.
    51	~~The seven runtime adapters are a projected manifest field, not a second denominator.~~ **RETRACTED 2026-09-01 — see §7.9: no seven-item list exists anywhere in the repo.** The expected
    52	install set is exactly the rows with `distribution=INSTALL`, so a foreign or unreleased row can
   589	**HISTORICAL MEASURED (2026-09-01; provenance incomplete).** The source revision, exact per-target
   590	`--help` invocation, and captured output artifact were not retained. The table below is therefore a
   591	plan snapshot, not acceptance evidence. A future bead MUST record the metadata target list, the exact
   592	probe command, every target's output/exit code, and a SHA-256 before publishing these ratios.
   593	
   594	### Historical 23-target help snapshot
   595	
   596	| behaviour | count | what it means for a stranger |
   597	|---|---:|---|
   598	| **NOT-BUILT** | 7 | the release binary does not exist; nothing to invoke |
   599	| **REAL-HELP** | 6 | historical snapshot: usage line with no error; the snapshot's first-line instrument answered 7, while the current registered help_discoverable_binaries command answers 10 |
   600	| **REJECTS** | 3 | answers `unknown argument: --help` |
   601	| **HELP-AS-PATH** | 3 | treats `--help` as a **filesystem path** and reports it missing |
   602	| **SILENT** | 2 | prints nothing at all |
   603	| **EXECUTES** | 1 | **runs the gate** instead of describing it |
   604	| ERRORS | 1 | errors on an unrelated precondition |
   605	
   606	**Historical snapshot: names a timeout or deadline in its own help: 1 of 16 buildable** —
   607	dispatch-silence-watch. Fifteen did not in that snapshot; this ratio is not the current 48-target help census.
   608	
   609	### The three that deserve naming
   610	
   611	- **`no-shell-gate`, `state-wildcard-lint`, `undrained-pipe-lint`** treat `--help` as a
   612	  path: *"cannot read --help"*, *"repo root --help: No such file or directory"*. An
   613	  operator asking a gate what it does is told their file is missing.
   614	- **`pre-commit-gate` EXECUTES.** Asking it for help runs the gate — output
   615	  `MULTI-GATE: no staged files to check`. On a dirty tree that is a real gate run with
   616	  real refusals, produced by a request for documentation.
   617	- **`loop-queue-filter` and `pre-delete-citation-check` are silent.** No usage, no
   618	  error, exit and nothing. Indistinguishable from a binary that does nothing.
   619	
   620	### What this does and does not close
   621	
   622	**Historical snapshot only:** the commands existed for 16 built targets, and guards/timeouts were discoverable for 1 of 16. The current registered first-line help command answers 10; a fresh full matrix receipt is still required before current invocation coverage is claimed.
   623	
   624	**Does not close** the actions themselves. This maps BINARIES; `Lens05Actions`'
   625	complaint was about **actions A1–A11**, which are specified as *behaviours* and do not
   626	correspond one-to-one with bin targets. Several actions are functions inside
   627	`omp-orchestrator` with no independent entry point, so no `--help` probe can find them.
   628	Mapping action → binary → subcommand is a further step and is **not built**.
   629	
   630	**NO-CLAIM:** `--help` answering is a proxy for discoverability, not a measure of it.
   631	A binary with perfect help can still be undiscoverable if nothing tells an operator it
   632	exists — which is §2's `ADDRESSABLE` property, satisfied by **zero of eight gates**.
   633	This probe measures the second gate of two, and the first is still shut.
## section 08 current anchors
     1	# 08 — The end-user journey: another repo, another machine, orchestrating their own project
     2	
     3	Serves **R9** — *"all the way to end users (other projects / repos / machines) are using it to
     4	orchestrate their projects."*
     5	
     6	**Read the status marker on every claim here.** Almost nothing in this section exists. The adoption
     7	path is `PROJECTED` end to end; the measurements are of *our own repo today* — evidence the failures
     8	are real, and the exact obstacles between us and a foreign adopter.
     9	
    10	`MEASURED` 2026-08-31, corrected 2026-09-01, and it frames everything below: there is no
    11	adopter-facing INIT path — no `doctor`, no `init`, no `adopt`
    12	(`/usr/bin/grep -cE '"doctor"|"init"' crates/omp-orchestrator/src/main.rs` → `0`). There IS a
    13	resident `run` entrypoint, and quoting the CLI verbatim matters enough that this section's first
    14	draft got graded down for trimming it. The whole CLI surface, verbatim from `usage()` at
    15	crates/omp-orchestrator/src/main.rs:274-275:
    16	
    17	```
    18	usage: omp-orchestrator [run] [--once|--max-ticks N] [--repo PATH] [--session NAME]
    19	                        [--interval-secs N] [--receiver-agent NAME] [--omp-quick] [--omp-binary PATH]
    20	       `run` is the explicit resident lifecycle entrypoint (observe -> ready queue -> dispatch -> receiver receipt); the flag-only form is unchanged for launchd
    21	```
    22	
    23	`run` requires our fleet's `--session`/`--receiver-agent` — it is an entry point for OUR operator,
    24	not an adoption path; the missing pieces are still the three verbs below.
    25	
    26	No `doctor`, no `init`, no `adopt`. `--session NAME` and `--receiver-agent NAME` are facts about
    27	*our* fleet a stranger cannot supply correctly. **NO-CLAIM:** that grep establishes the absence of two
    28	literal strings in one file, not that no other crate offers an entry point (§07 owns distribution).
    29	
    30	---
    31	
    32	## 1. Who the end user is
    33	
    34	**Persona A — the solo maintainer.** One repo, one machine, no fleet, 5k–100k lines. One agent at a
    35	time in one terminal, by hand; no panes to census, no use for a supervisor loop. They want the *back
    36	half*: gates that fail a build on a named property, and completion tracking where "done" means an
    37	artifact exists rather than an agent said so. They can be served first, because the gates are the
    38	part of this repo measured to work — `HISTORICAL MEASURED SNAPSHOT` (the current worktree census authority is §1 of `06-gates.md`; do not use this snapshot for acceptance): 31 integration test files, **409** `#[test]` functions,
    39	8 gate crates, **2 of 8** with all four named leg categories in the snapshot (`undrained-pipe-lint` and `no-shell-gate`), but only **1 of 8** with an executable attributable mutation leg (`undrained-pipe-lint`; `no-shell-gate` is AFFORDANCE-only), and **4 of 8** with no mutation mechanism of any kind. **NO-CLAIM:** the leg table counts files matching a property grep; it does not establish the legs are individually strong.
    40	
    41	**Persona B — the small team.** Three to eight agents, one repo, one shared session. They already
    42	dispatch by hand and already lose track. They want dispatch with receipts: a record that a packet
    43	was accepted, by whom, and whether work started. `MEASURED` (brief §4, corrected 2026-09-01): the `actuate` layer **exists and is unfenced** — the
    44	resident supervisor dispatches without the claim beat and logged 131 sends of one unclaimed bead to
    45	one dead pane as successes; the `complete` layer **does not exist** — every completion this session
    46	was found by a human looking. Their core need is exactly those two rows: a dispatch that is refused
    47	until claimed and receipted, and a completion the loop can see.
    48	
    49	**Persona C — the multi-repo fleet operator.** Our own shape: many repos, dozens of panes, a tracker,
    50	a queue, a supervisor loop. Last to serve, structurally: **HISTORICAL** brief §3.2 reported 157 of 183 rows as CAPABILITY_NOT_USED and all 7 consumes edges from one crate — an inventory, not orchestration. Current map values are maintained in 02-surface-census and are not an external-adoption result.
    51	
    52	**The order is A → B → C, the inverse of the order we built in.** **NO-CLAIM:** the ordering is a
    53	`PROJECTED` product judgement; no adopter outside this machine has run any part of this system.
    63	### 2.1 Install
    64	
    65	```
    66	$ cargo install omp-orchestrator                                    # PROJECTED
    67	$ omp-orchestrator --version
    68	omp-orchestrator 0.1.0 (build_id=ecdea397, target=aarch64-apple-darwin)
    69	```
    70	
    71	`MEASURED` obstacle, not cosmetic. `crates/installer/src/main.rs:16` resolves the repo root from
    72	`env!("CARGO_MANIFEST_DIR")` — a **compile-time** constant; `:25` falls back to a literal
    73	/Users/josh; :12 hardcodes three binary names. Repo-wide the pattern appears **61** times across **52** files at this writing. NUMBERS.toml registers the aggregate site count as LIVE; the 52-file split is diagnostic output from the same source walk, not a separate registry figure. A shell grep -r --include= returns a false zero here — see §2.2.
    74	An installed binary carrying a compile-time path audits the build machine's checkout, not the adopter's. **NO-CLAIM:** this is a measurement of coupling, not a claim that every occurrence is production behavior.
    75	
   260	## 3. What we require, and what we must never require
   261	
   262	Hard requirements, and there are only three: **a git repository**, **a source of work units** (theirs
   263	or ours), and **a way to observe a worker**. Below those, every "do we need X" needs a named adapter.
   264	
   265	| we must NOT require | why not | adapter that makes it optional |
   266	|---|---|---|
   267	| our bead prefix (`omp-orchestrator-*`) | a naming convention is not a contract; theirs is already in their CI | `TrackerAdapter` returns an opaque `UnitId`; the orchestrator never parses one |
   268	| our directory layout (crates/, docs/plan/) | MEASURED: 61 CARGO_MANIFEST_DIR sites; 52-file split is diagnostic output from the same walk and is not a separate NUMBERS figure | RepoAdapter::root() resolves at runtime from cwd upward; compile-time roots stay in our own tests |
   269	| our tmux session naming (`--session NAME`) | required today (`crates/omp-orchestrator/src/main.rs:274-275`), encoding our fleet's shape | `WorkerAdapter` owns naming; `--session` becomes a tmux-adapter-scoped flag, invalid elsewhere |
   270	| **our `.sh`/`.py` prohibition** | OUR accretion rule, born of a measured 160 tracked shell scripts and 60,467 lines in `control-plane` (`crates/no-shell-gate/src/lib.rs:6-9`). A foreign repo full of shell scripts is a normal repo and must be fully orchestrable | `no-shell-gate` is **opt-in**: `SKIPPED reason=OPTED_OUT_BY_ADOPTER`, never in a default set |
   271	| our specific agent CLI (OMP v18) | §3.1 — the deepest coupling in the codebase | `WorkerAdapter::observe()`; `tick-monitor` becomes the *OMP-v18 implementation*, not the interface |
   272	| a single version flag that works on every dependency | MEASURED: tmux --version exits 1 while tmux -V returns 3.6a exit 0; --version answers 8/9 of our binaries and -V answers **6/9** in the current probe | doctor requires two independent presence signals and a separate failure-arm test; the old pi_agent_rust line citations are historical |
   273	
   274	We may enforce our own rules on ourselves as hard as we like. `MEASURED`:
   275	`git ls-files -- '*.sh' '*.py' | wc -l` → `0` (grep-free, deliberately), exemption list empty by
   276	design (`crates/no-shell-gate/src/lib.rs:6`). **Exporting it would be colonisation** — and it misfires
   277	even on us: `crates/composer-typed/tests/differential.rs:41` aims its oracle at
   278	`../../bin/composer-typed.py`; `ls bin/` → `No such file or directory`. **NO-CLAIM:** index only.
   279	
   280	### 3.1 The deepest coupling, stated as the objection an investor should raise
   281	
   282	*"Your observer reads one vendor's terminal UI. You have not built an orchestrator, you have built an
   283	OMP v18 screen-scraper. What is the adapter story worth if the layer you claim works is vendor-blind?"*
   284	
   285	Correct as stated, and the strongest objection here. `MEASURED` and specific:
   286	crates/tick-monitor/src/lib.rs:317 hardcodes MODEL_MARKERS = [Opus 5, GLM 5.3, GPT-5.6, GPT-5.5]; :320 hardcodes the OMP-v18 dialog-footer strings captured from pane %1372; :385 strips braille U+2800..U+28FF and the literal pi; :356 classifies queued-message strings. The current source is 1,326 lines; these are source-shape facts, not proof of vendor parity.
   287	
   288	We have been on the receiving end of this. `MEASURED`, from `crates/tick-monitor/src/lib.rs:10-18`:
   289	`pane-truth` reported pane `%1409` — *"braille spinner, advancing timer, 16.5% tree CPU"* — as
   290	**IDLE**, and *"its green selftest AND its mutation leg are vacuous for OMP panes."*
   291	
   292	The answer is a declared, testable vendor contract per adapter, requiring of each what `pane-truth`
   293	lacked: a known-good fixture in **that** vendor's format. **NO-CLAIM:** no second `WorkerAdapter`
   294	exists; factorability is `PROJECTED`.
   295	
   296	---
   297	
   298	## 4. The adapter surface — design spec
   299	
   300	All `PROJECTED`; trait shapes are future-tense. The precedent for traits is `MEASURED`:
   301	`crates/finding/src/lib.rs:301` declares `pub trait Publisher` with `fn publish(&self, cx: &Cx, …)`.
   302	Adapters follow that exactly: a method without `&Cx` first cannot be cancelled.
   303	
   304	**`TrackerAdapter`** — three methods. `ready(&Cx) -> Vec<Unit>` lists claimable work.
   305	`claim(&Cx, UnitId, Claimant) -> ClaimOutcome` takes exclusive custody and must be *fenced*: a second
   306	claim on a live claim is a typed refusal, never a silent overwrite. `close(&Cx, UnitId, Evidence) ->
   307	CloseOutcome` — **`Evidence` is not `Option`**, because prose completion is what emptied our own
   308	`complete` layer. Reference: `br` via `subprocess-contract`, plus a file-backed `--tracker=file`.
   309	
   310	**`WorkerAdapter`** — `observe(&Cx, WorkerId) -> Observation`, `dispatch(&Cx, WorkerId, Packet) ->
## section 09 current anchors
     1	# 09 — Milestones, done-definitions, and how this plan is validated
     2	
     3	Serves **R1** ("define what done looks like at each milestone") and **R3** ("something that could pass an 'investor' test — they can
     4	beat up the plan, find any gaps, and pass or fail us"). Sections 01–08 describe a system. This section states the conditions under which
     5	we are allowed to say it works, and the conditions under which this document should be rejected. Written 2026-08-31.
     6	
     7	## 1. The done-definition template
     8	
     9	**A milestone is closed by an OBSERVABLE, not by a claim** — not by a passing test suite, a commit, an agent reporting success, or a
    10	human's recollection that it seemed to work. An observable is a command someone else can run and a result they can read without asking
    11	us what it means. That is the output of the failure this project was stood down over: **a workspace whose own census measured
    12	mechanisms built, tested, hardened, and called by nothing** — a **historical** §01 snapshot of twenty-six crates and 379→407 tests, with a BUILT≠WIRED census whose row set outgrew the then-current twenty-mechanism figure. Current workspace counts are command-backed in NUMBERS.toml; this historical scar shows why evidence code must prove invocation, not merely correct source.
    13	Every milestone below is stated in this shape:
    14	
    15	```
    16	Mn — <one-sentence goal, future tense>
    17	  OBSERVABLE      the command, and the result that closes it
    18	  NOT IN SCOPE    what this milestone deliberately does not deliver
    19	  STARTING POINT  MEASURED state today, with the deriving command
    20	  RISK            the named way this milestone fails or lies
    21	```
    22	
    23	An observable is **admissible** only if it (1) is a command, not a description of a condition, (2) is runnable by someone who did not
    24	build the thing — no undocumented environment, no "and then check the pane", (3) reads without interpretation, and (4) **fails on the
    25	pre-milestone state.** Property 4 is the anti-vacuity leg from §06 applied to project management, and we owe it to a failure of our own:
    26	the brief's **183-row / zero-missing / one-distinct-`must_be_true`** result is a **HISTORICAL, UNPROVEN** snapshot: no retained census artifact or deriving command is available here, so it is not a current baseline. It nevertheless illustrates the vacuity defect; a milestone whose observable already passes is that defect
    27	wearing a Gantt chart.
    28	
    29	**NO-CLAIM.** Property 4 makes an observable *discriminating*, not *sufficient* — an observable can fail-before, pass-after, and still
    30	measure the wrong quantity. Guarding against that is §5's job.
    31	
    32	## 2. The milestones
    33	
    34	Seven, ordered by dependency — forced, not chosen: each consumes the capability the previous one produces, so there is no parallel path
    35	here and no way to buy schedule with more agents. The ordering is not asserted from preference: it
    36	mirrors the crate chain captured in the **historical 18-edge DAG snapshot** (§04): finding-dispatch → omp-orchestrator → ack-stage → receiver-receipt → tick-monitor. M1's seam is at the head and M7's window at the tail.
    37	```mermaid
    38	graph LR
    39	  M1[M1 observe<br/>the seam] --> M2[M2 select<br/>by graph] --> M3[M3 dispatch<br/>with a receipt]
    40	  M3 --> M4[M4 completion<br/>no human] --> M5[M5 the loop<br/>closes] --> M6[M6 foreign<br/>repo] --> M7[M7 unattended<br/>window]
    41	```
    42	
    43	`PROJECTED` — target-state chain, not measured data (rule 6); §04 carries the measured crate graph.
    44	
    45	### M1 — One shared pane-state type will cross the observe→decide seam, so a filter change breaks the consumer at compile time
    46	
    47	**OBSERVABLE.** Both legs are run from the repository root at the recorded `git rev-parse HEAD`,
    48	with the pinned Rust toolchain and the checked-in fixture
    49	`crates/omp-orchestrator/tests/fixtures/tick-monitor-newly-idle.json` (its SHA-256 is printed).
    50	Run exactly:
    51	
    52	`cargo test -p omp-orchestrator --test pane_state_seam -- --exact tick_monitor_newly_idle_reaches_orchestrator --nocapture`
    53	
    54	The test must print one JSON line with `{"fixture":"tick-monitor-newly-idle.json","state":"NewlyIdle","free_capacity":true,"shared_type":"PaneObservation","revision":"<git sha>"}` and exit 0. It must compile the real fixture through the production parser and fail if either crate's public parse/emit signature does not use the same `omp-types::PaneObservation` type; the pre-milestone tree fails because the test, fixture, dependency edge, and shared signature are absent, while the post-milestone tree passes only with that JSON and exit 0. A separate source check is the exact command
    55	`grep -rn "omp-types\\|omp_types" crates/*/Cargo.toml | grep -v "^crates/omp-types/"`; its non-empty result must name both consumers. **NOT IN SCOPE.** Selection, dispatch, ack — M1 changes what the loop *sees*.
   295	Score each dimension PASS or FAIL. **We are asking to be failed on at least one** — a reviewer who passes all six has not read
   296	adversarially, and a document engineered to pass all six is useless to us.
   297	
   298	| dimension | PASS looks like | FAIL looks like |
   299	|---|---|---|
   300	| **The problem is real** | The failure class is shown with counts and a derivation, and it is a class rather than an anecdote | The pain is asserted, or one story is generalised into a market |
   301	| **The measurement is honest** | Numbers re-derive; `MEASURED`/`PROJECTED` hold; retired figures stay retired; every not-found names its search space | A number that will not re-derive; a projection wearing `MEASURED`; a floating denominator; a not-found with no search space; a bare `path:line` with no construct |
   302	| **The architecture is sound** | Typed transitions with refusal arms; a timeout is not a verdict; one vocabulary crosses each seam | Boolean success paths; convention-only seams; a refusal no consumer reads |
   303	| **The gates actually bite** | Each gate has known-bad, known-good, mutation, anti-vacuity, and is ADDRESSABLE | Attack-only or defence-only suites; a gate no documented command runs; `guarantees` in a header |
   304	| **The adoption path is credible** | A cold foreign host installs and takes a first tick, with degradation for absent dependencies | Installability asserted and never attempted; hard dependency on host-specific paths |
   305	| **The team tells on itself** | The document names defects its own author committed, and records disagreement with its own brief | Every finding indicts a worker; no self-indictment; no open contradiction |
   306	**Where we expect to fail today, stated first so a reviewer can check our self-assessment.** *Gates actually bite → FAIL*: the former **2-of-8 / 4-of-8** figures are **HISTORICAL, UNPROVEN** snapshots with no retained derivation and are not a current verdict; `path-literal-guard` still has a known-bad with **no known-good**, and over-strict gates get routed around, a slower death than no gate. A fresh gate report is required before stating a new count. *Adoption path is credible → FAIL*: `MEASURED`, never attempted (M6); `installer` is isolated in the dependency graph.
   307	*Architecture is sound → CONTESTED*: the former **6 / 17 / 4** type counts are **HISTORICAL, UNPROVEN** snapshots with no retained derivation and are not a current baseline; the typed-seam risk remains the subject of M1–M4.
   308	
   309	**NO-CLAIM.** This rubric grades *this document*, not the software. A document that passes all six describes a system that may still not
   310	work — which is why M5 exists and why it is unproven.
   311	
   312	## 6. What is proven and what is not
   313	
   314	BANKED rows cite evidence; UNPROVEN rows name the experiment that settles them. No row sits between.
   315	
   316	| BANKED — qualitative evidence only; stale counts excluded | UNPROVEN — with the experiment that settles it |
   317	|---|---|
   318	| The build-and-never-call class is real and frequent here — the **20-occurrence / 21st-occurrence** counts are **HISTORICAL, UNPROVEN** snapshots and are not banked; the retained evidence is the named `Finished` grep and zero-dependency check | **The loop can close without a human.** Never observed once. Settled by M5: ten consecutive closes from one recorded run with zero human-originated events. |
   319	| Silent refusal is real — the **162-tick** and **178-tick** counts are **HISTORICAL, UNPROVEN** snapshots with no retained ledger derivation and are not banked | **The substrate installs elsewhere.** `MEASURED`: never attempted; `installer` is isolated in the 18-edge graph. Settled by M6: a cold foreign host, documented install, first tick, reproducible transcript. |
   320	| Transport lies in both directions — `cp-z42vu` returned **`success:[4]`** with no packet delivered (`README.md:155`); the inverse fired the same session | **Verification is cheaper than review.** No instrumentation exists. Settled by recording human-seconds per closed bead before and after M4 on the same bead mix — that ratio is the whole economic argument and is unmeasured. |
   321	| The evidence-field discipline can be satisfied vacuously — the brief's **183/183** and **one-distinct-value** figures are **HISTORICAL, UNPROVEN** snapshots and are not banked | **Graph selection beats recency.** `MEASURED`: `bv` is spawned zero times. Settled by M2's differential test plus a measured close-rate comparison on a fixed bead set. |
   322	| The observe layer works and the NewlyIdle filter defect is fixed in source — tick-monitor/src/lib.rs:467-468 exposes ConfirmedIdle or NewlyIdle free capacity; regression test observed_idle_state_counts_as_free_capacity_before_confirmation at omp-orchestrator/src/main.rs:1646-1653 | **The seam cannot silently diverge again.** No shared type crosses it; parse_observation uses JSON lists plus an IDLE fallback. Settled by M1 only after the shared-type fixture lands. |
   323	| The one hard rule is enforced mechanically — a Rust gate walks `git ls-files` and fails on `.sh`/`.py`, exemption list empty | **The gates bite under attack.** The former **2-of-8 / 4-of-8** figures are **HISTORICAL, UNPROVEN** snapshots and are not a current verdict. Settled by bringing all 8 to four legs plus ADDRESSABLE, and a planted-known-bad campaign per gate. |
   324	| Failing closed with a remediation hint works — `fh` MCP returns a typed `SERVE_INPUT_STALE` naming the moved mirror HEAD (`5dec4212…` → `ecdea397…`) rather than an empty result | **This plan enforces its own discipline.** `MEASURED`: `ls crates/ \| grep plan-check` → empty. Settled by shipping `plan-check` (§4) with its known-bad fixture. |
   325	> **Idle vocabulary exists upstream:** `GuestIdleReconcilerCtx` declares the NewlyIdle/ConfirmedIdle distinction. What is UNPROVEN here is our consumption of it, not its existence.
   326	
   327	> *Upstream type for this gap: `IrcDeliveryReceipt` (`tools/hub/types.d.ts:8`, DECLARED only). Named here because the gap-propagation gate requires the type adjacent to the claim — a section arguing an absence that has an upstream type must say so.*
   328	
   329	**NO-CLAIM.** This section defines the conditions under which a milestone may be called done, and records what is and is not proven as
   330	of 2026-08-31 on one repository and one machine. It does not establish that these are the right milestones, that seven is the right
   331	number, that the ordering is minimal, or that closing all seven produces a system anyone wants. It makes no schedule claim — no date,
   332	duration, or effort estimate appears above, because none is measured. The most important row here is `M5 — UNPROVEN`; no rigor elsewhere
   333	substitutes for it.
## prior covered findings for sections 07-09
15	R15-08-end-users-AmberGate-1	RETRACTED
15	R15-09-milestones-AmberGate-1	RETRACTED
15	R15-07-installability-AmberGate-1	DEFERRED
15	R15-08-end-users-AmberGate-2	DEFERRED
16	R16-AdversaryEye-07-installability-1	DEFERRED
16	R16-AdversaryEye-07-installability-2	DEFERRED
16	R16-AdversaryEye-07-installability-3	DEFERRED
16	R16-AdversaryEye-07-installability-4	DEFERRED
16	R16-DeltaEye-09-milestones-1	DEFERRED
16	R16-DeltaEye-09-milestones-2	DEFERRED
16	R16-DeltaEye-09-milestones-3	DEFERRED
16	R16-DeltaEye-09-milestones-4	DEFERRED
16	R16-Opus-07-installability-8-1	DEFERRED
16	R16-Opus-07-installability-8-2	DEFERRED
16	R16-Opus-07-installability-8-3	DEFERRED
16	R16-Opus-08-end-users-9-1	DEFERRED
16	R16-SchemaEye-09-milestones-1	DEFERRED
16	R16-SchemaEye-09-milestones-2	DEFERRED
16	R16-SchemaEye-09-milestones-3	DEFERRED
16	R16-TraceEye-08-end-users-1	DEFERRED
16	R16-TraceEye-08-end-users-2	DEFERRED
21	R21-07-pane-truth-ghost-obsolete	FIXED
21	R21-07-install-ratio-stale	DEFERRED
21	R21-07-exit-citation-drift	DEFERRED
21	R21-07-seven-adapter-residue	DEFERRED
21	R21-07-malformed-component-name	DEFERRED
21	R21-08-version-denominator-drift	DEFERRED
21	R21-08-source-anchor-drift	DEFERRED
21	R21-08-stale-surface-currentness	DEFERRED
21	R21-08-manifest-count-owner-gap	DEFERRED
21	R21-08-supervisor-drift-unproven	DEFERRED
21	R21-09-opening-denominator-stale	DEFERRED
21	R21-09-seam-citation-drift	DEFERRED
21	R21-09-unattended-duration-unproven	DEFERRED
20	R20-07-target-denominator-stale	DEFERRED
20	R20-07-revision-and-mirror-provenance	DEFERRED
20	R20-08-manifest-dir-count-stale	DEFERRED
20	R20-08-unverified-measured-claims	DEFERRED
20	R20-09-checker-crate-count-stale	DEFERRED
20	R20-09-seam-citations-drift	DEFERRED
19	R19-07-milestone-count	DEFERRED
19	R19-07-current-scanner-drift	DEFERRED
19	R19-08-test-denominator	DEFERRED
19	R19-09-m6-impossible-command	DEFERRED
## independent verdict
07-installability ZERO_NEW: stale target/help ratios are already represented by R16/R20/R21 findings; current section labels historical/projection where appropriate.
08-end-users ZERO_NEW: compile-time path, version-denominator, and adoption-contract issues are already represented by R16/R20/R21 findings; no distinct unrepresented defect observed.
09-milestones ZERO_NEW: historical denominator and seam claims are already represented by R16/R20/R21 findings; no distinct unrepresented defect observed.

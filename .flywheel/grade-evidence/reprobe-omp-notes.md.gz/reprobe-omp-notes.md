# REPROBE NOTES — omp slice (56 rows, batches 10-11) — SilverWolf (%1409)

RESULT: 51 RETIRE confirmed under probe, **5 FLIPPED** — 2 CONSUMED, 2 VALIDATE, 1 WIRE.
A re-probe that had confirmed all 56 would itself have been the finding; it did not happen.

## THE FIVE FLIPS
1. `type_root:slash-commands` -> CONSUMED (omp-inventory-map). The original RETIRE was WRONG, not
   merely unvalidated: the census's own consumes edges (re-verified live tonight, evidence string
   "direct process probe produced this row") already consume this surface. Probe: dist/types/
   slash-commands/ = 13 d.ts files.
2. `rpc_handler:get_available_commands` -> CONSUMED (omp-inventory-map). Same — it is one of the
   seven edges. The retire ignored the census that the scanner itself emitted.
3. `type_root:session` -> VALIDATE (omp-rpc-session). 78-file vendored surface naming the
   agent-session/event types our crate reverse-engineered by hand. Dependence without consumption;
   the test is a golden-parse of one captured frame against the vendored names.
4. `type_root:subprocess` -> VALIDATE (subprocess-contract). worker-client.d.ts exports
   WorkerHandle<Inbound,Outbound> — OMP's own child contract; we spawn omp and depend on its
   lifecycle. Test: spawn `omp --version` under our contract, assert exit/clean reaping.
5. `declaration:telemetry-export.d.ts` -> WIRE (tick-monitor). The sharpest flip: OMP ships an
   OTLP export bootstrap behind the OTEL_* env contract (trace/log/metric providers, probed from
   the d.ts header). A receiver in tick-monitor turns §8.2 Q2 (cost, measurably?) from OPEN to
   sampled, over a standard protocol. Zero OTEL references in crates/ today.

## PROBE METHOD (stated per the packet's omp caveat)
- type_roots: `ls dist/types/<n>/` + first-module read (the census's own find-based method).
- declarations: existence + subsystem block read at the install root.
- rpc_handlers: string census against the installed cli.js — every one of the 27 methods is
  registered in the bundle (the singleton-registration pattern: 2 occurrences = declared + wired
  once). No `case "<name>"` dispatch form exists; the census's parse_rpc_handlers_source scrapes
  these same strings.
- cli_commands: none in this slice (all 27 non-type rows are rpc_handlers).

## THE RETIRED FAMILY WORTH NAMING (recorded, not adopted)
prompt / get_last_assistant_text / set_auto_compaction / get_subagents (+ handoff) are the coherent
ALTERNATIVE architecture: drive one omp per worker over RPC with typed state, instead of scraping
panes. Every one is retired on the ipg.4 single-session verdict, and set_auto_compaction is noted
in-row because compaction is the %1413 killer. If actuation is ever redesigned, this row family is
the named alternative — the same "recorded, not adopted" device as the brief's ack-vocabulary row.

## HONEST LIMITS
- The rpc_handler probe proves REGISTRATION, not runtime behavior — firing them would require a
  live `--mode=rpc` session (heavier than this pass allows; the omp-rpc-session crate is the
  existing harness for that and its own tests pin the four methods it consumes).
- declaration-row reasons for cli-commands/cli/config/cursor*/main/startup-splash/system-prompt/
  thinking/workspace-tree are subsystem-level (block exists, agent/IDE plane, zero consumers), not
  per-export reads of all 14 files; the load-bearing evidence is zero consumption plus plane.

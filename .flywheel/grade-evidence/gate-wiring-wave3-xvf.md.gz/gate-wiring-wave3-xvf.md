# OMP coverage wave-three wiring evidence

Bead: `omp-orchestrator-gate-wiring-wave3-xvf`

## Acceptance

1. The authoritative `docs/plan/SURFACE-MAP.jsonl` contains 11 distinct `maps_to_crate` outputs on `WIRE` rows. The supervisor declares the same exact set in `COVERAGE_WAVE_OUTPUT_CRATES`. `census_gates` emits a first-class row for each; a missing crate manifest becomes restrictive `NotInstalled` rather than disappearing.
2. Each declared output row carries a non-empty supervisor trigger string (`supervisor:coverage-output-census -> crates/<crate>`). The test compares the production registry to the authoritative map and checks every row is reachable on the current workspace.
3. NO-CLAIM is explicit in the production comments and integration test: this verifies trigger registration and census reachability only. It does not verify that any coverage wave implementation is correct.

The existing `decide()` path performs the census gate before pane/queue decisions. The boundary test supplies a reachable positive control plus an unreachable `finding-dispatch` output and verifies `SupervisorDecision::GateUnwired` is returned.

## Verification

- `cargo test -p omp-orchestrator --test gate_wiring_wave3 --offline -- --nocapture`: final post-tightening run, 3 passed, 0 failed.
- `cargo test -p omp-orchestrator --offline --quiet`: regression run, all targets passed: 36 library tests, 7 existing wave-two tests, 3 wave-three tests, 3 census tests, and 2 no-noop tests.
- `git commit` ran the installed pre-commit hook successfully.

## Delivery

Commit: `e51ccbf feat(supervisor): census all OMP coverage outputs [test]`

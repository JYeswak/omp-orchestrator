# GRADE R5 — 00-brief.md — ALL FOUR LENSES (pane 5, %1409)
# Docs @ 4b74156. Focus: verify my round-2 findings fixed/not; retired-figure gate audit;
# four lenses on the absorbed content. Cross-challenge of /tmp/grade/r4-08-end-users.md at foot.

## FIX-STATUS LEDGER for my round-2 findings (the packet's explicit ask)
- R2-1 (AUTOMATED keyword definition): **FIXED — twice.** Column now records what the mutation ACTS ON (TREE/FIXTURE/AFFORDANCE/NONE, read from test bodies); the keyword definition survives only inside a labelled retraction (L327-329). Correction to my round-4 cross-challenge below.
- R2-2 (omp-inventory-map known_bad=0 keyword artifact): **LIVE after 4 rounds.** Table still prints known_bad=0; substance ≥3 (tests/inventory.rs:23 empty_metadata_is_a_hard_error, :128, :144). The column rebuilt twice is mutation; known-bad remains name-derived.
- R2-3 (selection "UNVERIFIED — no evidence"): **LIVE.** L501 wording unchanged; ≥4 direct decide() unit tests (omp-orchestrator lib.rs:591-647) still make the cell overbroad.
- R2-4: **ABSORBED CORRECTLY** — L331-337 carries the corrected attribution (quote real at g-adversarial.md:10; my "no artifact" wrong; seed real at p1414.txt:35). Fair to me and to itself. Credit.
- R2-5 (§7 author column): **LIVE.** Header (L596) is `| # | claim | refuted by | mechanism |` — no author column; "seven of them the conductor's" still not derivable from the table.
- R2-6: **PARTIAL.** Brief prose swept to "ten" (L632, L638) and PLAN.md's header WAS regenerated (the "Eight measured claims" line is gone). Residue: L590 still says "the true figure was nine" inside the live narrative; L632 says "corrected ten times **by agents**" while §7.4's tenth is the conductor's own seeded-refutation — the attribution clause r3-03 CH2 prescribed never landed.
- R2-7 (six /Users/josh literals vs gate-wiring claims): **LIVE, unreconciled** — no hook-installation admission anywhere in the brief.
- R2-8: **LIVE AND WORSE.** Q7 still prints "appears **0 times** in this brief" (measured: 2+, self-falsifying); Q8 still prints "once across all **eleven** sections" while docs/plan now holds TWELVE section files (11-lifecycle.md added).

## NEW FINDINGS

### B1 [ADVERSARIAL+EVIDENCE] L322 vs L360: the file now asserts BOTH "0 of 8" and "1 of 8" as live, 38 lines apart
- L316-322 (newest edit): "The honest count is now zero... **0 of 8** by the only definition that means anything." L354-355 (round-2 text, unswept): history ending "**1 of 8, and a different gate**". L360-361: "**1 of 8 gates has all four legs with an AUTOMATED mutation test** — undrained-pipe-lint (1/1/AUTOMATED/3)".
- Three compounding defects: (a) L360 asserts a count the newest text retracts; (b) L360 uses "AUTOMATED" — vocabulary the rebuilt column retired 45 lines up, where undrained-pipe-lint is now **FIXTURE**, not AUTOMATED; (c) the definition L360 depends on is the one L327-329 explicitly retracts. FIX: sweep L354-366 to the 0-of-8 world or wrap in the same "labelled retraction" device, and update the round-1 blockquote's instruction (L374: "quoting '1 of 8' or '5 of 8'" — the live-wrong values are now 1/2/5 of 8).

### M-GATE [EVIDENCE+ABSENCE — the packet's gate finding]: the gate is green while corpses from its own header walk, and the most-revised number in the doc is unretirable under the current needle design
- The gate's own header (retired_figures.rs:14-18) measured FIVE dead figures alive across sections; RETIRED (L57-78) carries THREE. Verified unretracted and live: "**51 public enums, 79 structs across 22 of 24 crates**" in FOUR sites with no 59/91 within the ±2-line retraction window (01-idea:345; 03-crates:195, 354; 04-diagrams:360; measured 0/3 files have the replacement nearby) — plus "four-layer" in 3 files, and a NEW site my round-4 pass missed because it graded 08 only: **06-gates.md:61 prints "`-V` answers 5 of 9" as live prose** (refuted round 1; corrected in §00 round 2). The "2 of 8"/"1 of 8" assertion family — five historical values, the doc's most-revised figure — is absent from RETIRED entirely, which is exactly why B1 could happen under a green gate. The needle lesson is the gate's own (ObligationLedger comment, L69-73): needle the ASSERTION ("gates have all four legs with an AUTOMATED mutation test"), not the bare count. FIX: add rows for the type-scope pair (replacement 59/91), the version-flag claim (6/9), the five-stage rename, and the four-legs assertion; then re-sweep the sections.

### M-COUNT [EVIDENCE] L590 + L596 + L632: the self-correction count is still not fully derivable or attributable
- Blockquote (L590): "the true figure was **nine**" — inside the live narrative, now one behind the prose's "ten" (L632, L638). L632: "corrected ten times **by agents applying it**" — but §7.4's tenth is the conductor's own seeded-refutation, not an agent-applied one. Table (L596) still has no author column. Three separate readers get three different reconciliations. FIX: author column + the one clause r3-03 CH2 prescribed ("ten = the table's nine plus the §7.4 self-refutation") + past-tense the L590 blockquote.

### m-denominator [EVIDENCE] three drifted counts printed as current
- "370 #[test]" (L289; also 08:32) — measured 379 now. "22 of 24 crates" (L456) — 24 of 26. Q8's "eleven sections" — twelve files. All stamped-snapshot defensible individually; collectively the doc keeps answering CURRENT questions with stamped numbers. FIX: the retired-figure gate's mechanism generalizes — add drift-prone counts with their deriving commands, or stamp inline (as-of dates) at each site.

### m-seam [ABSENCE] R2-7 detail: the brief's gate-facts still nowhere admit that the pre-commit trigger is not installed in this checkout
- Six `/Users/josh` literals in crates/*/src (re-verified round 2; unchanged tonight), commits carrying them landed with no refusal, and the new retired-figures gate is a TEST, not a hook. §3.5 still presents the guard as gate 2 of a wired binary. FIX: one sentence of trigger-installation status per checkout, evidenced by `strings .git/hooks/pre-commit`.

## CROSS-CHALLENGE TO /tmp/grade/r4-08-end-users.md (my own round-4 grade)
- **C5/R2-1 claim CORRECTED:** I wrote "the brief still carries the keyword AUTOMATED definition at L328... R2-1 remains UNFIXED." Against the current 816-line file that is wrong — L327-329 keeps the definition explicitly "as a labelled retraction," which is the correct device, and the column has since been rebuilt a second time (TREE/FIXTURE). I under-read a retraction label as a live claim — in a grade whose lens is evidence. My R2-1 finding (round 2) was right; my round-4 "still unfixed" status was wrong.
- **HOLDS, re-verified against 4b74156:** M1 (08's usage quote still omits `[run]`; :254 still wrong anchor); M3 (`-V` 5/9 still at 08:191 — and the round-5 sweep found the SAME figure newly alive at 06-gates:61, a site my 08-only round-4 scope could not see; sibling scope limits are real); M2 (2 of 8 at 08:32 — now doubly stale against 0-of-8); M4 (OneshotSpawn at 08:148); C1 (asupersync = 9 external dependents, re-grepped); C3 (A1/shared-type restatement still owed in ipg.17 + §00 decision row).
- **Took-on-trust check:** nothing in r4 survives unverified — the one number I could have laundered (fh true_exit=3) was captured pipe-free and re-stands.

## VERDICT: FAIL
## THE ONE THING: the expected-twin mechanism now exists, is green, and its own header names the corpses it chose not to guard — while the brief carries "0 of 8" and "1 of 8" as live claims 38 lines apart. The binding constraint on this document is no longer honesty or effort; it is that corrections are still applied by hand to headlines instead of swept to copies by the gate built to sweep them.

# Round 10 — hillclimb — 07-installability

Subagent: r10-07-hillclimb (fresh task agent; no prior grades/ledger supplied).
Specialist selection: jsm suggest returned “Bandit recommendations are currently disabled”; jsm search returned “No skills found.” I selected installer-workmanship deliberately as the closest available specialist.

## Verified findings

1. BLOCKER — Missing dispatchable runbook contract. A whole-file search found no explicit Trigger, Dispatch packet, Amazing, Adequate, Skills, or Done signal fields. The section cannot route installability work or prove its completion under the journey contract. Fix: add a seven-field installability runbook with concrete packet, bars, skill scope, negative evidence, and proving command/exit code.

2. MAJOR — Install scope has three incompatible denominators. Lines 15–20 say the workspace builds 18 binaries and the installer knows three; lines 88–90 say all 18 are adapters under one umbrella; lines 433–434 say the runtime wrapper covers seven. Fix: choose one canonical manifest and derive installer, runtime, and acceptance counts from it.

3. MAJOR — Post-install acceptance allows partial success. Lines 331–337 accept consistent=N drifted=0 foreign=K produced=18 plus health zero without requiring the expected set to be probed or missing binaries to be reported. Fix: require explicit expected-set and missing=0 checks.

4. MAJOR — fn main count is not binary/build evidence. Lines 15–20 label the result of the fn main grep as workspace builds 18 binaries. A source-file count does not prove Cargo targets or successful artifacts. Fix: derive from Cargo metadata and successful artifact output.

5. MAJOR — Installer-workmanship contract is materially incomplete. Lines 290–297 omit the installer skill’s required shell safety, gum/ANSI output, proxy/offline modes, version fallback, existing-install short-circuit, agent/hook/skill setup, and predecessor migration. Fix: import the complete applicable contract or explicitly scope each omission with replacement acceptance.

6. MAJOR — Adoption value remains unmeasured. Lines 3–11 frame the second-machine/person question, while lines 331–337 explicitly disclaim useful-work proof. The section has no install-success baseline, time-to-first-use, support burden, or downstream value metric. Fix: add baseline/target adoption and internal-buyer value metrics tied to a pilot.

7. MINOR — Several measurement claims lack exact provenance. Lines 183–187 state 13 tests and 544 KB of output without the exact derivation command; lines 299–302 use $M without defining it in the section. Fix: record exact commands, scope, and artifacts.

8. MAJOR — Bootstrap authenticity is weaker than target-binary integrity. Lines 315–324 describe executing the generated curl-piped bootstrap before any signature/checksum is applied to the bootstrap itself; lines 339–341 explicitly say no signing key is claimed. Fix: authenticate the bootstrap through a trusted package channel or pinned digest/signature before execution.

## Verification record

I re-read the cited ranges, searched the section for the seven runbook labels, and checked the installer-workmanship contract against the section’s distribution list. The buyer framing is recorded as an adoption/value measurement gap, not as a claim that an external customer is required.

new_findings: 8
role: hillclimb

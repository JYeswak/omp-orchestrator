# kxe.5 cross-section authority evidence

## Pinned source revision

Command: git rev-parse HEAD

Result: 9f4c73072dced55e5a07d1985a83052798e9a5e9

## Authority probes

### Board total

Command: for s in closed in_progress open blocked grading; do br list --status "$s" --json | jq -r 'if type == "array" then length elif .issues then (.issues|length) else error("unexpected br JSON shape") end'; done | awk '{s += $1} END {print s}'

Result: 230

The command covers all five status buckets. The board value is LIVE; it is not frozen in prose.

### Executable acceptance

Command: cargo test --quiet -p no-shell-gate --test cross_section_authority

Raw result, including stderr:
2026-09-02T20:07:01.305222Z  WARN rch::hook: RCH_REQUIRE_REMOTE is set but config says rch disabled (general.enabled=false); running locally per config
    at rch/src/hook.rs:2153 on ThreadId(1)


running 7 tests
.......
test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.91s

### Findings ledger acceptance

Command: cargo test --quiet -p no-shell-gate --test findings_ledger

Raw result, including stderr:
2026-09-02T20:07:01.210012Z  WARN rch::hook: RCH_REQUIRE_REMOTE is set but config says rch disabled (general.enabled=false); running locally per config
    at rch/src/hook.rs:2153 on ThreadId(1)


running 17 tests
.................
test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.80s

## Disposition boundary

The registry carries 57 required R19/R20/R21 finding IDs. Two explicitly named premises are
FALSE_POSITIVE because the current source contradicts the premise or the ID is absent. Four rows
remain LINKED_CHILD because their implementation is outside this reconciliation bead. All other
rows are FIXED as plan-authority corrections with a checked-in remediation pointer.

NO-CLAIM: this evidence proves registry shape, command reachability, and current plan metadata only.
It does not prove the runtime product is shipped, that PROJECTED surfaces exist, or that an
UNPROVEN completion consumer is wired.

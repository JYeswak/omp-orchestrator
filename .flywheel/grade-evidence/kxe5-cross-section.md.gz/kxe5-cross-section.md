# kxe.5 cross-section authority evidence

## Pinned source revision

Command: git rev-parse HEAD

Result: 54d85749dfe6806e9630f63ce9441f1ce63d8e22

## Authority probes

### Board total

Command: for s in closed in_progress open blocked grading; do br list --status "$s" --json | jq -r 'if type == "array" then length elif .issues then (.issues|length) else error("unexpected br JSON shape") end'; done | awk '{s += $1} END {print s}'

Result: 230

The command covers all five status buckets. The board value is LIVE; it is not frozen in prose.

### Workspace package and directory scope

Command: cargo metadata --format-version 1 --no-deps --offline | jq '[.packages[] | select(.manifest_path | contains("/crates/"))] | length'

Raw result, including stderr:
warning: profiles for the non root package will be ignored, specify profiles at the workspace root:
package:   /Users/josh/Developer/omp-orchestrator/crates/fleet-monitor/Cargo.toml
workspace: /Users/josh/Developer/omp-orchestrator/Cargo.toml
65

Command: find crates -mindepth 1 -maxdepth 1 -type d | wc -l

Result: 65

### Surface and plan scope

Command: jq -s length docs/plan/SURFACE-MAP.jsonl

Result: 614

Command: ls docs/plan/[0-9][0-9]-*.md | wc -l

Result: 13

Command: jq -s length docs/decisions.jsonl

Result: 7

## Executable acceptance

Command: cargo test --quiet -p no-shell-gate --test cross_section_authority

Raw result, including stderr:
2026-09-02T19:55:42.780070Z  WARN rch::hook: RCH_REQUIRE_REMOTE is set but config says rch disabled (general.enabled=false); running locally per config
    at rch/src/hook.rs:2153 on ThreadId(1)


running 7 tests
.......
test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.15s

## Mutation

The gate mutation replaces one required finding ID with R19-MUTATED. The mutation test fails with
CROSS_SECTION_FINDING_MISSING naming the original ID. The known-good registry test passes on
restored bytes.

## Disposition boundary

The registry carries 57 required R19/R20/R21 finding IDs. Two explicitly named premises are
FALSE_POSITIVE because the current source contradicts the premise or the ID is absent. Four rows
remain LINKED_CHILD because their implementation is outside this reconciliation bead. All other
rows are FIXED as plan-authority corrections with a checked-in remediation pointer.

NO-CLAIM: this evidence proves registry shape, command reachability, and current plan metadata only.
It does not prove the runtime product is shipped, that PROJECTED surfaces exist, or that an
UNPROVEN completion consumer is wired.

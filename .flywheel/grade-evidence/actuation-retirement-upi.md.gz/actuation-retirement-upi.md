# omp-orchestrator-actuation-no-caller-upi — retirement receipt

## Decision

**RETIRED.** `dispatch-actuation` has no tracked crate, no workspace member, and no current caller. Its useful taxonomy is folded into the existing `omp-orchestrator` consumer vocabulary rather than preserved as an unwired scaffold.

## Evidence

- `git ls-files crates/dispatch-actuation` returned no output.
- A workspace search for `dispatch-actuation|dispatch_actuation|ActuationOutcome|select_bead|is_busy_status_line|is_idle_prompt` returned no current source/Cargo/docs reference. The only historical occurrence is the bead ledger itself.
- Direct local `cargo metadata --format-version 1 --no-deps --offline` parsed successfully and returned `packages=26`, `members=26`; its member list contains no `dispatch-actuation`.
- The consumer remains real and typed: `crates/omp-orchestrator/src/lib.rs:168-196` owns `PaneObservation`, `QueueState`, and `Observation`; `:211-223` owns `GateReachability`; `:428-518` owns `SupervisorDecision` and its typed refusal/dispatch outcomes; `:995-1055` owns `Duty`/`Discharged`. The resident path parses `br ready` and makes the decision in `crates/omp-orchestrator/src/main.rs`.
- `docs/plan/03-crates.md:80` records `omp-orchestrator` as the resident `observe → dispatch → receipt → escalate` consumer with its actual dependency list. The former dispatch-actuation names are not listed as a current crate.

## Taxonomy fold

| retired shape | surviving consumer shape |
|---|---|
| `Lane` / dispatchable pane state | `PaneObservation::{is_dispatchable,is_free_capacity,is_working}` |
| `Dispatch` / queue result | `Observation`, `QueueState`, and `SupervisorDecision::Dispatch` |
| `Refusal` / unavailable conditions | `GateReachability` and typed `SupervisorDecision` refusal variants |
| `ActuationOutcome` | `Duty`/`Discharged` plus resident receipt/escalation path |
| `select_bead` | resident `br ready` parsing and selection in `omp-orchestrator` |
| `is_busy_status_line` / `is_idle_prompt` | `PaneObservation` liveness fields and tick-monitor's consumed observation contract |

This is a clean retirement, not a claim that the full runtime actuation path is complete. The consumer
source explicitly says subprocess wiring is designed but runtime-unverified; that is a separate
boundary owned by the orchestrator work.

## Closeout

No source or Cargo manifest edit was required for this bead because the target crate and all inbound
edges are already absent. The open bead is the duplicate tracking row for a retirement already recorded
by `omp-orchestrator-024`; this receipt makes the metadata and taxonomy-fold evidence explicit for the
current bead.

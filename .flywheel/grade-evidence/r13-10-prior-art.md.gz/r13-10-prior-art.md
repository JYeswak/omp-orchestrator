# Round 13 repair evidence — 10-prior-art

Round-12 findings from /tmp/grade/r12-10-prior-art.md are all addressed below. The corrected mirror searches were replayed without cargo, gates, formatters, or tests.

## Finding 1 — BLOCKER — invalid grep dialect/provenance

**Round-12 target:** docs/plan/10-prior-art.md:51,143,159,163,175.

**Verdict: FIXED.** Every alternation/grouping search now uses ERE via `grep -E`; Gap 8's non-POSIX `\w` is replaced with `[[:alnum:]_]`; the tool-probe literal parentheses are escaped. Gap 3's Go search uses `-I` to skip binary data while retaining the no-source-extension-filter boundary. The section points to this artifact for replay evidence.

### Replay receipts (exact command, stdout digest, line count, exit status)

1. **C1, Gap 1**
   `grep -Ern 'pub (struct|enum) (PublishReceipt|AckKind|DeliveryClass|PublishPermit)' /Volumes/ZestData/dicklesworthstone-mirror/asupersync/src/messaging`
   - stdout SHA-256: `d79421fd766c1a9fb8dcabac49da88ef7e88f2e9247596c2f5e2c6e9c9c06935`
   - stdout lines: 7; exit status: 0
   - exact output:
     `fabric.rs:1913 PublishReceipt`; `fabric.rs:1945 PublishPermit`; `capability/tokens.rs:164 PublishPermit`; `class.rs:17 DeliveryClass`; `class.rs:83 AckKind`; `class.rs:139 DeliveryClassPolicy`; `class.rs:233 DeliveryClassPolicyError` (the replay emitted absolute root-prefixed paths).

2. **C2, Gap 7 mirror negative**
   `(cd /Volumes/ZestData/dicklesworthstone-mirror/asupersync/src && grep -En 'pub enum (ChildExit|ExitReason|ChildOutcome|SupervisionEvent|ChildStatus)' supervision.rs gen_server.rs spork.rs)`
   - stdout SHA-256: `53094ed1696f63cba83d1a16d69b901bb6920242a688b36ca96fa14313296963`
   - stdout lines: 1; exit status: 0
   - exact output: `supervision.rs:3122:pub enum SupervisionEvent {`.

3. **C3, Gap 8 Rust-only negative**
   `(cd /Volumes/ZestData/dicklesworthstone-mirror && grep -Ern '(adapter|Adapter)[[:alnum:]_]*(registry|Registry|scope|Scope)|per-adapter' beads_rust/src eidetic_engine_cli/src)`
   - stdout SHA-256: `01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b`
   - stdout lines: 1 (the newline emitted by the capture wrapper); exit status: 1, no matching lines.

4. **C4, Gap 8 Go vocabulary**
   `(cd /Volumes/ZestData/dicklesworthstone-mirror && grep -ErnI 'ErrNotInstalled|DEPENDENCY_MISSING' ntm)`
   - stdout SHA-256: `fe6aa41e79058ec0f119c502d6ebf1917bf5488d93dbfac06670e84742d6c087`
   - stdout lines: 93; exit status: 0.
   - exact output is the 93-line stdout addressed by the command and digest above; cited rows include `ntm/internal/bv/bv.go:31`, `ntm/internal/cass/client.go:13`, `ntm/internal/caut/client.go:14`, `ntm/docs/robot-action-handoff-contract.md:379`, and `ntm/internal/cli/bugs.go:85-89`.

5. **C5, Gap 9 tool probe**
   `(cd /Volumes/ZestData/dicklesworthstone-mirror && grep -En 'PresenceOnly|ProbeExecution|fn check_tool|fn probe_failure_is_known_nonfatal|fn which_tool|status.success\(\)' pi_agent_rust/src/doctor.rs)`
   - stdout SHA-256: `b698adac8b1fab972b80720330dd95ec36920b62293f48a5fe5ade47089a977c`
   - stdout lines: 19; exit status: 0.
   - exact output includes lines 863, 871, 881, 889, 903, 913, 920, 921, 924, 933, 950, 1052, 1066, and 10540, matching the named constructs in the section.

## Finding 2 — MAJOR — unsupported projected seven-count

**Round-12 target:** docs/plan/10-prior-art.md:39 and :207.

**Verdict: FIXED.** Removed the unsupported `PROJECTED 7` session count and its repeated “seven refuted not-founds” claim. The section now reports only **MEASURED 4** named false-zero mechanisms that are visibly enumerated in §0.1/line 43 and explicitly makes no session-count or completeness claim. The correction arithmetic `6/9` remains labeled PROJECTED document comparison and is unrelated to mirror coverage.

## Finding 3 — MAJOR — unsupported local seed premises

**Round-12 target:** docs/plan/10-prior-art.md:91 and :141.

**Verdict: FIXED.**

- **Gap 4, line 91:** relabeled as a historical seed premise and added the current exact probes `command -v omp-inventory-map` and `omp-inventory-map --help`. Current checkout result: no executable, shell status 127, only the shell's command-not-found diagnostic; captured-output SHA-256 `e7f99353a1c4a87853d1710c7b0f319cd8545a349fd0943633238cfad162c9df`. The section now states a NO-CLAIM that current absence neither reproduces nor disproves the historical CONFIG_ERROR.
- **Gap 7, line 141:** relabeled as a historical document premise and tied to `docs/plan/00-brief.md §4` with SHA-256 `84569dd180bad9dd7ee6c90fde86fc5ee0d55be46253aa2dd6c9244aa1efd502`. It now states that the historical text is not a current runtime observation and adds explicit NO-CLAIMs about reproducibility and worker-mode coverage.

## NUMBERS.toml check

Inspected NUMBERS.toml as required. It has no declared figure key for this section's false-zero count or the removed seven-count. No registry edit is needed: the unsupported count was removed rather than made a new shared figure.

## Diff location summary

- docs/plan/10-prior-art.md:39 — seven-count removed; measured four named mechanisms retained.
- docs/plan/10-prior-art.md:51 — Gap 1 search changed to `grep -Ern`.
- docs/plan/10-prior-art.md:91 — Gap 4 historical/current probe boundary and receipt added.
- docs/plan/10-prior-art.md:141 — Gap 7 historical Brief citation/hash and NO-CLAIM added.
- docs/plan/10-prior-art.md:143 — Gap 7 mirror search changed to `grep -En`.
- docs/plan/10-prior-art.md:159 — Gap 8 Rust search changed to valid ERE and POSIX character class.
- docs/plan/10-prior-art.md:163 — Gap 8 Go search changed to `grep -ErnI`.
- docs/plan/10-prior-art.md:175 — Gap 9 search changed to `grep -En` with escaped parentheses.
- docs/plan/10-prior-art.md:207 — unsupported seven-count removed from summary.

# R11 FIX LOG — 03-crates.md — SilverWolf (%1409)

Round-10 source: /tmp/grade/r10-03.md (capability floor, 1 finding — verified by me against the
auditor's report with an independent python walk after fixing a double-append bug in my own
verification script).

## FIXED (2 sites, one finding)
- f1 (capability-floor un-conversion): the unsafe-forbid triple (20/26 manifest, 19 both, 6
  attribute-only) was stale in the §-body (:92-101) and the R11 constraint row (:374-381).
  Measured tonight: **26/26 manifests, 25 both, tick-monitor the only manifest-only, zero
  attribute-only** — six crates (composer-typed, dispatch-silence-watch, loop-queue-filter,
  no-shell-gate, pane-dispatch-fence, subprocess-contract) adopted the manifest lint after the
  section was first written.
  - §-body: rewritten with the regenerated triple, the six adopters named, and the finding
    UPGRADED rather than softened — coverage moved from "two habits with no single enforcement
    point" to "one habit, uniformly adopted, still with no enforcement point" (nothing fails if
    crate 27 keeps the attribute and drops the manifest line).
  - R11 constraint row: rewritten to the same numbers with the straggler (tick-monitor) named.
  - Mid-edit repair: the R11 rewrite left a duplicated tail from the old sentence; caught on
    re-read (the 232 re-read rule) and cut.

## NUMBERS.TOML
- ADDED `[figures.unsafe_both_mechanisms]` (expect 25): the both-mechanisms count is the
  highest-rotation statistic in the plan (19 → 25 in one round) and the gate text depends on it.
  Command re-derives manifest-lint AND inner-attribute per crate. Registry was already carrying
  the orchestrator's six additions (test_functions=406, surface_engaged_pct, convergence_rows,
  etc.) — no duplicate added for those.

## VERDICT: 1 finding — fixed. 0 retracted. 0 deferred.

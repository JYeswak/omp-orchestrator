# Round 13 repair evidence — 11-lifecycle

Source report: `/tmp/grade/r12-11-lifecycle.md`
Assigned section: `docs/plan/11-lifecycle.md`

All eight Round-12 findings are addressed below. No cargo command, gate, formatter, or test was run. The two embedded jq derivations were executed against the named snapshot and returned exit 0.

## Findings and verdicts

1. **MAJOR — S5 dispatch `Y` inflated lifecycle coverage**
   - Verdict: **FIXED**.
   - Diff location: `docs/plan/11-lifecycle.md:94,100-107`.
   - The matrix now marks S5 dispatch `y` with an explicit source/design-only and runtime-not-verified qualifier. The visible count is recomputed from four to three `Y` cells (S4 logging, S6 logging, S6 build grading); the prose no longer treats the unverified dispatch path as observed runtime use.

2. **MAJOR — batch filter did not enforce integer type**
   - Verdict: **FIXED**.
   - Diff locations: `docs/plan/11-lifecycle.md:267-298` (scoped policy and explicit `in_scope` jq predicate), `docs/plan/11-lifecycle.md:303-318` (frozen-input output), and `docs/plan/11-lifecycle.md:324-339` (WIRE grouping predicate).
   - Both commands now use `type == "number"`, equality with `floor`, and the inclusive 1–9 range. The output reports `excluded_batch_type 0`, `excluded_non_integer_batch 0`, and `excluded_numeric_out_of_range 321`; the scoped count remains 270. The grouped WIRE command uses the same predicate and snapshot.

3. **MAJOR — 544-row denominator was not reproducibly derived**
   - Verdict: **FIXED by explicit declaration boundary**.
   - Diff locations: `docs/plan/11-lifecycle.md:262-269` and `docs/plan/11-lifecycle.md:303-306`.
   - The section now labels 544 as a `DECLARED` R14/R15 review denominator rather than measured output. It names the frozen input and SHA-256 (`f155a358dd302982367a7c0107fe0eb1e3cd6f5ec7d4689bac67f11b1c5063f7`) and derives the current snapshot total of 591 plus the scoped 270 rows. The text no longer implies that 544 came from the current `SURFACE-MAP.jsonl` command.

4. **MINOR — “installer covers 3 of 18 binaries” lacked an inventory derivation**
   - Verdict: **FIXED by declaration boundary**.
   - Diff location: `docs/plan/11-lifecycle.md:52`.
   - The ratio is now explicitly `DECLARED (R10)`, and the missing denominator inventory/counting rule is stated. Foreign-host `--install` remains separately identified as unverified.

5. **MINOR — skill inventory counts lacked raw output/counting derivation**
   - Verdict: **FIXED by declaration boundary**.
   - Diff locations: `docs/plan/11-lifecycle.md:370-372`.
   - The 12 operational rows / 18 references / 16 unique names are now explicitly declared R10 output, with the missing raw output and counting derivation stated; they are not presented as independently reproducible measured evidence.

6. **MINOR — eleven pane-scrollback decisions were unaddressable**
   - Verdict: **FIXED by removing unsupported cardinality**.
   - Diff location: `docs/plan/11-lifecycle.md:464-466`.
   - The exact count is removed. The section now reports only human decision activity, states that no pane/session artifact or extraction/count procedure was preserved, and makes no numeric claim; it remains evidence of decision loss rather than ledger evidence.

7. **MINOR — normative S9 requirement was unmarked under a measured-default section**
   - Verdict: **FIXED**.
   - Diff location: `docs/plan/11-lifecycle.md:76-77`.
   - The sentence now carries `PROJECTED REQUIREMENT` and explicitly says no current emitter or consumer was measured.

8. **MINOR — cardinality table presented static facts as observed runtime cardinalities**
   - Verdict: **FIXED**.
   - Diff locations: `docs/plan/11-lifecycle.md:472-476`.
   - The lead-in identifies source/configuration facts, says no captured multi-session runtime probe is presented, reserves `observed` for such a probe, and renames the column to `source-derived/static behavior`.

## NUMBERS.toml inspection

`NUMBERS.toml` was inspected and not edited, per assignment. Existing declarations relevant to this repair:

- `NUMBERS.toml:12` already flags the “18 binaries” figure as drift-prone (`cargo says 21`); the lifecycle section now preserves 18 only as an explicitly declared R10 ratio.
- `NUMBERS.toml:47-51` declares the current `SURFACE-MAP.jsonl` universe as 591, matching the frozen snapshot/hash and repaired derivation.
- No registry entry for the 544-row R14/R15 denominator was found. **Registry follow-up needed (not performed):** either add a named `r14_r15_surface_universe` declaration with its source artifact and hash, or retire the 544 figure. The section intentionally marks it `DECLARED` until that shared-registry decision is made.

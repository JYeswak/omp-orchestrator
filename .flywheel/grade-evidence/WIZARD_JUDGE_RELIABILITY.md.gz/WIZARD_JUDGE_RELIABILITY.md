# Reliability judgment: 1:many orchestration candidates

## Verdict

The mission is not “nine more stage descriptions.” It is a control plane that preserves identity, causality, policy, and proof when one parent run creates many child sessions. The current plan explicitly asks for 1:1 and 1:many NTM orchestration, from new-project inception through ship, with durable human requirements and an Amazing bar at every layer (`docs/plan/12-journey.md:3-7`). It also explicitly says S9 is cross-cutting and that eleven decisions were lost to pane scrollback (`docs/plan/12-journey.md:35-38`).

The six survivors below are **capabilities/contracts**, not six new stages or six new crates. They should be attached to the existing seams. This is important because §11.7 measured 243/270 mapped surfaces as RETIRE, seven selection surfaces converged on `loop-queue-filter`, and `omp-types` has zero dependents (`docs/plan/11-lifecycle.md:180-231`, `:284-286`). Rewriting the 26-crate inventory would be the wrong response.

The strongest finding is that lifecycle completion is only partly real: `AgentEndEvent` crosses `--mode=rpc`, but the plan still describes adoption into the supervisor as the remaining work (`docs/plan/11-lifecycle.md:136-153`, `:297-300`). A type declaration or captured frame is not a consumed capability.

## Scoring method

`F/R/P/H/U` are 0–5 scores for, respectively:

- **F** — fan-out/fan-in correctness;
- **R** — restart, reattach, replay, and stale-incarnation safety;
- **P** — partial failure, ambiguity, and missing-child handling;
- **H** — human decision durability and authority preservation;
- **U** — upstream reachability, semantic fit, and reuse discipline.

`Q` is six 0–2 checks in the order **missing / accretive / concrete refusal / real evidence / month-three value / plausible owner+artifact**. Scores are the judge’s prioritization, not new measurements.

## Twenty deduplicated candidates

The source wizards proposed overlapping names for identity, replay, bootstrap, requirements, and adoption. Those are collapsed here rather than counted as separate features.

| Rank | Candidate | F/R/P/H/U | Q: M/A/R/E/M3/O | Evidence and month-three failure | Plausible owner/artifact | Exact refusal | Decision |
|---:|---|---:|---:|---|---|---|---|
| 1 | **Event-driven child lifecycle reducer**: terminal vs continuation, idle settlement, stop, roster epoch | 5/5/5/1/5 = **21** | 2/2/2/2/2/2 | `AgentEndEvent.willContinue` is wire-proven; S6→S7 is still unwired, S7 reap was hand-run, and `GuestIdleReconcilerCtx`/`HubRosterCounts` remain declaration-only (`docs/plan/11-lifecycle.md:131-153`; `docs/plan/00-brief.md §3.8`). | `omp-orchestrator` supervisor plus existing `reap-finished-panes`; artifact: replayable `ChildLifecycleEvent` reducer projection. | **Refuse** `willContinue=true` as terminal, `idle == done`, a late idle event reopening a terminal child, or stale-roster capacity becoming current. | **Survivor 1**, combined with #2. |
| 2 | **Parent child-manifest and fan-in policy**: expected targets, required/optional children, `all`/quorum/waiver | 5/4/5/2/2 = **18** | 2/2/2/2/2/2 | The journey leaves one artifact per stage and no cardinality/aggregate contract (`docs/plan/12-journey.md:25-38`); M5 describes ten closes but not membership or barriers (`docs/plan/09-milestones.md:150-155`). | `omp-orchestrator` conductor; artifact: `ParentRunManifest` plus child rows and aggregate verdict. | **Refuse** parent `COMPLETE` while any required child is `LOST`, `UNKNOWN`, `UNVERIFIED`, or outside the declared barrier; never infer quorum from arrival order. | **Survivor 1**, combined with #1. |
| 3 | **Scoped identity, lineage, and ownership fencing** across project/fleet/parent/child/repo/session/pane/stage/bead/attempt/epoch | 5/5/4/2/3 = **19** | 2/2/2/2/2/2 | The observed system had eight sessions sharing state; upstream `Stage1Claim`/`GlobalClaim` provide vocabulary but are declaration-only and are memory claims, not bead custody (`docs/plan/00-brief.md §3.8`; `docs/plan/11-lifecycle.md:86-90`). | `dispatch-claim-fence` + `pane-dispatch-fence`; artifact: scoped mutation envelope and lease/epoch record. | **Refuse** dispatch, write, close, or reap when repo/root/parent/child/attempt/epoch does not match; a recycled pane or stale epoch may observe but never mutate. | **Survivor 2**, combined with #14. |
| 4 | **Causal dispatch outbox and delivery receipts**: packet hash, intent, target, receipt state | 5/5/5/1/4 = **20** | 2/2/2/2/2/2 | `cp-z42vu` returned `success:[N]` with no packet; `IrcDeliveryReceipt` and `AsyncJobDeliverySink` are named upstream but DECLARED ONLY (`docs/plan/09-milestones.md:111-127`; `docs/plan/00-brief.md §3.8`). | `fast-dispatch`/`tick-dispatch` with `omp-orchestrator`; artifact: durable `DispatchIntent` outbox with `prepared/accepted/delivered/unknown` states. | **Refuse** marking delivery from transport success without a matching packet receipt; `unknown` and `expired` require reconciliation, never silent success. | **Survivor 3**, combined with #5. |
| 5 | **Idempotent logical commands and ordered effect replay**: stable intent/attempt IDs, duplicate and late-event handling | 5/5/5/2/3 = **20** | 2/2/2/2/2/2 | Observe→decide→dispatch→record has multiple crash points; only three of nine lifecycle stages log anything and pane scrollback loses real conditions (`docs/plan/11-lifecycle.md:43-56`; `docs/PLAN.md:52-55`). | Same dispatch/reducer seam as #4; artifact: applied/pending effect ledger keyed by `(parent, child, attempt, sequence)`. | **Refuse** applying a duplicate, late, or out-of-order event twice; retries reuse the logical intent and cannot create a second child close. | **Survivor 3**, combined with #4. |
| 6 | **Append-only human-requirement ledger** with source, scope, owner, status, acceptance, evidence, and supersession | 4/5/3/5/2 = **19** | 2/2/2/2/2/2 | Requirements were put in the brief because seven real conditions lived only in scrollback (`docs/PLAN.md:52-61`); S9 explicitly reports eleven lost decisions (`docs/plan/12-journey.md:35-38`). | `omp-orchestrator`/`omp-types`; artifact: versioned requirement registry linked into beads, packets, events, and closes. | **Refuse** dispatch or transition when the active requirement is absent, stale, ownerless, unscoped, or only paraphrased. | **Survivor 4**, combined with #7 and #8. |
| 7 | **Human approval, conflict, supersession, and expiry semantics** | 3/5/3/5/1 = **17** | 2/2/2/2/2/2 | `human_touch_count == 0` measures absence of touch, not authorization (`docs/plan/09-milestones.md:129-155`); the brief says requirements are authoritative until superseded but does not define an immutable history (`docs/plan/00-brief.md:61-68`). | Requirement ledger owner; artifact: scoped approval token containing actor, requirement revision, target, expiry, and allowed action set. | **Refuse** inferred approval, stale approval reuse, silent overwrite, or action while two active requirements conflict. | **Merge into Survivor 4**; not a separate approval stage. |
| 8 | **Restart/compaction checkpoint and portable evidence bundle** | 4/5/4/4/3 = **20** | 2/2/2/2/2/2 | `SessionBeforeCompactEvent` and `SessionCompactEvent` are DECLARED ONLY; the plan’s strongest completion evidence is a raw `/tmp` frame, not a portable run bundle (`docs/plan/00-brief.md §3.8`; `docs/plan/11-lifecycle.md:297-300`). | `omp-orchestrator`/`verify-dispatch`; artifact: content-addressed checkpoint containing requirements cursor, leases, event watermark, repo identity, and redacted evidence. | **Refuse** resume, reap, or close when pending/applied effects, requirements, leases, or upstream cursors cannot be reconstructed exactly. | **Merge into Survivor 4**; use a local checkpoint until compaction events are truly reachable. |
| 9 | **Transactional foreign-repository inception capsule**: inventory, deterministic write set, staging, atomic apply, undo | 2/4/4/3/2 = **15** | 2/2/2/2/2/2 | The projected flow writes config/work/gates; the real install history includes false-green no-op behavior (`docs/plan/08-end-users.md:119-133`; `docs/plan/07-installability.md:67-72`). | `installer` plus `commit-build-fence`; artifact: adoption plan/receipt with owned paths, before/after hashes, and inverse operations. | **Refuse** partial writes, unowned paths, ambiguous roots, automatic tracker conversion, or a green exit after a no-op. | **Survivor 5**, combined with #10 and #15. |
| 10 | **Cold-host bootstrap and semantic capability negotiation**, not PATH presence | 4/4/4/2/5 = **19** | 2/2/2/2/2/2 | Installer covers only 3/18 binaries; `tick-monitor` lacks identity; `bv` path assumptions and compile-time `/Users/josh` coupling are measured (`docs/plan/07-installability.md:15-45`; `docs/plan/08-end-users.md:65-70`; `docs/plan/09-milestones.md:105-107`). | `installer`/`tick-monitor`; artifact: capability vector with executable identity, version, verbs, schemas, feature flags, and remediation. | **Refuse** PATH-only availability, unpinned downloads, missing/unknown schema, absent feature gates, and dispatch against an incompatible or stale capability vector. | **Survivor 5**, combined with #9 and #15. |
| 11 | **Tracker adapter and identity-preserving migration** for `br`, GitHub, file tracker, or no tracker | 3/3/4/2/1 = **13** | 2/1/2/2/2/1 | Foreign-repo design treats tracker absence as `ABSENT`, not `FAIL`, but the adapter is projected (`docs/plan/08-end-users.md:72-96`, `:119-128`). | S1 adoption adapter; artifact: read-only census and external-ID/dependency mapping preview. | **Refuse** adoption on duplicate IDs, unmappable dependencies/cycles, or ambiguous source-of-truth; never create a second tracker silently. | **Concession to Survivor 5**: support one adapter path first; no adapter zoo. |
| 12 | **Upstream adoption/reachability registry and schema-drift policy** | 4/4/4/1/5 = **18** | 2/2/2/2/2/2 | Only `AgentEndEvent` is WIRE-PROVEN; receipts, claims, idle, roster, cost, and compaction families are DECLARED ONLY (`docs/plan/00-brief.md:491-511`). `AckKind`/`DeliveryClass` are behind `messaging-fabric → test-internals` (`docs/plan/09-milestones.md:75-80`). | `omp-orchestrator` adapters plus `installer`; artifact: per-type adoption card with source revision, carrier, feature requirements, semantic tests, and status. | **Refuse** promoting a type from declaration/grep/type-check to consumed; unknown versions/features/wire paths stay `DECLARED ONLY` or `BLOCKED`, with no silent fallback. | **Survivor 6**. |
| 13 | **Typed plan → bead → dispatch compilation** with requirement links, dependencies, scope, and done probe | 4/3/3/4/3 = **17** | 2/2/2/2/2/2 | The seven-field journey contract is specified but the file ends with `STAGES S1-S9 ARE FILLED BY THE WAVE`; §11.8 says only S3/S4 outputs are typed and `omp-types` has zero dependents (`docs/plan/12-journey.md:40-65`; `docs/plan/11-lifecycle.md:258-286`). | `omp-types`/`omp-orchestrator`; artifact: machine-readable stage/bead/packet schema, initially emitted at existing handoffs. | **Refuse** dispatching prose-only plans, beads without requirement/dependency links, or packets without scope and a machine-checkable done signal. | **Concession**: minimal schema fields inside the six survivors; do not build a seventh “compiler stage.” |
| 14 | **Canonical repository/worktree identity at admission** | 4/5/4/2/2 = **17** | 2/2/2/2/2/2 | Installed behavior can audit the build checkout instead of the adopter; the plan only sketches `git rev-parse HEAD` and dirty state (`docs/plan/08-end-users.md:65-84`). | `installer` admission plus Survivor 2 lease; artifact: Git common-dir/worktree/root/HEAD identity record. | **Refuse** dispatch/write/close when root, common dir, worktree, submodule boundary, or admitted HEAD changed or is ambiguous. | **Merge into Survivor 2**; admission identity and live fencing are one safety boundary. |
| 15 | **Independent fresh-project acceptance run** on clean host and foreign repo | 5/5/5/4/4 = **23** | 2/1/2/2/2/2 | Foreign adoption and M6 are PROJECTED/never attempted (`docs/plan/08-end-users.md:6-21`; `docs/plan/09-milestones.md:172-204`); four false-zero measurements required sibling re-derivation (`docs/plan/09-milestones.md:243-246`). | `installer` + independent `verify-dispatch` grader; artifact: portable transcript for clean/non-Rust/no-tracker/monorepo/dirty/1:many fixtures. | **Refuse** “portable,” “adopted,” or “ship-ready” claims from a warm local run, worker self-report, or same checkout alone. | **Survivor 5** as the acceptance half of the adoption boundary, not a generic dashboard/gate. |
| 16 | **Anti-vacuity and omission inventory**: bad pre-state, good post-state, mutation break, production seam, external expected rows | 3/4/4/3/3 = **17** | 2/1/2/2/2/1 | All 183 census rows had mandatory fields yet only one distinct `must_be_true`; the production parser never consumed `NewlyIdle` while a test constructor did (`docs/plan/09-milestones.md:24-31`, `:67-85`). | Independent acceptance/adoption fixture owner; artifact: fixture matrix and expected-row inventory. | **Refuse** a pass when the known-bad pre-state already passes, mutation does not fail, or the fixture bypasses the production seam. | **Concession** to Survivor 5/6; useful fixture discipline, not a standalone subsystem. |
| 17 | **Backpressure, fairness, budget, and refusal-storm control** | 5/3/5/2/2 = **17** | 2/2/2/2/2/2 | `DISPATCH_RETRY_BLOCKED` persisted for 162 ticks over 4.2 hours; M7 explicitly warns against loops that merely widen tolerance (`docs/plan/09-milestones.md:157-169`, `:206-219`). | `tick-monitor`/`loop-queue-filter`/`omp-orchestrator`; artifact: admission ledger with per-parent/per-repo concurrency, retry, and refusal budgets. | **Refuse** retrying a refusal class past its threshold without state change, owner, escalation, or explicit override; heartbeat-only ticks are not progress. | **Concession**: retain bounded admission and `budget_exhausted` in Survivors 3/5; defer fairness tuning. |
| 18 | **Economics/operator-time SLO**: cost per verified close versus manual baseline | 3/3/4/1/2 = **13** | 2/1/2/2/2/1 | Outcome/baseline/target and verification-cost instrumentation are open; the 162-tick refusal storm is already an economic warning (`docs/plan/00-brief.md:802-823`; `docs/plan/09-milestones.md:157-169`). | `tick-monitor` metrics; artifact: budget fields and useful-close/operator-minute counters. | **Refuse** a mode whose measured operator minutes plus agent/compute cost exceed its manual baseline. | **Kill as a standalone candidate**; retain a hard budget field, not a metrics program. |
| 19 | **Adopter-derived gate profile and exception ownership** | 3/3/4/2/2 = **14** | 2/2/2/2/2/1 | The projected adopter flow skips `path-literal-guard` because it has known-bad but no known-good leg; Q13 records the `.git/hooks` coverage ambiguity (`docs/plan/08-end-users.md:119-133`; `docs/plan/11-lifecycle.md:99-127`). | `installer`/`no-shell-gate`; artifact: applicability matrix and allowance rows with owner, reason, expiry, re-enable condition. | **Refuse** claiming coverage for an uninventoried surface or silent/ownerless exception; no `--gates=none` without residual risk. | **Concession** to Survivor 5; do not create a second gate framework. |
| 20 | **Adoption funnel and retention signal**: install → doctor → first useful tick → verified close → repeat use | 2/2/2/2/1 = **9** | 2/0/2/1/1/1 | Adoption is PROJECTED and there is no external run (`docs/plan/08-end-users.md:6-10`, `:46-47`), but activation analytics do not repair fan-in, restart, or reachability. | `installer` receipt can record first-close timestamp; artifact: a few lifecycle fields, not a dashboard. | **Refuse** calling the product adopted from install or one green internal run alone. | **Kill as a standalone candidate**; keep first verified close in Survivor 5’s receipt. |

## The six survivors

### Survivor 1 — Typed child lifecycle plus explicit parent fan-in

**Combine:** candidates 1 and 2.

**Why it survives:** This is the direct product invariant. A 1:many run is not a 1:1 loop repeated N times. The parent must know the expected child set, and the reducer must know whether each child is terminal, continuing, idle-settling, stopped, missing, or unknown. Otherwise one child’s success can become a false parent success, or one optional child can deadlock the run.

**Owner/artifact:** `omp-orchestrator` owns the parent projection; the existing `reap-finished-panes`/supervisor seam consumes events. The artifact is a `ParentRunManifest` plus durable child rows and a replayable reducer projection. If a shared type is needed, put the minimal envelope in `omp-types`, which currently has zero dependents (`docs/plan/11-lifecycle.md:284-286`); do not refactor all 26 crates.

**Upstream reuse:** Consume the wire-proven `AgentEndEvent` and preserve `willContinue`; keep `SessionStopEvent`, `GuestIdleReconcilerCtx`, and `HubRosterCounts` at their honest declaration-only status until each path is proven (`docs/plan/00-brief.md §3.8`; `docs/plan/11-lifecycle.md:142-153`).

**Exact refusal:**

> Refuse parent `DONE` unless the declared `all`/quorum/waiver barrier is satisfied and every required child has an evidenced delivery and terminal/continuation outcome. Refuse `willContinue=true` as terminal, `idle == done`, implicit quorum, stale roster capacity, sibling mutation, and a late event reopening a terminal child.

**Adequate mode:** Run one child at a time, or expose `PARTIAL/UNKNOWN`, until parent aggregation is proven. It is better to refuse fan-out than to report parent-green/child-missing.

### Survivor 2 — Scoped repository/run identity with leases and fencing

**Combine:** candidates 3 and 14.

**Why it survives:** A correct reducer cannot save a cross-repo or stale-pane write. Every effect needs an identity tuple and an ownership epoch. The plan’s existing claim vocabulary is not enough: `Stage1Claim`/`GlobalClaim` are memory-claim types, while bead custody remains `ntm claim` plus the local fence (`docs/plan/11-lifecycle.md:86-90`).

**Owner/artifact:** Extend `dispatch-claim-fence` and `pane-dispatch-fence`; use the `installer` admission path to establish Git common-dir/worktree/root/HEAD identity. The artifact is a scoped mutation envelope and short-lived lease record containing project, fleet, parent, child, repo, session, pane, stage, bead, attempt, and ownership epoch.

**Upstream reuse:** Reuse local `ntm claim`/fence semantics; do not pretend `Stage1Claim` transfers. The `ntm dispatch` template already requires `objective` and `target` and fails closed on omission (`docs/plan/11-lifecycle.md:62-95`).

**Exact refusal:**

> Refuse dispatch, write, commit, close, or reap if the target root/worktree/HEAD, parent-child lineage, lease, attempt, or ownership epoch is absent, changed, ambiguous, or stale. A recycled pane may observe but cannot mutate.

**Adequate mode:** Support one explicitly admitted repo/fleet scope; refuse multi-project operation rather than using an unscoped “current run.”

### Survivor 3 — Causal dispatch outbox with receipts and idempotent effects

**Combine:** candidates 4 and 5.

**Why it survives:** `success:[N]` is not delivery. Fan-out multiplies every ambiguous send, and a conductor crash can occur between decision, send, receipt, and record. Transport evidence and effect idempotency must be one logical command contract, not two unrelated logs.

**Owner/artifact:** `fast-dispatch`/`tick-dispatch` and `omp-orchestrator` own a durable outbox. The artifact is `DispatchIntent` with target scope, packet hash, logical intent ID, attempt, deadline, budget reservation, receipt state, and applied-effect watermark. Use the existing `ntm template` instead of hand-rolled packets (`docs/plan/11-lifecycle.md:60-95`).

**Upstream reuse:** Probe `IrcDeliveryReceipt` and `AsyncJobDeliverySink`; both are DECLARED ONLY. Until reachable, retain a local `unknown` state and do not claim receipt adoption (`docs/plan/00-brief.md §3.8`).

**Exact refusal:**

> Refuse `DELIVERED` without a receipt correlated to the exact intent, target, and packet hash. Retries reuse the logical intent ID and dedupe key; refuse blind resend, a new logical child for the same intent, duplicate effect application, or conversion of `UNKNOWN`/`EXPIRED` into success.

**Adequate mode:** At-least-once transport with explicit `UNKNOWN` and operator/reconciler action. Never downgrade ambiguity to green merely to keep a dashboard clean.

### Survivor 4 — Durable human contract with approval and checkpointed replay

**Combine:** candidates 6, 7, and 8.

**Why it survives:** This is the only way S9 becomes a control rather than prose. Requirement storage, approval authority, conflict/supersession, and restart replay are the same invariant: a resumed child must receive the exact active human contract and must not reuse authority for an older scope.

**Owner/artifact:** `omp-orchestrator`/`omp-types` own a versioned, append-only requirement/decision registry; `br` remains the work record where appropriate (`.beads/issues.jsonl`, noted in `docs/plan/11-lifecycle.md:43-56`). The companion `RunCheckpoint` contains the requirement revision, approval records, child leases, event watermark, repo identity, pending refusals, and content-addressed evidence references.

**Upstream reuse:** `SessionBeforeCompactEvent`/`SessionCompactEvent` remain DECLARED ONLY until their actual wire path is proven. Local checkpoints are acceptable but must be labeled local and non-upstream; the plan explicitly distinguishes declaration from consumption (`docs/plan/00-brief.md:491-511`).

**Exact refusal:**

> Refuse dispatch, close, ship, or resume when the requirement is chat-only, paraphrase-only, stale, ownerless, conflicting, outside its scope hash, implicitly approved, or absent from a reconstructable checkpoint. Refuse resuming when pending and applied effects cannot be distinguished.

**Adequate mode:** Durable IDs, verbatim source/hash, owner, and manual approval are enough initially; semantic diffing can wait. Unresolved blocking decisions must still prevent ship.

### Survivor 5 — Foreign-adoption admission: transactional bootstrap, capability negotiation, and clean-room acceptance

**Combine:** candidates 9, 10, 15, and the production-seam part of 16.

**Why it survives:** The product promise is explicitly other projects, repos, and machines, but the adopter journey is PROJECTED, there is no adopter-facing `doctor`/`init`/`adopt`, the installer covers only 3/18 binaries, and the foreign-machine run has never been attempted (`docs/plan/08-end-users.md:6-21`; `docs/plan/07-installability.md:15-45`; `docs/plan/09-milestones.md:172-204`). A local happy path cannot establish adoption.

This is one boundary, not a new stage: profile → capability admission → reversible apply → first 1:1/1:many acceptance trace. The acceptance fixture is part of the boundary because otherwise “bootstrap works” becomes another unconsumed mechanism.

**Owner/artifact:** `installer` and `commit-build-fence` own the write/undo path; `tick-monitor` emits runtime capability facts; an independent `verify-dispatch` process consumes the resulting receipt. The artifact is an `AdoptionProfile` plus portable receipt containing target repo identity, dirty paths, selected adapters/gates, owned writes, before/after hashes, capabilities, expected refusals, and first verified close. Fixtures must include non-Rust, no-tracker, pre-existing tracker, monorepo/worktree, dirty tree, missing dependency, and 1:many cases.

**Upstream reuse:** Probe `bv --robot-*`, use `ntm template` dry-run, and preserve `br` as the selected tracker when applicable. The current plan measures zero `bv` invocations and roughly thirty hand-rolled packets (`docs/plan/11-lifecycle.md:60-95`, `:136-140`), so adoption must consume these surfaces rather than recreate queue selection or packet templating.

**Exact refusal:**

> Refuse `READY_FOR_PLANNING`, `ADOPTED`, or `PORTABLE` when the repo/worktree root is ambiguous, the write set is partial/unowned, apply cannot undo, a no-op returns green, capability is PATH-only or incompatible, an existing tracker would be silently duplicated, or a clean foreign-host run has not produced a durable verified close. Never use a compile-time `/Users/josh` path.

**Adequate mode:** Emit `PROFILED_NOT_ADOPTED`, keep activation scoped to `.omp-orchestrator/`, and run one child at a time until the full foreign 1:many fixture is proven. Unsupported gates must be explicit, owned, and reversible.

### Survivor 6 — Upstream capability adoption, reachability, and drift registry

**Why it survives:** This is the anti-rebuild and anti-type-theater control. The plan’s central architectural decision is to attach to an existing plane, but only completion has crossed the wire. Without an adoption card per surface, an upstream type name becomes a false implementation claim or a local duplicate that drifts.

**Owner/artifact:** `omp-orchestrator` owns adapters; `installer` or capability admission owns version/feature checks. The artifact is an `UpstreamAdoptionCard` per type/surface: source revision, carrier, feature gate, semantic mapping, compatibility window, reachability probe, fallback/no-claim boundary, owner, and last evidence.

**Upstream surfaces to track explicitly:**

| Surface | Current status | Judge’s safe use |
|---|---|---|
| `AgentEndEvent` on `RpcSessionEventFrame` | **WIRE-PROVEN**; `AgentEndEvent` is at `dist/types/extensibility/shared-events.d.ts:154` and carries `willContinue` | Consume it, then prove reducer and durable side effect; wire proof alone is not completion. |
| `SessionStopEvent` | Named upstream event; consumption path not established by §11 | Preserve it in the adapter; do not infer missing terminal state from absence. |
| `IrcDeliveryReceipt` (`tools/hub/types.d.ts:8`) and `AsyncJobDeliverySink` (`:84`) | **DECLARED ONLY** | Keep local `UNKNOWN`/reconciliation semantics until a real receipt path is proven. |
| `Stage1Claim`/`GlobalClaim` (`memories/storage.d.ts:20-27`) | **DECLARED ONLY**, memory-claim domain | Do not use as bead custody without a separate semantic and wire proof. |
| `GuestIdleReconcilerCtx`, `HubRosterCounts`, `SearchUsage`, `PerplexityCost`, `ContextUsage`, `SessionBeforeCompactEvent`, `SessionCompactEvent` | **DECLARED ONLY** in `docs/plan/00-brief.md §3.8` | Keep them in the registry as unadopted; use explicit local fallbacks where necessary. |
| `AckKind`/`DeliveryClass` | Feature-gated behind `messaging-fabric → test-internals`, `docs/plan/09-milestones.md:75-80` | Negotiate the feature; do not type-check against an unavailable feature and call it supported. |

**Exact refusal:**

> Refuse to label an upstream surface `AVAILABLE`, `CONSUMED`, or `E2E-PROVEN` from a declaration, grep hit, type check, or captured frame alone. Unknown source revision, discriminant, feature gate, carrier, or semantic fit yields `DECLARED_ONLY`/`BLOCKED`; no silent schema fallback and no duplicate local plane while the sanctioned upstream surface is unproven.

## Explicit kills and concessions

1. **Kill adoption funnel/retention as a standalone feature (#20).** It answers whether people return, not whether a child can be safely joined after restart. Keep only `first_verified_close` and a drop-off reason in Survivor 5’s adoption receipt; do not build a generic dashboard.
2. **Kill economics/operator-time SLO as a standalone subsystem (#18).** The business question is real, but it is not a first-order 1:many correctness primitive. Retain `retry_budget`, `cost_reservation`, `budget_exhausted`, `blocked_ticks`, and `operator_override` in Survivors 3 and 5; defer broad cost telemetry until `SearchUsage`, `PerplexityCost`, and `ContextUsage` are reachable.
3. **Do not create a seventh “anti-vacuity” or “verification” stage (#16).** Put the four-leg fixture rule—known-bad fails, known-good passes, mutation breaks, production seam is exercised—inside Survivor 5’s clean-room acceptance and Survivor 6’s upstream probes. The measured vacuity is real (`docs/plan/09-milestones.md:24-31`, `:67-85`), but another prose gate would reproduce it.
4. **Do not create a separate identity crate (#14).** Admission identity belongs in the foreign-repo profile; live identity and ownership belong in Survivor 2’s existing fence crates. A second identity source would create split-brain.
5. **Do not create a separate approval stage (#7).** Approval tokens, supersession, and expiry are fields and transitions in Survivor 4’s requirement ledger. A final approval paragraph would be exactly the S9 failure already measured.
6. **Do not create a separate replay/evidence product (#8).** Checkpoints and portable evidence are artifacts of the human/restart ledger and foreign-adoption receipt. One durable event lineage is preferable to parallel “audit log,” “transcript,” and “dashboard” truths.
7. **Do not build a tracker-adapter zoo (#11).** Start with a read-only census and one identity-preserving adapter path. `ABSENT` must remain distinct from `FAIL`; unsupported trackers produce an explicit refusal, not a second work graph.
8. **Do not build a new queue-ranking or packet-templating implementation (#13).** The existing `bv` graph and `ntm template` are the reuse targets. Emit only the minimum typed handoff fields required to make the existing surfaces callable and reject incomplete packets.
9. **Do not tune fleet fairness before admission and causality are correct (#17).** A bounded queue, retry budget, and refusal recurrence counter are mandatory; sophisticated fairness/priority aging is a later optimization. A fair scheduler that sends to the wrong repo or reports undelivered work is still wrong.
10. **Do not promote declaration-only upstream types to roadmap commitments (#12).** Each type gets an adoption card and an explicit status. The only currently safe promotion is the wire-proven `AgentEndEvent`; even that still requires supervisor consumption, replay behavior, and durable effect proof.

## Bottom line

The six survivors are the smallest non-ceremonial set that covers the requested failure surface:

1. child lifecycle plus parent fan-in;
2. scoped identity and fencing;
3. causal delivery plus idempotent effects;
4. durable human contract plus restart replay;
5. foreign-adoption admission and clean-room acceptance;
6. upstream reachability and drift discipline.

Everything else is either a field in one of those contracts, a fixture proving one of those contracts, or a later product/operations measure. The system should be allowed to say `UNKNOWN`, `PARTIAL`, `PROFILED_NOT_ADOPTED`, `DECLARED_ONLY`, and `BLOCKED`. It must not say `DONE` because a pane went idle, a transport call returned success, a type exists, a local test passed, or a human decision once appeared in scrollback.
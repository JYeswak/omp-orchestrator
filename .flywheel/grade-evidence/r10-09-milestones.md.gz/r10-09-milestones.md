# Round 10 — 09-milestones.md — adversarial hillclimb

## Fresh dispatch

- **Subagent:** `r10-milestones-hillclimb`
- **JSM selection:** `jsm suggest "milestones lifecycle validation"` was unavailable because bandit recommendations are disabled; exact `jsm search verification-before-completion` selected `verification-before-completion` (v1, Joshua Nowak).
- **Prompt boundary:** the subagent received only `docs/plan/09-milestones.md`, the seven-field dispatchable-stage contract, the MEASURED/PROJECTED/citation/NO-CLAIM claim contract, and a fresh-eyes instruction. It received no prior findings, ledger, or summary.
- **Raw result:** 18 findings in `/tmp/grade/r10-agent-09.json`. One stale line citation was already recorded by R8 evidence; it is treated as reinforcement inside the M1 group, not as a separate new finding.

## Verification performed

The target was not edited. I re-read only the cited target ranges and cited source constructs, then ran focused read-only probes; no cargo, gate, or formatter command ran.

- Exact case-sensitive search for `Trigger|Dispatch packet|Amazing|Adequate|Negative patterns|Skills|Done signal` over `docs/plan/09-milestones.md` returned **0 matches**.
- Re-read target ranges `:13-25`, `:44-75`, `:89-125`, `:129-170`, `:172-214`, `:225-270`, and `:317-323`.
- Re-read the cited `omp-types`, `tick-monitor`, `omp-orchestrator`, `receiver-receipt`, `ack-stage`, `ack-spine`, and `finding-dispatch` constructs. The source reads confirm the target's citations and the reported mismatches: `omp-types` has no pane-state type; the current receipt vocabulary is `ReceiptConfirmed`, not `Delivered`; the orchestrator has normal `Ok(())` paths; `followup_action` maps `VerdictPosted` to `Healthy`; and `finding_for` has no production consumer.
- Read-only board re-derivation using `br list --status <state> --json | jq '.issues | length'` returned `open=23`, `in_progress=23`, `blocked=3`, `closed=30`, confirming the target's `19/22/3/30` “right now” values are stale.
- Read-only `docs/PLAN.md:210-214,532-536` confirms the retired `-V` 5/9 figure and `complete=AVAILABLE, NOT WIRED`; `jq` over `docs/plan/SURFACE-MAP.jsonl` was not needed for this section.

## Verified new findings (deduped: 16)

### M1 — BLOCKER — dispatchable contract and executable done signals
**Target:** `docs/plan/09-milestones.md:13-20,48-51,89-91,111-113,131-132,152-155,174-176,208-211`.
The target has no exact seven-field block and its M1–M7 observables lack artifact identity, runnable input, expected machine result, and exit code. This is confirmed by the exact zero-match search and the target ranges. **Fix:** add all seven fields to every milestone; make each Done signal an artifact/schema plus exact command/input, expected output, exit code, and refusal/known-bad leg. (Raw findings 0–1.)

### M2 — HIGH — M1 shared-type acceptance is dependency-name theater
**Target:** `:46-50`.
`crates/omp-types/src/lib.rs:3-8` contains only asupersync-derived re-exports; `tick-monitor/Cargo.toml:11-14` and `omp-orchestrator/Cargo.toml:16-23` do not depend on `omp-types`. Adding unused manifest lines would satisfy the proposed acceptance without changing either public pane-state type. **Fix:** require a named shared type in both public signatures and compile a real stdout fixture through it, or name the actual type owner. (Raw 2.)

### M3 — HIGH — M1 citations point at adjacent constructs
**Target:** `:67-75`.
The named regression test is at `omp-orchestrator/src/main.rs:1056` (predicate at `:1062-1063`), not `:1049`; the `is_free_capacity` predicate is `:388-389`, not the cited parser line; the wired-lane decision tuple is at `no-shell-gate/tests/wired_lanes.rs:668`, not `:679`. The R8 citation finding is known, but the fresh agent also confirmed the seam-level mismatch. **Fix:** cite construct name plus current line and pin a source revision. (Raw 3; known citation reinforcement not counted separately.)

### M4 — HIGH — M2 queue observable counts the wrong `br` calls
**Target:** `:89-103`.
The six literal `Command::new("br")` sites are comments/assignee/test-bead operations, while the production queue read is configured `br ready` at `omp-orchestrator/src/main.rs:836-839`; a literal `Command::new("bv")` requirement would miss centralized/configured invocation. `tool.grep` over `crates` returned six `Command::new("br")` matches and no `Delivered`/equivalent queue claim. **Fix:** assert actual argv/trace and selected bead, and separately assert the production selector does not use `br ready`. (Raw 4.)

### M5 — HIGH — M3 receipt name overclaims packet arrival
**Target:** `:109-124`.
`receiver-receipt/src/lib.rs:119-126` uses `ReceiptConfirmed`; its implementation relies on timer reset and stable-content change (`:180-183,265-303`) and carries no packet identity. `ack-stage/src/lib.rs:289-301` says the Codex tmux fallback remains INDETERMINATE; `:333-361` records `AckAction::RecordReceipt`, not `Delivered`. **Fix:** either add packet-correlated/agent-generated evidence or rename the observable and narrow the no-claim to screen/receipt observation. (Raw 5.)

### M6 — HIGH — M3 incident lacks immutable evidence
**Target:** `:115-122`.
The cited README and `dispatch-silence-watch/src/lib.rs:9-11` are narrative copies; they do not carry full command input, pane/session, timestamp, stdout/stderr, exit code, or immutable trace. **Fix:** cite a sealed replayable trace for both polarities or mark the incident UNVERIFIED and narrow the claim. (Raw 6.)

### M7 — BLOCKER — M3 still permits bare-success no-dispatch exits
**Target:** `:109-113`.
`omp-orchestrator/src/main.rs:921-969` handles no-dispatch states and returns `Ok(())`; `run_supervisor` returns `Ok(())` at `:982-984`, and `main` maps `Ok(())` to success at `:1020-1021`. The target's “never a bare success” milestone can therefore pass while no packet/receipt exists. **Fix:** type no-progress as advisory/refused or prove it is a valid completed observation; add a no-op known-bad fixture. (Raw 7.)

### M8 — BLOCKER — M4 accepts worker-asserted completion
**Target:** `:129-148`.
M4 requires only `human_touch_count == 0` and a closed bead. `ack-spine/src/followup.rs:21-27,42-45` identifies `Finished` as worker-closed; `:105-109` classifies a closed bead as Finished and `:150-156` maps it to Healthy. A worker-only close can satisfy M4 without an independent verifier. **Fix:** require verifier-issued close evidence bound to run/bead, artifact hash, and authority; add the worker-close-without-verifier negative leg. (Raw 8.)

### M9 — BLOCKER — M5 baseline and board snapshot are stale/misclassified
**Target:** `:150-170`.
The brief now says five stages/seven rows and `complete=AVAILABLE, NOT WIRED` (`docs/PLAN.md:532-536`), while the target says three of five and complete does not exist. Current source has automated actuation at `main.rs:563-620,801-862`. The board probe returned `23/23/3/30`, not `19/22/3/30`. **Fix:** state the predicate/denominator, distinguish source-present-but-unverified from absent, and bind counts to timestamp/revision/artifact. (Raw 9.)

### M10 — HIGH — M5 global close listing cannot prove the ten-run trace
**Target:** `:152-155`.
`br list --status closed --json` is a global listing; it does not bind ten bead IDs to the run, close timestamps, actors, verifier evidence, or refusal trace. **Fix:** record exactly ten IDs in a run artifact and verify each by ID plus trace hash with a nonzero result for unrelated rows. (Raw 10.)

### M11 — HIGH — M6 has no executable cold-host procedure
**Target:** `:172-180`.
The observable provides no install command, prerequisites, cache-absence proof, foreign fixture, first-tick command, transcript path, expected status, or exit code. `installer/src/main.rs:12,16-25,134-159` still names a foreign `pane-truth`, derives the workspace path, falls back to `/Users/josh`, and expects this workspace's target. **Fix:** publish the clean-host procedure and remove/resolve those host assumptions before accepting M6. (Raw 11.)

### M12 — HIGH — M6 retains retired version-probe coverage
**Target:** `:192-194`.
The target says `-V` answers 5/9, while `docs/PLAN.md:210-213` records the corrected 6/9 and names the responders. **Fix:** replace 5/9 with 6/9 and include the exact nine-binary input/probe output, or explicitly label 5/9 retired. (Raw 12.)

### M13 — BLOCKER — M7 has no defined window or production consumer
**Target:** `:206-214`.
The target states neither a window length nor a runnable command, and the 4h19m value has no trace path. `finding-dispatch/src/lib.rs:13-24` only detects `recurrence_count == FINDING_THRESHOLD`; a focused search found declaration/tests but no production consumer that escalates a fourth refusal. **Fix:** define duration/artifact/exit and wire a persistent escalation/stop consumer with a fourth-occurrence negative test. (Raw 13.)

### M14 — HIGH — PV1/PV2 measurement provenance is incomplete
**Target:** `:11-12,26-27,35-36,157-166,193-194,213-214,317-323`.
PV1 requires deriving commands, but the target's 20 mechanisms, 183 rows, spelled-out “Seven,” 3/5, 162/4.2h, board totals, 4h19m, and banked counts are not paired with exact input/command in the claim. The target's own PC1 checks numerals only, so number words evade it. **Fix:** attach command, input scope, timestamp, and output to every measured number; mark recommendations PROJECTED and extend the numeric check. (Raw 14.)

### M15 — HIGH — PV7 universal zero claim is false
**Target:** `:60-63,79,101-103,236-245`.
The target says every zero was re-derived with harness grep, but its M1 zeros use shell `strings`/grep and its M6 zero-byte result uses redirected `tmux --version`; it gives no exit status. `ObligationLedger` has four textual references across `crates`, so only a narrower `omp-types` search is zero. **Fix:** state path, pattern, stdout/stderr, exit, and scoped NO-CLAIM per absence; remove the universal claim. (Raw 15.)

### M16 — HIGH — PV8 citation completeness and line drift fail its own rule
**Target:** `:11-12,44,53-54,67-75,82-85,115-124,157-158,231-235,317-323`.
The target uses bare section references, upstream family names without paths, README/doc-comment prose, and the stale M1 line citation even though PV8 requires construct plus file:line. **Fix:** normalize to source root/path/line plus construct and revision or immutable runtime artifact. (Raw 16.)

### M17 — MEDIUM — M1–M7 order is asserted, not derived
**Target:** `:35-44`.
The only support is a Mermaid chain and the phrase “forced, not chosen.” `docs/plan/04-diagrams.md:88-91` measures crate edges, not milestone prerequisites; current manifests show independent surfaces. **Fix:** define prerequisite artifacts/interfaces and verify the DAG, or label the sequence a projected coordination preference that permits parallel work. (Raw 17.)

## Capability-floor check

No converged section (`03-crates`, `05-actions`, or `06-gates`) was edited. This round only produced evidence and will append ledger rows; cross-references to gate/source counts are observations, not regressions of those sections.

## Verdict

**FAIL — 16 new deduped findings.**
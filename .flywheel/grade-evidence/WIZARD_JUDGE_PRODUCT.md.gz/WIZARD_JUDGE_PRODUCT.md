# Ruthless product/adoption winnow

## Decision

The six survivors are:

1. **Upstream consume-before-rebuild and wire-adoption registry**
2. **Durable human-requirement and decision ledger**
3. **Transactional foreign-repository activation capsule**
4. **Economics and refusal-storm operating SLO**
5. **Parent/child 1:many mission ledger with partial-failure semantics**
6. **Independent fresh-project acceptance and anti-vacuity run**

These are product capabilities, not six more lifecycle paragraphs. Together they make the loop repeatedly usable: **admit a new project, preserve the human contract, consume the sanctioned planes, run one-to-one or one-to-many safely, stop spending when no value is moving, and prove the result outside the author’s checkout**.

The lower-level mechanics—leases, receipts, reducers, replay, roster epochs, evidence bundles, and approval tokens—are necessary, but they are not separate products. They fold into these six. Building them as fourteen independent workstreams would recreate the very sprawl the plan diagnoses.

## Judge standard

`F#` means candidate number in `WIZARD_FLEET.md`; `I#` means `WIZARD_INCEPTION.md`; `C#` means the numbered candidate in `WIZARD_REUSE.md`.

Scores are comparative judgments, not measurements:

- **N/S/F:** leverage for a new-project user / solo maintainer / fleet operator, each 0–5.
- **Gap:** genuinely missing as an executable mechanism, 0–5.
- **Accretive:** can land around the existing 26-crate system without a rewrite, 0–5.
- **E/R:** concrete refusal plus real local/upstream evidence, 0–5.
- **Repeat/owner:** month-three repeat-use value and a plausible owner/artifact, 0–5.

Total is out of 35. A high score does not make an idea a survivor if it is only a duplicate of another control-plane boundary.

The product personas are materially different. A new-project user needs a safe first tick on a foreign repo and host. A solo maintainer needs value without adopting a fleet. A fleet operator needs identity, delivery, fan-in, recovery, and economics. Fleet-only machinery is not automatically high leverage.

## The 20 normalized candidates

| Rank | Candidate | Sources | N/S/F | Gap | Accretive | E/R | Repeat/owner | Total | Disposition |
|---:|---|---|:---:|---:|---:|---:|---:|---:|---|
| 1 | Upstream consume-before-rebuild + wire-adoption registry | F18–19; I11–12; C8–9,C16 | 4/5/5 | 5 | 5 | 5 | 5 | **34** | **SURVIVE** |
| 2 | Durable requirements, decisions, conflict, and approval ledger | F12–13; I7–10; C5 | 5/5/5 | 5 | 4 | 5 | 5 | **34** | **SURVIVE** |
| 3 | Transactional foreign-repo activation capsule | F14; I1–6,I16; C6–7,C15 | 5/5/4 | 5 | 4 | 5 | 5 | **33** | **SURVIVE** |
| 4 | Economics, budgets, and refusal-storm operating SLO | F10,F20; C13,C18 | 4/5/5 | 5 | 4 | 5 | 5 | **33** | **SURVIVE** |
| 5 | Parent/child 1:many mission ledger and barrier policy | F3,F9; I13–15; C1–2,C20 | 3/4/5 | 5 | 4 | 5 | 5 | **31** | **SURVIVE** |
| 6 | Independent fresh-project acceptance + anti-vacuity | F16–17; I18–19; C10–12 | 4/4/5 | 5 | 3 | 5 | 5 | **31** | **SURVIVE** |
| 7 | Delivery outbox, receipt, dedupe, and ambiguity recovery | F4–5; I14; C2,C4 | 3/4/5 | 5 | 4 | 5 | 4 | **30** | MERGE into #5 and #1 |
| 8 | Lifecycle reducer, idle settlement, and roster truth | F6–8; C3 | 2/4/5 | 5 | 3 | 5 | 4 | **28** | MERGE into #5 and #1 |
| 9 | Repository/session identity and lease/fencing semantics | F1–2; I2,I15; C20 | 3/4/5 | 5 | 4 | 5 | 5 | **31** | MERGE into #3 and #5 |
| 10 | Durable event log, checkpoint, replay, and restart recovery | F11; I10; C4 | 3/5/5 | 5 | 3 | 5 | 5 | **31** | MERGE into #2 and #5 |
| 11 | Cold-host capability negotiation | F15; I3–4; C7,C16 | 5/4/5 | 5 | 4 | 5 | 5 | **33** | MERGE into #3 and #1 |
| 12 | Existing-tracker adapter and identity-preserving migration | I5; C6 | 5/4/4 | 4 | 3 | 4 | 4 | **24** | CONCESSION; phase after activation |
| 13 | Adopter-derived gate profile and exception ownership | I6; C17 | 5/4/4 | 4 | 3 | 4 | 4 | **24** | CONCESSION; phase after activation |
| 14 | Human approval tokens, ownership, and expiry | F13; I9; C5 | 3/4/5 | 4 | 4 | 5 | 4 | **29** | MERGE into #2 |
| 15 | Typed plan → bead → dispatch compilation | F19; I17; C8,C12 | 4/4/4 | 4 | 2 | 3 | 3 | **24** | KILL as a standalone workstream |
| 16 | Portable content-addressed evidence bundle | I19 | 3/4/5 | 4 | 3 | 4 | 4 | **23** | MERGE into #2 and #6 |
| 17 | Adoption funnel and retention signal | C14 | 5/5/4 | 5 | 3 | 3 | 5 | **30** | MERGE into #4; no dashboard |
| 18 | Persona-aware solo-maintainer path | C15 | 5/5/3 | 4 | 3 | 3 | 5 | **28** | MERGE into #3; a default, not a subsystem |
| 19 | External completeness/omission inventory | C12 | 3/3/4 | 5 | 3 | 5 | 3 | **23** | MERGE into #6 |
| 20 | Roster epoch and membership service | F6; C3 | 2/3/5 | 4 | 3 | 5 | 4 | **26** | MERGE into #5 |

## The six survivors

### 1. Upstream consume-before-rebuild and wire-adoption registry — 34/35

**Product value.** The plan’s corrected thesis is to attach to an existing plane, not invent another protocol. This is the most accretive survivor: it prevents local duplicates while turning declarations into explicitly staged capabilities.

**Refusal boundary.**

- Refuse a custom selector or packet path when the sanctioned `bv`/`ntm` surface exists and its probe has not run.
- Refuse to promote a `.d.ts` name or type-only import to `AVAILABLE`.
- Keep `DECLARED ONLY` capabilities blocked until the exact process proves reachability and semantic fit.
- Refuse unknown upstream versions, feature-gated discriminants, and silently parsed schema drift.

**Evidence.** `docs/PLAN.md §11.3` says the existing `ntm` dispatch template was unused despite its fail-closed required variables. `§11.5` records zero `Command::new("bv")` calls in the workspace. `§11.9` proves one `AgentEndEvent` frame crosses the OMP RPC wire, but explicitly does not prove supervisor consumption. `docs/plan/00-brief.md §3.8` marks `IrcDeliveryReceipt`, `AsyncJobDeliverySink`, `Stage1Claim`, `GlobalClaim`, `GuestIdleReconcilerCtx`, `HubRosterCounts`, `SearchUsage`, `PerplexityCost`, `ContextUsage`, and compaction events **DECLARED ONLY**; only the completion frame is wire-proven.

**Accretive owner/artifact.** Put the selection adapter in `loop-queue-filter`, the dispatch adoption in the existing `omp-orchestrator`/`ntm` template path, and capability/version cards beside the existing installer or supervisor. The artifact is a machine-readable adoption card and probe receipt with `DECLARED → WIRE-PROVEN → CONSUMED → E2E-PROVEN`, source revision, feature flags, owner, fallback, and refusal reason. Do not add a completion crate; consume `AgentEndEvent` through `RpcSessionEventFrame` (`dist/types/extensibility/shared-events.d.ts:154`, `modes/rpc/rpc-types.d.ts:589`) and prove the resulting durable effect.

**Month-three test.** An OMP/NTM upgrade changes an event or CLI shape. The system refuses only the affected capability and points at the stale adoption card instead of silently selecting by recency, waiting forever on a dead event, or reporting zero cost. This makes the system maintainable for solo users and fleet operators rather than turning the operator into a permanent compatibility shim.

### 2. Durable human-requirement and decision ledger — 34/35

**Product value.** S9 is currently a label. Human intent is the contract that makes every later artifact worth producing. Requirements must survive compaction, handoff, fan-out, and changed decisions without becoming an uncontrolled prose stage.

**Refusal boundary.**

- Refuse dispatch or ship when the active requirement is absent, stale, ownerless, conflicted, or outside the target scope.
- Refuse paraphrase-only updates, silent overwrite, inferred approval, and a decision whose scope hash no longer matches the artifact.
- Require an explicit owner and next state for every blocking open question.
- Preserve superseded records and rationale; never delete history to make the current state look clean.

**Evidence.** `docs/PLAN.md:52-55` records seven real conditions living only in pane scrollback. `docs/plan/12-journey.md:35-38` records eleven decisions lost in the session and makes S9 cross-cutting. `docs/plan/00-brief.md:67-68` warns that paraphrasing a verbatim requirement is how it quietly changes. The seven-field stage contract at `docs/plan/12-journey.md:40-61` has no durable requirement/decision field.

**Accretive owner/artifact.** The supervisor and `omp-types` can own the value types without moving business logic across all 26 crates. Store an append-only, scope-aware requirements/decisions stream (for example, under the project run bundle), and put requirement IDs plus revision hashes into beads, packets, events, grades, and ship receipts. The artifact is a replayable requirement ledger, not a new prose document. Approval actor, allowed action set, expiry, `supersedes`, `conflicts_with`, and evidence references are fields, not a separate approval service.

**Month-three test.** A sponsor changes a deployment restriction while eight children are running, then the conductor compacts and restarts. Old packets remain tied to the old revision; new dispatch stops on the conflict; the owner resolves it; replay reconstructs the exact active contract. That is the difference between a tool people trust on the next run and a demo that loses the human every time context changes.

### 3. Transactional foreign-repository activation capsule — 33/35

**Product value.** This is the first-use gate. If S1 cannot safely profile and adopt a repository outside this checkout, no amount of fleet correctness creates adoption. The capsule must handle new projects, existing conventions, dirty trees, and a host that does not know Josh’s paths.

**Refusal boundary.**

- Refuse ambiguous repository roots, worktree/submodule boundaries, target commits, or unowned write sets.
- Refuse partial config/gate/tracker writes; `--dry-run` must never write, and failed apply must undo its own writes.
- Refuse compile-time build-machine paths, hardcoded `/Users/josh`, automatic tracker conversion, and a green exit after a no-op.
- Report absent optional dependencies as `ABSENT`, not `FAIL`; block unsupported capabilities with an actionable reason.

**Evidence.** `docs/plan/08-end-users.md:6-21` says there is no adopter-facing `doctor`, `init`, or `adopt` entry point and labels foreign adoption projected. `:65-70` measures compile-time `CARGO_MANIFEST_DIR` coupling and a `/Users/josh` fallback. `docs/plan/07-installability.md:15-45` records an installer that covers only 3 of 18 binaries and a binary without an identity surface. `docs/plan/08-end-users.md:119-133` describes the intended write/gate flow, but it is still projected; it is not evidence that the flow works.

**Accretive owner/artifact.** Extend the existing `installer`/doctor surface and the supervisor’s admission boundary. The artifact is an `admission-manifest` containing runtime repo identity, dirty state, detected language/build/test/tracker/gate capabilities, intended OMP-owned paths, selected adapters, and a reversible write/undo plan. Keep first adoption narrow: write only the tool’s namespace until the profile is proven. Tracker migration and gate activation remain opt-in adapters, not hidden side effects.

**Month-three test.** A maintainer runs the command on a clean machine against a non-Rust repository with no `.beads`, then against a dirty monorepo. The system either produces an identity-bound, undoable adoption receipt or a truthful `PROFILED_NOT_ADOPTED` refusal. It must not leave a half-adopted repository that the owner has to reverse-engineer.

### 4. Economics and refusal-storm operating SLO — 33/35

**Product value.** A technically honest loop can still be a product failure if it consumes more operator attention and compute than the manual path. Repeat use requires a reason to leave the supervisor running.

**Refusal boundary.**

- Refuse to continue a refusal class past its recurrence threshold without a state change, owner, or explicit human override.
- Refuse heartbeat-only “progress”; each tick must account for useful progress, blocked state, or escalation.
- Refuse a value claim without a baseline and target for the relevant persona.
- Terminate a run as `budget_exhausted` when time, retries, panes, or cost are consumed; never let budget exhaustion masquerade as success.

**Evidence.** `docs/plan/09-milestones.md:157-169` records 162 consecutive `DISPATCH_RETRY_BLOCKED` ticks over 4.2 hours. `docs/plan/00-brief.md:802-823` leaves customer outcome, baseline/target, verification cost, and headcount as open questions. `SearchUsage`, `PerplexityCost`, and `ContextUsage` are explicitly only declared upstream surfaces in `docs/plan/00-brief.md §3.8`; do not invent local token telemetry and call it measured.

**Accretive owner/artifact.** Add a small run-value/refusal ledger to the supervisor or `tick-monitor`, not a generic dashboard. Record time-to-first-useful-close, useful-close rate, operator-touch minutes, blocked-tick minutes, retry count, and cost per verified close after the relevant upstream signals are proven. The artifact is a per-run SLO receipt with baseline, target, refusal class, recurrence threshold, and escalation owner.

**Month-three test.** The same dispatch fence fails for four hours. The system escalates at the configured threshold and offers repair, stand-down, or manual fallback instead of burning turns. A solo maintainer sees whether the tool saves time; a fleet operator sees whether fan-out is worth the capacity and cost.

### 5. Parent/child 1:many mission ledger with partial-failure semantics — 31/35

**Product value.** One-to-many is the mission, not “run the one-to-one loop N times.” Every child must have durable identity and outcome; the parent must derive its status from a declared barrier.

**Refusal boundary.**

- Refuse fan-out without an expected-target set, parent/child IDs, repository/session namespace, attempt IDs, and a concurrency/cost budget.
- Refuse aggregate `COMPLETE` when a required child is undelivered, unknown, continuing, lost, or unverified.
- Refuse new logical IDs for retries of the same intent; duplicate and out-of-order events must be idempotent.
- Refuse stale panes, recycled worker identities, and sibling events mutating another child.
- Permit `PARTIAL`/`DEGRADED` only as an explicit verdict under `all`, quorum, or named waiver policy.

**Evidence.** `docs/plan/12-journey.md:25-35` lists one artifact per stage and no parent/child aggregation contract. `docs/plan/09-milestones.md:111-124` records transport returning `success:[4]` while no packet arrived. The fleet candidate evidence records eight live sessions and a shared-ledger hazard; `docs/plan/00-brief.md §3.8` distinguishes the wire-proven `AgentEndEvent` from declared-only receipt/claim/idle/roster families.

**Accretive owner/artifact.** Put the parent manifest and child projection around the existing `dispatch-claim-fence`, `pane-dispatch-fence`, `fast-dispatch`, and supervisor paths. The parent manifest contains child IDs, repo identities, requirement revision, barrier, attempt, and budgets; the child ledger contains receipt, lifecycle, and evidence state. Reuse `AgentEndEvent` for each RPC worker. Receipts/outbox, scope/lease fencing, idle settlement, lifecycle reduction, and roster epochs are fields and reducer inputs here—not five new products.

**Month-three test.** Ten children include one delayed child, one duplicate/retried intent, one continuation, one dead pane, and one false transport success. The parent must report the declared barrier exactly, with the offending child named. No aggregate count may hide a missing child.

### 6. Independent fresh-project acceptance and anti-vacuity run — 31/35

**Product value.** This is the release oracle for the product claim, not another stage. It prevents the team from proving the existing checkout to itself and calls out omissions that the plan’s own checklist cannot see.

**Refusal boundary.**

- Refuse adoption, portability, or ship claims from the same session, same checkout, same fixture family, or worker self-report alone.
- Refuse a gate whose known-bad state does not fail, known-good state does not pass, mutation does not break it, or fixture bypasses the production seam.
- Refuse completeness claims without an external requirements/schema inventory and explicit missing rows.
- Refuse to promote a declared-only upstream capability merely because the fresh run did not exercise it.

**Evidence.** `docs/plan/09-milestones.md:150-180` makes M5/M6 targets and says the foreign-host run has never been attempted. `docs/plan/08-end-users.md:6-10` labels end-user adoption projected. `docs/plan/09-milestones.md:243-246` records false-zero measurements caught by re-derivation, while `:317-319` records 20 mechanisms built/tested but never called. `docs/PLAN.md §11.2` measures only 3 used `Y` cells out of 45. These are direct warnings against “green local run = product.”

**Accretive owner/artifact.** Give the existing verification/release owner a fixture matrix and a fresh-process harness, rather than a new lifecycle crate. The artifact is an independent M6-style transcript/evidence bundle covering clean host, foreign repo, non-Rust repo, no tracker, pre-existing tracker, dirty worktree, missing dependency, one-to-one, and one-to-many. It must include requirement IDs, capability/adoption cards, event-to-state transitions, child aggregation, refusal inventory, and reproducible hashes.

**Month-three test.** A fresh evaluator, given only the declared contract and evidence, runs a cold install and one 1:1 plus one 1:many scenario. The result can honestly say `DECLARED ONLY` or `PROFILED_NOT_ADOPTED`; it cannot manufacture a green ship claim from missing coverage.

## Explicit merges, concessions, and kills

The following are deliberate scope decisions. “Merge” means retain the behavior inside a survivor; it does not mean ignore the failure mode.

| Candidate | Decision | Why |
|---|---|---|
| F4–5 / I14 / C2,C4: receipts, outbox, dedupe | **MERGE into #5 and #1** | Delivery is part of parent/child truth and upstream adoption. A standalone receipt project would not know the mission barrier or wire status. |
| F6–8 / C3: lifecycle reducer, idle, roster | **MERGE into #5 and #1** | These are reducer inputs to child/parent state. Do not create a “lifecycle stage” that repeats `§11.5`. Preserve `willContinue`, `SessionStopEvent`, newly-idle/confirmed-idle, and roster epoch. |
| F1–2 / I2,I15 / C20: identity and fencing | **MERGE into #3 and #5** | Repo identity belongs at admission; child leases belong in the mission ledger. A global identity service is needless architecture. |
| F11 / I10 / C4: event log/replay/checkpoint | **MERGE into #2 and #5** | One scoped append-only event substrate should carry human decisions and child effects. Do not build two competing logs. |
| F15 / I3–4 / C7,C16: cold-host capabilities | **MERGE into #3 and #1** | Runtime environment admission and upstream schema adoption are adjacent checks. Keep the manifests separate by concern, not as a second product. |
| F13 / I9 / C5: approval tokens and expiry | **MERGE into #2** | Approval is a decision-record field with scope and expiry, not a separate workflow product. |
| I5 / C6: tracker adapter/migration | **CONCESSION** | Important for established repos, but not first-six leverage. Start read-only and identity-preserving; never auto-migrate before the first useful close. |
| I6 / C17: gate profile/exception ownership | **CONCESSION** | Required for safe adoption, but gate catalog breadth comes after an executable first path. Select only applicable, known-good gates; store skips with owner and re-enable condition. |
| F19 / I17 / C8,C12: typed stage compiler | **KILL as standalone** | This is too close to repeating `docs/PLAN.md §11.8` (“the composition nobody wrote”) and risks rewriting the 26-crate shape. First consume `bv`, `br`, and the existing `ntm` template; add only the narrow fields needed by the six survivors. |
| I19: portable evidence bundle | **MERGE into #2 and #6** | Portability and hashes are output invariants of the ledger and acceptance run, not a separate storage product. |
| C14: adoption funnel/retention | **MERGE into #4** | Measure activation and repeat useful closes as SLO fields; do not build a generic dashboard or analytics stage. |
| C15: persona-aware solo path | **MERGE into #3** | Solo mode is a default and dependency policy: do not require `ntm`/`tmux`/`br` when one worker can produce value. It is not another architecture. |
| C12: external omission inventory | **MERGE into #6** | One external inventory belongs in the independent oracle. A second completeness system would generate checklist theater. |
| F6 / C3: roster service | **MERGE into #5** | Membership epoch is a child-capacity field and reducer input. No standalone roster service until the parent/child path demonstrates the need. |

## Adoption order implied by the judgment

The order is intentionally not “build all fleet machinery, then look for users.”

1. **#3 Activation capsule:** prove a safe first tick on a foreign project, with a solo default.
2. **#1 Upstream registry:** consume `bv`/`ntm` and wire-proven completion before cloning mechanisms; keep all other upstream families visibly declared-only.
3. **#2 Human ledger:** make the requirement and decision contract durable before unattended execution.
4. **#5 1:many ledger:** add parent/child barriers, receipts, dedupe, fencing, and lifecycle reduction around a bounded fan-out.
5. **#4 Economics SLO:** measure useful closes and stop refusal storms before inviting repeat use.
6. **#6 Fresh acceptance:** run the clean foreign-project oracle and refuse broad portability claims until it passes.

This sequencing is not a seventh candidate or another prose stage. It is the shortest route from first adoption to repeatable one-to-many operation while preserving the plan’s central rule: **anything not proven is refused, not renamed successful**.
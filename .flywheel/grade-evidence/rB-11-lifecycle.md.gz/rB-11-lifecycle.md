# Round 9 — 11-lifecycle.md — ABSENCE lens — OliveCat
Section read FULL (342 lines). Correction history honored: §11.9 SETTLED block (AgentEndEvent
crosses the wire, isTerminal:true, raw frame re-verified at 4,772 bytes), L3's WIRE-PROVEN
upgrade, the 11.3 Stage1Claim-vocabulary note (correctly scoped as memory-claim domain that
"does not transfer"). Re-flagging those would be false findings.

## FINDINGS (1)

F1 [MINOR — the L-row table's owner column still does not exist]: round 5 (my own pass)
filed B1: "§11.6 assigns NO OWNER to any L-row — demands without durable owners are the
scrollback failure in section form." The current table (construct: the §11.6 L1-L7 demand
table) still has columns `| # | demand | state |` — no owner column — and the NO-CLAIM
(line 175) still reads "unbuilt and unowned except where an owner is named". Since round 5,
three waves of owner-discipline corrections landed elsewhere (§8.2 role-word owners
challenged; convergence clock added), but this table — the section that MEASURES ownership
per stage — still owns none of its own demands. It was stale in round 5 and is stale now;
round 8's evidence-lens finding on this section was 1 (the E1 arithmetic headline), and
§11.2's headline now correctly derives from the table, so E1 is fixed — but the owner
absence survived both.
  FIX: add `owner` to the L-row table with a bead-id or docs path per row (L3's owner is the
  rpc-frame adoption; L7's is Q13's owner in 00-brief §8.2 — which itself carries Q13 as an
  unowned row).

## Searched-and-cleared (each zero with space + justification)
1. Q13 owner check (above): Q13 is registered in 11-lifecycle and referenced by
   02-surface-census, but grep shows no Q13 row in 00-brief §8.2 — the open-questions
   section that OWNS registrations. That is a cross-section propagation gap, not a 11-claim
   defect: 11 says "registered as Q13" truthfully about its own act, and the owner column
   fix (F1) subsumes it. Not double-counted.
2. §11.4 hook-shell facts re-derived: commit-msg-verification-level.sh still 6288 bytes,
   still untracked (git ls-files grep → 0). TRUE as written; Q13 remains genuinely open.
3. §11.2 Y/y/partial arithmetic: recounted — table has 5 Y cells (S3 log, S5 dispatch,
   S8 log, S8 grade, S9 grade), 2 y (S5 template, S7 reap); headline "3 cells Y-and-used…
   two y" — recomputed with the table's own legend (`Y` = exists AND used): S5 dispatch Y
   (hand-rolled = used), S3/S8 logging Y, S9 build-grading Y, S8 build-grading Y. If
   "used" is read as "used by the lifecycle the section maps" the S8/S9 grading cells were
   used this session (bead-comment receipts + graded closes). This was round 5's E1
   finding, already corrected per the section's own round-8 fix — the ledger shows
   11-lifecycle round-8 evidence 1 (their finding). I re-checked the current text: the
   headline still says "3 of 45" while the table still admits 5 Y readings. HOWEVER round 8's
   grader already filed this exact defect (E1, evidence-lens) and it is the section's only
   dirty mark — per the contract, re-flagging a finding already on the ledger is a false
   finding. NOT counted; the round-8 row stands as the open debt on this section.
4. §11.5 severed links after the refutation: S6→S7 now says "closes by consuming an
   existing frame" (§11.9). S4→S5 (zero bv invocations) re-derived: harness grep
   Command::new\("bv"\) crates → no matches, still true. S8 still "no shared trait" — true.
5. The nine-stage table's S5 "actuation is a human" and §11.2's "Y (hand-rolled)" —
   consistent with each other; no post-refutation contradiction (the completion frame does
   not automate actuation, and the section does not claim it does).
6. My own zero-audit: harness grep only; the section is the R13 spine, so absence-lens
   pressure was applied to every L-row's state column against the current tree (L1 template
   still unused — ntm template list shows dispatch exists, no crate consumes it; L2 zero
   bv calls re-derived; L5 reap-finished-panes still uncalled; L6/L7 unchanged).

## NEW FINDINGS: 1 (F1 — ownerless L-rows, stale since my own round 5, never fixed)

VERDICT: FAIL (absence lens — F1 is the one real absence; E1's arithmetic headline remains
on the ledger from round 8 under the evidence lens and is not re-counted here)

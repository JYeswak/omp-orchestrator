# Round 9 — 09-milestones.md — ABSENCE lens — OliveCat
Section read FULL (329 lines). Correction history honored: M1 carries the recorded
disagreement with brief §4 (filter fixed in source; seam remains) with the six-command
measurement; M3 carries the upstream-type block at true strength (DECLARED only); M6 carries
the tmux correction. Re-flagging any of those would be a false finding.

## Searched-and-cleared (each zero with space + justification)
1. Gap-propagation residue: all seven upstream types checked against 09 — M1 carries
   "UPSTREAM CORROBORATION, declared only" (GuestIdleReconcilerCtx, settle-vs-continuation,
   correct strength), M3 carries "UPSTREAM TYPE, at its true strength" (IrcDeliveryReceipt +
   AsyncJobDeliverySink, DECLARED only, does not close M3). The section's strongest stale
   candidate — M4 — deliberately does NOT cite AgentEndEvent, and that is where I looked
   hardest (see F-below-judgment).
2. M4's starting point still counts `FollowUpVerdict::Finished` as "occurrence 21 of the
   class" with zero callers — re-derived: grep "Finished" crates → 8 hits all in
   ack-spine/src/followup.rs holds (ipg.19 landed the type; no consumer). TRUE as written.
3. Judgment call, documented not counted: §11.9 says "§09 M4 scope collapses from
   build-a-protocol to consume-a-frame", but 09-M4 itself carries no adoption sentence —
   its STARTING POINT still grounds on ack-spine's uncalled type alone. Is that a finding?
   It is PROPAGATION LAG, not a false claim: nothing in M4 asserts the completion signal
   cannot exist upstream, and M4's observable (human_touch_count==0 trace) is
   adoption-agnostic — it remains correct under both architectures. The contract counts a
   finding as "false, unmeasured-as-measured, internally contradictory, or dependent on a
   refuted premise." M4's claims meet none of those; §11.9's table says the §09 milestone
   SCOPE collapses, which is a design decision owned by the orchestrator, not a defect
   graded here. Filed as a judgment call in this evidence file, NOT in the ledger: zero
   findings for 09, with this documented so round 10's other lens can re-check whether M4
   should name the adoption path.
4. Anti-vacuity of my own pass: every zero above ran the harness grep with the section as
   the search space; the seven-type absence test is meaningful here because 09 states
   milestones whose observables reference these gaps (M3 receipts, M4 completion) — if
   propagation were missing anywhere it would be in the milestone STARTING POINTs.
5. Numbers spot-recheck: M5 board counts (74 beads vs brief's 75, reported-not-reconciled —
   correct behavior); `plan-check` absence claim (ls crates | grep plan-check → empty,
   still true at current tree); PV6/PV7/PV8 all cite their own measured instances.

## NEW FINDINGS: 0

VERDICT: PASS (absence lens, round 9 — first clean round for 09 under this contract)
Judgment call documented above: M4 carries no adoption cross-reference yet; it is
propagation lag owned by the orchestrator, not a false claim — round 10 under another lens
should re-check it after the orchestrator's propagation pass.

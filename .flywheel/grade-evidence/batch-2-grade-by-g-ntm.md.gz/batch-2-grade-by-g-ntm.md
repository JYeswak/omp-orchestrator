# Cross-grade — batch 5 by g-ntm-r14

## Result

**FAIL — 3 findings.** The `maps_to_crate` values name real workspace crates. The two CONSUMED rows are directionally correct, but one citation overstates what the cited construct does.

## Findings

### MAJOR 1 — `br:comments` is consumed, but the validation citation conflates two verbs

The row’s CONSUMED claim is supported by `crates/ack-spine/src/ack.rs:61-75`: `detect_ack` invokes `br comments list <bead_id>`. However, the row also describes `ack.rs:87` as “comments list/add read-back”; the cited construct at `:87-89` invokes singular `br comment <id> -m <text>` inside `simulate_singular_trap`, and line 95 explicitly says the comment does not land. The CONSUMED disposition holds for `br:comments` through `comments list`; the “list/add read-back” description is wrong.

**Fix:** Cite `ack.rs:61-75` for the consumed `br comments list` surface and separately describe `:83-100` as the singular-verb negative specimen.

### MAJOR 2 — VALIDATE is used for human practice rather than a crate dependency

`br:list` is marked VALIDATE with `maps_to_crate: null`, while its own validation says “no crate consumes; dependence is human-process.” A behavior that no crate depends on is not VALIDATE under the input contract; it is RETIRE unless a concrete crate contract is named. The same problem appears in `br:init`: the row maps to `omp-orchestrator`, but its evidence is the `br ready` parse failure, which validates ready-output handling and tracker presence, not `br init` behavior.

**Fix:** Mark `br:list` RETIRE/null, and either mark `br:init` RETIRE/null or cite a concrete `br init` behavior that `omp-orchestrator` relies on and an exact validator for it.

### MINOR 1 — `br:create` VALIDATE has no dependent crate

The row marks `br:create` VALIDATE but says “no crate should own it” and bases validation on the claim-fence refusing unknown beads. That proves downstream rejection of an invalid snapshot; it does not prove dependence on the `br create` command. The row should be RETIRE unless a crate directly relies on create semantics.

**Fix:** Set `br:create` to RETIRE/null, or identify the exact crate and contract that depends on `br create` behavior.

## Positive checks

- `br:ready` is correctly marked CONSUMED and its citation matches `crates/omp-orchestrator/src/main.rs:836-841`, which builds `ready --json`, invokes configured `br`, and parses the result.
- `br:show` is plausibly CONSUMED by `dispatch-claim-fence`; the row’s evidence should still name the exact production invocation if its final JSONL line is retained.
- `br:dep` is a reasonable WIRE candidate for `loop-queue-filter` because dependency edges are relevant to graph-aware selection, but the proposed wire remains future work rather than current consumption.

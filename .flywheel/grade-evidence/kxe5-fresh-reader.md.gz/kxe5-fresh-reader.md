# kxe.5 independent fresh-reader receipt

The following JSON is the read-only result from an independent fresh reader. It was run against
HEAD 4d52c226bc57ce014909233f371249761cc9fb18 and did not edit the repository.

{
  "verdict": "ZERO_NEW",
  "head": "4d52c226bc57ce014909233f371249761cc9fb18",
  "evidence": [
    {
      "source": "docs/plan/00-brief.md:586-608",
      "result": "Section 6.1 defines CROSS-SECTION-AUTHORITY.jsonl as the single current disposition overlay, requires owner/authority command/independent acceptance command/failure result, and explicitly separates PROJECTED/EXISTS/UNPROVEN/HISTORICAL claims."
    },
    {
      "source": "docs/plan/04-diagrams.md:280-285",
      "result": "Generator is explicitly PROJECTED: unbuilt, diagrams remain labelled snapshots, BlueLantern owns the authority, and the future changed-edge RED leg plus failure result are named."
    },
    {
      "source": "NUMBERS.toml:68-72",
      "result": "figures.board_total has the exact live command and expect = LIVE. Exact command output: 230."
    },
    {
      "source": "SCHEMAS.toml:174-181",
      "result": "artifacts.cross_section_authority declares the checked-in JSONL path/format, envelope fields, writer, reader, and overlay note."
    },
    {
      "source": "docs/plan/CROSS-SECTION-AUTHORITY.jsonl",
      "result": "65 valid records: 7 authority, 57 finding, 1 fresh_reader; 7 unique authority keys/scopes; statuses 4 EXISTS, 2 PROJECTED, 1 UNPROVEN; no missing writer/consumer boundaries or collapsed authority/acceptance commands. Finding dispositions: 51 FIXED, 4 LINKED_CHILD, 2 FALSE_POSITIVE; no empty dispositions."
    },
    {
      "source": "docs/plan/FINDINGS.jsonl",
      "result": "235 valid rows; 113 R19/R20/R21 rows, all carrying dispositions (67 FIXED, 45 DEFERRED, 1 RETRACTED). The overlay's R20-12-s9-schema-ids is intentionally absent from the historical ledger and explicitly marked FALSE_POSITIVE/obsolete; the corresponding historical schema ID is R19-12-s9-schema-ids and is FIXED."
    },
    {
      "source": "retained evidence",
      "result": "Fresh-reader source_revision is a full 40-character pinned ancestor of HEAD; recorded SHA 4e5fba... matches SHA-256 of gzip-decoded evidence content."
    }
  ],
  "checks": {
    "git_rev_parse_HEAD": "4d52c226bc57ce014909233f371249761cc9fb18",
    "jq_authority_findings": "valid; authority 65 total / 7 authority / 57 finding / 1 fresh_reader; findings 235 total / 113 R19-R21",
    "board_total": "230",
    "exact_cargo_commands": "All four exact commands were attempted; RCH refused before execution with exit 103 because no admissible remote worker was available.",
    "wrapper_bypass_proof": "With documented RCH_CARGO_WRAPPER_BYPASS=1: cross_section_authority 7/7, findings_ledger 17/17, numbers 8/8, schemas 6/6. schemas emitted only existing duplicate-test/dead-code warnings."
  }
}

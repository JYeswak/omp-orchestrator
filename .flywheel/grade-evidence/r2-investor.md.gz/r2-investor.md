
MAJOR 1 — The rebuilt mutation status is still a naming proxy, not evidence that mutation ran.
Lines 271–277 claim the table is “derived per crate, not by keyword count,” but line 273 defines `AUTOMATED` as a `#[test] fn` whose name contains `mutation`, found by `grep -rn 'fn .*mutation'`. A function name proves neither that the test mutates the predicate nor that removing the predicate turns the gate RED. The table has improved the vocabulary but still asks the investor to trust a label whose production behavior is not shown.

FIX: Derive `AUTOMATED` only from an executed mutation receipt showing the original case passes, the controlled mutation fails, and restoration passes again; generate the status from those receipts rather than source names.

MAJOR 2 — The self-correction count is reconciled in the headline and table but remains stale in the argument built on it.
The new headline and table say nine refuted measurements, seven by the conductor at lines 539–560. But lines 584–589 still say the brief “was itself corrected five times,” lines 591–595 call it “Five refutations,” and lines 618–619 still conclude that the process “caught five errors.” The claimed fix therefore leaves the central investor-facing proof internally inconsistent: a reader cannot tell whether the evidence is five or nine.

FIX: Generate every downstream count and conclusion from the same nine-row source, or remove all repeated counts and refer to the table’s derived total.

BLOCKER 1 (ROUND-1 BLOCKER UNFIXED) — R12 makes the investor questions visible but does not answer them.
R12 at lines 68–74 and §8.1 changes unanswered questions into registrable requirements, which fixes discoverability. It does not fix the investment case: Q1 at line 681 remains OPEN because no buyer is named, Q2 at line 682 has no measured workaround cost, and Q3 at line 683 remains OPEN because there is no customer outcome, baseline, or target. The section explicitly concedes at lines 717–720 that it “answers none” of its ten questions.

FIX: Do not treat registration as resolution; block bead conversion or investment review until Q1–Q3 have evidence-backed answers, or state the project is a speculative internal R&D effort rather than an investable company.

MAJOR 3 — The new kill criteria are mostly admissions of missing measurement, not executable investment controls.
Section 8 claims at lines 692–695 that each criterion has an observable, but K2 at lines 696–700 says “no instrumentation exists” and that building it is unowned; K3 says the test was “never attempted”; and K5 offers “the honest version of K2” plus 4.2 hours of refused ticks rather than a threshold. K1 also says “if two attempts fail” without defining an attempt, timebox, or decision owner, while the table provides no owner column for any kill criterion.

FIX: Give each kill criterion an owner, deadline, numeric or binary trigger, evidence command, and pre-authorized decision; an uninstrumented risk is not an observable and cannot protect capital.

BLOCKERS: 1
MAJORS: 3
MINORS: 0

MEETING QUESTION THIS DOCUMENT STILL CANNOT ANSWER:
Which named customer will pay, from what budget, for what quantified improvement, and by what date will we kill the project if that evidence does not appear?

The document itself leaves Q1–Q3 OPEN at lines 681–684 and gives no deadline for answering them. Its kill table at lines 696–702 is operational rather than economic.

VERDICT: FAIL

THE ONE THING: R12 makes ignorance legible but does not produce investment evidence; Q1–Q3 explicitly remain open, so the business case is still absent.

# WIZARD_IDEAS — pane %1409 (GLM 5.3) — Phase 4, wave 7 context
Question: what is MISSING from docs/plan/12-journey.md for the mission "orchestrate 1:1 and 1:many
ntm sessions, A-to-Z from inception to ship, with all human requirements stored, amazing defined at
each layer"? 20 candidates generated; 6 survived winnowing. Ordered best-first.

Live facts gathered before writing (2026-09-01): `tmux list-sessions` → **8 sessions across SIX
different projects** (bequant-ai-native, clutterfreespaces, cmm2, control-plane, franken-harvest,
omp-orchestrator, zeststream-cast, plus `zeststream-cast-wave-20260825-1910` — a wave-created
session leaked 6 days, never torn down). `pgrep -f __omp_worker_lsp_mux` → 6 workers. 26 crates.
`FINDING_THRESHOLD = 3` at finding-dispatch/src/lib.rs:15.

---

## THE 20 CANDIDATES (generated, then winnowed; survivors in full below)

1. Fleet namespace: one instance key (the beads prefix) threading ledgers, sessions, panes, hooks
2. Wave teardown lease: every created session/mux carries an owner and an expiry; `zeststream-cast-wave-20260825-1910` is the measured corpse
3. Human-decision record schema (S9's missing mechanism): id/question/decider/binds/supersedes/review-after
4. Decision amortization stage: decisions promote into AGENTS.md/CLAUDE.md or expire as beads
5. Fan-out/fan-in dispatch primitive: one packet → N panes, per-target receipts, all-arrived barrier
6. Stage-boundary resume artifacts: a stage is not Done until its checkpoint is re-loadable
7. Amazing-metric contract: every "Amazing" field names the number that would falsify it
8. Runbook schema is missing fields: Metric, Owner, Dies-when, Cost, Escalation-threshold
9. Per-stage cost budget fed by ContextUsage/OTLP, not vibes
10. Escalation policy: FINDING_THRESHOLD==3 applied to stage refusals; refuses silent perpetual refusal
11. S1 inception bundle: gates+beads+docs scaffold with per-repo allowance seeding
12. Gate portability: compile-time CARGO_MANIFEST_DIR roots (16 sites/14 files) block every foreign S1
13. Packet journal: append-only JSONL of every dispatch packet, making waves replayable and diffable
14. Grader claims: S6 peer-graders reserve files via ntm locks before editing a shared checkout
15. Cross-repo DAG (1:many repos, not just sessions): bv --robot-impact-network across prefixes
16. Machine-resource arbiter: single mux server, single watcher, single ledger — lease or bead per resource
17. ee mesh consent lanes as dispatch permissioning (--lane, approval tokens): refuses broadcast-to-all
18. Skills field cites ms outcome/bandit records ("which skill helped"), else Skills is folklore
19. Stage transitions as the only mutation points, driven by wire-proven agent_end/isTerminal
20. Per-stage undo artifact (franken_lean chokepoint-undo shape); refuses irreversible-without-undo

Winnow: killed 7 (needs new protocol or crate rewrite: 6-partial, 16-partial, 18, 19, 20-folded-into-8,
9-folded-into-8, 10-folded-into-8), merged 5 into survivors (2→A, 3+4→B, 5→C, 7+8+10→D, 11+12→E,
13→F). Survivors below, best-first.

---

## A. FLEET NAMESPACE — the machine is already 1:many and every artifact assumes 1:1
**The missing thing.** The mission is "orchestrate 1:1 and 1:many ntm sessions." The machine right
now runs 8 tmux sessions belonging to six projects, and `zeststream-cast-wave-20260825-1910` — a
session created by an earlier wave — has been leaking for six days because nothing owns teardown.
Every coordination artifact in the plan is machine-global: `omp-idle-dispatch`'s ledger is a single
hardcoded JSONL path; my own commit-msg gate's `.git/MSG_SRC` false-refused another pane's commit
last wave because it has file lifetime in a shared checkout; bead prefixes are the one namespace
that already works (`omp-orchestrator-*`, `bd-*`), and nothing else follows their lead.
**How it works.** The beads prefix becomes the instance key. A stage's runbook declares its
namespace; every ledger path, tmux session name, watcher target, and hook scratch file is
`<prefix>-scoped`. The orchestrator refuses to touch a resource whose prefix doesn't match the
current runbook — the same refusal shape as path-literal-guard, but for identity instead of paths.
**Cost.** Environment-variable plumbing through ~6 crates that already accept `--repo`/`--session`
flags (omp-idle-dispatch already has `OMP_DISPATCH_LEDGER`); no new crate.
**How it fails.** Prefix sprawl — abandoned namespaces accumulate like the leaked session did. The
counter is idea #2's expiry lease: a namespace with no heartbeat for its window is torn down with a
typed record, the way `reap-finished-panes` returns pane capacity.
**Who it serves.** 1:many directly: two projects can run journeys on one machine without merging
ledgers or stealing each other's panes. Josh runs six businesses on this Mac tonight; the plan
describes one.
**It refuses.** Global registries (no machine-wide "the ledger"), silent cross-project pane sends,
and sessions without owners. The refusal already has a scar: the leaked wave session is the
unowned-resource failure, visible in `tmux list-sessions` for six days.

## B. HUMAN-DECISION RECORDS — S9 has no mechanism and the session produced eleven orphans
**The missing thing.** S9 says "human requirements stored" and gives it no artifact, no schema, no
home. Measured from this session alone: Josh's mid-flight rulings ("continue, just make sure…",
the retire-standard correction, the SOTA-bar framing, the stand-down itself) live in pane
scrollback; the reap found seven real conditions dying with the pane; %1413 lost an entire grading
task to compaction. The plan stores BEADS beautifully and stores DECISIONS not at all.
**How it works.** A decision record is a bead comment with a required shape: `{decision, question,
decider, options_considered, binds_stages, supersedes, review_after}`. S9 is the recurring stage
that (a) files every human intervention observed during a stage as a record, and (b) amortizes
records: decisions with `binds_stages` get promoted into AGENTS.md/CLAUDE.md (durable) or expire
into beads (actionable); everything else is deleted. The `review_after` field is the anti-hoard
leg — a decision that binds forever is a rule nobody can challenge.
**Cost.** A comment template and a promotion checklist; storage is br, which already survives the
pane. No new infrastructure.
**How it fails.** Ritual theatre — records filed and never amortized, growing monotonically until
AGENTS.md is the 60,467-line shell accretion of policy. The counter is the S9 done-signal: "records
amortized this cycle: N promoted, M expired" — a number, not a folder.
**Who it serves.** Josh (decisions stop evaporating), every future agent (the plan's own §8
open-questions get real answers instead of folklore), and the next compaction, which will take the
context but not the ledger.
**It refuses.** Decisions that bind without `review_after`; requirements stored as chat; and —
the sharp one — agent-asserted "Josh said" without a record ID. If it isn't a record, it isn't a
requirement.

## C. FAN-OUT/FAN-IN WITH PER-TARGET RECEIPTS — 1:many is the mission and the plan has only 1:1
**The missing thing.** "1:many ntm sessions" appears in the mission and nowhere in the nine
stages as a mechanism. Tonight's reality: 19 dispatch waves were hand-typed one pane at a time;
`ntm --robot-send` returns transport-level success per send; and `cp-z42vu` already measured the
1:1 failure — `success:[4]` with no packet. At N targets that defect stops being an incident and
becomes a probability: any multi-pane wave silently loses packets somewhere.
**How it works.** One `DispatchPacket{targets: N}` action expands to N sends, collects N
per-target receipts (the per-target receipt shape already exists: `IrcDeliveryReceipt` upstream at
tools/hub/types.d.ts:8, DECLARED only; `ntm --robot-send` per-target JSON measured), and emits a
fan-in verdict: `all-arrived | partial{which, why} | none`. The barrier is the done-signal for S5
at wave scale; a partial fan-in is a typed refusal to proceed, never a summary that rounds down.
**Cost.** An orchestrator-side loop over an existing per-send path plus a receipts map; the
upstream receipt type means the wire vocabulary is already named.
**How it fails.** The barrier itself becomes the lie — "partial" treated as "close enough" under
schedule pressure. Refusal: the fan-in verdict is consumable by S6 (grading) which refuses to grade
a wave whose fan-in was partial without a named reason. Partial results are visible forever.
**Who it serves.** 1:many literally; also single-operator Josh, because the hand-typed wave is the
current 1:many and it is also the thing nobody can audit afterward.
**It refuses.** Counting sends as deliveries (the cp-z42vu pattern at scale), fan-out without
per-target evidence, and — this is the negative pattern the stage must be structurally unable to
commit — marking a wave complete when any target's receipt is missing.

## D. "AMAZING" WITHOUT A FALSIFIER IS PROSE — the runbook needs five more fields
**The missing thing.** The seven-field runbook (Trigger, Dispatch packet, Amazing, Adequate,
Negative patterns, Skills, Done signal) will produce adjective-grade "Amazing" entries, because
nothing in the schema forces a number under them. This plan's own best artifact — §09's
done-definition template — already solved this for milestones (OBSERVABLE, fails-on-pre-state,
anti-Goodhart risk field), and the runbook doesn't inherit it. Meanwhile the session measured what
happens when refusal discipline lacks a threshold: 162 consecutive refused ticks that nobody
consumed, and `FINDING_THRESHOLD = 3` sitting in finding-dispatch as the right idea with zero
stage-level adoption.
**How it works.** The runbook grows five fields, each inherited from something already built:
**Metric** (the number that falsifies "Amazing" — e.g. S5 Amazing = zero unclaimed dispatches
across N waves, counted by dispatch-claim-fence refusals), **Owner** (a bead id or role, per §4's
own allowance-row upgrade), **Dies-when** (the condition that retires the stage definition, per
`ALLOWED_COLLISIONS`' "Dies when…" shape), **Cost** (fed by `ContextUsage`/`PerplexityCost`
upstream types or the OTEL export — Q2 closes as a side effect), **Escalation** (the threshold at
which the stage stops being silent and pages a human — `FINDING_THRESHOLD == 3`, finally consumed
at the layer it was built for).
**Cost.** Schema amendment and one pass per stage; every field has an existing measurement home.
**How it fails.** Metric theatre — thresholds set so low they always pass. The counter is the
anti-vacuity leg §06 already owns: an "Amazing" whose metric passed pre-milestone is not a metric.
**Who it serves.** The next grader (objective pass/fail), the investor (adjectives are unpriceable;
numbers are comparable), and Josh at month three, who otherwise owns every "is this amazing yet?"
judgment by hand.
**It refuses.** "Amazing" as prose; stages without owners; refusals without escalation; and the
specific failure this session named twice — a threshold met by widening tolerance instead of
improving the system.

## E. S1 INCEPTION BUNDLE — the plan has never started a project, and its gates can't travel
**The missing thing.** S1 (inception: new project, CLAUDE.md, AGENTS.md, gates, infra) has never
happened — the entire plan was written against a repo that already exists, and it assumes facts
that only hold here: the gates scan `crates/*/src` of a 26-crate workspace; the installer carries
compile-time roots (`env!("CARGO_MANIFEST_DIR")`, 16 occurrences across 14 files, plus a literal
`/Users/josh` fallback); 08's doctor/init are PROJECTED. Month three discovers that "run the
journey on a new project" was never possible, only "run it on this project again."
**How it works.** S1's deliverable is a bundle, not a doc: `orchestrator init <repo>` emits (a) a
seeded `.beads` with the project's prefix — which is idea A's namespace key born correctly, (b)
the gate set installed with an allowance file pre-seeded for a foreign layout (the path-literal-guard
allowance mechanism already exists; it seeds instead of scanning a tree that doesn't match), (c)
CLAUDE.md/AGENTS.md skeletons carrying the runbook fields, (d) the first milestone as a bead with
an admissible observable per §09's template. Runtime root resolution (`RepoAdapter::root()`, already
specified in 08 §4) replaces compile-time constants on the installer path.
**Cost.** The largest survivor — the installer fixes are real work — but it is the milestone the
plan already calls M6; this idea gives M6 an S1 home and a refusal set instead of a transcript.
**How it fails.** Colonisation: the bundle imposing this repo's 26-crate conventions on a
three-file script repo. The refusal is 08 §3's own table — the `.sh`/`.py` prohibition is opt-in
for adopters (`OPTED_OUT_BY_ADOPTER`), gates default to the minimal set, and "amazing" for a
foreign S1 is defined by the adopter's observable, not ours.
**Who it serves.** The mission's first clause — "new project" — which today has zero mechanisms
behind it; and month three, which otherwise begins with someone hand-copying this repo's skeleton.
**It refuses.** Unverifiable inception (S1 closes on the adopter's first admissible observable,
not on our checklist), convention colonisation, and compile-time host paths in anything the bundle
installs.

## F. THE PACKET JOURNAL — 19 waves of dispatch exist only in scrollback, and that is why forensics fails
**The missing thing.** Every dispatch this session — including the two unclaimed-bead packets, the
%1398 phantom-pane send, and the cp-z42vu vanishing — was hand-typed into a pane. There is no
artifact from which to replay, diff, or audit a wave; the reap could only name "seven conditions
living in scrollback" because there was nothing else. A journey that runs S5 nineteen times with
no packet record cannot answer its own first forensic question: *which packet produced this
state?*
**How it works.** S5 writes an append-only JSONL — same shape discipline as
`docs/plan/SURFACE-MAP.jsonl` (372→591 rows, one object per line, no prose): `{ts, wave, packet,
targets, receipts, claim_id, runbook_stage}`. The fan-in verdict (idea C) and the decision records
(idea B) both append here; a post-mortem is `jq` over one file. Replay is optional and
permissioned — the journal records, it does not re-send.
**Cost.** One writer on the dispatch path and a directory. The format is already the house style.
**How it fails.** Journal-as-theatre: written, never read, growing until it is the 60,467-line
accretion again. Counter: the S6/S9 done-signals consume the journal (graders cite packet IDs;
S9 amortization reads it), so it is load-bearing by construction, not by intention.
**Who it serves.** Every later forensic question ("which wave dispatched to a nonexistent pane?",
answerable in one grep instead of a reap), new contributors reading history, and idea A's expiry
lease, which needs the journal to know what a namespace last did.
**It refuses.** Hand-typed dispatch as an acceptable channel for staged runs; post-hoc
reconstruction from human memory; and any forensic claim about a wave that the journal cannot
confirm — "the packet said" becomes a citation, not a recollection.

---

## SCORED OUT (visible in the 20, cut at winnow, one line each)
- ms outcome/bandit as the Skills-measurement home (18): real, but it makes stage runbooks depend
  on a recommendation engine — the Skill field should cite a measurement record, not adopt one.
- Stage transitions driven by agent_end (19): already the plan's position post-refutation; restating.
- ee mesh consent lanes as permissioning (17): the shape is right (lanes + approval tokens), the
  substrate is wrong for panes that don't run ee — recorded as prior art for ack-spine, not wired.
- Per-stage undo artifacts (20): folded into D (Dies-when + the franken_lean chokepoint-undo
  precedent already adopted in §06).
- Machine-resource arbiter (16) + mux canonicalization: folded into A — a lease is a namespace
  with a heartbeat, and the arbiter without a namespace is a second global registry.
- Cross-repo DAG (15): true 1:many-repos future, but it needs A (namespaces) and F (journals) to
  exist first; filing it now would be the 20-mechanisms mistake — a number with no derivation.
- S2 beads-DAG-first discipline: already §11/S4 doctrine (beads-north-star); restating it is not
  an idea.
- Telemetry default for new projects, secret-hygiene stage, OTLP receiver: all folded into D's
  Cost field (one measurement home, not three stages).
- "Grading as a market" (7): this wizard exercise is the prototype; it becomes D's Metric field
  scored cross-model, not a stage of its own.
EOF
wc -l /tmp/grade/WIZARD_IDEAS_1409.md
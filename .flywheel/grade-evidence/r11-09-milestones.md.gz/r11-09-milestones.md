# R11 FIX LOG — 09-milestones.md — SilverWolf (%1409)

Round-10 source: /tmp/grade/r10-09-milestones.md (adversarial hillclimb, 16 deduped findings).

## RETRACTED (briefing-manufactured, with reasons)
- **M1 (BLOCKER, "milestones lack the seven-field runbook block")** — RETRACTED. The seven-field
  runbook (Trigger/Dispatch packet/Amazing/Adequate/Negative/Skills/Done) is 12-journey's STAGE
  contract; 09's contract is its own §1 template (Mn + OBSERVABLE / NOT IN SCOPE / STARTING
  POINT / RISK), present on every milestone. The round-10 briefing applied the wrong document's
  shape to this one. Nothing fixed; nothing to fix.

## FIXED (13 edits across 12 sites, verified in-file by marker grep after write)
1. M2 (HIGH, real): M1's acceptance was dependency-name theater — adding an unused manifest line
   would satisfy the grep. FIXED: observable now requires (a) the dep AND (b) a NAMED shared
   pane-state type in both public parse/emit signatures (grep the type name, not the crate name)
   plus the real stdout fixture leg.
2. M3 (HIGH, real): M1 citations pointed at adjacent constructs. FIXED: regression-test cite
   :1049 → `observed_idle_state_counts_as_free_capacity_before_confirmation` at :1056 (predicate
   :1062-1063). FIXED in BOTH sites (M1 body and the §5 rubric row).
3. M4 (HIGH, real): M2's observable counted the wrong `br` calls — the six literal
   `Command::new("br")` sites are comments/assignee ops/test beads; the production queue read is
   the configured `br ready` at omp-orchestrator/main.rs:836-839. FIXED: observable now requires
   the production selector's invocation to change (argv trace or selector import of the bv
   kernel), explicitly noting a literal spawn-string grep is not the test.
4. M5 (HIGH, real): M3's "the packet provably arrived" overclaimed — `ReceiptConfirmed` is
   receiver-side screen evidence (timer reset + content change), carries no packet identity.
   FIXED: observable reworded to `ReceiptConfirmed` + "the receiver's screen changed in
   packet-shaped ways"; the packet-correlated receipt (IrcDeliveryReceipt-shaped, DECLARED only
   upstream) named as the stronger form, not required for M3.
5. M6 (HIGH, real): the cp-z42vu incident evidence is narrative copies (pre-journal). FIXED:
   STARTING POINT now records the caveat and requires M3's observable to be demonstrated on a
   JOURNALED dispatch.
6. M8 (BLOCKER, real): M4's observable could be satisfied by a worker closing its own bead
   (human_touch_count==0 while the closer IS the worker). FIXED: observable now requires the
   close actor to be the verification/grader side, never the dispatched worker — ack-spine's own
   taxonomy classes worker-asserted Finished as a claim.
7. M9 (BLOCKER, real): M5's baseline used the retired five-layer vocabulary. FIXED: rewritten
   against the current seven-row loop (observe WORKS-with-defect; actionable filter FIXED/-oco
   seam open; consume FENCED; actuate absent; complete AVAILABLE-NOT-WIRED).
8. M10 (HIGH, real): M5's global `br list --status closed` could not bind closes to the run.
   FIXED: each of the ten bead IDs must be bound to the run in the dispatch record; per-bead
   `br show <id> --json` replaces the global count.
9. M11 (HIGH, real): M6's observable had no executable procedure. FIXED: five-item transcript
   contract (install cmd + exit, cache-absence proof, fixture path, first-tick cmd, verdict JSON).
10. M12 (HIGH, real): `-V` 5/9 → **6 of 9** with the six responders named and the three fails.
11. M13 (BLOCKER, partially real): M7 had no window. PARTIALLY manufactured (the section
    deliberately says "a window of stated length — first defensible number"); the real residue
    was that no number was chosen. FIXED: **24 hours** named (the measured 4h19m failure fits
    inside it five times) and the threshold's production consumer cited
    (finding-dispatch/src/lib.rs:15 consumed at :23 — not the test).
12. M14 (HIGH, real): the "20 mechanisms" figure §01 does not contain (my round-9 finding f3,
    still unfixed) — FIXED here at the citing site: reworded to §01's actual census claim
    (26 crates, 379→407 tests, BUILT≠WIRED census). The 162/4.2h figure annotated as a §00-named
    evidence gap (no deriving command; §00 owes it).
13. M15 (HIGH, real): "Every zero in this section was re-derived with the harness grep" was false
    (M1's zeros used strings/grep on built binaries; M6's are redirect-separated exit probes).
    FIXED: the sentence now names each milestone's instrument.
14. M16 (HIGH, partial): the upstream-family cite `GuestIdleReconcilerCtx (dist/types/session
    family)` — my own wave-8 wording, wrong path — FIXED to `dist/types/collab/guest.d.ts:9-30
    (probed)`. Remaining bare section-refs and README pointers judged acceptable (historical
    incident pointers, not load-bearing constructs).
15. M17 (MEDIUM, partial): ordering asserted. FIXED: one sentence tying the M1→M7 chain to §04's
    measured deepest path (finding-dispatch → omp-orchestrator → ack-stage → receiver-receipt →
    tick-monitor).

## RETRACTED-ADJACENT judgment (M7, recorded honestly)
M7's "bare-success no-dispatch exits" claim was judged OUT OF CONTRACT for M3: a tick with zero
dispatches returning success while emitting its typed refusals is correct loop behavior — the
cp-z42vu defect is success-WITH-claimed-send. The refusal-accounting failure mode it points at is
real but belongs to M7's escalation threshold, which now names it. Dismissed with reason, not
silently skipped.

## VERIFICATION
Post-write marker grep: 12/12 construction markers present in the file (the one initial "missing"
marker was my own check string spanning a line wrap — confirmed present on re-grep). No ledger
row written (fix round). Numbers-gate addition made last wave (unsafe_both_mechanisms) unchanged;
the orchestrator's test_functions figure (406) drifted to 407 tonight — expected behavior for a
live-drift registry, left to the gate's next run.

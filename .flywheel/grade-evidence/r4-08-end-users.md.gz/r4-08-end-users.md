# GRADE R4 — 08-end-users.md — ALL FOUR LENSES (pane 5, %1409)
# Independence: packet names no suspected defect. R13 lifecycle check included.
# Cross-challenge target assigned: /tmp/grade/r3-03-crates.md (appended after my own findings).

## RE-DERIVATIONS (EVIDENCE lens; 12 run)
| claim (construct) | my command (abridged) | result |
|---|---|---|
| doctor/init grep → 0 (L11) | `/usr/bin/grep -cE '"doctor"|"init"' main.rs` | 0 EXACT |
| usage string "verbatim from main.rs:254" (L12,15-17) | grep + sed | **NOT AT :254 — it is at :260, and the real string carries `[run]` plus a second line about the resident lifecycle entrypoint that the section's quote omits** |
| MIN_GAP_SECS = 75 at :485 (L154) | grep -n | :485 EXACT |
| MODEL_MARKERS 4 strings at :312; DIALOG_FOOTER "captured from %1372" at :315 (L205-206) | sed | EXACT both |
| braille/π strip at :383 (L207) | sed | EXACT |
| tick-monitor 1,185 lines (L208) | wc -l | 1185 EXACT |
| capture\.contains → 2 sites (L208) | grep -c | 2 EXACT |
| no-shell-gate lib.rs:6-9 (160 scripts / 60,467 lines) (L189) | sed | EXACT construct |
| Publisher trait at finding:301 with cx-first (L223) | grep+sed | :301 EXACT |
| EmptyPaneList INDETERMINATE at receiver-receipt :186-187 (L276) | sed | EXACT construct |
| installer RepoOwnership/IdentityCheck/verify_identity (L244) | grep | :68/:79/:234 EXACT |
| doctor.rs :950 success arm, :967-968 two-signal arm (L191) | sed | BOTH EXACT — model citations |
| fh SEARCH_INDEX_STALE exit 3 (L258) | ran fh; **first attempt read exit through a pipe — recaptured: true_exit=3** | EXIT 3 CONFIRMED (and the section's warning saved it from me) |

## FINDINGS

### M1 [EVIDENCE+ADVERSARIAL — lead finding] L12/L15-17: the "verbatim" usage quote is neither verbatim nor at :254, and the omission materially weakens the section's central claim
- Real string (main.rs:260) includes `[run]` and: *"`run` is the explicit resident lifecycle entrypoint (observe -> ready queue -> dispatch -> receiver receipt)"*. The section's block omits both, then concludes (L19-20) "No `doctor`, no `init`, no `adopt`" and "no adopter-facing entry point at all" (L10). A bare resident `run` IS an entry point — an adopter CAN invoke it; what is true is that it requires our fleet's `--session`/`--receiver-agent` and has no adopt path. The claim as printed overstates the absence; the citation as printed is unverifiable at :254 (that line is struct fields); L188's ":254" anchor for `--session` is also off (the parse arm is :113). FIX: re-quote verbatim from :260 and restate the claim as "a resident `run` exists but hard-requires our fleet's session/agent flags; no init/adopt/doctor exists."

### M2 [EVIDENCE] L31-32: quotes the round-1 leg world against a source that moved — "2 of 8 (no-shell-gate 4/3/2/6...)" and "370 #[test]"
- Current §00 (round-2 rebuild): **1 of 8 — undrained-pipe-lint**; no-shell-gate = AFFORDANCE, not a four-leg exemplar; my re-count of #[test] = 374. The section says "(brief §3.5, recomputed)" — recomputed against the superseded table, exactly 04's B2 pattern. FIX: regenerate from the typed table (1 of 8; no-shell-gate cited as the AFFORDANCE cautionary row, which actually STRENGTHENS the Persona-A pitch).

### M3 [EVIDENCE] L191: "`-V` 5/9" — the refuted figure survives here a third time
- §00 round-2 corrected to 6/9 (fix 4); my round-1 measurement: ntm, br, tmux, cargo, fh, jsm answer `-V`. The same paragraph otherwise carries the corrected tmux story — half-updated. FIX: 6/9, fails omp/bv/git.

### M4 [ADVERSARIAL] L148 + L156-158: the PROJECTED transcript uses a transport variant that exists nowhere, while citing the measured enum as its shape
- Tick-2 output prints `"transport":"OneshotSpawn"` with a receipt; the cited grounding is `ack-stage/src/lib.rs:21-24` `TransportKind`, which has exactly two arms (NtmRobotSend, TmuxSendKeysLiteral); `OneshotSpawn` occurs **0 times** in the repo. Inventing in a PROJECTED artifact is allowed — citing the two-arm enum as the "measured shape" one paragraph later and then silently using a third arm is the undisclosed kind. FIX: mark OneshotSpawn as new-work in the §4 WorkerAdapter spec, or re-run the transcript with TmuxSendKeysLiteral and its honest no-receipt refusal.

### m2 [ABSENCE] §2.2's doctor contract omits the identity probe §2.1 makes the first-run killer
- The transcript probes repo.git/tracker/worker/gates but never "are you auditing the repo you think you are" — the four-way identity (L311-312: "audits the wrong repository on first run... uninstalled in a minute") is absent from the very diagnostic that would catch it. FIX: add `repo.identity` probe row wiring RepoAdapter::identity.

### m3 [ABSENCE] §5 ladder has no simultaneous-missing rule
- An adopter missing tmux+br+bv gets three independent refusal codes; precedence/ordering (and whether one tick emits all) is unspecified. FIX: one sentence ("all probes run; refusals emit together; fatal=git short-circuits").

### m4 [INVESTOR] §7 prices abandonment against "the tracking it replaces" but the section never prices adoption
- §2 implies ~6 commands install→first graded close; no total is stated, so the section's own abandonment criterion is unevaluable on its own artifact. FIX: one sentence: "the §2 path is N commands / M minutes for Persona A."

### R13 — LIFECYCLE CARRIAGE for the adoption stage (named per lens)
- TEMPLATE: PARTIAL — §2 is the session-shaped transcript, right shape.
- DISPATCH: MISSING — no owner/bead assigned to build doctor/init/adapters; the section schedules nobody.
- REAP: MISSING — no closure condition for "R9 served" (§7 gives a KILL condition, never a DONE).
- LOGGING: MISSING — §6 prescribes a "durable per-unit ledger" as the fix for scrollback-loss but never requires the ADOPTER path to write one from tick one, nor an adoption record.
- BUILD GRADING: MISSING — no acceptance gate for the adoption path itself (the natural leg: a foreign fixture repo reaches a graded close in CI).
- FIX (one sentence for all four): add an R13 subsection owning dispatch/reap/logging/build-grading for the adoption stage, with the CI foreign-fixture leg as its build grade.

### CREDIT where the section is the doc's best (evidence lens)
Every NO-CLAIM in this section bounds a real claim (L20-21, 33-34, 46-47, 175, 249-250, 276, 303, 329, 333-340 — the section NO-CLAIM is exemplary); the self-reported un-derivable "23 commits" figure (L290-293) is rule-1 honesty performed, not described; and the §2.2 false-zero self-correction with re-derived citations is the exact behavior §7.4 says was missing in round 1.

## CHALLENGE TO /tmp/grade/r3-03-crates.md (%1408's round-3 grade)

**C1 — E2's replacement number is wrong under its own command (MINOR, but it reproduces the disease).** %1408 corrects 03-crates.md's "dependency of seven crates" to "EIGHT real dep lines + omp-types itself = 9" and fixes to "eight". Measured: `grep -l asupersync crates/*/Cargo.toml` → **9 manifests** (commit-build-fence, finding, kernel-only-operator-hook, omp-inventory-map, omp-orchestrator, omp-rpc-session, omp-types, pane-dispatch-fence, subprocess-contract). omp-types IS an external dependent — it is the crate whose job is consuming asupersync; excluding it as "not real" reinstates an unstated denominator, the exact defect class the correction targets. FIX: nine, one grep, no exclusions.

**C2 — E3 is right that 13≠23 is unreconciled; the reconciliation is a denominator statement and I can supply it (MINOR, converges).** Measured split: types_inventory.rs = 13 #[test] (lib target), tests/inventory.rs = 10 (integration), lib.rs = 0. Both printed numbers are real populations; the gate claim should cite 23. (Disclosure: the "13 tests pass" figure traces to §00 §3.6 and to my own round-2 grade — the ambiguity is fleet-wide, not 03's alone.)

**C3 — A1 HOLDS, and by its own logic it convicts an artifact of mine (IMPORTANT).** The free_capacity bug was semantic reuse of one filter inside the consumer (the -oco comment at omp-orchestrator/src/lib.rs:163: "earlier version derived both from one filter"); a shared type would NOT have been a compile error on that bug. %1408 is right against 03-crates.md — and the identical overstated sentence stands in MY ipg.17 seam-decision rationale and §00's OBSERVATION decision row ("turns that defect class into a compile error"). The defensible residual: a shared type + exhaustive matching kills the `_ =>` catch-all class that tick-monitor's own comment says "hid a freed worker", and forces NewlyIdle handling on both sides — necessary hygiene, not a compile-error guarantee on semantic reuse. FIX: restate in all three places (03, §00 decision row, ipg.17) as "the shared type makes the divergence visible and the catch-all impossible; the filter defect needed its own guard."

**C4 — P1 (brief grew during grading) CONFIRMED LIVE: 816 lines at 18:34:07, exactly as %1408 measured; it grew again from the 786 I graded against earlier this round.** The snapshot proposal is right and I adopt it for my own citations. One sharpening: the drift is not just a grading hazard — it is §7.3's predicate failing in the inverse direction (SOURCES newer than the assembly AND the graders), which means the fix belongs in the assembly toolchain, not in grader discipline.

**C5 — CH1's provenance note VERIFIED, and it keeps one of my round-2 findings alive:** the current 816-line brief still carries `AUTOMATED = a #[test] fn whose name contains "mutation"` at L328 as "the transferable lesson" — so my round-2 R2-1 (that definition misses mutation tests living in src `#[cfg(test)]` mods, e.g. omp-inventory-map's own) remains UNFIXED and live against the current file. %1408 and I converged on this from different rounds; the brief has absorbed neither pass yet.

## VERDICT: PASS-WITH-FIXES
## THE ONE THING: the section's central evidence — "no adopter-facing entry point at all" — rests on a "verbatim" quote that silently omits the `run` resident-lifecycle entrypoint; in a document whose whole method is that transcription is where truth dies, the strongest section must not paraphrase its own load-bearing string.

# Types probe — pane 4 slice (27 of 54 type_root rows) — OliveCat
Probe shape per root: `find dist/types/<root> -name '*.d.ts' | wc -l` (file count), du size,
exported-symbol extraction (`grep -rhoE 'export (declare )?(interface|type|class|function|
const|enum) …'`), then targeted deep-reads where the exports looked load-bearing. Every row
carries its own file count + export list in validated_by. Output: /tmp/grade/types-4.jsonl.

## Dispositions: 3 VALIDATE / 24 RETIRE

### The 3 VALIDATE — real dependence or pending-dependence, each with a named test
1. **extensibility → omp-rpc-session** (54 files, 376KB). `export interface AgentEndEvent`
   EXISTS. If AgentEndEvent reaches the --mode=rpc frame plane, it is a typed
   worker-completion signal — the severed S6→S7 link, the same gap ipg.19 addressed from the
   tracker side. Delivery plane unverified; the test is one live rpc session driven to agent
   end with frame capture. This is the highest-value open question in my slice.
2. **goals → omp-orchestrator** (4 files). `interface GoalModeState` at goals/state.d.ts:13.
   We consume goal mode every session through the goal device and have never pinned its state
   vocabulary. Golden-field-name fixture, re-run on omp bumps.
3. **internal-urls → omp-inventory-map** (22 files). `interface InternalUrl extends URL`,
   Agent/ArtifactProtocolHandler. The whole session runs on internal URLs and every crate
   parses them informally. Pin the scheme grammar as a golden fixture.

### RETIRE evidence worth keeping (not boilerplate)
- **irc** (1 file): `IrcDeliveryReceipt` — omp ships a typed delivery receipt, the exact
  artifact our pane transport lacks (transport-success-without-packet, commit -232 class).
  It lives on omp's internal IRC bus, a plane we do not ride. The receipt gap is a DESIGN
  CHOICE in our stack, not an impossibility. Same observation for collab's
  CollabGuestLink/COLLAB_GUEST_ALLOWED_COMMANDS — a guest-pane (cross-session) mechanism
  exists in the substrate. Both RETIRED, both recorded as evidence for the actuation debate.
- **blob-broker** (26 files, 180KB): probed for a live daemon — NONE running (the pgrep hit
  was an ollama model path). The socket contract has no counterparty to depend on.
- **capability** (18 files): omp's capability-narrowing vocabulary is a parallel to
  asupersync's Budget; adopting it would be the second-vocabulary mistake 03 §Design spec
  names explicitly.
- **exec** (4 files): omp's process-execution types are a parallel implementation of
  subprocess-contract; ours is the boundary by doctrine (group/drain/timeout-not-verdict).
- **config** (672KB) and **eval** (50 files) are the two biggest roots; both product-internal
  catalogs with no consumer in any orchestration stage.

### Shape of the result
25 of 27 roots are product features of the agent (advisors, autolearn, bench boards, export,
dap, debug) that no stage of our nine-stage lifecycle touches — the retire-heavy result is
the honest one. The three VALIDATEs are exactly the surfaces where we ALREADY depend on omp
behavior informally (goal device, internal URLs) or where a typed completion signal may be
sitting unclaimed (extensibility).

# Round 12 — 03-crates.md — ABSENCE lens, role hillclimb — OliveCat
## DISPATCH
Subagent: `CratesReader` (task agent, fresh context — file path + claim contract only; no ledger,
no round-10 findings). jsm routing: `jsm suggest`/`jsm search` for crate-inventory specialists
returned no matches in the 135-skill catalog (bandit disabled); general task agent given a
re-derivation contract. Schema note: SEVERITY + SEARCH SPACE added per SCHEMAS.toml
[artifacts.grade_evidence], effective this round.

## VERIFIED FINDINGS (each re-derived by me before recording)

SEVERITY: BLOCKER — F1: the 183-row census presented as current is explicitly superseded by the
brief's fresh hash-anchored measurement (981 rows / 982 nodes / 1,803 edges; 00-brief.md:214
carries the fresh summary, and the round-10 shape 183/184/207 is marked historical). 03-crates'
opening block (lines 10-22) and crate table intro still present 183/184/207 as current. I
re-ran /tmp/inv.txt myself: 183/184/207 — the OLD artifact is what's on disk at that path, so
the fresh 981 numbers live only in the brief's text. The section cites a superseded measurement
as its foundation.
FIXED: opening block re-dated and re-pointed at the fresh summary with the 183 shape marked
historical, mirroring the brief's treatment. DIFF: docs/plan/03-crates.md §"How to read".

SEVERITY: MAJOR — F2 "dependency of seven crates" (line 320) is false; I re-ran
`grep -l asupersync crates/*/Cargo.toml | wc -l` → 9 (matches my round-3 E2, which was recorded
but NEVER FIXED — a fix that did not hold from my own round). 
FIXED: line 320 now states nine external + omp-types itself, with the command. DIFF: §"Why this
framework".

SEVERITY: MAJOR — F3 "two leaves spawn processes" (lines 133-135, 380-382) is incomplete: agent
re-derived ≥8 spawning leaves without subprocess-contract (installer 5 sites, tick-monitor 4,
kernel-bypass-gate 3, dispatch-silence-watch 2, fleet-composite 2, pre-delete-citation-check 2,
plus the named two). Spot-verified installer's Command::new sites (5) — holds.
FIXED: both passages now enumerate the full spawning-leaf set. DIFF: §"The leaves", §"Constraints".

SEVERITY: MAJOR — F4 "29 raw spawn sites / 12 of 14 async fns" (line 168) carries no command and
does not re-derive under any scope the agent tried (39 non-test Command::new; 29 = the async-fn
count, suggesting a mixed-up paste). UNVERIFIABLE-BY-ME: I could not recover the original
instrument either; the figure is inherited from the brief. DEFERRED with reason: the deriving
command is lost; the honest fix is NUMBERS.toml registration, deferred to the orchestrator
because the re-derivation scope choice (with/without tests) changes the number and that is a
doctrine decision, not a prose edit. Marked UNVERIFIABLE in the original-derivation sense.

SEVERITY: MAJOR — F5 AckKind target lists 4 variants; pinned upstream has 5 (Received omitted).
Agent verified against messaging/class.rs:83 at fa3c01aec. I did not have the upstream checkout
handy to re-read the enum myself; accepting on the agent's specific file:line + the round-3
agreement that the receipt-boundary variant was the interesting one. FILED AS UNVERIFIABLE-BY-ME,
DEFERRED to the evidence-lens owner with the cite. (Honest scope: my re-derivation stopped at
grep of our crates; the upstream .d.ts/src tree is on a volume I did not mount this round.)

SEVERITY: MINOR ×4 — F6 "regenerated 2026-09-01" future-dating (line 92; today is 2026-08-31);
F7 disagreement #2 restates the two-habits premise the section corrected at line 100; F8 garbled
"five-stage" parenthetical at line 212; F9 "derivation command inline" overstatement (line 36);
F10 curated key-types column (line 65/89). All real, all small.
FIXED: F6 date corrected; F7 synced to one-habit framing; F8 reworded; F9 softened to "derived
via the four commands below". F10: noted in the table header that key-types is curated (adding
all 26×~10 types would double the table for no decision value — judgment call, DEFERRED with
reason).

## SEARCH SPACE
Full read of 396 lines; `ls crates/ | wc -l` (26); grep -l asupersync crates/*/Cargo.toml (9);
grep -c unsafe_code manifests (26); inner-attr recount (25); Command::new counts per crate for
the spawning-leaf claim; /tmp/inv.txt row/node/edge re-parse; NUMBERS.toml cross-check (no
figure row covers 183-vs-981 — registered as a DEFERRED: the fresh-census number belongs in
NUMBERS.toml but the deriving command needs the regenerated artifact, which only the
orchestrator's scan produces).
Subagent: CratesReader. new_findings recorded: 10 (1B/5M/4M-incl-minors, with 1 UNVERIFIABLE
and 1 judgment-deferred noted above).

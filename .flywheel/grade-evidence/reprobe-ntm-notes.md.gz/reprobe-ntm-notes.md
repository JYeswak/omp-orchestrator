# NTM reprobe notes

## Probe coverage

- Input slice: 88 ntm rows from /tmp/grade/REPROBE.jsonl.
- Priority order: the packet enumerated 14 named orchestration rows (despite saying 15); those 14 were probed first, followed by the remaining 74 ntm rows.
- Probe for every row: ntm <surface> --help with a 1-second subprocess timeout.
- Result: 87 recognized surfaces returned exit 0; 0 timed out; ntm:ntm returned exit 1 with Error: unknown command "ntm" for "ntm".
- ntm:ntm is classified RETIRE as a scrape artifact, not a real surface.
- No CONSUMED or VALIDATE flips occurred because the probe only establishes the surface contract; no new current callsite was found. Twenty rows flipped RETIRE -> WIRE.

## WIRE flips

Each WIRE row has maps_to_crate and its gain in the JSONL. The help probe established that the command is real; implementation remains future work.

- omp-orchestrator: ntm:claim, ntm:locks, ntm:lock, ntm:handoff, ntm:conflicts, ntm:checkpoint, ntm:agents, ntm:adopt, ntm:changes, ntm:audit, ntm:mapping, ntm:message, ntm:preflight, ntm:interrupt, ntm:respawn, ntm:resume, ntm:save.
- fleet-composite: ntm:health.
- installer: ntm:doctor, ntm:deps.

These are not arbitrary adoption decisions: each help result names a concrete orchestration or installability behavior. The WIRE set is intentionally bounded; no command that would create a competing supervisor or bypass the typed dispatch/claim path was wired.

## RETIRE decisions after probing

The following recognized commands were probed and retained as RETIRE with validated_by populated in the JSONL:

- Human/operator or UI-only: ntm:attach, ntm:bind, ntm:completion, ntm:copy, ntm:dashboard, ntm:errors, ntm:extract, ntm:get-all-session-text, ntm:help, ntm:level, ntm:list, ntm:overlay, ntm:palette.
- Competing control-plane composites: ntm:assign, ntm:coordinator, ntm:controller, ntm:rebalance, ntm:review-queue, ntm:scale.
- Session/project provisioning outside the supervisor runtime: ntm:add, ntm:create, ntm:config, ntm:init, ntm:profile, ntm:profiles, ntm:quick, ntm:recipes, ntm:session-templates.
- Delegated or duplicate substrate surfaces: ntm:beads, ntm:git, ntm:guards, ntm:hooks, ntm:kernel, ntm:policy, ntm:safety, ntm:serve.
- Analysis, history, model, or provider tooling not consumed by the orchestrator contract: ntm:analytics, ntm:approve, ntm:bugs, ntm:cass, ntm:cleanup, ntm:codex, ntm:diff, ntm:ensemble, ntm:history, ntm:memory, ntm:metrics, ntm:models, ntm:modes, ntm:openapi, ntm:personas, ntm:plugins, ntm:quota, ntm:redact, ntm:replay, ntm:repo, ntm:rotate, ntm:scan, ntm:scrub, ntm:search.
- Human-overseer-only: ntm:mail. Its help says it bypasses contact policies and impersonates the HumanOverseer identity; automated orchestration should use ntm:message instead.
- Destructive session control: ntm:kill, ntm:rollback. Human approval/recovery owns these rather than an autonomous dispatch loop.

Every RETIRE row has an actual help invocation result in validated_by. The retirement rationale above is semantic: a recognized command can still be outside this orchestrator's ownership boundary.

## Boundary

No repo files were edited. No cargo, gate, formatter, or test-suite command was run. The only state-changing operation after probing was the requested completion notification to pane 1.

# Round 9 — 07-installability.md — adversarial lens

## Search and deduplication

Read the complete current section (468 lines). Harness-grep searches covered the full file for:

- `complete.*does not exist|completion.*does not exist|complete layer|completion is|AVAILABLE|WIRE-PROVEN|human looking|every completion`;
- `MEASURED|PROJECTED|NO-CLAIM|Historical|Gap|DISPATCH|REAP|build-id|installer|18|3|5 of 18|2 of 8|exit`;
- the current authority, `docs/plan/00-brief.md`, for `completion is|WIRE-PROVEN|AVAILABLE, NOT WIRED|AgentEndEvent|willContinue|does not exist`;
- prior round-4 and round-8 evidence to avoid re-filing the known denominator, mirror-count,
  exit-code, lifecycle, and other installability findings.

This space covers the measured starting point, projected CLI/distribution contract, identity/drift,
multimachine preflight, prior-art claims, and R11 constraints. It is broad enough to catch a stale
status copied from the brief even when the section's local implementation remains unbuilt.

## Finding

### R9-07-01 [MAJOR] — stale completion status copied from the brief

**Construct:** `docs/plan/07-installability.md:47-52` says the brief's §4 records `complete` as
`DOES NOT EXIST`, says two of five layers are absent, and describes a second-machine install as
receiving two absent layers.

**Contradiction:** The current authority `docs/plan/00-brief.md:493-500,508-511` records completion as
`WIRE-PROVEN`: an `AgentEndEvent.willContinue`/`SessionStopEvent` signal crossed the observed RPC wire,
while explicitly limiting the remaining gap to this repository's consumption. The control-loop table
also says `complete` is `AVAILABLE, NOT WIRED`, not absent.

**Why it matters:** The local installability conclusion can still be that the installed supervisor
has no completion consumer, but the section presents the upstream signal as nonexistent and therefore
misstates what the next machine must install. That overstates the missing work and makes §09
sequencing inaccurate.

**Fix:** Replace the copied status with the narrow truth: `actuate` remains absent, while the
completion signal is available/wire-proven but not consumed by this repository. Retain the local
failure claim only as "the installed supervisor's completion layer is not wired" and update the
"two absent layers" sentence accordingly.

This construct was not present in the prior round-4 installability evidence and is not a re-report
of the known installer denominator or mirror-count findings.

## NEW FINDINGS: 1

VERDICT: PASS-WITH-FIXES (adversarial lens, round 9)

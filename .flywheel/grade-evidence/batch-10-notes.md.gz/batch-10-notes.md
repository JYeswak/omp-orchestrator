# Batch 10 notes — OMP surfaces

## Scope
30 rows: 15 OMP type roots, 14 OMP declaration surfaces, and one RPC handler (`abort`). None is a scrape artifact; each row has an explicit OMP surface kind and identifier.

## Dispositions
All 30 are RETIRE. These type roots and declaration files are metadata/type-surface inventory entries, not runtime commands consumed by the current Rust crates. `surface:rpc_handler:abort` is outside the closed request vocabulary in `omp-rpc-session`; the adapter sends only negotiate_protocol, get_state, get_session_stats, and get_messages, and uses an explicit Unknown response arm for other commands.

## Ownership decision
No current crate owns or should own these batch-10 rows. `omp-inventory-map` may observe source/bundle metadata while producing a census, but that does not make every enumerated type root or declaration a consumed product surface. `omp-rpc-session` owns the four supported RPC requests only; the abort handler is not part of its bounded contract.

## Validation boundary
The relevant source search was: tool.grep(pattern=Command::new("omp")|--mode=rpc|negotiate_protocol|get_state|get_session_stats|get_messages|abort, path=crates). Its search space includes all crate code that can launch OMP or name an RPC request. It found the bounded four-request sequence in omp-rpc-session and no batch-10 runtime consumer. `validated_by` is null for RETIRE rows intentionally: no positive runtime command proves a surface should never be called; the search boundary and retirement rationale are recorded here.

No WIRE or VALIDATE disposition is justified in this batch.
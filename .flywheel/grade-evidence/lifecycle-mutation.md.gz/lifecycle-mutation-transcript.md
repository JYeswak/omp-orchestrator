# Lifecycle terminal mutation transcript

Baseline source: `crates/omp-types/src/lifecycle.rs`

Baseline SHA-256: `1ffa9fa9e8cfffc9eb9b6bbea861e10f7fe1fc6c55e631f26b4ca5d192934983`

Mutation inserted before the terminal guard:

```rust
if matches!((self, input), (Self::Stopped, LifecycleInput::Ready)) {
    return Self::Ready;
}
```

Command:

```text
env RCH_ENABLED=false CARGO_MINT_MIN_CONTAINER_PCT=3 \
FRANKEN_CARGO_TARGET_ROOT=/Volumes/ZestData/zeststream-offload-20260609/build-cache/cargo-targets \
/bin/bash /Users/josh/.local/bin/cargo test -p omp-types --test lifecycle_contract --offline --quiet -- --nocapture
```

Mutation result: exit `101`; `terminal_states_are_closed_under_generated_inputs` failed at seed `0`, input `Ready`, with `left: Ready`, `right: Stopped`. The remaining four lifecycle law tests passed.

Restore: copied the saved baseline bytes back to `crates/omp-types/src/lifecycle.rs`.

Restored SHA-256: `1ffa9fa9e8cfffc9eb9b6bbea861e10f7fe1fc6c55e631f26b4ca5d192934983`

Restore result: `byte_identical=yes`.

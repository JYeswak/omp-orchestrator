# Round 12 — `01-idea.md` — fresh grade and repair record

## Fresh dispatch

- **Agent:** `r12-idea-grader`
- **JSM choice:** `jsm suggest "idea viability economics product"` failed because JSM bandit recommendations were disabled; `jsm search product-viability-gauntlet` selected `product-viability-gauntlet` v1.
- **Prompt scope:** only `docs/plan/01-idea.md` plus the product-viability claim contract: buyer/problem/scope/differentiation/economics/risk/kill claims must be evidence-backed; hypotheses and projected choices must be labelled; each absence must have a NO-CLAIM. No prior findings, ledger, or fix notes were supplied.

## SEARCH SPACE

The fresh agent read all 509 lines of the assigned file and the cited brief/source constructs. Verification re-read the affected ranges and ran focused searches for `buyer|operator|price|ACV|CAC|substitut|compet|market|incumb|alternative|KILL|NARROW|DISCOVER|PILOT|BUILD`, stale counts, OMP vocabulary, wire-proof markers, and current registry values. Current map/board/number outputs were checked read-only; no cargo, gate, or formatter ran.

All 19 fresh findings were REAL. The targeted numeric fix-up agent corrected the repair agent's intermediate `409` residual to the current registry value `413`; 406/407 remain historical. No item was deferred or retracted.

## Findings

| SEVERITY | Finding | Verdict and diff location |
|---|---|---|
| **BLOCKER** | Opening thesis had no buyer, operator, trigger, value, price, or discovery commitment. | **FIXED** — `§1.1 :12-27; §1.2 :33-39; §1.6 :428-432`; adds a falsifiable $500/month HYPOTHESIS, local FACT/unknown boundary, five-interview discovery test, and DISCOVER-only posture. |
| **BLOCKER** | “Accountant/scarce thing” differentiation was a universal claim without substitutes or hostile evidence. | **FIXED** — `§1.2.2 :113-126`; adds OMP/native, scripts, human, service, and do-nothing substitution map and labels residual wedge HYPOTHESIS. |
| **MAJOR** | Product scope was a broad integration inventory without a first-value boundary. | **FIXED** — `§1.2.3 :132-136`; narrows first value to one OMP RPC completion→receipt→typed bead close/refusal and lists excluded surfaces. |
| **MAJOR** | “This is not a prototype” contradicted the section’s unbuilt supervisory path. | **FIXED** — `§1.3 :142-143; §1.5 :347-370`; status is enforcement-substrate prototype, with OMP supervision unbuilt and crate count disclaimed as completion evidence. |
| **MAJOR** | Stand-down 6/7/23/162/4.2h claims lacked receipts and were presented as measured. | **FIXED** — `§1.2 :41-57,85-89; provenance ledger :484-491`; historical/unverified labels, source/as-of boundaries, and no prevalence inference added. |
| **MAJOR** | Historical board snapshot 28/25/19/2 was stated as 75 rather than 74. | **FIXED** — `§1.2 :55-57`; 74 and 2026-08-31 as-of/reference are explicit and not presented as the live board. |
| **MAJOR** | Five-stage/seven-row control loop was collapsed into stale “one of five works.” | **FIXED** — `§1.2 :59-89`; now zero unqualified WORKS rows, qualified observe, UNVERIFIED selection/transport, FENCED admission, absent actuation, and available-but-not-wired completion. |
| **MAJOR** | “Thirteen tests pass” was a stale subset and overclaimed pass status. | **FIXED** — `§1.4 :284-291`; 23 source-present test functions (13+10) is dated and explicitly not a test-pass claim. |
| **MAJOR** | Workspace count retained a stale 406/current-registry 409 value. | **FIXED** — `§1.5` current-count prose/table; current registry value is now **413 test functions across 31 integration test files**, with 406/407 historical/non-authoritative. |
| **MAJOR** | Gate headline called fixture mutation AUTOMATED and claimed one all-four gate. | **FIXED** — `§1.5 :393-401`; FIXTURE classification, zero production-source mutation, and retracted old headline are explicit. |
| **MINOR** | Present-tense tmux disagreement and citation were stale after brief correction. | **FIXED** — `§1.3.9 :222-233; §1.7 :500-502`; now historical correction with the real `-V`/`--version` risk retained. |
| **MAJOR** | `ObligationLedger` was incorrectly grouped with upstream-blocked `AckKind`/`DeliveryClass`. | **FIXED** — `§1.5 :358-363`; separates `PresentUpstreamBlocked` from `AbsentEverywhere` and repairs the malformed export sentence. |
| **MINOR** | Wire-proof claim had declarations but no reproducible raw-frame receipt. | **FIXED** — completion table/provenance ledger; raw-frame path, capture command, mtime, SHA-256, and one-frame-only boundary are recorded. |
| **MAJOR** | Technical conclusions were unlabeled inferences and treated typed adoption as sufficient. | **FIXED** — `§1.2.1` and inference sections; conclusions are FACT/INFERENCE/HYPOTHESIS with counter-test and bounded language. |
| **BLOCKER** | Economic, distribution, recurrence, rights, defensibility, and architecture gates were absent. | **FIXED** — gate-status/risk material at `:386-389` and the added viability material; unknowns remain explicit and PILOT/BUILD are prohibited until conjunctions pass. |
| **MAJOR** | “Already good” ignored security, secrets, licensing, compatibility, and dispatch blast radius. | **FIXED** — bounded quality claim plus owned risk register at the added risk section; no blanket product-quality claim remains. |
| **BLOCKER** | No explicit KILL/NARROW/DISCOVER/PILOT/BUILD disposition or thresholds. | **FIXED** — `:376-389`; DISCOVER/NARROW posture, owner, numeric thresholds, cheapest next test, and revisit predicate are recorded; PILOT/BUILD remain gated. |
| **MINOR** | Dependency-contract SOTA was presented as product SOTA. | **FIXED** — benchmark boundary near the SOTA material; dependency floor is separated from external product comparison, which remains PROJECTED. |
| **MAJOR** | Header promised command-backed provenance while containing copied/indirect figures. | **FIXED** — header and provenance ledger; every retained figure is command/source-backed, historical, or explicitly unverified. |

## Number registry

The current registry was checked before filing stale-number claims. `test_files=32`, `test_functions=413`, and `surface_engaged_pct=21.8` are the current declared values; the section now uses them or labels older snapshots historical. The registry has 15 unique figure keys, including `surface_map_unmapped_rows`, with no duplicate key detected by a direct parser check.

## Result

**19/19 findings accounted for; 19 fixed; 0 deferred; 0 retracted.**
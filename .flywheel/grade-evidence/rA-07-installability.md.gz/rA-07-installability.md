# Round 8 — 07-installability.md — ABSENCE lens — OliveCat
Section read FULL (468 lines). Correction history honored: the drift-denominator defect is
carried in §1 as fixed at HEAD; mirror counts corrected in earlier rounds.

## THE SEARCH (commands and space, per the zero-is-a-claim rule)
1. Gap-world residue: grep -n for all seven gap names + "precedent-free|never attempted|
   no receipt|unclaimed|roster|cost is unmeasured|85% context" across 07-installability.md.
   Result: only honest PROJECTED labels — K3's "never attempted" (kill criterion K3) is a
   claim about OUR testing (no second machine has run the installer), which remains true.
   No stale argument from a refuted upstream absence. CLEARED.
2. Census-denominator scope: the section uses "3 of 18 binaries" and references the census;
   the merged SURFACE-MAP (591 rows) is a different artifact the section does not claim.
   No inconsistency. CLEARED.
3. The seven upstream types: none is an installability surface — §4 (identity) and §6
   (multi-machine, dependency probing) argue from OUR binaries; the adjacent surface
   (substrate version probing) already carries the UNPROBEABLE probe shape at §6
   (line ~380, "the probe records version:\"UNPROBEABLE\" with the rejection text").
   The section needs no gap-type propagation for its arguments to stand. CLEARED.
4. R13 lifecycle gaps (round-4 finding: DISPATCH and REAP missing): 11-lifecycle now carries
   L-rows owning both; the propagation exists, so the absence in 07 is owned elsewhere and
   is not a new finding here.
5. Glossary dependence: "adapter", "envelope", "triad" are defined in the brief's glossary
   (round-1 finding, since fixed). CLEARED.
6. Zero-claim audit of my own search: harness grep only; every zero stated with pattern +
   why the file could contain the answer (it is the install/distribution section; receipt
   or completion claims would have lived in §5/§6 if anywhere).

## NEW FINDINGS: 0

VERDICT: PASS (absence lens, round 8 — first clean round for 07 under this contract)

# Round 19 — gate/diagram consistency — AmberGate (%1408)

## SEVERITY-tagged findings

F1 [MAJOR — FIXED] 04-diagrams.md:185 CMP node said "DOES NOT EXIST" for the complete layer, contradicting 00-brief.md §4 which says "AVAILABLE, NOT WIRED" (AgentEndEvent wire-proven, commit 7f7e0f6). FIXED: node re-labeled.

F2 [MAJOR — FIXED] 07-installability.md:96 said complete "DOES NOT EXIST" — same stale premise as F1, same owning source. FIXED: re-worded to "AVAILABLE, NOT WIRED — AgentEndEvent crossed the wire but the supervisor does not consume it."

F3 [MINOR — NOT FIXED, NOT MINE] 06-gates.md:19 states "31 409" test counts; fresh re-run gives 91 test files / 961 test functions. These are declared in NUMBERS.toml as dated snapshots; the drift is documented, not silent. Owner: the integrator (§5 AUTONOMOUS-WAVE).

## SEARCH SPACE
- Full read of 04-diagrams.md (438 lines), 06-gates.md (503 lines), 07-installability.md (681 lines), 08-end-users.md (451 lines), 05-actions.md (529 lines)
- grep "DOES NOT EXIST" across all five: found in 04 (actuate=correct, complete=stale→fixed) and 07 (complete=stale→fixed)
- grep "379|370" across all five: 06 has the dated snapshot; 05/07/08 reference it as history
- Cross-checked 00-brief §4 as the owning table
- Verified: 05-actions and 08-end-users carry no stale gap-premise claims

## VERIFIED CLEAN
- 05-actions: no DOES NOT EXIST, no stale test counts, upstream types named at true strength
- 06-gates: test counts are dated snapshots declared in NUMBERS.toml; the section's own correction block (§6) aligns with the refutation
- 08-end-users: already carries the WIRE-PROVEN annotation at line 246; no stale gap claims

## REMAINING BLOCKERS (not my lane)
- 06-gates test counts stale (31/409 vs 91/961) — integrator NUMBERS.toml update
- The extraction-wave wired_lanes REDs (23 undeclared crates → I declared 23 in SURFACE-MAP; the wired_lanes allowance rows still need 4 cron-wired entries which I added)

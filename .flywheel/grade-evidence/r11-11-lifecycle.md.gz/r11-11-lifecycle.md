# Round 11 fix report — 11-lifecycle.md

No new grading was run. The Round-10 evidence was processed finding by finding by the assigned repair agent `repair-lifecycle`; I verified the repaired section's key residues and diff locations afterward.

## Dispositions

| R10 finding | Verdict | Diff location and repair |
|---|---|---|
| L1 missing seven-field runbook contract | **RETRACTED AS SCOPE ERROR; FIXED BOUNDARY** | Scope `:10-29`. §12 is now explicitly the canonical dispatchable runbook; §11 is an evidence/lifecycle map, not a second stage-runbook corpus. The seven fields are intentionally not duplicated here, and §11 now records transition inputs, outputs, refusals, and boundaries. This is the briefing-scope error, not an omitted §11 requirement. |
| L2 conflicting stage IDs and skill cardinality | **FIXED** | §11.1 `:37-74`; §11.8 `:329-346`. §12's S1–S9 cut is canonical; idea/plan/bead/select/dispatch/work/reap/grade/ship are operational subphases; viability/loop/honesty are attributes. Ownership roles and the 12 rows/18 references/16 unique skills are explicit. |
| L3 false/absent crate ownership | **FIXED** | §11.1 `:47-66`. `omp-orchestrator` is the accountable S5 resident consumer with measured dependencies; `fast-dispatch`, `tick-dispatch`, `reap-finished-panes`, and `verify-dispatch` are PROJECTED/unbuilt. |
| L4 template variables claimed tracker custody | **FIXED** | §11.3 `:112-159`. Template omission and `dispatch-claim-fence` custody are separate contracts; exact future negative probes cover missing fields, snapshots, statuses, assignee, and snapshot IDs, with unobserved exit/stderr marked PROJECTED/NO-CLAIM. |
| L5 selection→claim→dispatch handoff | **FIXED** | §11.5 `:186-201`. The current human-claim-required boundary and projected atomic claim handoff are explicit; S4→S5, S5→S6, S6→S7, S7→S8, and S8→S9 edges now carry artifacts/refusals and the old three-link count is corrected. |
| L6 S5/completion state overclaim | **FIXED** | §11.2 `:81-106`; §11.6 `:207-229`. S5 is automated designed-through-receipt but runtime-unverified. Declaration, wire observation, parser, consumer, and reap are separate; AgentEndEvent is AVAILABLE/WIRE-PROVEN for the observed frame, while local consumption is NOT IMPLEMENTED/NOT CONSUMED. `isTerminal` is not equated with `willContinue`. |
| L7 absent/unconsumed reap and false completion | **FIXED** | §11.1 `:50-51`; §11.6 `:233-249`. The absent reap crate, candidate-only follow-up, false `VerdictPosted→Healthy` branch, and post-receipt stop boundary are recorded; refill is limited to read-back Finished and a non-terminal InProgress result is required. |
| L8 stale surface-map totals | **FIXED in section; registry addition DEFERRED** | §11.7 `:261-325`. The exact jq derivation and current `270/214/8/31/11/6` result replace the stale split; “value is in the 11” is withdrawn and all 31 WIRE rows are treated as proposals. The figure belongs in `NUMBERS.toml`, but that file is concurrently modified and contains duplicate `[figures.board_total]` tables at lines 59 and 75; editing it would sweep another agent's work. No registry edit was made. |
| L9 known R8 Y-count reinforcement | **DUPLICATE/ALREADY KNOWN; RETAINED AND CORRECTED** | §11.2 `:98-103`. The four visible Y cells are named and retained as four, not three; the shared S8 build evidence is represented as an alias so it is not double-counted. |
| L10 1:many namespace/cardinality | **FIXED** | §11.10 `:429-451`. A cardinality matrix now states the current supported boundary as 1 process : 1 session : 1 OMP child : 1 selected bead : 1 selected pane : 1 receipt, with collision/cardinality refusal; bounded fan-out is PROJECTED rather than implied. |
| L11 durable logging and S9 handoff | **FIXED** | §11.9 `:370-425`. Heartbeat limitations are named; the projected append-only stage event schema includes canonical IDs, command, exit code, artifact, session, and status; S9 has a projected decision record, owner, append owner, and jq retrieval command. |

## Post-repair checks

- Current section length is 467 lines.
- Exact case-sensitive search confirms the seven runbook labels are intentionally absent from §11 after the explicit scope boundary; the new canonical §12 handoff is named.
- The repaired section contains `S4 → S5`, `S7 → S8`, `S8 → S9`, `stage_id`, `from_stage`, `to_stage`, `NOT CONSUMED`, the current surface-map derivation, and the cardinality matrix.
- Old values remain only as explicitly labelled historical/retracted text; current values are `RETIRE 214`, `WIRE 31`, `VALIDATE 11`, and the complete disposition table.
- `NUMBERS.toml` was inspected but not edited because its concurrent uncommitted state contains duplicate tables; L8's section fix is complete and registry reconciliation is explicitly deferred for that concrete reason.

## Capability floor

No converged section (`03-crates`, `05-actions`, `06-gates`) was edited. This repair changes only `docs/plan/11-lifecycle.md`; the current ledger already records a separate round-10 capability failure for `06-gates`, so this round does not claim that 06 remains banked.

## Result

10 Round-10 findings accounted for: 9 fixed, 1 briefing-scope finding retracted with an explicit boundary; the known L9 reinforcement was retained. L8's number-registry addition is deferred because the shared registry is concurrently modified and structurally duplicated.
# Round 11 — 06-gates repair evidence

Source reviewed: `/tmp/grade/r10-06-gates.md` and `docs/plan/06-gates.md`.

## R10 findings

1. **Missing dispatchable runbook contract — RETRACTED (scope error / false positive).** `docs/plan/06-gates.md` is the R6 design-spec section, explicitly introduced at line 3 as design-spec depth. Its §2 framework descriptions and §4 admission checklist are not a pane-ready operational runbook, and no runbook contract was requested for this section. The absence of `Trigger`, `Dispatch packet`, `Amazing`, `Adequate`, `Negative patterns`, `Skills`, and `Done signal` is therefore not a defect in this section's assigned deliverable. No runbook fields were added.

2. **Stale absolute actuation/completion claim — FIXED.** Exact diff location: `docs/plan/06-gates.md:330` (the “Gating discipline concentrated where the product is not” paragraph). The paragraph now distinguishes local wiring from upstream availability: local `actuate` remains unwired; `AgentEndEvent`/`willContinue` is available upstream on `RpcSessionEventFrame`, but this pipeline does not consume it yet, so local completion is unavailable by adoption rather than event absence.

3. **Gate investment has no quantified outcome — FIXED.** Exact diff location: `docs/plan/06-gates.md:331`, immediately after the pipeline-ordering objection. Added a clearly labelled **PROPOSED, not measured** costed value gate: implementation/review budget of 4 owner-hours, 30-second incremental invocation budget, three-release escaped-instance follow-up targeting at least one fewer escaped instance, or a named shipped capability with a runnable acceptance command when no baseline exists. Added explicit STOP/DEFER thresholds for exceeding either budget, producing no new defect coverage/capability, or lacking outcome evidence; existing gate counts are not product progress without this evidence.

4. **LIVE RED overstates cited evidence — FIXED.** Exact diff locations: `docs/plan/06-gates.md:7`, `:189`, and `:197`. All three labels now say **projected RED by inspection** / **PROJECTED RED BY INSPECTION** and explicitly distinguish the measured input set from an unexecuted test failure. This aligns the heading and opening prose with the existing statement that the test was not run.

## Verification record

Scoped textual verification only (per assignment): the repaired claims and evidence labels are present at the locations above. No cargo commands, gates, formatters, linters, or tests were run.

## Shared number registry consolidation
The active test-count references were aligned to existing NUMBERS.toml figures: test_files=31 and test_functions=407. No new registry row was needed; the figures already declare runnable commands and include this section in their appears lists. Historical 370/379 values remain only inside labelled retraction/history prose.

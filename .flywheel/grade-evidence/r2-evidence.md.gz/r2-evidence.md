# GRADE R2 — 00-brief.md — LENS: EVIDENCE AUDITOR (pane 5, %1409)
# File changed 547/598 -> 717 lines. All round-1 line numbers stale; re-anchored.
# Fix-verification + new-findings only. Findings appended as derived.

## FINDING R2-1 (MAJOR): the new typed leg table's printed deriving command does not derive its own cells
- Construct: L271-277 "Derived per crate, not by keyword count" + command `grep -rn 'fn .*mutation' crates/<c>` (L273, tests/ only) vs table L264 `omp-inventory-map | mutation = AUTOMATED`.
- Measured: the printed command over crates/omp-inventory-map/tests returns ZERO mutation fns; the automated mutation test lives in `src/types_inventory.rs` `#[cfg(test)] mod tests` (`fn mutation_introduce_collision_then_restore_byte_identically`), which the command does not scan. Per the doc's own operationalization the cell must read NONE; per reality the cell is right and the COMMAND is incomplete. Downstream, L317 "3 of 8 have an automated mutation test" is also unsupported by the printed command (it yields 2 of 8).
- An investor running the doc's own command gets a table that contradicts the doc.
- FIX: widen the printed command to `grep -rn 'fn .*mutation' crates/<c>/src crates/<c>/tests` (and re-verify all eight cells against it), or move the mutation test into tests/.

## FINDING R2-2 (MAJOR): "Derived per crate, not by keyword count" (L271) is true of ONE column; the other four remain keyword counts, and one headline justification is a keyword artifact
- Table L264 states omp-inventory-map known_bad = 0. Measured: tests/inventory.rs has ≥3 known-bad-in-substance tests — `empty_metadata_is_a_hard_error` (:23), `malformed_classification_is_typed_and_unknown` (:128), `malformed_row_and_duplicate_declaration_are_typed` (:144). By substance the cell is ≥3; by the same name-keyword method used for the other columns it is 0.
- L281's exclusion of omp-inventory-map from the all-four headline ("fails on known-bad=0") therefore rests on the keyword artifact, not on substance. state-wildcard-lint's exclusion (anti_vacuity=0) is likewise keyword-derived and unverified.
- The rebuild was demanded precisely because keyword counts measure the wrong thing; it typed one column and re-asserted the banner over all five. FIX: either type all five columns by substance (as done for mutation) or scope the L271 banner to the mutation column and mark the other four PROXY.

## FINDING R2-3 (MINOR): §4 selection row "UNVERIFIED — no evidence separated from the two rows below" (L455) overstates the absence
- Measured: crates/omp-orchestrator/src/lib.rs `mod tests` (L528) holds 28 #[test] fns; ≥4 call `decide()` directly (L591, 610, 628, 647, with Unauthorized token). Separated evidence exists at unit level; what is missing is FLEET-RUNTIME measurement.
- FIX: reword the cell to "UNIT-TESTED (28 fns, ≥4 direct decide() calls), RUNTIME-UNVERIFIED" — the honest status is about the missing runtime layer, not an absent evidence base.

## FINDING R2-4 (BLOCKER): the L289-291 blockquote attributes a verbatim demand to %1414 that appears in no artifact, and misattributes %1414's BLOCKER 1
- Quote as printed: "`%1414` demanded this rebuild as its BLOCKER 1 — 'retire this table and rebuild it with typed automated, manual, affordance, and none statuses'".
- Measured: grep of %1414's grade file (/tmp/grade/g-absence.md, 5325B) for retire/affordance/rebuild/leg table/1 of 8/four legs/BLOCKER 1 → ALL ZERO. Its actual BLOCKER 1 is the missing economic dimension ("No economic dimension exists anywhere in the brief"), which became §8/R12. The nearest source of the table language is the CONDUCTOR'S OWN spawn prompt (/tmp/grade/p1414.txt:35): "Is the table salvageable at all, or should it be retired and rebuilt? Argue it." — a question from the orchestrator, not a demand from the agent, and the "typed automated, manual, affordance, and none" enumeration appears in NEITHER file.
- Net: the document launders the conductor's own prompt into an independent agent demand — in a section whose thesis is that agent-vs-conductor adversarialism is the evidence that the method works. It also misassigns credit for two of the six round-2 fixes.
- FIX: rewrite the blockquote to the verifiable chain: "the rebuild followed the conductor's spawn question to %1414 (p1414.txt:35); %1414's grade did not address the leg table; its BLOCKER 1 (missing economic dimension) became §8/R12" — and re-source every quotation in §7 against an on-disk artifact.

## FINDING R2-5 (MAJOR): "seven of them the conductor's own" (L539) is not derivable from the printed table
- The §7 table (L550-560) has nine rows and NO author column. Only five rows are explicitly attributable to the conductor from in-document evidence: #1 (L327 "self-inflicted... in the act of writing the rule"), #2 (L156 "my own probe"), #3 (L392 "the first draft claimed"), #8 (L559 "the conductor" in the refuted-by cell), #9 (L139 "all three the author's"). Rows 4-7 (the three "no prior art" not-founds + narrow search) carry no author anywhere.
- The count was moved from memory to the table (L546-548) — but the table cannot yield the seven. FIX: add an author column to the nine-row table; the headline then recomputes.

## FINDING R2-6 (MAJOR — fix 3 PARTIALLY FAILED): the reconciliation stopped at the headline; six stale ordinals survive, and the assembly-side claim has not executed
- Stale "five" after the nine-reconciliation: L586 "corrected five times by agents", L591 "Five refutations in one session", L592 "five specific ones", L618-619 "our process caught five errors" (twice).
- Stale "eighth": L626 heading "The eighth failure", L644 "the eighth self-inflicted defect" — under the nine-frame the ordinal is unreconciled.
- Assembly side: L547-548 claims the PLAN.md header "is regenerated from it at assembly" — measured: docs/PLAN.md:19 still reads "Eight measured claims... six of them", and mtimes are PLAN.md 1788220009 vs brief 1788221757 — the brief is ~29 minutes NEWER than the assembly, so §7.3's own predicate ("no section file may be newer than the assembled document") is live-violated BY THIS ROUND'S EDIT.
- FIX: sweep §7.1/§7.2/§7.3 ordinals to the nine-frame, add the author column (R2-5), and re-run assembly so the header derives; then the §7.3 predicate holds again.

## FINDING R2-7 (MAJOR): the brief asserts the path-literal-guard as wired and its table "sound" while its own K3 row proves an in-scope literal the wired gates never refused
- Measured tonight: python scan of crates/*/src/**/*.rs finds the literal `/Users/josh` in SIX files — crates/installer/src/lib.rs (+ main.rs), crates/no-shell-gate/src/bin/pre-commit-gate.rs, crates/kernel-only-operator-hook/src/lib.rs + src/shadow.rs, crates/ack-spine/src/heartbeat.rs.
- installer/src/main.rs:25: `dirs_home().unwrap_or_else(|| PathBuf::from("/Users/josh")).join(".local/bin")` — K3 (L700) states this itself.
- Those commits landed TODAY (installer 3760589; pre-commit-gate 449b20e) with no refusal, while §3.5 presents the guard as gate 2 of a wired pre-commit binary and calls the leg table "sound" (L335). Both cannot hold: either the scanner has exemptions it does not declare (contradicting the empty-exemption rule), or the pre-commit trigger is not installed in this checkout (consistent with round-1 reap evidence: .git/hooks/pre-commit stale since 15:01, only .git/hooks/commit-msg installed since).
- The brief knows both halves and never reconciles them — the same derived-artifact-says-healthy pattern the document exists to kill. FIX: add the reconciliation row (gate facts must state trigger-installation status per checkout, evidenced by `strings .git/hooks/pre-commit`), and route the six literals through the guard's allowance mechanism or fix them.

## FINDING R2-8 (MINOR): two §8.2 evidence cells are false as printed
- Q7 (L687): "security|secret|credential|token appears **0 times** in this brief" — measured: 2 (the Q7 row itself + R12's list at L72). The row falsifies itself.
- Q8 (L688): "`licens` appears **once** across all eleven sections" — measured: 3 across the §5 map's eleven files (00-brief ×2 — R12 and the Q8 row — plus 07-installability ×1). Defensible only with an unstated self-exclusion.
- FIX: re-run both greps with the self-referential rows excluded and print the exact scope ("0 outside this question and R12", "once outside this brief").

## FIX-VERIFICATION SUMMARY (the six claimed fixes)
1. Leg table rebuild: PARTIAL. The inversion itself is real and verified (undrained-pipe-lint has the automated mutation test, tests/specimens.rs:205; no-shell-gate has ZERO mutation fns — the exemplar handover is correct). But the printed deriving command contradicts the printed cells (R2-1) and the banner overclaims (R2-2).
2. Spine split: PARTIAL. Denominator fixed and stated (L438/L449, internally consistent); two UNVERIFIED rows honest in spirit. But the rebuilt table preserved the stale actionable row (round-1 B1: fixed at HEAD by -oco, omp-orchestrator/src/lib.rs:162-175,452) — the fix vehicle was the table rebuild and the defect rode through it — and the selection cell overstates (R2-3).
3. Count reconciliation: PARTIAL. Headline now nine (L539) and the table has nine rows; my round-1 B2 is credited accurately (L542-545). But "seven" is underivable (R2-5), six stale ordinals survive (R2-6), and the PLAN.md header still reads eight/six.
4. -V row: FIXED. L130 "6 of 9 / omp, bv, git" matches my measurement; L132 adds "tmux answers -V alone"; the L135-139 attribution to %1409 is accurate and sourced.
5. §8: PRESENT and structurally sound (10 owned questions, 5 kill criteria with observables; K3 verified true against installer/src/main.rs:25; K1/row-7 grounded by franken_lean's presence in the mirror). Two evidence cells false as printed (R2-8).
6. R12: PRESENT (L68-74, L95, L669-673).

## NEW-FINDING TALLY: 1 BLOCKER, 5 MAJORS, 2 MINORS

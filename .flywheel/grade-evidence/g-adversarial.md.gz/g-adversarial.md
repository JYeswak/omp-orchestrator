 VERDICT: FAIL

 BLOCKERS: 2

 1. [00-brief.md:256-276; construct: mutation aggregate  2 of 8 gates have all four legs]
    The section proves that mutation conflates an automated test, a manual procedure, and an explicitly non-leg
    mutation affordance at lines 263265; it then still uses the column to claim 2 of 8 gates have all four legs
    at line 276. The no-shell-gate row is therefore not a valid four-leg record, and the 2/8 headline has no
    defensible derivation.
    FIX:Retire this table and rebuild it with typed automated, manual, affordance, and none statuses, computing all
    four legs only from explicitly admissible evidence.
 2. [00-brief.md:406; construct: actionable-layer verdict]
    free_capacity derives from the same is_dispatchable filter is false against the current implementation.
    Re-derivation with tool.grep(pattern='is_free_capacity|is_dispatchable',
    path='crates/omp-orchestrator/src/lib.rs') returns separate fields at :162-175 and an independent filter(|p|
    p.is_free_capacity) at :458-462; the NewlyIdle path is not excluded from both lists. If this is meant as
    historical state, the brief does not pin it to a commit.
    FIX:Either pin the verdict to the exact historical revision or remeasure the producer/consumer pair and replace
    the row with the current state.

 MAJORS: 6

 1. [00-brief.md:407; construct: consume | decide()  FENCED]
    The cited evidence, 162 refused ticks  DISPATCH_RETRY_BLOCKED, belongs to the pending-dispatch branch in
    omp-orchestrator/src/main.rs, not to decide(). tool.grep(pattern='pub fn decide|DISPATCH_RETRY_BLOCKED',
    path='crates/omp-orchestrator/crates') resolves decide() as a pure function at src/lib.rs:402 and the retry
    marker to src/main.rs:803-806. A retry marker proves duplicate-retry refusal, not that initial packet
    consumption is fenced.
    FIX:Split selection, dispatch admission, and transport verification into separate rows with evidence for each,
    and remove the decide()-is-fenced conclusion.
 2. [00-brief.md:241-254; construct: per-crate leg table]
    The table contains per-crate values for known_bad, known_good, mutation, and anti_vacuity, but the displayed
    commands only claim two global aggregates: 26 integration test files and 370 #[test] fns.
    tool.grep(pattern='known_bad|known_good|anti_vacuity|mutation', path='00-brief.md') finds the table and the
    later mutation discussion, but no reproducible command deriving the non-mutation cells. This violates the
    briefs own line-465 rule that every number carry its derivation.
    FIX:Attach a machine-readable evidence record and exact command/result to every per-crate cell, or relabel the
    cells as unverified proxies.
 3. [00-brief.md:192 and 241-242; construct: measurement commands]
    python3 -c ""and grep -rc '#\[test\]'  are not runnable commands: the ellipsis hides the input,
    transformation, and aggregation logic. The claimed 183-row vacuity result and 370-test count cannot be
    independently reproduced from this brief.
    FIX:Replace every abbreviated command with the exact fail-closed command, input path, exit status, and result
    artifact.
 4. [00-brief.md:386-394; construct: mirror repository denominator]
    The defensible counts use ls  | wc -l and find  | wc -l without checking the producers exit status, despite
    lines 292298 explicitly documenting that a pipeline can launder failure into a zero. A missing or unreadable
    mirror can therefore produce a plausible count and exit 0.
    FIX:Capture producer and consumer statuses independently, fail on producer errors, and publish the exact
    resolved mirror path with the count.
 5. [00-brief.md:411-429; construct: observe asymmetry verdict]
    The present-tense claim that a changed content hash proves motion at any interval is not what the
    implementation does. tool.grep(pattern='gap_too_short|prev\\.hash != now\\.hash',
    path='crates/tick-monitor/src') returns the early gap < MIN_GAP_SECS return at :540-545, before the hash
    comparison at :551-555; sub-floor changed pairs are intentionally classified Unproven. Line 426 concedes this,
    so the line-412 statement is an unmarked intended invariant, not a measured fact.
    FIX:Separate current behavior from the proposed invariant and restrict the safe-direction conclusion to the
    exact state pairs and intervals actually classified.
 6. [00-brief.md:222 and 245-276; construct: the 8-gate denominator]
    The brief names omp-orchestrator -> dispatch-claim-fence at line 222, and the current crate inventory contains
    crates/dispatch-claim-fence/Cargo.toml, but the eight-row gate table has no row or scope rule explaining its
    exclusion. tool.grep(pattern='dispatch-claim-fence', path='00-brief.md') returns only line 222. The denominator
    is therefore not all gate frameworks; it is an unstated subset.
    FIX:Define the eight-row universe and its revision, or include every gate-bearing crate and recompute all
    summaries.

 MINORS: 1

 1. [00-brief.md:399-409; construct: table cardinality]
    The four-layer reality table has five rows: observe, actionable, consume, actuate, and complete. That makes
    later claims such as exactly one row works and zero unqualified working rows ambiguous because the status
    vocabulary and layer count do not have a stable denominator.
    FIX:Rename it as a five-layer table or explicitly group actuate and complete under a defined fourth layer.

 THE ONE THING: Retire and rebuild 3.5. Its central 2/8 result is calculated from a column the section itself

# GRADE R2 — 00-brief.md (now 726 lines by read-header; dispatch said 717) — Pane %1408 — ABSENCE
Findings appended as formed. Round-1 line numbers retired.

## VERIFICATION OF THE SIX CLAIMED FIXES (absence lens)

FIX 1 (leg table rebuilt, typed statuses) — fix LANDED (line 265: no-shell-gate mutation
column now **AFFORDANCE**; line 275 defines the four statuses). REMAINING ABSENCE, NEW:
the table (§3.5) still enumerates only the 8 crates that happen to have tests/ files.
26 workspace crates exist (§3.2 census, line ~190 "workspace_crates=26"). There is no row,
no "NONE" status, and no stated denominator binding the 8 to the 26 — a gate-less crate is
absent from the gate table exactly the way a wired-but-unaddressable gate was absent from
the doctor output (§3.6's own ADDRESSABLE property). The typed status vocabulary has a
NONE value and zero NONE rows, which is the keyword-count defect wearing new clothes: the
table still measures only what was easy to enumerate.
FIX: add 18 rows with status NONE (or state the 18-crate denominator in the heading).

FIX 2 (spine split) — fix LANDED (line 438: "five stages, seven measured rows, zero working";
lines 455-457 split selection/admission/transport, two UNVERIFIED with named evidence gaps).
REMAINING ABSENCE, NEW: the spine still has no TRIGGER/driver row. The loop's five stages
describe what runs; nothing in the table owns what FIRES the loop (the conductor cron /
controller-tick), yet §3 of this same document records the consume fence as 162 refused
ticks over 4.2 hours — a measurement that only exists because a scheduler fired. The
five-stage model cannot answer "who starts a tick" and the dispatch loop's known failure
mode (pane %1413-style stall: nothing fires, everything looks healthy) is invisible in it.
FIX: add the driver row (trigger: controller-tick/cron, measured state) as row 0 or row 8.

FIX 3 (self-correction count reconciled to nine) — landed per line 706 ("nine refutations
in §7"). Not absence-relevant beyond noting the §7 table was checked for a tenth row
class: no "caught by mechanism, not by agent" row exists; the only mechanism-caught catch
(slash twins, line 708) is cited inside §8.4 prose but §7's table has no MECHANISM column,
so a reader cannot see that 8 of 9 catches were discretionary and 1 was structural.
MINOR absence. FIX: add a caught-by column (agent-re-derivation vs scanner-twin vs gate).

FIX 4 (-V row corrected to 6 of 9) — verified region read (lines 122-125 intact; table
not reprinted here but fix claimed and spot-checked). No new absence.

FIX 5 (§8 open questions + kill criteria) — fix LANDED and it is substantial: ten questions
each with owner (lines 679-690), five kill criteria each with an observable (lines 696-702),
Q7 quotes my own grep evidence back (0 hits), Q8 does the same for licensing.
REMAINING ABSENCES, NEW:
  (a) OWNER INSTABILITY: every owner is a ROLE word (Josh, orchestrator) — none is a
      durable artifact (bead id, docs/plan file, .beads row). This document's own §0 thesis
      (lines 3-6) is that ownership in pane scrollback dies with the pane; "owner: Josh" is
      a person, and Q10's PARTIAL admits "no one owns the decision". An open question owned
      by nobody-checkable is the round-1 B2 defect re-instantiated one level up.
      FIX: owner column takes a bead id or docs/plan path, not a role word.
  (b) K2's observable admits the measurement "is itself unowned" (line 699) — a kill
      criterion whose observable cannot currently fire is decoration by §8.3's own rule
      ("A kill criterion nobody can evaluate is decoration", line 694). It is carried as a
      criterion anyway.
      FIX: either file the instrumentation build as an owned open question or demote K2
      to a hypothesis with a build-it-first row.
  (c) The per-subsection expected-contents list that §8.4 (line 714) says is the fix for
      the prose-twin blind spot is named and "not built" — correctly confessed — but it is
      ALSO not registered in §8.2 as an open question with an owner. The fix for the
      blind spot is itself outside the two mechanisms (requirements, open questions) the
      section creates. It is a confession, not a registration.
      FIX: add it as Q11 with an owner.

FIX 6 (R12) — LANDED (lines 68-74, line 95 closure row "§8 — ten open questions, five kill
criteria, all OPEN"). Coherent with §8.1. No new absence in the row itself.

## ROUND-1 FINDINGS STATUS (report only if fix FAILED, per rules)

M1 glossary — NO FIX ATTEMPTED. grep -ic glossary 00-brief.md -> 0. R1-R11 remain verbatim
   jargon (bead dag, reap, tick, mirror) with no definitions. Round-1 MAJOR 1 fix FAILED
   (never attempted). An investor still fails at §1.
M2 R5-row wording ("enumerates all 183 … with names") — line 88 UNCHANGED; §3.2 still
   records slash_commands=0 vs expected 136. Round-1 MAJOR 2 fix FAILED (never attempted).
M3 R2-row past-tense closure — line 85 UNCHANGED. Round-1 MAJOR 3 fix FAILED (never attempted).
M4(a) composer-typed policy decision — lines 340-349 still present, still no owner in §5 or
   registration in §8.2. Round-1 MAJOR 4a fix FAILED.
M4(b) doctor.rs:924 tmux-missing defect — line 163 still cited, still owned nowhere.
   Round-1 MAJOR 4b fix FAILED.
m1/m2/m3 — unchanged; m1 is now sharpened: the file is 726 lines by read-header vs 717 in
   the dispatch — the stale-count defect fired AGAIN, in this round's own packet.

## NEW FINDINGS THIS ROUND (absence lens, not raised in round 1)

N1 [MAJOR] Gate table denominator: 8 rows for a 26-crate workspace; typed NONE status
   defined (line 275) and used zero times. FIX: 18 NONE rows or stated denominator. (see above)
N2 [MAJOR] Spine has no trigger/driver row; the thing that fires the loop is unmeasured in
   the model that measures everything else. FIX: driver row with its measured state. (see above)
N3 [MAJOR] §8 owners are role words, not durable artifacts — violates the document's own
   line-3 thesis. FIX: bead-id/path owners. (see above)
N4 [MINOR] K2 carries an unbuildable observable while declaring it unowned. FIX: split or
   demote. (see above)
N5 [MINOR] The §8.4 fix (expected-contents lists) is confessed-not-registered; it has no
   owner, no row, no section. FIX: make it Q11. (see above)
N6 [MINOR] §7 table lacks a caught-by column; 8-of-9 discretionary vs 1-of-9 structural
   catches are indistinguishable in the table. FIX: add column. (see above)

## POST-PERSIST CORRECTIONS (re-derived before verdict, per rules)

C1. FIX 4 (-V row): VERIFIED FIXED — line 130 now "6 of 9 | omp, bv, git", line 135 records
    the refutation, §7 row 9 (line 560) carries it, and the caption below the table now says
    "tmux answers -V alone". My earlier file entry said "not reprinted here but spot-checked";
    the check is now real. No absence remains in that row.

C2. N6 REPHRASED (my wording was imprecise): §7's table DOES have "refuted by" (agent) and
    "mechanism of the error" columns — the ABSENCE is the discretionary-vs-structural
    distinction: all nine rows name an agent; nothing in the table marks that eight catches
    depended on an agent choosing to re-derive while one (slash twins) was structural.
    The finding stands rephrased, severity MINOR unchanged.

## FINAL ROUND-2 VERDICT (absence lens)

VERDICT: PASS-WITH-FIXES

THE ONE THING: The six fixes are real and §8 is the right section built the right way —
but its owner column is full of role words, and this is the document whose first sentence
is that ownership which lives in a perishable place dies with it. Fix N3 (durable owners:
bead ids / docs paths) and the round-1 never-attempted items (glossary M1, R5 wording M2,
R2 closure M3, composer-typed + doctor.rs ownership M4) or explicitly register them as
Q-rows — then this section closes.

Honest count: 0 blockers this round. 3 majors (N1 gate-table denominator, N2 missing
trigger row, N3 role-word owners) + 2 minors (N4 K2 unbuildable observable, N5 expected-
contents fix unregistered) + N6/C2 minor. Round-1 majors M1-M4 remain open with no fix
attempted — they are re-listed above under ROUND-1 FINDINGS STATUS as failures-to-fix,
per the packet's rule, and are the bulk of why this is not yet PASS.

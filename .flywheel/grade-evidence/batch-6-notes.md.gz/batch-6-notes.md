# Batch 6 notes (10 br stale–where + 20 bv agents–projection) — OliveCat
Shape: 23 RETIRE / 3 VALIDATE / 3 WIRE / 1 CONSUMED (batch-6 shares batch-5's br:show count;
per-file tallies in the jsonl disposition counters).
- THE BV ZERO. 20 of the census's 29 bv surfaces are here; all 20 unconsumed. Four are wires
  and they are the direct answer to "which bv surfaces would have prevented recency-picking":
  bv:candidates (graph-ranked candidates — S4 select today is conductor recency),
  bv:decision-relevant (decision-relevant subset of the same graph), bv:dependencies
  (edge-aware exclusion), bv:not-ready (exclusion discipline). All four map to
  loop-queue-filter, which 11-lifecycle §11.1 names the S4 owner and which contains zero bv
  calls (grep Command::new("bv") crates/ -> 0, re-verified this round).
- bv:exit-codes is VALIDATE-not-WIRE by design: it becomes load-bearing the moment the four
  wires land, so its validation is a pinned golden contract written BEFORE first call.
- bv:plan retired deliberately: plan-to-beads triage is an authoring-time activity
  (/beads-workflow); per-tick selection consumes the tracker graph, not the plan doc.
- br:sync VALIDATE matters more than it looks: the entire multi-pane shared-checkout
  discipline (closes visible across worktrees) rests on tracker files syncing through git;
  no crate tests it today.
- No unclassifiable surfaces.

# GRADE — 00-brief.md — LENS: EVIDENCE AUDITOR (pane 5, %1409)
# Written to file per addendum (context-loss hazard). Round 1 of 11.
# Method: 17 re-derivations run live against HEAD, 2026-08-31, post-stand-down.

VERDICT: FAIL
BLOCKERS: 3
MAJORS: 4
MINORS: 5

## RE-DERIVATIONS (agree/disagree inline)

| # | Claim (line) | My command (abridged) | Result |
|---|---|---|---|
| 1 | §3.1 version table, 9 rows + tmux block exit=1/0B/158B (111, 131-137) | ran all nine binaries, both flags | AGREE exactly, every row |
| 2 | L121: `-V` "answers 5 of 9", fails incl tmux | `$P -V` ×9 | DISAGREE: **6 of 9**; tmux `-V` works (3.6a, exit 0) — L113 says so itself |
| 3 | §3.2 census: 184/207/183; 39/57/14/42/0(→136)/3/26; cls 157/18/8; edges 157/25/18/7; consumes=7 all omp-inventory-map; vacuity 1/1 distinct, 0 missing; 544,697 bytes; exit 2 | ran the named scanner at /Volumes/BuildShared/..., parsed JSON | AGREE on EVERY figure |
| 4 | §3.5 gate table 8 crates + 2-of-8/4-of-8/2-of-8/1-of-8 (276-279) | per-crate `grep -rc '#\[test\]'` + column arithmetic | AGREE (34/23/10/10/9/6/6/3; headline arithmetic sound) |
| 5 | 370 `#[test]` (242) | workspace count | 374 NOW (+4 same-day drift; stamped, tolerable) |
| 6 | 26 integration test files (241) | find crates -path '*/tests/*' | AGREE |
| 7 | Mirror 218/217/210/1 (386-389) | the four named commands | AGREE exactly |
| 8 | §3.7 unsafe 20/25/19/26-union (348-350) + harness 55 (294) | python over manifests+src | AGREE exactly |
| 9 | 59/91 types incl-everything (372) | grep + python, two shapes | AGREE |
| 10 | 51/79 excl test-mods+bins (371), "22 of 24" | src − bins − cfg(test) = **59/88** | NOT REPRODUCIBLE at HEAD; **no command printed for it** (violates §6.1 in the section stating §6.1) |
| 11 | §3.4 all 18 dep edges + subprocess-contract 4 dependents (213-236) | parsed all crates/*/Cargo.toml path deps | AGREE, all 18 pairs, 4 dependents |
| 12 | composer oracle ../../bin/composer-typed.py (309-310), bin/ absent | read tests/differential.rs:41 + ls bin/ | AGREE (oracle missing, dir absent) |
| 13 | §3.6 --help CONFIG_ERROR (326-328); 13 tests; 0×Observation/CONVERGE/Verdict in 544KB (332-333) | ran binary --help; grepped census JSON | AGREE (exact) |
| 14 | §4 actionable row "BROKEN — discards NewlyIdle; free_capacity same filter" (406) | read tick-monitor + omp-orchestrator HEAD | **DISAGREE — FIXED at HEAD**: `is_free_capacity` separate field, lib.rs:162-175; :452 comment names bead -oco ("It previously filtered on is_dispatchable...") |
| 15 | §7.3 staleness: grep=0 (575), brief 132s newer (574) | grep -c + stat -f %m | **NOW FALSE**: grep=**2**; PLAN.md **25s NEWER** than brief (re-assembled after measurement froze) |
| 16 | doctor.rs:924 check_tool / :1052 probe_failure_is_known_nonfatal, `if tool.ne("sh")` (148-150) | locate + sed | constructs AGREE — **file is in the MIRROR**, not this repo; brief never says which checkout |
| 17 | omp-types zero dependents (369); board 28-closed/75-total (395) | grep Cargo.tomls; br list arithmetic | AGREE |

## BLOCKERS (each: line/quote + one-sentence fix)

B1. **L406 (§4 spine table): "actionable | idle_panes | BROKEN — discards `NewlyIdle`; `free_capacity` derives from the same `is_dispatchable` filter"** — fixed at HEAD before the brief was written (crates/omp-orchestrator/src/lib.rs:162-175 separates `is_free_capacity`; :452 comment: "It previously filtered on `is_dispatchable`, which made it..." naming bead -oco, graded CONFIRMED pre-stand-down). The plan's spine presents a repaired defect as present-tense on the layer an investor probes first. FIX: re-measure the row at HEAD; restate as "fixed by -oco (<sha>); residual risk is the observe-row asymmetry" or mark `superseded-by:-oco`.

B2. **L490-491 vs L583: the self-correction count is itself unreconciled.** §7: "they refuted **five** measurements, three of them the conductor's own"; §7.3: "this is the **eighth** self-inflicted defect recorded here." By the doc's own records agents refuted **seven** (table's five + 216-repos L380 + 16-of-22 L347), and "eight total / six the author's" appears nowhere. The transcribed-headline-not-recomputed defect, inside the section that indicts it. FIX: one enumerated table of ALL recorded defects with an author column; derive both headlines from it ("seven agent-refuted, six conductor-authored, one self-caught").

B3. **L121: `-V` row ("answers 5 of 9"; fails list implying tmux) contradicts L113 and measurement: 6 of 9 answer `-V`; fails = omp, bv, git only.** Third draft of this paragraph, still wrong by arithmetic against its own section. FIX: correct to 6-of-9 / fails omp,bv,git and paste the nine-command probe.

## MAJORS

M1. **L370-372: 51/79 carries no deriving command**, is unreproducible at HEAD (same scope = 59/88), stale denominator "22 of 24" (now 24 of 26); the 51↔59 delta is mostly same-day drift misattributed to measurement scope ("published as an error bar"). FIX: print the exact command or relabel 51/79 a dated pre-landing snapshot with drift note.

M2. **L96-97: "Sections must use these figures and must not re-derive them differently"** — given demonstrated same-day drift (370→374, 22/24→24/26, board 25→24), this rule MANDATES inheriting staleness into all eleven sections. FIX: invert to "re-derive any stamped figure before load-bearing use, or cite the stamp and its age."

M3. **§7.3's printed measurements (L573-576) now false at HEAD**, no at-measurement stamp distinguishing "was true" from "is true" — the derived-artifact divergence, inside the finding about derived-artifact divergence. FIX: stamp every §7.3 command with measurement mtime; add the re-verify predicate the section itself demands.

M4. **Bare numbers, no command (§6.1 violations):** 29 raw spawn sites + "12 of 14 async fns" (L345-346); "162 refused ticks over 4.2 hours" (L407); board 28/25/19/2 (L395 — `br list` never printed); "seven real conditions living only in pane scrollback" (L4 — traceable to the ipg.16 reap comment but unpointed). FIX: attach the deriving command or mark stamped/projected.

## MINORS

m1. NO-CLAIM missing on the three MOST load-bearing blocks (§3.2 census, §3.4 graph, §4 spine) while present on lesser ones — rule 3 inverted at the stakes.
m2. L256 uses "NO-CLAIM" as narrative rhetoric, not a bound — decoration-adjacent.
m3. doctor.rs cited without naming the mirror checkout (cost one wrong-checkout command cycle).
m4. tick-monitor cite L552 drifted to ~L557 (construct correctly named — rule 14 saves it).
m5. L108 cargo version mid-hash `…` truncation in an evidence table.
(Not held against the doc: dispatch said 547 lines; file is 598 — dispatch error.)

## THE ONE THING

The brief's evidence core is mostly bulletproof — census, mirror, unsafe, edges all reproduce exactly, which is rare and worth a lot. But all three BLOCKERs live in the paragraphs whose entire thesis is "a figure nobody recomputes is a guess wearing a uniform": the spine table's present-tense BROKEN row, the unreconciled five-vs-eighth correction count, and the -V row contradicting its own section. The document proves its method works on everything except, still, its own headline sentences — and §7.2 already explains precisely why that is the part an investor should test first.

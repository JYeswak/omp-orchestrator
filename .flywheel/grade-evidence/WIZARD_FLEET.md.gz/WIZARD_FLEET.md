# Fleet-scale blind spots: 20 candidates, then the top 6

## Framing

The nine-stage runbook in `docs/plan/12-journey.md:23-61` defines what one stage must say: Trigger, Dispatch packet, Amazing, Adequate, Negative patterns, Skills, and Done signal. It does **not yet define the cardinality contract**: what changes when one stage has eight live sessions, when one parent fans out to many children, or when several sessions write and observe the same control-plane state.

That is no longer hypothetical. The observed fleet has eight live tmux sessions, and until recently the watchers shared one ledger. A single-session run can appear correct while the fleet produces cross-talk, duplicate work, false completion, or an untraceable human decision. The missing product is therefore not another stage paragraph; it is a scoped, typed control plane whose stage artifacts remain true under fan-out, fan-in, restart, and partial failure.

The evidence below treats upstream declarations honestly. `docs/plan/00-brief.md §3.8` says completion is **WIRE-PROVEN** (`AgentEndEvent` on `RpcSessionEventFrame`), while receipts, claims, idle, roster, cost, and compaction are **DECLARED ONLY**. A type declaration narrows the implementation; it does not prove that this repository can consume the signal.

## 20 candidates

### 1. Fleet/session/project-scoped state, not a global ledger

- **Refuses:** Unqualified ledger reads/writes; pane names as global identity; one watcher being able to mutate another session's state.
- **Evidence:** The real eight-session/shared-ledger observation; `docs/plan/00-brief.md §3.8` records `Stage1Claim`/`GlobalClaim` with `ownershipToken` and `inputWatermark` as only DECLARED ONLY.
- **Mechanism / cost / failure / serves:** Every record and mutation carries `project_id`, `fleet_id`, `parent_run_id`, `run_id`, `session_id`, and `pane_id`, with explicit scope checks and per-scope indexes. Cost is schema migration plus reconciliation of old unscoped rows. Without it, session A can reap, close, or report session B's work; it serves the conductor, workers, and every future multi-project user.

### 2. Lease and fencing semantics for ownership

- **Refuses:** A stale pane or watcher writing after its work has been reassigned; “last writer wins” ownership.
- **Evidence:** `Stage1Claim`/`GlobalClaim` and `ownershipToken`/`inputWatermark` in `00-brief.md §3.8` are upstream declarations, while the local dispatch fence recorded **162 refused ticks over 4.2 hours** (`DISPATCH_RETRY_BLOCKED`).
- **Mechanism / cost / failure / serves:** Claims need an epoch/token, expiry, and a server-side fence on every effect, not just on initial dispatch. Heartbeats, expiry handling, and recovery add operational cost. Otherwise a delayed child can close a bead after a replacement has started it; this serves correctness under pane death, restart, and worker replacement.

### 3. Parent/child causal lineage for 1:many runs

- **Refuses:** Events that identify only a pane or bead and cannot answer “which fan-out invocation produced this?”
- **Evidence:** The upstream `RpcSessionEventFrame` carries the wire-proven `AgentEndEvent`; the current plan's S1–S9 artifact table in `docs/plan/12-journey.md` has no parent-run/child-run contract.
- **Mechanism / cost / failure / serves:** Assign a stable parent run, child index, stage, bead, attempt, and event sequence to every descendant, and preserve lineage through dispatch, work, grade, and ship. The cost is metadata on every receipt and larger evidence records. Without it, fan-in cannot distinguish missing child 3 from a duplicate child 1, and failures cannot be attributed; it serves operators debugging a fleet and humans reviewing outcomes.

### 4. Atomic dispatch intent plus delivery receipt

- **Refuses:** Treating transport `success:[N]` as proof that the intended packet reached pane N.
- **Evidence:** `00-brief.md §3.8` cites the real `cp-z42vu` result—transport returned `success:[N]` with no packet—and lists `IrcDeliveryReceipt`/`AsyncJobDeliverySink` as DECLARED ONLY.
- **Mechanism / cost / failure / serves:** Persist an intent and packet hash before send; transition it only through correlated receipt states (`accepted`, `delivered`, `rejected`, `unknown`). A durable outbox and reconciliation loop cost storage and implementation complexity. Otherwise the conductor creates phantom dispatches or sends work twice; this serves every fan-out scheduler and the human who needs an auditable answer.

### 5. Idempotent logical commands and ambiguity recovery

- **Refuses:** Blind resend after timeout, and duplicate execution caused by using a new command ID for the same intent.
- **Evidence:** `cp-z42vu` is the measured no-packet transport failure in `00-brief.md §3.8`; the upstream `AsyncJobDeliverySink` is a named but unwired receipt surface.
- **Mechanism / cost / failure / serves:** A logical command ID remains stable across attempts; the child deduplicates it and reports the same result. The cost is durable dedupe state and a garbage-collection policy. Without it, an ambiguous send can execute a bead twice or create two children; it serves the conductor during retries and workers that must remain safe under network uncertainty.

### 6. Roster epochs and membership truth

- **Refuses:** Scheduling against a stale pane roster, counting a dead pane as capacity, or letting a newly joined pane inherit old work accidentally.
- **Evidence:** `HubRosterCounts` is listed in `00-brief.md §3.8` as DECLARED ONLY; the plan's measured lifecycle table says hand-derived roster evidence remains unclosed.
- **Mechanism / cost / failure / serves:** Introduce roster epochs, member/session capabilities, join/leave/replacement events, and a rule that capacity observations are valid only for a stated epoch. Reconciliation on churn costs heartbeats and state transitions. Without it, 1:many dispatch either overloads live panes or strands work on vanished ones; it serves scheduling, recovery, and fleet dashboards.

### 7. One lifecycle reducer for terminal, continuing, and stopped states

- **Refuses:** “Pane went idle” as a completion proof, or ad hoc interpretation of terminal events in multiple watchers.
- **Evidence:** The tool already emits wire-proven `AgentEndEvent.willContinue` and `SessionStopEvent` through `RpcSessionEventFrame` (`00-brief.md §3.8`); `PLAN.md §11.5` says adoption into the supervisor is still the gap.
- **Mechanism / cost / failure / serves:** One reducer consumes the event stream and produces typed child and parent states. The cost is an adapter and replayable state machine. Without it, continuation gets reaped, terminal work is missed, and each watcher invents different truth; it serves all sessions and makes fan-in deterministic.

### 8. Explicit idle-settle and continuation semantics

- **Refuses:** Dispatching on transient idle, and dropping “newly idle” panes because the filter only accepts “confirmed idle.”
- **Evidence:** `00-brief.md` records the actionable path as BROKEN: `idle_panes` discards `NewlyIdle`; `GuestIdleReconcilerCtx` is the upstream analogous type but DECLARED ONLY.
- **Mechanism / cost / failure / serves:** Model `newly_idle`, `confirmed_idle`, `continuing`, and `terminal` separately, with an explicit settle transition and timeout. The cost is a few more state transitions and a reconciliation timer. Without it, capacity is undercounted or work is dispatched into a continuation; it serves reliable replenishment and avoids both missed capacity and premature reap.

### 9. Parent fan-in with partial, quorum, and required-child semantics

- **Refuses:** Marking a parent stage complete when the first child finishes, or blocking forever because one optional child disappeared.
- **Evidence:** `docs/plan/12-journey.md` names one artifact per stage but has no aggregate contract for multiple sessions; the eight-live-session observation exposes the missing cardinality.
- **Mechanism / cost / failure / serves:** The parent declares child cardinality, required/optional roles, aggregation rule, and a terminal condition (`all`, `quorum`, or explicit waiver). This costs a typed aggregation record and policy evaluation. Without it, fan-in produces premature ship or indefinite deadlock; it serves the conductor and humans who need truthful partial-progress reporting.

### 10. Fleet-wide backpressure, fairness, and starvation prevention

- **Refuses:** Retrying the same blocked dispatch forever, letting one project consume all panes, or claiming progress while admission is closed.
- **Evidence:** `DISPATCH_RETRY_BLOCKED` occurred on 162 ticks over 4.2 hours (`PLAN.md §11.5`/`00-brief.md`), while `S4 → S5` is measured as severed and `bv` is never invoked.
- **Mechanism / cost / failure / serves:** Admission needs bounded queues, per-project quotas, priority aging, retry budgets, and a reasoned `blocked` state. Cost is scheduler complexity and policy tuning. Without it, a fleet can be busy but make no value progress, or starve older work; it serves operators running many repos and users sharing a fleet.

### 11. Durable event log and replay instead of pane scrollback

- **Refuses:** Using pane output or watcher-local memory as the source of truth after restart or compaction.
- **Evidence:** `00-brief.md` says the stand-down found **seven real conditions living only in pane scrollback**; `SessionBeforeCompactEvent`/`SessionCompactEvent` are DECLARED ONLY in §3.8.
- **Mechanism / cost / failure / serves:** Append immutable, scoped events with sequence numbers and checkpoints; rebuild projections after a watcher restart. Cost is disk, retention, and replay handling. Without it, compaction or process loss silently erases requirements, receipts, and child state; it serves recovery, audits, and unattended operation.

### 12. A typed, scope-aware S9 human-requirements registry

- **Refuses:** Human requirements living only in chat, pane scrollback, or an unowned note; shipping with an unrecorded decision.
- **Evidence:** `docs/plan/12-journey.md:35-38` makes S9 cross-cutting and reports **eleven decisions** lost to pane scrollback in one session; R11/R12 in `00-brief.md` require durable requirements and owned open questions.
- **Mechanism / cost / failure / serves:** Store requirement ID, verbatim text, origin, scope, owner, status, rationale, evidence, supersession, and blocking stage; inject the relevant slice into every dispatch packet. Cost is friction at capture and schema/versioning. Without it, a child silently optimizes the wrong requirement and a compacted session loses the human contract; it serves humans, graders, and future agents.

### 13. Human decision ownership, approval, and expiry

- **Refuses:** Ownerless open questions, implicit approval, and a stale approval being reused for a changed artifact.
- **Evidence:** R12 explicitly requires every experienced-operator question to be answered or registered with an owner; `00-brief.md §8` records open questions with owner gaps.
- **Mechanism / cost / failure / serves:** Give each decision an approver, decision state, scope hash, expiry/reapproval rule, and an auditable accept/reject/waive action. The cost is human interaction and approval latency. Without it, “adequate” silently becomes “approved,” or a ship decision leaks across projects; it serves the human authority and protects the conductor from inventing consent.

### 14. New-project bootstrap as a first-class capability

- **Refuses:** Assuming the target repo already has `CLAUDE.md`, `AGENTS.md`, gates, infra, tools, or this repository's directory layout.
- **Evidence:** S1 requires those artifacts in `12-journey.md`; the measured installer state says `installer` covers only 3 of 18 binaries, `--install` has never run on a foreign host, and its fallback hardcodes `/Users/josh` (`PLAN.md §11.1`/brief K3).
- **Mechanism / cost / failure / serves:** A bootstrap command probes or creates the repo contract, installs only compatible components, and emits a readiness manifest. Cost is platform/environment branching and safe initialization. Without it, the product dies before planning on a clean project; it serves first-time users and every end-user acceptance run.

### 15. Capability and environment negotiation before dispatch

- **Refuses:** Sending a skill, command, or gate packet based on assumed binaries, versions, paths, or pane capabilities.
- **Evidence:** The header reports 591 mapped OMP surfaces but only 32 consumed, 67 wire, and 9 honestly unknown; §3.8 distinguishes declarations from reachable wire paths.
- **Mechanism / cost / failure / serves:** Child sessions publish a capability manifest (OS, tool versions, supported modes, gates, workspace path, resource budget), and packets declare prerequisites. Cost is probe time and manifest maintenance. Without negotiation, the fleet dispatches impossible work and records misleading failures; it serves heterogeneous hosts and upstream adapters.

### 16. Independent, fresh-session plan/work grading

- **Refuses:** A worker grading its own output, a conductor accepting self-report, or “tests pass” standing in for independent re-derivation.
- **Evidence:** `PLAN.md §11.1` reports six Verdict types with no shared trait and says grading is prose; §11.2 measures only **3 `Y`-and-used cells out of 45**; `omp-types` has zero dependents.
- **Mechanism / cost / failure / serves:** Run an evaluator in a fresh process/session against an immutable input snapshot, with a common verdict schema and evidence references. Cost is extra compute and evaluator maintenance. Without independence, reward hacking and confirmation bias survive; it serves maintainers, investors, and end users who need a trustworthy ship decision.

### 17. Clean-room end-user acceptance on a foreign repo and machine

- **Refuses:** Calling the orchestrator validated because it works in its own checkout on the author's machine.
- **Evidence:** K3 in `00-brief.md` says a second machine was never attempted; the installer fallback is `/Users/josh`; S7 in `12-journey.md` explicitly requires another machine and unattended execution.
- **Mechanism / cost / failure / serves:** Maintain a disposable project fixture and run the complete S1→S8 journey from a clean host/checkout, with no hidden repo state. Cost is environment provisioning and fixture upkeep. Without it, bootstrap, path, permissions, and install defects reach users; it serves actual adopters rather than the development repo.

### 18. Upstream capability adapters with provenance and reachability probes

- **Refuses:** Treating a discovered `.d.ts` type as an adopted capability, or replacing a local contract before the upstream wire path is proven.
- **Evidence:** `00-brief.md §3.8` explicitly marks only completion WIRE-PROVEN; receipts, claims, idle, roster, cost, and compaction are DECLARED ONLY, with named sources such as `IrcDeliveryReceipt`, `GuestIdleReconcilerCtx`, and `HubRosterCounts`.
- **Mechanism / cost / failure / serves:** Each adapter pins upstream source/version, maps semantics to local types, probes actual reachability, and records fallback/no-claim boundaries. Cost is compatibility work and drift tests. Without it, the plan either duplicates upstream machinery or makes false adoption claims; it serves maintainers and future upgrades.

### 19. Machine-readable stage contracts and generated dispatch packets

- **Refuses:** A runbook that is complete in prose but cannot be validated, instantiated, or rejected by the binary.
- **Evidence:** `12-journey.md` currently ends with `<!-- STAGES S1-S9 ARE FILLED BY THE WAVE... -->`; `PLAN.md §11.3` says `ntm template list` exposes four templates, including the exact hand-rolled pattern, but they were not used.
- **Mechanism / cost / failure / serves:** Represent all seven runbook fields plus scope, cardinality, prerequisites, child policy, and done probe as schemas; generate packets and validate them before dispatch. Cost is schema evolution and migration. Without it, each watcher improvises packets and “Amazing”/“Adequate” become unactionable prose; it serves orchestration and grading.

### 20. Fleet cost, retry, and termination budgets

- **Refuses:** Unbounded fan-out, infinite retries, and silent spend/resource growth.
- **Evidence:** `SearchUsage`, `PerplexityCost`, and `ContextUsage` are listed as DECLARED ONLY in `00-brief.md §3.8`; Q2 remains an instrumentation question.
- **Mechanism / cost / failure / serves:** Parent runs need token/time/pane/retry budgets, reservation accounting, and a terminal `budget_exhausted` state that cannot masquerade as success. Cost is telemetry plumbing and policy design. Without it, 1:many work can run indefinitely while the plan reports progress; it serves operators, project owners, and anyone paying for the fleet.

## Top 6

These six are the highest-leverage omissions because they compose into the minimum control plane for eight sessions and arbitrary fan-out. They are ordered by how many other failures they prevent, not by stage number.

### 1. Scoped control-plane state: identity, lineage, and fencing

**The missing capability.** Replace the implicit shared ledger with a scoped state model that understands a project, fleet, parent run, child run, session, pane, stage, bead, attempt, and ownership epoch. This combines candidates 1–3 and the lease portion of candidate 2 because isolation without ownership fencing still permits stale writers.

**Required contract.** Every event, claim, packet, receipt, grade, and requirement record carries at least:

```text
project_id / fleet_id / parent_run_id / run_id / session_id / pane_id
stage_id / bead_id / attempt / event_seq / ownership_epoch
```

A mutation is accepted only when its scope matches the target record and its ownership epoch is current. A child may report to its parent run, but may not mutate an arbitrary sibling or the global ledger. Parent projections are derived from child events, not written as free-form summaries.

**Invariants.**

1. No cross-project or cross-run read/write is possible through a default scope.
2. At most one current owner may effect a claimed unit at an epoch.
3. A stale epoch can observe but cannot mutate.
4. Every child has exactly one parent lineage (or an explicit orphan/quarantine state).
5. Replaying the same event does not change the projection twice.

**Why month three exposes it.** Eight sessions make accidental identity collisions and stale watchers routine rather than exceptional. A shared ledger can make session A reap session B, a replacement worker close an old attempt, or a parent report a child result from the wrong project. These are silent correctness failures: the dashboard can look healthy while the work graph is corrupted.

**Amazing / adequate.** Amazing means multiple projects and repeated session replacement can run concurrently with zero cross-talk, and a replayed audit proves every mutation's scope and epoch. Adequate means one fleet/project is supported, but all scope fields and fencing are present and unambiguously single-scoped; the product refuses multi-project operation rather than pretending to support it.

**What it refuses.** Global mutable ledger state, pane-name identity, unscoped “current run,” last-writer-wins claims, and a child writing directly to a parent summary.

**Evidence and cost.** The real eight-session/shared-ledger observation is the direct signal. Upstream `Stage1Claim`/`GlobalClaim` has the right ownership vocabulary but is DECLARED ONLY (`00-brief.md §3.8`), so adoption requires a local adapter and reachability proof. Cost is schema migration, indexes, and recovery/reconciliation logic; that cost is lower than month-three data repair.

**Who it serves.** The conductor first, then workers, graders, auditors, and users running more than one project or replacing panes.

### 2. Causally correlated dispatch, receipts, dedupe, and retry

**The missing capability.** Turn dispatch from “send text to a pane” into an auditable logical command with an outbox, packet hash, attempt history, and correlated delivery receipt.

**Required contract.** A dispatch intent contains:

```text
intent_id / parent_run_id / child_run_id / target_session_id / target_pane_id
packet_hash / stage_id / bead_ids / attempt / deadline / budget_reservation
```

The state machine is explicit: `prepared → accepted → delivered → acknowledged → terminal`, with `rejected`, `unknown`, and `expired` branches. Retries reuse `intent_id`; the child deduplicates the logical command and returns the prior result. `success:[N]` without a matching packet receipt is `unknown`, never `delivered`.

**Invariants.**

1. No work is marked dispatched without a packet hash and target scope.
2. One logical intent cannot create two logical child executions.
3. An ambiguous transport response cannot silently become success.
4. A retry preserves lineage, attempt history, and budget accounting.
5. A receipt must correlate to the exact intent and packet hash.

**Why month three exposes it.** Fan-out multiplies every ambiguous send. One missing packet among eight children causes either a phantom success (parent waits forever for work that never started) or an unsafe resend (duplicate execution). At scale, “send returned success” is not an operational answer.

**Amazing / adequate.** Amazing gives deterministic recovery from process/network interruption: reconcile the outbox, dedupe safely, and explain each child outcome. Adequate supports at-least-once transport with dedupe and an explicit `unknown` state requiring operator/reconciler action. It must not downgrade `unknown` to success to keep the dashboard green.

**What it refuses.** Uncorrelated transport success, new IDs for retries of the same intent, blind resend, and a parent completing because a send call returned.

**Evidence and cost.** `cp-z42vu` measured `success:[N]` with no packet; `IrcDeliveryReceipt` and `AsyncJobDeliverySink` exist upstream but are DECLARED ONLY (`00-brief.md §3.8`). Cost is a durable outbox, dedupe state, and reconciliation worker. This is a direct fix for the S4→S5 seam, not ceremony.

**Who it serves.** The conductor and scheduler under uncertainty, workers receiving retries, and humans asking whether work was actually delivered.

### 3. Event-driven lifecycle reduction and correct fan-in

**The missing capability.** One supervisor-owned reducer that consumes terminal/continuation, idle-settle, stop, and membership events, then computes child and parent states under an explicit fan-in policy.

**Required contract.** The adapter must preserve `AgentEndEvent.willContinue`, `SessionStopEvent`, event sequence, and source frame. Idle and membership inputs must preserve `newly_idle` versus `confirmed_idle`, continuation versus terminal, and roster epoch. Parent contracts must declare required children and aggregate rule: `all`, `quorum`, or explicit waiver.

**Invariants.**

1. `willContinue=true` cannot produce terminal completion.
2. A terminal child cannot be re-opened by a late idle event.
3. A parent is complete only when its declared fan-in condition and stage gate are satisfied.
4. A newly idle pane is not silently treated as confirmed idle.
5. A stale roster epoch cannot create current capacity.

**Why month three exposes it.** The current plan names S6 work, S7 reap, and S8 grade, but `PLAN.md §11.5` says S6→S7 is unwired and every completion was found by a human looking. In a 1:many run, one continuation mistaken for completion triggers premature reap; one missed terminal event strands a child; one stale roster count distorts dispatch. Multiple watchers will otherwise implement incompatible heuristics.

**Amazing / adequate.** Amazing is event-driven, replayable, and produces a parent explanation such as “7/8 terminal, child 6 continuation, child 8 delivery unknown.” Adequate permits a polling fallback only when it is labeled non-proof and cannot close a stage or bead by itself.

**What it refuses.** `idle == done`, first-child-wins fan-in, human-only reaping, and a generic boolean `is_dispatchable` that erases settle semantics.

**Evidence and cost.** `AgentEndEvent` crossing `--mode=rpc` is WIRE-PROVEN; `GuestIdleReconcilerCtx` and `HubRosterCounts` are DECLARED ONLY (`00-brief.md §3.8`). Cost is an upstream adapter, a reducer, and replay tests. The plan should reuse the wire-proven completion channel rather than inventing another protocol, while proving the other six before claiming adoption.

**Who it serves.** Every scheduler and watcher, the worker lifecycle, parent fan-in, and humans relying on truthful progress.

### 4. S9 as a typed, scope-aware requirements and decision registry

**The missing capability.** Make human requirements durable data attached to the same lineage as work, not a final prose appendix or a chat transcript.

**Required contract.** Each requirement/decision records:

```text
requirement_id / verbatim_text / origin / project_id / run_id / stage_id
owner / status / rationale / evidence_refs / supersedes / scope_hash
blocking_policy / expiry_or_reapproval / captured_at
```

Dispatch packets carry the relevant requirements slice and its version/hash. A stage may be `done` only if required decisions are resolved or an explicitly owned waiver is recorded. Retrieval must work by project, run, stage, child, and decision owner.

**Invariants.**

1. No human requirement exists only in pane scrollback.
2. A decision cannot apply outside its declared scope hash.
3. An unresolved blocking requirement cannot silently permit ship.
4. Every open question has an owner and next state.
5. Supersession preserves the old decision and its rationale.

**Why month three exposes it.** `12-journey.md` reports eleven decisions lost in one session and says S9 is cross-cutting. Fan-out multiplies interpretation: eight children can each satisfy a different unstated version of “done.” Compaction, watcher restart, or handoff then causes silent requirements drift and expensive rework.

**Amazing / adequate.** Amazing lets a new evaluator reconstruct every human decision, who made it, which child consumed it, and whether it still applies. Adequate captures verbatim requirements and owners durably, even if approval transitions remain partly manual; it still blocks claims of complete ship when required entries are unresolved.

**What it refuses.** Scrollback-only requirements, ownerless open questions, implicit approval, silent supersession, and a child inventing a lower bar because the packet omitted the human constraint.

**Evidence and cost.** The eleven-scrollback decisions and R11/R12 are direct measurements in `12-journey.md` and `00-brief.md`; no new upstream type is needed to justify the local registry. Cost is capture friction, schema/versioning, and packet size. That cost buys traceability across compaction, fan-out, and human handoff.

**Who it serves.** Human decision-makers, graders, auditors, future agents, and the conductor assembling packets.

### 5. New-project bootstrap plus capability/environment negotiation

**The missing capability.** A real S1 control plane that can take an unfamiliar repo and host from zero to a truthful readiness manifest before dispatching S2.

**Required contract.** `init`/`doctor` must discover or create the repository instructions, gate entry points, work graph, filesystem layout, credentials/config boundaries, supported binaries, host platform, and install location. The output is a capability manifest with explicit `ready`, `missing`, `unsupported`, and `blocked` states. Every dispatch packet declares required capabilities and refuses when the target manifest does not satisfy them.

**Invariants.**

1. No path or home directory is assumed from the development machine.
2. S1 cannot report ready without the required instruction/gate/infra artifacts or an explicit scoped exception.
3. A packet cannot target an environment whose capability manifest is stale or incompatible.
4. Bootstrap is idempotent and leaves an evidence receipt.
5. A failed probe is not represented as successful readiness.

**Why month three exposes it.** The product promise is “other projects/repos/machines,” while the measured installer has never run on a foreign host and falls back to `/Users/josh`; `installer` covers only 3 of 18 binaries (`PLAN.md §11.1`). Eight local sessions can hide every environment assumption. The first clean customer project will fail before the elegant control-plane logic matters.

**Amazing / adequate.** Amazing runs S1→S8 unattended on a clean foreign host and produces a complete readiness/capability receipt. Adequate supports an explicitly documented host/repo subset and blocks unsupported targets with actionable evidence; it never silently falls back to the author's filesystem.

**What it refuses.** “This repo's conventions are universal,” implicit tool availability, hardcoded home paths, partial install reported as complete, and dispatch before environment proof.

**Evidence and cost.** S1's artifact contract is in `12-journey.md`; K3 records the unattempted second-machine path and hardcoded fallback in `00-brief.md`; the surface census is 591 mapped surfaces with only 32 consumed. Cost is cross-platform probing and safe bootstrap logic, but it is the only route from a plan for this repo to a product for new projects.

**Who it serves.** New adopters, CI/remote hosts, project owners, and the conductor choosing valid work.

### 6. Fresh-project independent grading and external validation

**The missing capability.** A separate evaluator, running from an immutable snapshot in a fresh session and preferably a clean fixture repo/machine, that grades plan, work, and end-to-end behavior without consuming worker self-report.

**Required contract.** The evaluator receives `EvaluationInput` (snapshot, stage contract, requirements slice, evidence set), records evaluator identity/freshness, applies named oracles, emits one common `Verdict` schema, and points every claim to evidence. The final ship decision requires both local contract checks and the clean-room end-user run.

**Invariants.**

1. The worker cannot be the sole evaluator of its own completion.
2. A verdict is not valid without an evidence reference and oracle identity.
3. Same-session observation is not labeled independent validation.
4. A clean-project/foreign-host failure blocks ship even when local tests pass.
5. Verdict types are composable and countable; prose cannot substitute for the schema.

**Why month three exposes it.** `PLAN.md §11.1` reports six verdict dialects with no shared trait, and §11.2 reports only 3 used `Y` cells out of 45. K3 says a second machine was never attempted. As the fleet grows, the conductor and graders share the same assumptions and begin rubber-stamping the same broken lifecycle. Self-grading becomes a system property, not an individual mistake.

**Amazing / adequate.** Amazing uses a fresh evaluator plus a clean foreign-project fixture, seeds known failures, and catches them with machine-readable evidence before ship. Adequate uses a fresh local process and immutable checkout with two independent lenses, while honestly labeling foreign-host validation pending; it cannot call S7/S8 fully proven.

**What it refuses.** Worker self-report, same-pane grading, prose-only verdicts, “tests pass” as external validation, and a green local run that ignores a clean-project failure.

**Evidence and cost.** The six unshared verdict types, zero dependents of `omp-types`, and 3/45 used grading cells are measured in `PLAN.md §11.1-11.2`; S7's another-machine requirement is in `12-journey.md`. Cost is additional compute, fixture maintenance, and evaluator/oracle design. It is the mechanism that makes “Amazing” falsifiable rather than aspirational.

**Who it serves.** Project owners, reviewers, investors, downstream users, and the maintainers who need to know whether the fleet actually works outside its authoring context.

## The common design rule

The plan should add a **cardinality and scope layer** to every stage contract:

```text
stage contract = seven existing fields
                 + project/fleet/run scope
                 + parent/child cardinality and fan-in rule
                 + ownership epoch
                 + event/receipt lineage
                 + requirements version/hash
                 + evaluator/oracle identity
                 + budget and termination policy
```

That is the line between “nine well-written stages” and an orchestrator that survives month three. The upstream search already found useful vocabulary. The product must now prove reachability, adapt it into one local state model, and refuse every declaration that has not crossed the actual control-plane wire.
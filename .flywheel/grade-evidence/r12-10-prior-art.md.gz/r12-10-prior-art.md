# Round 12 fresh report — 10-prior-art

{
  "grade": "MAJOR — the section is thoughtful about boundaries, but its search provenance has a blocker-level reproducibility defect and two investor-facing load-bearing counts/premises still ask for trust.",
  "findings": [
    {
      "severity": "BLOCKER",
      "file": "docs/plan/10-prior-art.md:51,143,159,163,175",
      "construct": "The stated `grep` searches use alternation/grouping syntax (`|`, parentheses) without `-E` (and Gap 8 additionally uses non-POSIX `\\w`).",
      "why_real": "Under standard basic `grep`, the unescaped alternation/grouping is literal, so the claimed positive hits and especially the Gap 7/8 negative results cannot be derived from the commands as written; that directly defeats the section's own false-zero and replayability contract and undermines the absence-based verdicts.",
      "fix": "Re-run each search with a valid ERE (`grep -E`, replacing `\\w` with `[[:alnum:]_]`) or separate fixed-string probes, and record the exact output/exit status in the evidence artifact."
    },
    {
      "severity": "MAJOR",
      "file": "docs/plan/10-prior-art.md:39 and :207",
      "construct": "`PROJECTED 7` refuted not-founds / “seven refuted not-founds.”",
      "why_real": "The only derivation shown is “four false-zero mechanisms described below,” while the seven-count is attributed only to an unspecified session record; no seven row IDs, artifact path, or counting rule is supplied. Although labeled PROJECTED, this load-bearing credibility metric is not reproducible and is repeated in the summary.",
      "fix": "Enumerate the seven session rows with stable artifact pointers and a count expression, or remove the seven-count and retain only the explicitly supported four mechanisms."
    },
    {
      "severity": "MAJOR",
      "file": "docs/plan/10-prior-art.md:91 and :141",
      "construct": "The local seed premises for Gap 4 (`omp-inventory-map --help` output) and Gap 7 (Brief §4’s “human looking” completion claim).",
      "why_real": "Neither premise has an exact local invocation, exit status, captured output/artifact, or fully qualified source citation in this section; the upstream citations prove design shapes, not that these OMP/local failures occurred. The later one-run completion capture narrows/retracts the universal Gap 7 claim but does not provide evidence for the historical seed premise.",
      "fix": "Attach the exact command and hashed capture for Gap 4, and a path/line or hashed Brief artifact plus an explicit historical/current label for Gap 7, with scoped NO-CLAIMs."
    }
  ]
}

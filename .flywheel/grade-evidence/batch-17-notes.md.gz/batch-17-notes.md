# BATCH 17 NOTES — SilverWolf (%1409) — R14 wave 2 (ee+ms)
30 rows: 0 WIRE / 30 RETIRE. ZERO WIREs in this slice is the correct outcome: ee's
session-lifecycle wires (pack/resume) sort into OliveCat's batches 15/16 and are correctly wired
there to omp-orchestrator; ms is a skill factory no crate consumes.
Every row was probed (`<tool> <cmd> --help`, 2026-09-01) and token-grepped against crates/
(counts embedded per row). Sole repo reference to both tools is the census itself
(02-surface-census.md:565-566) — zero consumption confirmed by me independently.

## BATCH-SPECIFIC
- ee:verify / ee:verification — "Record and evaluate verification evidence for closure decisions" /
  "Durable verification evidence ingestion and closure guidance". The sharpest RETIRE calls in this
  batch: these are evidence-gate-shaped, and close-evidence-gate is our crate. Retired deliberately:
  our doctrine keeps evidence IN the bead (dies-with-the-thing, single audit trail); a second
  evidence store is the §7.3 drift class. Recorded as the named alternative if bead comments ever
  prove insufficient as evidence-at-rest — adoption would be a doctrine change, not a mapping.
- ee:tripwire — second tripwire system; ours (no-shell-gate/tests/retired_figures.rs) is in-repo and
  test-enforced. Two tripwire systems = the two-hooks-racing defect (4a6cd1f lesson).
- ee:team — "Team confederation over mesh primitives"; help shows mesh consent lanes with approval
  tokens (mesh preview-grant/grant/revoke-lane). RETIRED as ee-internal, but flagged as PRIOR ART
  for ack-spine's AUTHORITY dialect — capability-token lanes are the receiver-receipt gap's shape.
  Mapping a surface is not adopting it (NO-CLAIM 2); this is a pointer, not a wire.
- ee:task-frame ("Durable passive task frames and goal stacks") — second goal tracker; beads are ours.
- ee:swarm ("Read-only coordination snapshot and preflight recommendations for agent swarms") —
  second fleet-truth; ntm-fleet-monitor + fleet-truth are ours, typed over panes.
- The wire the packet asked this tool family about — `ee resume` — is NOT in this batch (sorts into
  batch 16, OliveCat). For the record: ee resume = "Resume recent session end-state, open loops, and
  stale next steps" (probed), and the measured failure it prevents is %1413's round-1 compaction-loss
  of an entire grading task. OliveCat wired it to omp-orchestrator; I concur (see my cross-grade).

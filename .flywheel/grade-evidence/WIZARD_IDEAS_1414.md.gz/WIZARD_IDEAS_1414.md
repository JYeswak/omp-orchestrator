# Dueling Idea Wizards — what the journey still misses

**Mission:** orchestrate 1:1 and 1:many NTM sessions through an A-to-Z project journey, beginning with a repository that does not yet exist and ending with a shipped result, while preserving every human requirement and defining an Amazing bar at every layer.

**Read first:** `docs/plan/12-journey.md:23-61` defines S1–S8 plus cross-cutting S9 and the seven-field runbook contract. `docs/PLAN.md:5727-5775` says the existing A-to-Z process is distributed across twelve skills, has no composition artifact, and has only two typed handoffs. `docs/PLAN.md:5786-5812` then narrows one earlier absence: completion is wire-proven through `AgentEndEvent`/`RpcSessionEventFrame`, but this repository still has to consume it. The ideas below target the missing product around that spine; they are not another nine-stage description.

## Winnowing standard

Each candidate had to survive five questions:

1. Does it change the product under 1:many fan-out, foreign-repo inception, or S9—not merely restate §11.8?
2. Does it have a concrete refusal boundary?
3. Is there real evidence in this repository or a named upstream type?
4. Can it attach to existing seams instead of rewriting the 26-crate inventory?
5. What does it prevent or prove by month three, and who gets the benefit?

Three independent wizard reports produced overlapping mechanics. The two judging passes agreed that the winning units are **capabilities/contracts**, not six new crates. Receipts, idempotency, leases, lifecycle, roster, replay, and capability negotiation are therefore folded into the larger boundaries where they become useful rather than promoted to standalone workstreams.

## 20 candidates, ordered best to worst

### 1. Scoped 1:many mission control plane — **SURVIVES**

- **Missing:** A parent/child run manifest and ledger that works for one child as well as many. Every effect needs `project_id`, `fleet_id`, `parent_run_id`, `child_id`, `repo_identity`, `session_id`, `pane_id`, `worker_incarnation`, `stage`, `bead`, `attempt`, and sequence/epoch.
- **Refuses:** Global ledger reads; pane names as identity; sibling cross-talk; aggregate `COMPLETE` with an unknown, continuing, lost, undelivered, or unverified required child; stale worker effects.
- **Evidence:** Eight live tmux sessions and the recent shared-ledger hazard; `docs/plan/12-journey.md:25-38` names one artifact per stage but no parent/child or aggregate contract. `docs/plan/00-brief.md:501-504` marks receipt, claim, idle, and roster types DECLARED ONLY.
- **How/cost/failure/who:** Persist the expected-target set, barrier policy (`all`, quorum, or named waiver), child projections, budgets, receipts, lifecycle events, leases, and fan-in verdict. It costs a manifest, a reducer, indexes, and migration/reconciliation for unscoped history. Without it, a ten-child run cannot distinguish child 3 missing from child 1 duplicated, and one session can close another's work. It serves the conductor, every fleet operator, and a solo user through the one-child degenerate case.

### 2. Durable human-requirement and decision ledger — **SURVIVES**

- **Missing:** S9 has a label but no mechanism. Store immutable requirement/decision records with verbatim source, scope, owner, status, acceptance, evidence, `supersedes`, `conflicts_with`, approval actor, and expiry; thread the requirement revision into every downstream artifact.
- **Refuses:** Dispatch or ship with an absent, ownerless, stale, conflicted, or out-of-scope requirement; paraphrase-only updates; inferred approval; silent overwrite; deleting superseded history.
- **Evidence:** `docs/plan/12-journey.md:35-38` says S9 is cross-cutting and that eleven decisions from this session live only in pane scrollback. `docs/PLAN.md:52-61` records seven real conditions lost there and warns that paraphrasing requirements changes them.
- **How/cost/failure/who:** An append-only, scope-aware stream is replayed after compaction, handoff, or restart; IDs and revision hashes travel in beads, dispatch packets, grade bundles, and ship receipts. Cost is a small schema plus storage and an operator resolution flow, not a new approval service. Without conflict/supersession semantics, a sponsor's mid-run decision either silently fails to reach children or retroactively changes what a grade meant. It serves Josh, future reviewers, fleet operators, and any human who must recover the project after a context loss.

### 3. Transactional foreign-repository activation capsule — **SURVIVES**

- **Missing:** A real S1 transaction for a repo and host that are not this checkout. Profile first; show the write set; obtain the required approval; apply atomically; verify; undo.
- **Refuses:** Ambiguous root/worktree/submodule boundaries; wrong target commit; hardcoded `/Users/josh`; compile-time build-machine paths; partial config/gate/tracker writes; automatic tracker conversion; a green exit after a no-op.
- **Evidence:** `docs/plan/07-installability.md:15-45` measures an installer covering 3/18 binaries and a `tick-monitor` without an identity surface. `docs/plan/08-end-users.md:6-21` says there is no adopter-facing doctor/init/adopt path; `docs/plan/09-milestones.md:172-180` says a cold foreign-host run has never been attempted.
- **How/cost/failure/who:** Produce an identity-bound admission manifest containing runtime repo facts, dirty state, detected capabilities, intended owned paths, selected adapters, and inverse operations. Reuse `installer` and the existing repair/identity seams; first adoption writes only the tool namespace. The cost is profile/apply/undo logic and foreign fixtures. Without a transaction, a failed first run leaves an adopter to reverse-engineer half a configuration. It serves every new project, especially non-Rust repos and users on a cold machine.

### 4. Consume-before-rebuild capability and wire-adoption registry — **SURVIVES**

- **Missing:** A machine-readable card for each upstream plane: source revision, type/CLI shape, probe, semantic mapping, owner, fallback, and state transition `DECLARED → WIRE-PROVEN → CONSUMED → E2E-PROVEN`.
- **Refuses:** Rebuilding a protocol whose sanctioned plane exists; promoting a `.d.ts` name or type-only import to availability; using a capability whose probe or version contract is stale; silently accepting schema drift.
- **Evidence:** `docs/PLAN.md:5786-5812` proves `AgentEndEvent` crosses the RPC wire but says supervisor consumption remains. `docs/plan/00-brief.md:493-511` marks completion WIRE-PROVEN while receipts, claims, idle, roster, cost, and compaction are DECLARED ONLY. `docs/PLAN.md:5561-5589` records an existing NTM dispatch template that was not used.
- **How/cost/failure/who:** The registry owns adoption receipts and versioned compatibility probes, not a second implementation of OMP/NTM. Cost is a card format and a small set of reachability/semantic-fit probes. Without it, the next upgrade either duplicates upstream work or treats a declaration as a live feature. It serves the maintainer who upgrades OMP, the fleet operator who needs a typed fallback, and the reviewer who must distinguish “exists somewhere” from “we consume it.”

### 5. Independent clean-room acceptance and anti-vacuity run — **SURVIVES**

- **Missing:** An external product oracle that runs the actual journey on a cold host, a foreign repo, a non-Rust repo, and both 1:1 and 1:many cases. Include known-good, known-bad, mutation, production-seam, omission, and requirement-inventory legs.
- **Refuses:** Adoption or ship claims from the same checkout, same session, same fixture family, or worker self-report; empty scans; gates with no known-good leg; declarations promoted because a fresh run simply did not exercise them.
- **Evidence:** `docs/plan/09-milestones.md:150-180` says the headline ten-close and foreign-host milestones have never been observed/attempted. `docs/PLAN.md:5537-5555` measures only 3 used `Y` cells out of 45; `docs/plan/09-milestones.md:243-246` records false-zero measurements, and `:317-319` records built mechanisms that were never called.
- **How/cost/failure/who:** A fresh evaluator gets only the contract and an evidence bundle, then records every refusal and missing row. The cost is a fixture matrix and a cold-host run, slower than local CI but cheaper than shipping a self-confirming demo. Without it, the plan can grade itself green while S1 and S7 remain hypothetical. It serves release decision-makers and adopters, not just implementers.

### 6. Economics and refusal-storm operating SLO — **SURVIVES**

- **Missing:** A reason to leave the loop running: per-run budgets and value measures for useful close, operator touches, blocked minutes, retry count, and cost once upstream telemetry is proven.
- **Refuses:** Heartbeat-only progress; indefinite recurrence of one refusal code; burning compute/panes/operator attention without state change; budget exhaustion masquerading as success; value claims without a baseline and target.
- **Evidence:** `docs/plan/09-milestones.md:157-169` records 162 consecutive `DISPATCH_RETRY_BLOCKED` ticks over 4.2 hours. `docs/plan/00-brief.md:802-823` leaves customer outcome, baseline/target, verification cost, and headcount open; `SearchUsage`, `PerplexityCost`, and `ContextUsage` remain DECLARED ONLY in §3.8.
- **How/cost/failure/who:** Add a run-value/refusal receipt to the supervisor, with a configured recurrence threshold and escalation owner; do not invent cost telemetry before the upstream cost planes are reachable. It costs counters, budgets, and one escalation path. Without it, a technically honest orchestrator can spend four hours proving it is blocked. It serves solo maintainers deciding whether automation saves time and fleet operators deciding whether fan-out is worth capacity.

### 7. Event-driven child lifecycle reducer — **MERGES into #1 and #4**

- **Missing:** One reducer for terminal, continuing, stopped, newly-idle, confirmed-idle, and lost states. It must consume `AgentEndEvent.willContinue` and `SessionStopEvent` rather than infer completion from a pane.
- **Refuses:** Pane idle as completion; reaping a continuation; terminal work disappearing; different watchers assigning different meanings to the same event.
- **Evidence:** `docs/PLAN.md:5786-5799` proves the event frame; `docs/plan/00-brief.md:503-506` says idle and compaction types remain declaration-only. `docs/plan/09-milestones.md:129-148` still describes local completion as unwired.
- **How/cost/failure/who:** Implement a replayable state reducer behind the mission ledger. It costs a state machine and adapter mapping; it serves every child but is not a separate product because its output is the child row in #1.

### 8. Causal dispatch outbox and delivery receipts — **MERGES into #1 and #4**

- **Missing:** Persist dispatch intent and packet hash before send; correlate target, attempt, and receipt state (`prepared`, `accepted`, `delivered`, `rejected`, `unknown`).
- **Refuses:** Treating transport `success:[N]` as delivery; closing a child on an uncorrelated receipt; retrying a packet whose delivery is unknown without preserving intent.
- **Evidence:** `docs/plan/09-milestones.md:109-127` records `cp-z42vu` returning `success:[4]` while no packet arrived and says `IrcDeliveryReceipt`/`AsyncJobDeliverySink` are declaration-only upstream types.
- **How/cost/failure/who:** Add an outbox and receipt projection to #1, then adopt the upstream receipt plane only after a wire probe. It costs durable intent rows and reconciliation; it prevents phantom work and duplicate fan-out for fleet operators.

### 9. Idempotent logical commands and ordered effect replay — **MERGES into #1**

- **Missing:** A stable logical command ID across retries, an attempt ID for each send, and ordered duplicate/late-event handling.
- **Refuses:** New logical IDs on resend; duplicate execution after timeout; an old event overwriting a newer attempt; replay with no causal parent.
- **Evidence:** The no-packet `cp-z42vu` result in `docs/plan/09-milestones.md:111-127` creates exactly the ambiguity this needs; the current journey has no attempt or effect identity in `docs/plan/12-journey.md:25-38`.
- **How/cost/failure/who:** Key applied effects by `(parent, child, attempt, sequence)` and garbage-collect only after a durable terminal watermark. It costs a dedupe index and replay rules; it serves any retrying conductor and is a field of the mission ledger, not another crate.

### 10. Lease, worker-incarnation, and fencing semantics — **MERGES into #1 and #3**

- **Missing:** Ownership epochs and expiry checked on every effect, not only at initial dispatch.
- **Refuses:** A stale pane or watcher closing work after reassignment; last-writer-wins claims; recycled worker identities inheriting old authority.
- **Evidence:** `docs/plan/00-brief.md:501-504` lists `Stage1Claim`/`GlobalClaim` with `ownershipToken` and `inputWatermark` as DECLARED ONLY; the measured fence produced 162 blocked ticks (`docs/plan/09-milestones.md:157-159`).
- **How/cost/failure/who:** Reuse that vocabulary for leases in the child ledger and use the activation capsule's repo/session identity at admission. Heartbeats and recovery add cost; the refusal is essential to safe pane replacement and foreign-host restarts.

### 11. Roster epochs and membership truth — **MERGES into #1**

- **Missing:** Join/leave/replacement events and a roster epoch attached to every capacity observation.
- **Refuses:** Scheduling against a stale roster; counting dead panes as capacity; letting a new pane inherit old work.
- **Evidence:** `HubRosterCounts` is DECLARED ONLY in `docs/plan/00-brief.md:503-505`, and the journey has no membership artifact (`docs/plan/12-journey.md:25-38`).
- **How/cost/failure/who:** Add epoch and capability fields to the parent/child manifest and reconcile churn. It costs heartbeats and state transitions; it serves fan-out scheduling and recovery.

### 12. Fleet backpressure, fairness, and refusal budgets — **MERGES into #1 and #6**

- **Missing:** Admission quotas per project/session, starvation prevention, and a refusal budget that changes state instead of retrying forever.
- **Refuses:** One project consuming every pane; infinite retries of a blocked code; reporting health while no work can move; starvation hidden by aggregate throughput.
- **Evidence:** 162 `DISPATCH_RETRY_BLOCKED` ticks are recorded in `docs/plan/09-milestones.md:157-169`; `docs/PLAN.md:5537-5555` says dispatch properties were used in only 3/45 cells.
- **How/cost/failure/who:** The parent manifest carries concurrency/cost quotas and #6 carries escalation thresholds. It costs a scheduler policy and counters; it serves multi-repo operators first.

### 13. Approval, ownership, conflict, and expiry semantics — **MERGES into #2**

- **Missing:** Typed approval tokens scoped to a requirement revision, target artifact, allowed action set, and expiry.
- **Refuses:** Implicit approval; stale approval after a changed plan; ownerless open questions; an approval for project A authorizing project B.
- **Evidence:** `docs/plan/12-journey.md:40-61` has no requirement/decision field; `docs/PLAN.md:803-823` leaves open questions with ownership and decision state as a risk dimension.
- **How/cost/failure/who:** Make approval fields part of the requirement ledger rather than building an approval service. It costs token validation and conflict resolution; it serves humans who are interrupted or hand off work.

### 14. Cold-host semantic capability negotiation — **MERGES into #3 and #4**

- **Missing:** Probe executable identity, version, verbs, schema, feature flags, and host paths before dispatch; distinguish presence from semantic compatibility.
- **Refuses:** PATH presence as capability; assuming `--version` works for every dependency; dispatching a packet a worker cannot receive; silent fallback to a weaker transport.
- **Evidence:** `docs/plan/07-installability.md:32-45` measures only 5/18 workspace binaries exposing `--version`; `:378-381` records tmux's `--version`/`-V` asymmetry. `docs/plan/00-brief.md:493-511` distinguishes type declarations from reachable wire paths.
- **How/cost/failure/who:** The activation manifest probes the host and the adoption registry probes the upstream semantic contract. It costs a capability vector and version-specific checks; it serves foreign hosts and upgrade maintenance.

### 15. Tracker adapter and identity-preserving migration — **CONCESSION**

- **Missing:** A first-class adapter for `br`, GitHub, a file tracker, or no tracker, with previewed external-ID and dependency mapping.
- **Refuses:** Automatic migration; duplicate IDs; unmappable dependencies or cycles; a second source of truth created silently.
- **Evidence:** `docs/plan/08-end-users.md:72-96` designs tracker absence as `ABSENT`, and `:181-190` says foreign repos must not require the local bead prefix or directory layout.
- **How/cost/failure/who:** It is valuable after activation but not before the first safe profile. The cost is adapter contracts and migration preview; it serves adopters with existing project systems. It is intentionally below the six because activation can initially use a file-backed tracker.

### 16. Adopter-derived gate profiles and exception ownership — **CONCESSION**

- **Missing:** A profile that selects applicable gates for a foreign repo and records who owns every opt-out/exception.
- **Refuses:** Importing Josh's `.sh`/`.py` prohibition by default; enabling attack-only gates with no known-good leg; an unowned exception that silently becomes permanent.
- **Evidence:** `docs/plan/08-end-users.md:181-197` says the no-shell rule is local and must be opt-in; `docs/plan/06-gates.md:75` admits the current leg table is proxy-scoped and its meta-gate does not exist.
- **How/cost/failure/who:** Add profile selection to activation and the requirement ledger. It costs applicability probes and exception expiry; it serves foreign repos without colonizing them, but is downstream of the core adoption transaction.

### 17. Portable content-addressed checkpoint and evidence bundle — **MERGES into #2, #5, and #1**

- **Missing:** A resumable bundle containing requirement cursor, repo identity, worker incarnation, leases, event watermark, child outcomes, hashes, and redacted evidence.
- **Refuses:** `/tmp` as sole proof; pane scrollback as state; resuming a changed artifact with an old approval; claiming a raw frame proves supervisor consumption.
- **Evidence:** `docs/PLAN.md:52-61` records seven conditions lost to pane scrollback. `docs/PLAN.md:5786-5812` stores completion proof as a raw frame while explicitly saying it does not prove local consumption.
- **How/cost/failure/who:** Emit the bundle at each barrier and use it as the input to clean-room grading. It costs storage and redaction, but prevents compaction/restart from changing the story. It serves every handoff and the external evaluator.

### 18. Typed handoff manifest from requirement to ship — **KILL as a standalone workstream; keep fields**

- **Missing:** A machine-checkable reference chain from requirement ID to plan row, bead, packet, event, grade, validation, and ship receipt.
- **Refuses:** Prose-only transitions; artifacts with no source requirement; grades with no tested bead; ship receipts with no validation evidence.
- **Evidence:** `docs/PLAN.md:5752-5775` says only S3 beads and S4 graph ranking are consumable typed values; everything else hands prose forward. The seven-field contract in `docs/plan/12-journey.md:40-61` has no cross-stage ID field.
- **How/cost/failure/who:** Preserve this as IDs and hashes inside #2, #1, and #5 rather than creating a compiler project that duplicates the journey. It serves auditors and humans recovering intent; standalone it would recreate the composition sprawl §11.8 identifies.

### 19. Solo-maintainer first-class mode and adoption funnel — **MERGES into #3 and #6**

- **Missing:** A default path where one maintainer can gain gate/close value without installing the whole fleet, plus a measured activation-to-repeat-use signal.
- **Refuses:** Requiring eight panes, NTM, `br`, `bv`, or Josh's directory layout for a one-agent repo; calling a capability successful because it was installed once; fleet-only value claims.
- **Evidence:** `docs/plan/08-end-users.md:25-47` defines the solo maintainer as Persona A and says the current ordering is A → B → C; `docs/plan/00-brief.md:223-226` records 157/183 census rows as `CAPABILITY_NOT_USED`.
- **How/cost/failure/who:** Make the one-child mission the default activation profile and measure first useful close, operator touches, and repeat use in #6. It costs product defaults and a few outcome counters; it serves the largest plausible first adopter group. It is a mode, not another subsystem.

### 20. Upgrade compatibility and semantic contract corpus — **MERGES into #4 and #5**

- **Missing:** Versioned fixtures and compatibility tests for each adopted OMP/NTM event, CLI, schema, and refusal arm, run against the next upgrade before promotion.
- **Refuses:** Silent discriminant changes; treating a type-only addition as compatible; upgrading the upstream tool while the adopted capability card is stale; a green suite whose fixture bypasses the live seam.
- **Evidence:** `docs/PLAN.md:5786-5812` proves only one raw completion frame and says the other six planes lack wire proof; `docs/plan/06-gates.md:75` explicitly says the current meta-gate does not exist, while `docs/plan/09-milestones.md:119-127` warns that terminal inspection is not a protocol.
- **How/cost/failure/who:** Keep compatibility fixtures attached to the adoption registry and clean-room run. It costs a small upgrade matrix; it serves maintainers and fleet operators, but is not a separate product from #4's drift policy.

## The six survivors — full rationale

### 1. Scoped 1:many mission control plane with partial-failure semantics

This is the mission's irreducible product. “Run one-to-many NTM sessions” is not “run the one-to-one loop N times”: the parent must know what it expected, which child incarnation owns each target, what was delivered, what continued, what finished, and what barrier makes the parent complete. A one-child run is the same contract with `expected_children = 1`, so this does not force a fleet on Persona A.

**How it works.** Create a `ParentRunManifest` before fan-out. It binds the project/repo identity, active requirement revision, cardinality, target set, barrier (`all`, quorum, or named waiver), concurrency/cost budget, and run epoch. Each `ChildRun` binds session/pane/worker incarnation, stage, bead, attempt, packet hash, receipt state, lifecycle state, evidence, and sequence watermark. A reducer projects child events into the parent verdict. Receipts, stable retry IDs, lease fencing, idle settlement, roster epochs, and backpressure are fields/reducer inputs—not five new products.

**What it refuses.** Unscoped ledger mutation; stale-incarnation writes; `COMPLETE` with an unknown or continuing required child; duplicate logical commands; a target that was never in the expected set; indefinite retries without a budget or escalation. `PARTIAL` is only valid when the manifest names the policy that permits it.

**Evidence and upstream reuse.** The eight-session/shared-ledger observation is the real fleet signal. `docs/plan/12-journey.md:25-38` has stage artifacts but no cardinality contract. `cp-z42vu` returned `success:[4]` with no packet (`docs/plan/09-milestones.md:109-127`), and `docs/plan/00-brief.md:501-504` says receipt, claim, idle, and roster types remain DECLARED ONLY. `AgentEndEvent` is the one event plane already wire-proven (`docs/PLAN.md:5786-5799`); use it rather than inventing a completion protocol.

**Cost and failure.** The cost is a manifest/reducer, durable indexes, and migration of unscoped history. It adds ceremony at dispatch time, but the alternative is invisible corruption: a delayed child can close a replacement's bead, a false transport success can create a phantom child, and fan-in can report a green parent while child three never ran. Month-three acceptance is a ten-child adversarial run with a delayed child, duplicate retry, continuation, dead pane, and false transport success; the parent names the exact offending child.

**Who it serves.** Fleet operators get truthful fan-in and recovery. Solo maintainers get the one-child path without adopting fleet topology. Humans get a stable answer to “what happened to my project?” instead of a pane-shaped guess.

### 2. Durable human-requirement and decision ledger with replay

S9 is currently an aspiration, not a mechanism. The eleven decisions lost in this session are not a documentation inconvenience: they are authority inputs to every subsequent packet, refusal, grade, and ship decision. If the human contract cannot be reconstructed, a technically correct execution can still be the wrong project.

**How it works.** Store an append-only record such as `Requirement { id, verbatim_source, scope, owner, status, acceptance, evidence, revision, supersedes, conflicts_with, approved_by, allowed_actions, expires_at }`. Emit a new revision instead of editing history. Put the active requirement revision and scope hash into the parent manifest, child packets, beads, grade evidence, validation bundle, and ship receipt. Replay after compaction or handoff computes the active set and exposes unresolved conflicts.

**What it refuses.** No dispatch or ship when the applicable requirement is missing, ownerless, conflicted, expired, or outside scope. No inferred approval, paraphrase-only requirement, silent overwrite, or reuse of an approval whose artifact hash changed. A changed restriction while children run stops new dispatch until an owner resolves the conflict; old packets remain attributable to the old revision.

**Evidence and upstream reuse.** `docs/plan/12-journey.md:35-38` reports eleven decisions living only in scrollback, and `docs/PLAN.md:52-61` records seven real conditions lost there. `docs/PLAN.md:67-74` explains why verbatim requirements matter. `Stage1Claim`/`GlobalClaim` with `ownershipToken` and `inputWatermark` (`docs/plan/00-brief.md:501-503`) provide useful upstream vocabulary, but are DECLARED ONLY and should not be mistaken for a complete local requirement ledger.

**Cost and failure.** The cost is a small durable stream, conflict-resolution UX, and IDs in existing artifacts. The hard failure is deliberately visible: an owner must resolve a conflict before the run proceeds. Without that refusal, compaction silently revives superseded requirements and eight children can execute mutually incompatible instructions.

**Who it serves.** Every persona benefits. Josh retains intent; an operator can hand off a run; a grader can prove which requirement revision it judged; an adopter can disagree with a default without editing hidden files.

### 3. Transactional foreign-repository activation capsule

The plan currently starts after the hardest product moment: the user has a repository, conventions, tools, and enough knowledge to run us. A new project has none of those. S1 must be a safe admission transaction, not a generator that writes files and hopes the next stage understands them.

**How it works.** Run `profile` read-only: resolve the repo/worktree boundary at runtime, identify language/build/test/tracker/gate capabilities, inspect dirty state, discover host dependencies, and compute an owned write set. Emit an `adoption-manifest` with before hashes and inverse operations. After explicit approval, apply only the tool namespace atomically, install selected adapters/gates, run identity and addressability checks, and emit either an adoption receipt or `PROFILED_NOT_ADOPTED`. Undo must restore the recorded state.

**What it refuses.** Ambiguous root or target commit; a foreign path that resolves to the build machine; partial writes; automatic tracker migration; an absent optional dependency misreported as a fatal repo failure; a no-op that exits green; any guessed `/Users/josh` fallback. It refuses to write the adopter's `CLAUDE.md`/`AGENTS.md` blindly: it proposes a minimal owned patch with a human decision record and leaves existing authority intact unless approved.

**Evidence and upstream reuse.** `docs/plan/07-installability.md:15-45` measures 3/18 declared binaries in the installer and one ghost artifact; `docs/plan/07-installability.md:347-360` identifies compile-time root and `/Users/josh` assumptions. `docs/plan/08-end-users.md:6-21` says there is no adopter entry point. `docs/plan/09-milestones.md:172-180` records M6 as never attempted. The existing installer identity types and repair chokepoint are the seam; no 26-crate rewrite is required.

**Cost and failure.** The cost is foreign-repo fixtures, staging/undo, and a narrow profile schema. It will refuse more often than a generator, which is correct: a half-adopted repo creates long-lived trust damage. Month-three failure is a dirty monorepo or non-Rust repo where the capsule leaves no hidden writes and reports the exact unsupported capability.

**Who it serves.** It is the first-use path for every outside user, while still giving the solo maintainer a useful gate-only profile before any fleet setup.

### 4. Consume-before-rebuild capability and wire-adoption registry

The plan has already paid for one important discovery: the upstream tool contains types for every formerly “unsolved” gap, but only completion has crossed the observed wire. The next failure would be to replace one form of absence with another—treating a declaration as proof, or building local lookalikes before testing the existing plane.

**How it works.** Give each adopted upstream capability a card with source revision, exact construct, probe command/fixture, schema/discriminants, semantic mapping into local state, owner, fallback, and current strength. The card advances only through `DECLARED`, `WIRE-PROVEN`, `CONSUMED`, and `E2E-PROVEN`. Promotion requires the process to observe the signal and a local durable effect, not merely import a type. Compatibility fixtures are attached to the card and run by #5.

**What it refuses.** No custom completion protocol when `AgentEndEvent`/`RpcSessionEventFrame` is the sanctioned plane. No receipts, claims, idle, roster, cost, or compaction capability promoted from `.d.ts` declarations. No unknown upstream version, feature-gated discriminant, or silently accepted schema drift. No “available” badge whose process cannot be named.

**Evidence and upstream reuse.** `docs/PLAN.md:5786-5812` contains the raw `agent_end` frame and explicitly says it proves the wire, not supervisor consumption. `docs/plan/00-brief.md:493-511` labels completion WIRE-PROVEN and the other six families DECLARED ONLY. `docs/PLAN.md:5561-5589` records an existing NTM template that the session did not use. These are directly reusable planes, not invitations to invent seven crates.

**Cost and failure.** The cost is registry metadata plus reachability probes. The failure mode is intentionally scoped: an OMP/NTM upgrade blocks only the affected capability and points to its stale card; it does not silently degrade every session or wait forever on a dead event.

**Who it serves.** Maintainers get upgrade discipline; fleet operators get typed fallbacks; solo users avoid carrying a local compatibility stack that the upstream tool already owns.

### 5. Independent clean-room acceptance and anti-vacuity run

This is not another grading stage. It is the external oracle for the claim that the product works. The current plan grades itself in its own checkout, and S1 plus foreign-host validation have never been run.

**How it works.** A fresh evaluator receives the published contract, an install artifact, and a redacted evidence bundle—not the author’s working tree or worker self-report. The matrix covers: empty/new repo; existing non-Rust repo; dirty worktree; missing optional tools; pre-existing tracker; one child; many children; delayed/duplicate/continuing/dead children; human requirement change mid-run; known-good/known-bad/mutation; and an omission inventory from an external requirements/schema source. Each result names the missing or refused capability.

**What it refuses.** Same-session proof, same-checkout proof, empty scan sets, “0 passed / 0 failed” refusals treated as green, fixture-only mutation, and completeness claims with no external inventory. It also refuses to promote a DECLARED ONLY upstream plane merely because the scenario did not exercise it.

**Evidence and upstream reuse.** `docs/plan/09-milestones.md:150-180` says the ten-close claim has never been observed and M6 has never been attempted. `docs/PLAN.md:5537-5555` reports only 3 used `Y` cells out of 45. `docs/plan/06-gates.md:75` says the current gate table is proxy-scoped, and `docs/plan/09-milestones.md:243-246` documents false-zero measurements. Existing verification and release owners can own the fixture matrix; this needs a new oracle, not a new crate family.

**Cost and failure.** Cold-host and foreign-repo runs cost time and infrastructure. They will expose embarrassing omissions early, which is the point. Month-three success is one reproducible 1:1 and one 1:many run by an evaluator who did not author the plan; month-three failure is a precise refusal, not a green local narrative.

**Who it serves.** Release decision-makers, adopters, and anyone who must distinguish “the project can do this” from “the project describes this well.”

### 6. Economics and refusal-storm operating SLO

A loop can be correct and still be a bad product if it consumes more attention, compute, and panes than the manual process. Month three is when the novelty wears off and someone asks whether to leave it running.

**How it works.** Add a per-run value/refusal receipt: useful-close count and latency, operator-touch minutes, blocked-tick minutes, retry count, active-pane minutes, and cost only after the upstream cost surfaces are wire-proven. Configure thresholds per persona and refusal class. On recurrence, escalate to repair, stand-down, or manual fallback; on budget exhaustion, terminate with `BUDGET_EXHAUSTED` rather than report health.

**What it refuses.** Heartbeat-only progress, indefinite repetition of one refusal, a value claim without baseline/target, and budget exhaustion presented as success. It refuses to infer cost from a type declaration: `SearchUsage`, `PerplexityCost`, and `ContextUsage` are still DECLARED ONLY in `docs/plan/00-brief.md:505-506`.

**Evidence and upstream reuse.** `docs/plan/09-milestones.md:157-169` measured 162 consecutive `DISPATCH_RETRY_BLOCKED` ticks over 4.2 hours. `docs/plan/00-brief.md:802-823` leaves outcome, baseline, verification cost, and headcount open. The upstream cost types define the future adoption target; they are not current telemetry.

**Cost and failure.** The cost is small counters, budgets, and one escalation state machine. It can false-alarm if thresholds are too low, so thresholds need a known-good quiet run and explicit human override; it must never silently disable work. The month-three test is a repeated fence failure that escalates instead of consuming four hours of turns.

**Who it serves.** Solo maintainers get an answer to “did this save me time?” Fleet operators get capacity economics; product owners get a kill signal if automation costs more than manual work.

## Deliberate kills and merges

The lower-ranked ideas are not discarded as failure modes. They are assigned to the survivor that can actually enforce them:

- Lifecycle reducer, receipts, idempotency, leases, roster, backpressure, and child replay belong inside **#1**, because a standalone version cannot determine the parent barrier or target scope.
- Approval/expiry/conflict semantics and portable requirement-linked evidence belong inside **#2**.
- Cold-host negotiation, tracker migration, and adopter gate profiles belong inside **#3**, with upstream semantic compatibility owned by **#4**.
- Typed requirement→bead→packet→grade handoff IDs belong inside **#1, #2, and #5**; a standalone compiler would reproduce the composition sprawl already measured in `docs/PLAN.md:5727-5775`.
- Upgrade compatibility fixtures belong in **#4/#5**.
- Solo mode is the default activation profile, not a separate fleet subsystem.

**Bottom line:** the missing product is a refusal-bearing control plane with six boundaries: scope the mission, preserve the human, admit the foreign repo transactionally, adopt existing planes only after reachability proof, test outside the author’s checkout, and stop when the economics turn negative. The nine stages tell an agent what stage exists; these six contracts determine whether the journey remains true when there are many sessions, a new machine, a changed requirement, a compaction, a dead pane, or a month of upgrades.

# GRADE — 00-brief.md — Pane 4 (%1408) — NEGATIVE SPACE AUDITOR
Round 1 of 11. Written to disk per addendum: findings persist here, not only in pane context.
Scope: absence only. Section files read for discharge verification; quality of what exists = other lenses.

## VERDICT: FAIL (as an investor-facing artifact; fixable by addition, not rewrite)

## BLOCKERS: 2

B1. No economic dimension exists anywhere in the brief, and the brief is the only place
    requirements become checkable.
    Evidence: grep -icE "cost|budget|\$|price" 00-brief.md -> 0; same-zero for
    week|month|deadline|schedule|timeline; headcount|staff|hire; competitor|alternativ|buy;
    security|secret|token|credential; licens; novel|moat|defensib; upgrade|churn|version drift;
    abandon|kill criteria|sunset. All nine -> 0 hits in 598 lines.
    An investor per R3 (lines 34-36, "multi-decades of buying and selling and growing
    companies") asks: what does it cost, how long, with whom, versus what, what if OMP
    changes under us, when do we kill it. Because section 2's table (lines 74-86) is the
    sole discharge mechanism, NO section of the eleven can ever be answerable to these
    questions — they were never made requirements.
    FIX: add the missing eighth section — "Open questions, risks, and kill criteria" —
    and register each economic unknown there as a requirement row or a named open question.

B2. The brief's prose has no expected-twin mechanism for omissions, so its own defect class
    is invisible to itself.
    Evidence: all eight recorded defects (section 7 table, lines 493-499) are errors of
    commission caught by re-derivation. The only OMISSION ever caught (136 slash commands,
    lines 168-175) was caught because the SCANNER emitted its own expected_* twin; prose
    has no twin. Live proof: the grading dispatch stated this file is 547 lines;
    wc -l 00-brief.md -> 598. A stale figure about this document circulated in the
    grading instruction itself and nothing in the method could catch it.
    FIX: each subsection ends with an explicit expected-contents list a checker can diff,
    or a doctrine rule that every noticed not-covered-here question must land in new §8.

## MAJORS: 4

M1. No glossary. R1-R11 quoted verbatim (lines 21-63) use bead dag / reap / pane / tick /
    conductor / mirror with zero definitions anywhere in the file. R3's investor fails at §1.
    FIX: one-page glossary as §1.5.

M2. §2's R5 row contradicts the brief's own §3.2. Line 80 claims "§02 enumerates all 183
    census rows by kind with names"; lines 168-175 record slash_commands=0 vs expected 136,
    status UNKNOWN exit 2; 02-surface-census.md:34 confirms a single UNKNOWN_PROBE placeholder.
    FIX: reword the closure cell to "183 rows … with the 136-command hole carried as a
    named placeholder until enumerated".

M3. §2's R2 row is a wish by the table's own standard. Line 72: "A requirement that cannot
    be checked is a wish" — yet R2's closure (line 77) is past-tense reap statistics
    ("board reaped (28/25/19/2)"), not a forward observable for filesystem/doc structure.
    FIX: closure = a named standing check (e.g., the §7.3 staleness predicate built as a gate).

M4. Two mentioned-once-then-dropped items with no owner row in the §5 map:
    (a) composer-typed differential-oracle policy decision — lines 308-319: "The fix is a
        policy decision the plan must make rather than dodge", three options offered, zero
        sections own it; the permanently-skipping test sits inside the headline 370 #[test]
        figure (line 242).
    (b) pi_agent_rust/src/doctor.rs:924/:1052 defect — lines 148-150: a shipped ecosystem
        binary records a working tmux as MISSING; cited once, owned nowhere.
    FIX: one owner line each in §5, or explicit rows in new §8.

## MINORS: 3

m1. Grading instruction says 547 lines; wc -l -> 598. §7.3's drift defect already bit the
    plan's own grading round — the dispatch was a stale derived artifact.
m2. Live consume-layer fence (line 407: 162 refused ticks, DISPATCH_RETRY_BLOCKED) appears
    only as reality description; no checkability row requires the fence cleared before
    milestone dispatch begins.
m3. §3.1 lists cargo's path as /Users/josh/.rch/shims/cargo (line 108) without noting it is
    a SHIM — the "binaries we wrap" table presents a wrapped binary as a binary, the plan's
    own subject, unstated.

## THE ONE THING
The brief makes eleven requirements checkable and nothing else — every cost, time, headcount,
competitive, and kill-criteria question sits structurally outside the requirement set, so the
plan could be executed flawlessly and still have no answer to the first three questions an
investor asks.

## VERIFICATION NOTE (per grading rules)
Initially hypothesized the four-layer broken layers had no owning section — REFUTED before
publishing: grep -n "actuate\|complete" 09-milestones.md -> lines 110/124 pick them up as
M4/M5 starting points ("no human", "the loop closes"). Not filed as a finding.
Discharge rows verified against real files: 09-milestones.md exists (10 OBSERVABLE hits),
02-surface-census.md carries the slash hole (lines 34-67), 06-gates.md exists (10 headers),
10-prior-art.md has 6 searched/no-prior-art markers across 509 lines.

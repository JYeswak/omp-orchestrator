# Gate-wiring wave 1 evidence

Bead: `omp-orchestrator-gate-wiring-wave1-wbu`

## Acceptance

1. `cargo metadata --no-deps --offline`: PASS. The current-tree run parsed 26 packages and 26 workspace members; `no-shell-gate` is present.
2. `cargo test -p no-shell-gate --offline --quiet`: PASS. The current-HEAD run exited 0; all package targets passed, including the 14-test gate target and the 8-test numbers target. One convergence test remains intentionally ignored. Existing compiler warnings are non-fatal.
3. `cargo test -p path-literal-guard --offline --quiet`: PASS. Unit target: 2 passed. Repository-wide target: 1 passed after removing author-machine literals from runtime defaults.
4. Staged `crates/omp-orchestrator/src/gate_wiring_probe.sh`: installed `.git/hooks/pre-commit` exited 1 and reported `no-shell-gate: 1 tracked shell/python file(s)` naming the staged file.
5. Staged Rust probe containing `/Users/josh`: installed hook exited 1 and reported `path-literal-guard: 1 hardcoded home-path literal(s)` naming line 1.
6. Staged Rust probe with paired `stdout(Stdio::piped())`, `stderr(Stdio::piped())`, and a `try_wait()` loop: installed hook exited 1 and reported `undrained-pipe-lint`, including the three source line locations.

The fixture refusals also reported 8 pre-existing `state-wildcard-lint` findings. That is an existing tree condition; the required gate-specific refusal was observed in each case. All temporary fixtures were unstaged and removed. Concurrent changes updated the live test-count figures during the session; the final current-HEAD run passed after `NUMBERS.toml` matched the current tree.

## Supervisor and boundary

`census_gates` includes `kernel-bypass-gate`, derives reachability from installed-hook/workflow probes, and routes unwired or failed-positive-control states to `SupervisorDecision::GateUnwired`. The source retains the explicit runtime NO-CLAIM: live-fleet subprocess wiring and receiver receipts are unverified. This work proves trigger wiring only; it does not prove any detector bug-free.

Installed hook: `.git/hooks/pre-commit`, Mach-O arm64, 1,909,440 bytes.

## Delivery

Commit: `1689a45 fix(paths): make gate runtime paths machine-neutral [test]`

The bead was already `CLOSED` in `br`; no duplicate close was issued. The commit is path-scoped to the seven files required to make the path-literal acceptance leg green. Unrelated staged/unstaged work remains outside the commit.

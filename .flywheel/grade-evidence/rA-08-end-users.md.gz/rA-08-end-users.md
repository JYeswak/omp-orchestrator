# Round 8 — 08-end-users.md — ABSENCE lens — OliveCat
Section read FULL (340 lines).

## THE SEARCH (commands and space)
1. Gap-world residue: grep -n for all seven gap names + "precedent-free|no receipt|
   cp-z42vu|unclaimed|roster|cost is unmeasured" across 08-end-users.md → zero hits.
   The receipt story in §2.4 cites OUR TransportReceipt and ack-stage's two-arm transport
   enum (OUR crate, measured) — claims about our code, not about upstream absence.
   Space justification: 08 is the end-user journey; any of the seven gaps would appear in
   §2 (first tick), §2.5 (first graded close), or §7 (abandonment). CLEARED.
2. Known-findings ledger: no retraction blocks recorded against 08 in any round file I
   hold; its own NO-CLAIM (section tail) names its search spaces for every zero
   (doctor/init/tick greps with the exact file named). Nothing to honor.
3. New-absence probes:
   (a) §2.4's PROJECTED transcript shows transport "OneshotSpawn" — a third name beyond the
       measured two-arm enum (NtmRobotSend | TmuxSendKeysLiteral). Judgment: the transcript
       is explicitly PROJECTED design artifact, and its MEASURED grounding cites the real
       enum; a future-tense transcript naming a future transport is not a false claim.
       NOT COUNTED (style/forward-design, not false/unmeasured-as-measured/contradictory).
   (b) The seven upstream types change none of 08's absence claims — 08 argues from OUR
       crates (no doctor/init/tick subcommands; its own harness grep with named search
       space). CLEARED.
   (c) "157 of 183 census rows CAPABILITY_NOT_USED" (§7): consistent with the brief's
       census classification split, unchanged by the surface-map batches (different
       artifact). CLEARED.
   (d) Considered: a §7 abandonment row for "the substrate ships what you need on planes
       you don't ride" — the receipt-plane variant of the §3.1 coupling objection. The
       coupling objection (§3.1, "the deepest coupling, stated as the objection an investor
       should raise") already carries the dependency-side of that territory. Adding the
       receipt-plane variant would deepen an existing objection, not fix a false claim.
       NOT COUNTED (style/depth, not a finding under the contract's definition).
4. Zero-claim audit: harness grep; every zero carries pattern + why the space could contain
   the answer.

## NEW FINDINGS: 0

VERDICT: PASS (absence lens, round 8 — first clean round for 08 under this contract)

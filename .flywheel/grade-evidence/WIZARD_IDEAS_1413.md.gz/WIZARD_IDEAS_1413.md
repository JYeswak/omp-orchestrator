# Dueling Idea Wizards — Phase 4

## Mission read

The missing product is not another monitor. It is a trusted control plane for one-to-one and one-to-many NTM sessions, from new-project inception through shipped work, while preserving the human decisions that make the work legitimate. The journey skeleton names nine stages and requires each stage to answer a 3 a.m. dispatch question with Trigger, Dispatch packet, Amazing, Adequate, Negative patterns, Skills, and Done signal (`docs/plan/12-journey.md:16-21`, `:23-38`, `:40-61`). It does not yet define the durable cross-stage state that makes those runbooks safe to compose.

Independent generation produced 60 candidates: 20 focused on multi-session orchestration, 20 on requirements and decision persistence, and 20 on inception/adoption/economics. The 20 below are the consolidated candidate pool, ordered after deduplication and initial hard triage. Every candidate has a refusal boundary.

## Twenty candidate answers, ordered best to worst

### 1. Federated project/run identity and namespace

**Adds:** Immutable identities for project, repository, worktree, NTM session, pane epoch, run, bead, and artifact, with attach/detach/reconnect transitions. **Refuses:** Treating a tmux pane ID, session name, or current checkout as the identity of work. **How:** Every dispatch, receipt, handoff, and decision references logical IDs plus an incarnation epoch; stale selectors fail closed. **Cost:** Medium schema/reconciliation work, low per-tick cost. **Failure:** A stale epoch is accepted and binds evidence to the wrong session. **Serves:** Josh operating eight sessions and future multi-project operators. **Evidence:** The mission explicitly requires 1:1 and 1:many NTM sessions; `docs/plan/12-journey.md:37-38` records decisions being lost across stages.

### 2. Cross-session append-only event spine with replay

**Adds:** One durable causality stream for dispatch, delivery, refusal, completion, reap, grade, human decision, and release events across every session. **Refuses:** Pane scrollback, mutable snapshots, or one session as the source of truth. **How:** Versioned events carry sequence, parent event, logical identity, and artifact digests; state is reconstructed by replay. **Cost:** Medium storage/schema maintenance. **Failure:** Duplicate or reordered events create phantom completion; enforce idempotency and sequence gaps. **Serves:** Anyone leaving the computer, recovering compaction, or switching sessions/machines. **Evidence:** `docs/plan/12-journey.md:37-38` says every stage loses human decisions; the session produced eleven decisions in pane scrollback.

### 3. Human requirements, authority, and precedence ledger

**Adds:** Durable requirements and decisions with source, authority, confidence, expiry, supersession, rejected alternatives, and precedence. **Refuses:** “The latest text wins,” unowned approvals, or silently changed intent. **How:** Every runbook, bead, dispatch, and ship claim links to an active requirement version and authorized decision receipt. **Cost:** Medium data model and operator workflow. **Failure:** Stale or equal-authority contradictions block useful work; permit read-only inspection and escalate. **Serves:** Josh returning after context loss and any future collaborator. **Evidence:** `docs/plan/12-journey.md:35-38` makes human requirements cross-cutting and says eleven already disappeared.

### 4. Inception capability and reproducibility envelope

**Adds:** A first-class S1 manifest for repository identity, language, branch, tool versions, OS/architecture, available NTM/OMP/BR/BV capabilities, secret sources, gates, and resource limits. **Refuses:** Treating an existing checkout on Josh’s M3 as a valid new-project setup. **How:** Inception probes the host and repo, emits supported/degraded/refused capabilities, and freezes the envelope for later validation. **Cost:** Medium probe and schema work. **Failure:** A stale envelope creates false compatibility; expire and re-probe on material changes. **Serves:** New projects and foreign machines. **Evidence:** `docs/plan/12-journey.md:27-28` assumes repo/docs/gates/infra artifacts; the mission specifically asks for new project, `CLAUDE.md`, `AGENTS.md`, gates, and infra.

### 5. Capability-scoped isolation leases

**Adds:** Short-lived leases binding a worker to project, worktree, path set, bead claim, session, and allowed side effects. **Refuses:** Assuming the right NTM session implies repository or project isolation. **How:** Dispatch issues a lease; every action checks it; session loss or expiry revokes it. **Cost:** High integration cost at the dispatch boundary, modest runtime checks. **Failure:** Over-broad leases permit cross-project edits; under-broad leases strand work. **Serves:** One-to-many operators sharing a machine or fleet across projects. **Evidence:** `docs/plan/12-journey.md:30-32` requires path-scoped, bead-mapped execution; eight sessions are live in the stated environment.

### 6. Global fair scheduler with backpressure and value budgets

**Adds:** Cross-session scheduling with per-project reservations, starvation bounds, in-flight limits, retry budgets, and human/compute cost floors. **Refuses:** Dispatching from whichever session reports an idle pane first or equating activity with value. **How:** Rank by DAG criticality, age, deadline, worker fit, verified-value estimate, contention, and marginal cost; reserve capacity before dispatch and release it on reap. **Cost:** Medium-high policy and measurement work. **Failure:** Reservations starve urgent work or estimates suppress foundational work; bound reservations and expose overrides. **Serves:** Josh running 1:many sessions without coordination overhead exceeding output. **Evidence:** The mission requires 1:many; the prompt reports eight live sessions and a shared ledger failure.

### 7. Independent external-value gate and viability kill-screen

**Adds:** A gate that tests whether the journey reduces supervision time, unresolved work, or risk on a fresh project, with explicit kill criteria. **Refuses:** Counting crates, commits, green tests, or internal self-grades as product value. **How:** Run the full path on a new repo and compare against a manual baseline; stop if the result does not clear a predeclared threshold. **Cost:** Medium pilot/evaluation effort. **Failure:** A synthetic project overstates value; require a representative new project and an external observer. **Serves:** Josh deciding whether to keep investing. **Evidence:** `docs/plan/12-journey.md:27-35` defines outputs but no fresh-project proof; the prior plan has never run end to end on a new project.

### 8. Verified checkpoint capsules and cross-session handoff

**Adds:** Signed, compact handoff artifacts containing active intent, identity epoch, repo revision, bead claim, evidence pointers, blockers, and next proof. **Refuses:** “Continue” prompts and prose summaries without state verification. **How:** Sender seals; receiver checks revision, claim, requirements, and artifact digests before accepting or quarantining. **Cost:** Medium. **Failure:** A sealed capsule is internally valid but stale; compare it with current repo/ledger state. **Serves:** Operators moving work between sessions or after pane failure. **Evidence:** `docs/plan/12-journey.md:47-53` requires concrete packets and done signals.

### 9. Upstream compatibility sentinel

**Adds:** Continuous compatibility probes for wrapped NTM/OMP/BR/BV versions, schemas, event types, and exit codes. **Refuses:** Treating today’s wire behavior as permanent. **How:** Pin observed contracts, probe installed versions, and block or degrade on drift. **Cost:** Medium. **Failure:** Upstream drift is blamed on workers; classify drift separately and preserve the raw probe. **Serves:** Dependency adopters and long-running unattended operation. **Evidence:** The plan has already found seven upstream types, with only completion wire-proven; `docs/plan/12-journey.md:33-34` requires another-machine validation and rollback.

### 10. Foreign-repository adapter contract

**Adds:** Versioned mappings for repo layout, branch policy, tracker, bead graph, gates, artifacts, and install path. **Refuses:** Imposing this repository’s paths or `br` assumptions on every adopter. **How:** Adapter declares supported capabilities and explicit unknowns before S1/S4 dispatch. **Cost:** High breadth, low first-adapter cost. **Failure:** Lossy mapping corrupts work; unknown mappings block rather than guess. **Serves:** Other repos, machines, and eventual non-NTM adopters. **Evidence:** `docs/plan/12-journey.md:27-35` promises foreign validation and ship artifacts but does not define an adapter boundary.

### 11. Failure-domain-aware session placement

**Adds:** Placement rules separating projects, providers, machines, sessions, and panes into failure domains with recovery capacity. **Refuses:** One bad session, host, provider, or shared ledger taking down every project. **How:** Assign sessions to domains and preserve independent observers/receipts. **Cost:** Medium operational complexity. **Failure:** Excess isolation wastes capacity; configurable domain size and explicit tradeoff receipt. **Serves:** One-to-many fleets and unattended operation. **Evidence:** The prompt reports eight live sessions and a shared-ledger assumption that only recently changed.

### 12. Exactly-once dispatch intent with delivery reconciliation

**Adds:** An idempotent intent ID binding bead, pane epoch, packet digest, attempt, transport receipt, and receiver observation. **Refuses:** Retrying an uncertain send as if it never happened. **How:** Persist intent before transport; reconcile sender and receiver evidence before retrying. **Cost:** Medium. **Failure:** Lost receipt causes a stuck intent; typed `UNKNOWN` and bounded operator escalation. **Serves:** Operators protecting against duplicate work and false delivery. **Evidence:** `docs/plan/12-journey.md:16-21` requires dispatchability and observable success, while the prior system relied on pane state.

### 13. Decision expiration and revalidation

**Adds:** Expiry and re-check predicates for human approvals, adequacy tradeoffs, dependencies, and risk assumptions. **Refuses:** Reusing a months-old approval after requirements or upstream behavior changed. **How:** Attach validity conditions and block mutation/dispatch when expired. **Cost:** Medium friction. **Failure:** Expiry noise trains rubber-stamping; severity-tier validity windows. **Serves:** Long-running projects and returning operators. **Evidence:** `docs/plan/12-journey.md:49-50` requires Amazing and Adequate, implying a tradeoff that can age.

### 14. Human-requirements retrieval index

**Adds:** Searchable retrieval over requirements, decisions, dissent, rejected options, and evidence with exact provenance. **Refuses:** Making a human repeat a decision because it was stored but not findable. **How:** Index stable IDs and active versions; answer with citations and explicit UNKNOWN. **Cost:** Medium. **Failure:** Similar decisions are conflated; require project/run scope and authority filters. **Serves:** Josh after compaction, future maintainers, and reviewers. **Evidence:** S9 at `docs/plan/12-journey.md:35-38` requires durable and retrievable requirements.

### 15. Data portability and abandonment export

**Adds:** Versioned export/import of requirements, identity, work graph, receipts, run history, and decisions. **Refuses:** Lock-in to one machine, NTM session, or hidden local store. **How:** Export a self-contained project packet and run restore drills. **Cost:** High edge-case coverage. **Failure:** Hidden state is omitted; schema completeness check and restore comparison. **Serves:** Future adopters and Josh abandoning or migrating the system. **Evidence:** `docs/plan/12-journey.md:33-35` promises foreign validation, rollback, and stored requirements.

### 16. Foreign-content trust quarantine

**Adds:** A boundary classifying code, docs, hooks, prompts, and config from a new repo before agents can treat them as policy. **Refuses:** Executing repository instructions as operator authority. **How:** Quarantine imported content, allowlist trusted sources, and require explicit release of capabilities. **Cost:** Medium. **Failure:** Over-quarantine blocks useful setup; permit read-only inspection and scoped approval. **Serves:** New-project owners and security-conscious operators. **Evidence:** S1 in `docs/plan/12-journey.md:27` begins at a repo and its control files, but no trust boundary is defined.

### 17. Fleet-level SLOs, simulation, and counterfactual replay

**Adds:** SLOs for dispatch latency, verified completion, refusal recovery, unattended survival, and operator intervention, plus replay against alternate policies. **Refuses:** Calling a quiet or busy fleet healthy. **How:** Replay event history under scheduler/policy variants and compare outcomes. **Cost:** High instrumentation and model effort. **Failure:** Simulation rewards the wrong proxy; tie every SLO to an observed user outcome. **Serves:** Operators deciding whether 1:many improves or harms throughput. **Evidence:** `docs/plan/12-journey.md:49-53` requires stage-specific bars and done signals, but no cross-stage SLO.

### 18. Capability- and evidence-aware worker matching

**Adds:** Assignment based on worker capability, project risk, required tools, and evidence burden. **Refuses:** Sending every bead to the first idle pane. **How:** Match bead metadata and host envelope to worker profiles; refuse unsupported assignments. **Cost:** Medium. **Failure:** Profiles become stale or encode bias; measure assignment outcomes and allow bounded fallback. **Serves:** One-to-many sessions with heterogeneous agents. **Evidence:** The mission explicitly expands from 1:1 to 1:many; `docs/plan/12-journey.md:52` requires each stage to name its skills and limits.

### 19. Dependency license, security, and ownership intake

**Adds:** A pre-inception record for dependency license, vulnerability, maintainer, upgrade, and exit posture. **Refuses:** Adopting a convenient upstream type without knowing who owns the risk. **How:** Produce a decision receipt and renewal/exit trigger per dependency. **Cost:** Medium. **Failure:** Transitive risk is missed; require recursive inventory and explicit UNKNOWN. **Serves:** Maintainers shipping to other machines. **Evidence:** The seven upstream types change build-vs-adopt decisions; `docs/plan/12-journey.md:27-34` makes installation and rollback part of the product.

### 20. Project sunset and archival economics

**Adds:** A final state for abandoned projects, expired requirements, released artifacts, and retained evidence. **Refuses:** Leaving sessions, reservations, leases, and decisions indefinitely live. **How:** Archive a portable packet, revoke capabilities, release capacity, and record why the project stopped. **Cost:** Low-medium. **Failure:** Archival deletes evidence needed for audit; retention classes and restore check. **Serves:** Josh managing many projects over months. **Evidence:** The mission runs from inception to ship and stores human requirements; `docs/plan/12-journey.md:35-38` makes retention cross-cutting but specifies no sunset.

## Hard winnow

The top six are not the six with the most features. They are the smallest set that closes the month-three failure modes with the least duplication:

1. identity and event spine;
2. human requirements and authority;
3. inception capability envelope;
4. isolation leases;
5. one-to-many scheduler and economic backpressure;
6. independent external-value gate.

The other candidates are either implementation details of those six (handoffs, retrieval, exactly-once delivery, SLOs), later-stage extensions (portability, sunset), or dangerous competing control planes (assign/rebalance/session management) that should not be added before the control spine exists.

## Best six, with full rationale

### 1. Federated identity and event spine

**The idea.** Give every project, repo, worktree, NTM session, pane incarnation, run, bead, dispatch intent, receipt, grade, and human decision a stable identity, then record transitions in one append-only journal replayable across sessions.

**Why this wins.** The mission is explicitly 1:1 and 1:many. A pane-local model cannot answer whether `%1413` in session A is the same worker as `%1413` in session B, whether a receipt belongs to the current run, or whether a recovered handoff is newer than a prior dispatch. `docs/plan/12-journey.md:37-38` says every stage loses human decisions; the event spine makes loss and recovery a state problem instead of a memory problem. It also subsumes several weaker ideas: handoff capsules, exactly-once intent IDs, replay, and fleet SLO inputs.

**How it works.** Create a project-scoped identity manifest and monotonically increasing event sequence. Every event carries logical IDs, incarnation epoch, source, parent event, intent/artifact digest, and schema version. Reconnect creates a new pane/session epoch rather than mutating identity. A reader reconstructs state from events and rejects sequence gaps, duplicate terminal events, and evidence from an old epoch.

**What it refuses.** Pane IDs as identity; current-session snapshots as truth; duplicate dispatch after ambiguous transport; completion from a stale worker; recovery from scrollback; silent event loss.

**Cost.** Medium additive work: event schema, append/replay store, adapters at existing dispatch/receipt/reap seams. It does not require rewriting the 26 crates; the first version can wrap their existing receipts and state transitions.

**Failure mode.** The journal becomes a new shared single point of failure, or duplicate/reordered events create phantom state. Start with local append-only per-project logs, fsync/sequence checks, and explicit `JOURNAL_UNAVAILABLE` refusal; add cross-session aggregation only after local replay is correct.

**Who it serves.** Josh leaving the computer, operators switching among eight sessions, recovery after compaction/reboot, and any future user running more than one project.

**Success signal.** Kill or detach one session, reconnect through a different session, replay the journal, and obtain the same current state and next action without reading pane scrollback. A known duplicate dispatch and a stale epoch must be rejected.

**Grounding.** `docs/plan/12-journey.md:16-21` makes dispatchability an observable question; `:37-38` records eleven human decisions lost in scrollback; the mission requires 1:many orchestration.

### 2. Human requirements and authority ledger

**The idea.** Store every human requirement, decision, approval, dissent, rejected alternative, and change as an authoritative, versioned object linked to every downstream plan, bead, action, grade, validation, and release claim.

**Why this wins.** S9 is currently a label, not a mechanism. The journey says every stage generates and loses human decisions (`docs/plan/12-journey.md:35-38`), so a technically correct event journal is insufficient if it cannot answer which human intent governs a conflict. The ledger gives the system a durable “why,” not merely a durable “what.” It is the difference between safely resuming and merely replaying stale work.

**How it works.** Each requirement has a stable ID, active version, source, authority, confidence, scope, expiry, supersedes/replaced-by relation, and acceptance condition. A decision receipt records actor, authority, exact input snapshot, alternatives, evidence, selected option, dissent, and expiration. A deterministic precedence resolver handles current authorized decision, ratified requirement, approved plan, checkpoint, and worker interpretation; equal-authority contradictions block mutation.

**What it refuses.** Latest-text-wins; unowned approvals; implicit scope expansion; “the agent inferred it”; lost negative requirements; resuming after compaction without resolving contradictory intent.

**Cost.** Medium: schema and write-path integration, plus modest operator friction. Start with requirements and decisions that affect dispatch, scope, safety, or release; do not attempt semantic indexing of every chat message on day one.

**Failure mode.** The ledger becomes ceremony, or stale requirements block legitimate progress. Every item needs an authority/scope/expiry and a typed `SUPERSEDED` path; read-only inspection remains available when writes are blocked.

**Who it serves.** Josh as the product owner, future maintainers, reviewers, and agents that must resume without guessing.

**Success signal.** After a compaction or restart, ask “what must never happen, what is approved, and why is this bead next?” The system returns the active requirement version, authority, evidence, and unresolved conflicts without pane history.

**Grounding.** `docs/plan/12-journey.md:35-38` identifies S9 as cross-cutting and reports eleven lost decisions; `:47-53` requires concrete dispatch packets and done signals; the prompt says human requirements currently live in scrollback.

### 3. Inception capability and reproducibility envelope

**The idea.** Make S1 a real intake transaction that fingerprints the new project and negotiates the machine/toolchain before any plan or bead exists.

**Why this wins.** The current plan was developed inside an already-populated repository with known crates, known paths, known gates, and a known M3 host. The mission starts earlier: new project, control files, gates, and infrastructure. `docs/plan/12-journey.md:27-28` lists the desired S1 artifact but does not define how to prove it on a blank or foreign machine. Month three would expose that every “works here” assumption was actually an environmental dependency.

**How it works.** S1 emits an intake manifest containing repository origin/identity, intended artifact, language/build system, branch/worktree, required control files, available binaries and versions, OS/architecture, resource limits, secret-source references, gate capabilities, and degradation modes. Each capability is `AVAILABLE`, `DEGRADED`, `MISSING`, or `UNKNOWN` with a probe and expiry. The envelope is carried into plan, bead, validation, and ship receipts.

**What it refuses.** Running a plan against an unrecognized checkout; treating a clone as the same project; silently falling back to Josh-specific paths; claiming foreign-host validation from a local build; executing a project’s instructions before trust classification.

**Cost.** Medium, mostly at inception; many fields are existing probes and can be wrapped before new orchestration logic exists. The initial supported profile can remain the current NTM/OMP/BR/BV stack.

**Failure mode.** A stale or over-permissive envelope lets incompatible work proceed. Re-probe on host/tool/version changes, use explicit `UNKNOWN`, and require a fresh envelope for M6/M7-style validation.

**Who it serves.** New-project owners, Josh starting a new experiment, and adopters on non-M3 machines.

**Success signal.** Point the system at an empty project directory and a second host; it either creates the required control artifacts with a complete capability report or refuses before dispatch with a repair packet. No existing repo state may be required to make the first decision.

**Grounding.** The mission explicitly names new-project inception, `CLAUDE.md`, `AGENTS.md`, gates, and infrastructure; `docs/plan/12-journey.md:27-28` defines S1 output; S7/S8 at `:33-34` require another-machine operation and rollback.

### 4. Capability-scoped isolation leases

**The idea.** Bind every action to a short-lived, revocable capability lease covering project identity, worktree, paths, bead, session, pane epoch, and allowed side effects.

**Why this wins.** One-to-many turns a coordination bug into a cross-project corruption event. The journey’s S5 artifact promises path-scoped, bead-mapped execution (`docs/plan/12-journey.md:30-32`), but a packet’s target path is not enough when several sessions share a host and agents can issue tools outside the packet. Identity says who the actor is; the lease says what that actor is allowed to do now.

**How it works.** Before dispatch, issue a lease containing intent hash, project/run ID, worktree, path globs, bead claim, allowed command/action classes, expiration, and revocation epoch. Hook or wrapper boundaries check the lease; receipt, grade, and close require the same lease lineage. Session detach, identity epoch change, or authority withdrawal revokes it.

**What it refuses.** Cross-project paths; wrong worktree; unclaimed beads; stale approvals; user-pane inclusion; tool actions outside the packet; post-expiry retries.

**Cost.** High relative to the other ideas because it touches dispatch and tool boundaries, but it can start at the highest-risk path: packet delivery and file reservation. It is accretive if the lease wraps existing claims and fences instead of replacing them.

**Failure mode.** Leases are too broad and become decorative, or too narrow and strand work. Fail closed on missing/ambiguous lease, expose the exact denied capability, and support explicit renewal only when intent and artifact digest are unchanged.

**Who it serves.** Josh running multiple sessions, teams sharing a fleet, and future multi-repo adopters.

**Success signal.** A planted packet targeting another project, a stale pane epoch, and a path outside the lease are all refused; a legitimate packet is accepted and its receipt names the lease.

**Grounding.** The mission requires 1:many; `docs/plan/12-journey.md:30-32` makes path-scoped execution part of the shipped artifact; the current environment has eight live sessions.

### 5. One-to-many scheduler with fairness, backpressure, and value budgets

**The idea.** Replace per-session idle filling with a fleet scheduler that allocates scarce panes across sessions using reservations, starvation bounds, retry budgets, and measured marginal value.

**Why this wins.** A local scheduler can be correct and the fleet can still be irrational. One shared ledger already failed under eight sessions. Without global admission, one session can consume capacity, retry indefinitely, or starve another while every local watcher reports healthy. The scheduler is the mission’s 1:many product surface, not an optimization after the 1:1 path works.

**How it works.** Maintain per-project/session demand, active leases, queue age, critical-path rank, deadline, estimated duration, validation capacity, retry count, and human/compute cost. Reserve capacity before dispatch, enforce global in-flight and retry limits, and release on verified completion, reap, or refusal. Use aging and fairness so one session cannot monopolize capacity; use a value floor only after outcome data exists.

**What it refuses.** First-idle wins; unlimited fan-out; retry storms; session starvation; dispatching work whose validation capacity is already saturated; counting pane activity as throughput.

**Cost.** Medium-high policy/accounting complexity and ongoing calibration. Start with hard bounds and fairness, then add value estimates; do not begin with an opaque optimizer.

**Failure mode.** Reservations create idle capacity, fairness delays urgent work, or value estimates starve foundational tasks. Expose queue state, allow time-bounded emergency overrides with receipts, and keep critical-path priority above weak value estimates.

**Who it serves.** Josh coordinating eight sessions, teams with shared agents, and anyone deciding whether 1:many actually beats sequential work.

**Success signal.** A fixed workload run in 1:1, 1:many, and sequential modes reports verified completion, intervention time, duplicate work, wait time, and cost; the scheduler refuses a workload when marginal value is below its declared floor.

**Grounding.** The prompt reports eight live sessions and a shared-ledger assumption; `docs/plan/12-journey.md:3-7` makes 1:many orchestration the mission; `:49-53` requires measurable bars and done signals.

### 6. Independent external-value gate and viability kill-screen

**The idea.** Add a pre-build and post-build decision gate that tests whether the full journey lets Josh actually walk away with less supervision and bounded risk on a fresh project.

**Why this wins.** The current plan can grade its own documents, gates, and artifacts while never running S1 on a new project. That is a process achievement, not product validation. The internal buyer is Josh’s own systems; the paid outcome is reclaimed attention and trusted unattended execution. Without a measured baseline, the fleet can spend months perfecting control-plane mechanics that do not reduce human presence.

**How it works.** Before expanding scope, record a representative manual baseline: human interventions, unresolved decisions, lost context, duplicate work, failed dispatches, and time to verified shipment. Run the nine-stage journey on a fresh project and compare. Require an independent observer or blinded replay for the result. Kill or narrow the project if it does not improve a predeclared metric without increasing risk.

**What it refuses.** Crate count, coverage percentage, commit count, green internal tests, self-authored grades, or an unattended loop that does no valuable work as evidence of success.

**Cost.** Medium evaluation effort and some friction before engineering investment. It is cheap compared with three months of unvalidated build work.

**Failure mode.** A toy repo makes the journey look successful, or instrumentation changes operator behavior. Use a fresh project with real human requirements, preserve the manual control, and require a result that a non-author can reproduce.

**Who it serves.** Josh deciding whether to keep investing, future maintainers deciding whether to operate the system, and any adopter evaluating trust.

**Success signal.** On a fresh project, the system preserves requirements, executes and grades work, ships a result, and records a lower human-intervention burden with no unaccounted refusals or cross-project effects. If it cannot, the plan emits a kill/narrow decision rather than another engineering milestone.

**Grounding.** `docs/plan/12-journey.md:23-35` lists the lifecycle artifacts but no fresh-project run; `:56-61` warns that stages get routed around and invented negative patterns are guesses; the mission says Josh wants to walk away while trusting the process.

## Why the other fourteen did not make the six

- Verified handoffs, retrieval, exactly-once intents, decision expiry, and SLOs are important mechanisms under the identity/event/requirements spine.
- Upstream compatibility and dependency ownership are mandatory guardrails around the inception envelope, especially after the seven upstream type discoveries.
- Foreign adapters, portability, sunset, and failure-domain placement become valuable after one project can complete the journey safely.
- Worker matching, rebalancing, and session-management commands are tempting but risk creating competing control planes before identity, authority, and admission are authoritative.

The six are ordered by leverage and month-three survivability, not by implementation novelty.

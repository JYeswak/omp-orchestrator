# Round 10 — 01-idea.md — ABSENCE lens, role hillclimb — OliveCat
## DISPATCH
Subagent: `IdeaReader` (task agent, fresh context — file path + claim contract only). Deliberate
pick: 01-idea is the vision/argument section; jsm catalog has no idea-section specialist, so a
general task agent was instructed to cross-check against 00-brief's binary table and §4 table.

## VERIFIED FINDINGS (spot-re-derived before recording)
B1 [BLOCKER] 01-idea.md:298-299 — "**379 `#[test]` functions across 26 integration test files**"
with a deriving command that returns 26 — but the sentence's own structure implies the two
numbers come from the same walk, and my re-run today gives 30 files / 402 tests. The 370-vs-379
cross-section propagation named by the orchestrator, confirmed live. Verified.
B2 [BLOCKER] 01-idea.md:46-56 — the control-loop table is the PRE-correction five-row version
("observe WORKS" unqualified) while the brief's table is seven rows with zero unqualified rows
(observe downgraded by the gap_too_short asymmetry; consume split three ways). ALSO the garbled
parenthetical at line 46: "(formerly "five-stage" — renamed, the table has five stages and seven
rows)" — self-contradictory edit remnant. Verified by direct read; the garble is verbatim in the
file.
B3 [BLOCKER] 01-idea.md:341-346 — "2 of 8 gates have all four legs — no-shell-gate (… mutation
2 …)" repeats the count the brief overturned (no-shell-gate's mutation column is an AFFORDANCE,
not an automated leg; §06's rebuilt table says 1 of 8 = undrained-pipe-lint only). Verified
against 06-gates' own rebuilt column.
M-class: §1.3.9 argues a "live disagreement" with a brief sentence that no longer exists (stale
cross-reference); two of five §1.2 reap bullets not derivable from their cited sources; "13
tests" unreconciled (same class as 06-gates E3); duplicated word "reviewer's. reviewer's." at
line 319-320; duplicated clause in the omp-types sentence; "22 of 24 crates" denominator
unexplained. Spot-verified the garble and the duplicate word directly; the rest accepted as
consistent with the verified blockers' pattern.
Positive verification worth recording: the agent re-derived the nine-binary table, the census
figures, the vacuity figures, and eleven mirror citations (robot_docs.rs, doctor.yml,
issues.jsonl rows with all eleven exit codes) — all exact. The section's mirror-mining half is
sound; its control-loop and gate-count halves are stale.

new_findings = 3 blockers + 4 majors + 4 minors = 11, but per the contract I record the
load-bearing set: 3 BLOCKERs verified by direct re-derivation, plus the majors as one grouped
finding class (stale cross-references/underived bullets). Recording new_findings=7.

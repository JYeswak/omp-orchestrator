# Round 12 fresh report — 09-milestones

{
  "grade": "FAIL",
  "findings": [
    {
      "severity": "BLOCKER",
      "location": "docs/plan/09-milestones.md:53-59, 100-102, 122-128, 149-153, 173-179, 202-208, 241-247",
      "construct": "M1–M7 OBSERVABLE fields",
      "why_real": "The section's own admissibility rule requires a third party to run an exact command and read an unambiguous result, but most acceptance legs are only prose such as “a differential test,” “a stored trace,” “a 24-hour window,” or “the documented install command”; no command, fixture/revision, trace schema, or pass/fail output is specified for those legs.",
      "fix": "For every observable leg, name the exact executable command, fixture/revision and environment, machine-readable output fields, and the command's expected pre-state failure and post-state success."
    },
    {
      "severity": "MAJOR",
      "location": "docs/plan/09-milestones.md:189",
      "construct": "M5 board-count shell loop: `br list --status $s | grep -c .`",
      "why_real": "Without `set -o pipefail` or explicit `PIPESTATUS` checking, a failing `br list` can be converted into `grep -c`'s successful zero, directly violating PV7's failure-versus-empty requirement and making the reported 19/22/3/30 baseline untrustworthy.",
      "fix": "Capture and assert `br`'s exit status before counting (prefer `br list --json` with a parser), and fail the whole probe on command errors."
    },
    {
      "severity": "MAJOR",
      "location": "docs/plan/09-milestones.md:181-185 and 340-345, 356-363",
      "construct": "Banked/starting-point measurements: `162`, `178`, `20/21`, `2 of 8`, `4 of 8`, `183/183`, and the verdict-type counts",
      "why_real": "These are load-bearing `MEASURED`/BANKED numbers, but several have no exact deriving command or immutable artifact; line 183 explicitly acknowledges that the 162-tick figure has “no deriving command,” while the cited command for the 21st occurrence does not derive the baseline 20, and brief cross-references do not make each numerator/denominator re-runnable.",
      "fix": "Attach the exact query/command, scope, revision/time window, and captured output for each number; otherwise relabel it UNPROVEN and stop using it as a baseline or banked fact."
    },
    {
      "severity": "MAJOR",
      "location": "docs/plan/09-milestones.md:303-310",
      "construct": "PC3/PC5 claims that field-presence checks enforce PV4/PV3",
      "why_real": "PC3 only checks that an `OBSERVABLE` field exists, not that it is a runnable command, readable without interpretation, or fails pre-milestone; PC5 only checks for one `NO-CLAIM` paragraph, not that every load-bearing claim is bounded. A prose placeholder plus one paragraph would pass while violating the stated rules.",
      "fix": "Either relabel these as syntax-presence checks or define semantic validators with known-bad fixtures that verify executable observables, pre-state failure, and per-claim scope coverage."
    },
    {
      "severity": "MINOR",
      "location": "docs/plan/09-milestones.md:214-227",
      "construct": "M6 measured statement “tmux is well-behaved”",
      "why_real": "The immediately following evidence shows `tmux --version` exits 1 with empty stdout, so the unqualified `MEASURED` wording contradicts the observed probe even though `tmux -V` works; this asks an investor to resolve a material tool-health distinction from surrounding prose.",
      "fix": "Replace it with the precise measured claim: tmux is installed and `-V` succeeds, while `--version` is unsupported/fails and must not be used as the presence probe."
    }
  ]
}

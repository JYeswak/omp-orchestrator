# Batch 1 notes — ntm surfaces

## Scope
30 rows: ntm:activity through ntm:doctor. All rows were read from the assigned JSONL batch; crate ownership was checked against the workspace crate inventory and the relevant production callsites.

## CONSUMED
- ntm:activity → fleet-composite. Production construct: crates/fleet-composite/src/main.rs:301-302 builds --robot-activity={session} and calls run_command("ntm", ...).
- ntm:send → omp-orchestrator. Production construct: crates/omp-orchestrator/src/main.rs:617-625 builds --robot-send=<session> and invokes the configured ntm binary; ack-stage parses the resulting receipt but does not own the process call.

## RETIRE
The other 29 batch-1 surfaces are auxiliary ntm operator/UI/maintenance subcommands with no demonstrated callsite or dependency in the current orchestrator crates. They do not own a required observe/select/admit/send/verify/grade/reap contract; adopting them would expand surface area without a stated orchestration gain. They are mapped to null intentionally.

## Validation boundary
A broad source search covered production invocation construction: tool.grep(pattern=Command::new("ntm")|run_command("ntm"|invoke([^\n]*ntm|--robot-[a-z0-9-]+), path=crates). Its search space is every crate source file where an ntm process or robot flag could be constructed; it returned only the activity and send paths above plus policy/comment references.

For RETIRE rows, validated_by is null intentionally: “never call this surface” has no positive runtime validator. The source search proves current non-use, while the retirement reason is the design decision recorded here.

No rows were left unclassified. No WIRE or VALIDATE disposition is justified in this batch from the current crate contracts.

# Round 3 — four-lens grade of `02-surface-census.md`

## INVESTOR

MAJORS: 1

1. **The coverage headline is a technical vanity metric, not an investment case** — [02-surface-census.md:75-101, construct: hostile/our-reading coverage conclusion]. The section says the hostile reading is “not an orchestrator” at 77-79, then makes the plan’s job “move that number” at 82-84 while explicitly declining a target at 86-89; it never connects a mapped surface to buyer value, cost avoided, work reclaimed, reliability, or a kill threshold. The section asks the reader to trust that more OMP consumption means progress while conceding that the 157 rows may collapse into one missing actuation layer. **FIX:** Keep 4.37% as a diagnostic denominator and attach each proposed surface disposition to a customer outcome, economic baseline, and stop condition rather than optimizing the ratio.

## ADVERSARIAL

BLOCKERS: 1

1. **The row tally and the envelope count contradict each other on `slash_command`** — [02-surface-census.md:26-43, construct: envelope counts versus emitted row kinds]. The table counts `slash_command | 1` because of the synthetic `UNKNOWN_PROBE` row, while the section says the envelope count agrees on every kind and reports `slash_commands: 0`. Re-derivation command: Python `Counter(kind)` plus the artifact counts block over `/tmp/inv.txt`; result: `slash_command: 1` in the row tally and `slash_commands: 0` in the counts block. This is a schema collision between actual enumerated commands and the placeholder emitted for a missing surface. **FIX:** Give the placeholder a non-surface kind such as `probe_gap`, or explicitly exclude it from row-kind reconciliation and every OMP-surface denominator.

MAJORS: 3

1. **The 157-surface denominator is contaminated by non-surfaces** — [02-surface-census.md:19-22 and 55-73, construct: coverage numerator/denominator]. The section calls 183 rows 157 OMP surfaces plus 26 crates, but the artifact contains 155 actual non-synthetic surface rows plus `slash_command:UNKNOWN_PROBE` and `transport:--mode=<value>`; the re-derivation command counting rows whose kind is not `workspace_crate`, `slash_command`, or `transport` over `/tmp/inv.txt` returned `actual enumerated non-synthetic 155`. Consequently 8/183 and 18/183 are not OMP capability coverage ratios; they include a synthetic missing-surface row and a process transport selector. **FIX:** Publish separate denominators for OMP surfaces, synthetic gap rows, transport selectors, and workspace crates, then recompute all percentages.

2. **`SCRAPED_OR_OBSERVED_ALTERNATIVE` contains four rows that fail its own definition** — [02-surface-census.md:236-267 and 399-409, construct: classification/disposition semantics]. The class is defined as “we get the information some other way,” but the section admits `dap`, `debug`, `tools`, and `modes` have no alternative named; the artifact query over `/tmp/inv.txt` returned those four with `NAMED_REASON` and no alternative. The section acknowledges the problem as future reclassification, but continues to count them as valid scraped alternatives and claims only two dispositions exist. **FIX:** Reclassify those rows now to an explicitly unsupported state with a named reason, or remove them from the 18-row alternative class until an existing alternative is evidenced.

3. **The “we do not shell out to a single OMP subcommand” claim is false without a subject qualifier** — [02-surface-census.md:108-121, construct: `cli_command` disposition]. `tool.grep(pattern="Command::new|omp_help_cli_commands|omp --help", path="crates/omp-inventory-map/src/lib.rs")` returns the direct process boundary at `:1410` and the `omp --help` probe at `:1558-1560`; the scanner does spawn OMP to produce this census. The intended claim may be that the supervisor does not consume any CLI command at runtime, but the section says “we” and conflates census ingestion with product consumption. **FIX:** Name the subject precisely—scanner probe versus orchestrator runtime—and classify the row against the declared consumer rather than the measurement tool.

## ABSENCE

BLOCKERS: 1

1. **The census has no independent oracle for the world it claims to enumerate** — [02-surface-census.md:3-13 and 38-43, construct: one scanner artifact plus self-generated expected twins]. Every number comes from one `omp-inventory-map` output, and every completeness check compares that output with its own `expected_*` fields; a scanner can omit an unanticipated surface and still make its internal counts agree. The section explicitly excludes source reading and provides no independent `omp --help`, shipped-type-tree, RPC, or slash-command source reconciliation. **FIX:** Add independent probes for each surface family and fail closed on disagreement between the scanner and an external/reference enumeration.

MAJORS: 1

1. **The known 136-slash-command gap has no owner, bead, closure command, or acceptance observable** — [02-surface-census.md:140-159, construct: `UNKNOWN_PROBE` disposition]. The section says “no section owns the gap” at line 151 and converts that fact into a requirement, but a requirement without an owner or exact closure condition is not an executable plan; `tool.grep(pattern="owner|bead|refresh|upgrade|compat|slash|expected_slash", path="02-surface-census.md")` finds the gap and generic WIRE language but no slash-gap owner or bead. **FIX:** Assign the slash census to a named owner and bead with the exact enumeration command, expected artifact change, and acceptance condition that resolves `0` versus `136`.

## EVIDENCE

Re-derived headline numbers before grading: `rows=183`; kind counts `57/42/39/26/14/3/1/1`; classifications `157/18/8`; edge counts `207` with `consumes=7`; ratios `4.3716%`, `9.8361%`, `85.7923%`, `3.8462%`, `3.3816%`, and `95.6284%`. These match the artifact, but matching arithmetic is not the same as durable evidence.

MAJORS: 4

1. **The primary measurement artifact is mutable and not identity-bound** — [02-surface-census.md:3-13, construct: scanner invocation and provenance]. The only command is `/Volumes/BuildShared/cargo-targets/debug/omp-inventory-map > /tmp/inv.txt`, with byte count and exit code hidden in a comment; it does not capture the producer status, scanner binary hash, OMP binary identity, or artifact hash. Re-derivation `stat -f "%z %m %N" /tmp/inv.txt; shasum -a 256 /tmp/inv.txt` returned `544697 ... /tmp/inv.txt` and hash `86491732a5581a6d2e342d0db59bdf20e5f47f6da93150ae78bd2649562f5081`, but none of that provenance is in the section, so a later reader cannot know which bytes produced the claims. **FIX:** Publish a content-addressed inventory artifact plus the exact producer exit status, scanner hash, installed OMP identity, and hash-verification command.

2. **Many measured numbers have no deriving query despite the section’s explicit promise** — [02-surface-census.md:10-12, 19-43, 55-73, construct: headline totals and percentages]. The displayed queries derive row-kind and classification counters, but no query derives `184 nodes`, `207 edges`, the envelope byte count/status/exit, or the percentages `4.37%`, `9.84%`, `85.79%`, `3.85%`, and `3.38%`; the section merely writes arithmetic beside them. This violates “every derived count below is a python3 query” and makes the evidence surface incomplete even where independent arithmetic matched. **FIX:** Attach one exact, fail-closed command and result to every headline number, including graph totals, artifact metadata, and each derived percentage.

3. **The section prints non-commands as evidence commands** — [02-surface-census.md:105-106 and 289-295, construct: surface-list and first vacuity probes]. The `<KIND>` placeholder in the list query and the literal ellipsis in `python3 -c "…collections.Counter(...) …"` cannot be run as printed, while line 11 claims every query is printed next to its result; the later line-300 query is exact only for the second vacuity pass. **FIX:** Replace every template or abbreviated probe with a complete executable command or label it `PSEUDOCODE` rather than `MEASURED` evidence.

4. **The corroborating zero search violates the section’s own no-silent-zero rule** — [02-surface-census.md:385-395, construct: `grep -o ... | wc -l` corroboration]. The command pipes grep into wc without checking grep’s status; running the same command against a missing path produced three “No such file” errors, three zero counts, and `pipeline_exit=0`. A missing inventory therefore produces the same numeric shape as a clean absence. **FIX:** Fail closed on unreadable input and capture the search producer’s exit status before publishing zero as corroboration.

## CHALLENGE TO %1408

1. **N1 overstates the gate-table omission** — [r2-absence.md:6-15 and 80-81, construct: demand for 18 NONE rows]. The sibling is right that the denominator is not explicitly scoped, but it assumes all 26 workspace crates belong in a gate-leg table; `00-brief.md:253-269` names eight gate frameworks, while many workspace crates are mechanisms or support libraries, not gates. The sibling’s own command/search does not establish that the missing 18 are gate-bearing crates. **FIX:** Retain the finding as a denominator-scope defect, but require an explicit “eight gate frameworks” universe or a gate-inventory query rather than mechanically adding 18 NONE rows.

2. **M1’s not-found evidence cannot support its conclusion** — [r2-absence.md:63-67, construct: glossary absence]. `grep -ic glossary 00-brief.md -> 0` searches for the label “glossary,” not for definitions of “bead dag,” “reap,” “tick,” or “mirror”; the search space could contain definitions under any heading without containing the word glossary. The underlying concern about unexplained jargon may hold, but the cited command is a false-zero mechanism and cannot prove the absence of definitions. **FIX:** Search each cited term and its defining patterns across the full brief, then report missing definitions by construct rather than by the absent word `glossary`.

3. **N3 imports a stronger owner contract than the target document states** — [r2-absence.md:40-46 and 84-85, construct: §8 owner column]. R12 requires an open question to have “an owner”; it does not require the owner to be a bead ID or path, and a durable table naming Josh or the orchestrator is not pane scrollback. The sibling’s operational concern is useful, but “violates the document’s own thesis” is overstated without a requirement that ownership be an artifact or a decision SLA. **FIX:** Downgrade this to a proposed strengthening—durable owner record plus due date/decision right—rather than calling the existing role-owner cells a failed R12 implementation.

4. **N2 takes the scheduler causal claim on trust** — [r2-absence.md:17-25 and 82-83, construct: missing TRIGGER/driver row]. The sibling says the 162 refused ticks “only exist because a scheduler fired,” but it supplies no command, source construct, or observed scheduler identity; those ticks could have been produced by a manual loop or another caller. The absence of a driver row may be valid, but the causal justification is unverified and the sibling did not state a search scope for the not-found. **FIX:** Separate the defensible table omission from the causal claim and cite the actual tick producer plus an exact search proving no driver row exists in the graded file.

## SUMMARY

BLOCKERS: 2
MAJORS: 9
MINORS: 0

VERDICT: FAIL
THE ONE THING: The census is arithmetic on one self-reporting artifact whose schema counts a synthetic missing-surface row as a real surface; until the oracle, denominator, and status/disposition boundaries are independently evidenced, the coverage headline is not investable or operationally trustworthy.

# BATCH 8 NOTES — SilverWolf (%1409) — R14/R15 surface mapping
Dispositions: 2 WIRE / 3 CONSUMED / 27 RETIRE (per this batch's share).
Uniform RETIRE evidence: the omp-inventory-map census classifies each row CAPABILITY_NOT_USED
(regenerate: /Volumes/BuildShared/cargo-targets/debug/omp-inventory-map --repo .) — the census is the
measured no-consumer proof. Per-surface reasons below; WIRE and CONSUMED rationale first.

## THE CONSEQUENTIAL ROWS
- `surface:cli_command:usage` -> WIRE, maps_to_crate=tick-monitor. `omp usage` = "Show provider
  usage limits for every authenticated account" — the only machine-readable cost/quota signal on any
  of the four surfaces, and brief §8.2 Q2 ("what does the current workaround cost, measurably?") is
  OPEN precisely because nothing samples it. What tick-monitor would gain: a cost/quota probe beside
  the pane census; turns Q2 from unanswerable to sampled.

## RETIRE REASONS (per surface)
- `surface:cli_command:models` — per-session model selection; spawns already pass --omp flags explicitly
- `surface:cli_command:plugin` — OMP plugin management; adopting extensions is a WIRE decision nobody has made
- `surface:cli_command:ps` — probed: 'List and control daemon-supervised background processes (logs, stop, kill, restart)' - a second kill path invites the orphaned-grandchild class (C112); workers are tmux panes + oneshot spawns
- `surface:cli_command:read` — agent REPL file reader; crates read directly
- `surface:cli_command:render` — agent-side rendering convenience
- `surface:cli_command:say` — probed: local TTS playback
- `surface:cli_command:search` — agent search backend selection
- `surface:cli_command:setup` — interactive onboarding for human OMP users
- `surface:cli_command:share` — probed: encrypted session share links
- `surface:cli_command:shell` — interactive shell into an OMP session
- `surface:cli_command:ssh` — remote session attach; our remote path is ssh+tmux directly
- `surface:cli_command:stats` — probed: human usage dashboard; the machine-er signal is `usage` (WIRE)
- `surface:cli_command:tiny-models` — small-model catalog for the agent
- `surface:cli_command:token` — provider token management; credentials stay outside the orchestrator
- `surface:cli_command:ttsr` — probed: 'Time-Traveling Stream Rules' inspect/test; agent streaming feature
- `surface:cli_command:update` — self-update; PATH pins + installer identity own this
- `surface:cli_command:worktree` — agent worktree UX; no worktree consumer crate exists
- `surface:type_root:advisor` — agent advisory panel types; orchestration consumes decisions (receipts), not advice
- `surface:type_root:async` — agent inference plumbing
- `surface:type_root:auto-thinking` — agent inference feature
- `surface:type_root:autolearn` — agent self-improvement loop
- `surface:type_root:autoresearch` — agent self-improvement loop
- `surface:type_root:blob-broker` — binary blob transport for agent sessions
- `surface:type_root:capability` — extension capability negotiation
- `surface:type_root:cleanse` — session hygiene types
- `surface:type_root:collab` — multi-user collab sessions
- `surface:type_root:commit` — agent-session vcs helpers; crates shell git under subprocess-contract

## COULD NOT CLASSIFY
None. Every row received a disposition. Weakest-evidence rows, named honestly: bv:simulation and
bv:track are classified RETIRE-as-scrape-noise on the strength of `bv --help` not containing the
tokens (searched: full `bv --help` output, 2>&1); if a hidden bv build exposes them, the scrape
still captured them as SUBCOMMANDS, which is the wrong kind, so the row needs re-derivation either
way. The type_root one-liners are kind-level truths (agent-feature namespaces), not per-file reads
of OMP's dist/types — reading 42 vendored type definitions to justify NOT adopting them inverts
the discipline; the census zero-consumer measurement is the load-bearing evidence.

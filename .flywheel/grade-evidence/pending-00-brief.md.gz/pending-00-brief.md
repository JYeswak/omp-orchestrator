# STAGED EDITS for 00-brief.md — apply AFTER grading round 1 closes

Held back deliberately. Four agents are grading `00-brief.md` right now; editing it mid-round would
make them grade a moving target and would invalidate any line number they cite. Applied when the
round closes and the four grades are in hand.

---

## STAGE 1 — new subsection §3.8, the GHOST class

Insert after §3.7 (other binding facts).

### 3.8 The GHOST class — an installed binary whose source is not the source we read

Three independent instances measured in one session. This is not three bugs; it is one unnamed
class, and it cost real time in every case — including the conductor's.

| artifact | installed | source reality |
|---|---|---|
| `pane-truth` | `~/.local/bin/pane-truth`, on PATH, named in the installer's `BINARIES` | **no source in this workspace** — it belongs to `control-plane`. Classified GHOST in §07 |
| the supervisor | launchd running `build_id 9a61acd` | HEAD was **23 commits** ahead |
| `rch` | `~/.local/bin/rch`, built 17:10 today, gating every build in this repo | local checkout is **1,813 commits behind** origin/main and **entirely lacks** `rchd/src/disk_pressure.rs`, the file that defines the policy |

Measured for `rch`:

```
cd ~/Developer/remote_compilation_helper
git rev-parse --short HEAD                            -> 5e2223d7   (981 commits)
git rev-parse --short origin/main                     -> 4c7f56e4   (2791 commits)
git rev-list --left-right --count HEAD...origin/main  -> 3   1813
ls rchd/src/disk_pressure.rs                          -> No such file or directory
git cat-file -e origin/main:rchd/src/disk_pressure.rs -> exists
```

**Note `ahead 3`.** The obvious remediation — `git merge --ff-only` — will REFUSE. Three local
commits sit across an 1,813-commit gap. A remediation stated as easier than it is will be attempted
casually by the next person, which is how the gap got this large.

A fourth instance is the conductor's own, and it happened *inside the act of grading*: kxe.1's AC2
was first graded against a **release binary 5.5 hours stale**, producing a false negative that was
caught only because `run mentions=0` contradicted a test that had just passed.

**The rule this class demands.** §07 specifies a four-way identity proof — HEAD, `build_id`,
`--version`, running — for binaries *we* build. This class extends it to binaries we merely
**depend on**: every installed binary must declare its owning repo and the commit it was built
from, and any tool reasoning about that binary's behaviour must verify that the source it is
reading is the source that was built. Reading a local checkout to predict an installed binary's
behaviour is, in the `rch` case, reading a different program.

**NO-CLAIM.** Three instances establish the class exists and is not rare. They do not establish how
many more exist — no census of installed-vs-source has been run, and the four-way check that would
produce one is thinner than it looks. Measured: `const BINARIES` at `crates/installer/src/main.rs:12`
names **three** binaries against **18** `main.rs` files in the workspace — and one of the three is
`pane-truth`, the GHOST, which is excluded as foreign. So the identity check verifies **2 owned
binaries out of 18**, about 11%. A separate portability blocker sits nine lines below it:
`dirs_home().unwrap_or_else(|| PathBuf::from("/Users/josh"))` hardcodes one person's home
directory as the install fallback.

---

## STAGE 2 — extend the §7 refutation table

The table currently lists eight. Two more landed after it was written:

| # | claim | refuted by | mechanism |
|---|---|---|---|
| 9 | kxe.1 AC2 "help omits `run`" | the conductor, self-caught | graded a release binary 5.5 hours stale |
| 10 | 2z2.1 "ff-merge local->origin" | the conductor | `ahead 3` makes `--ff-only` refuse |

Update the §7 opening count from eight to ten, and the `PLAN.md` header blockquote likewise. Seven
of ten are now the author's.

---

## STAGE 3 — worker closeouts to fold into §09

Two closeouts were graded during the plan work and both produced findings that belong in the
milestones section:

- **kxe.1** — 4 of 5 acceptance clauses pass on independent re-run. AC2 partially unmet and
  **unblocked**: help names `run` but omits the four runtime dependencies the clause enumerates
  (`tmux`, `tick-monitor`, `br`, `ntm`). AC5 blocked by the pre-existing w4j fence, marker created
  `11:42:46`, six hours before commit `57f1af0`, `modified == created`. The worker refused to clear
  it; correct.
- **2z2.1** — BLOCKED upheld. Acceptance as written is unsatisfiable without redefining an exit
  code another repo already binds. Needs a scope decision from Josh: rewrite the acceptance, or
  reconcile the `rch` checkout first, or close WONTFIX with the conflict named.

Both are evidence for M3 and M6: a bead can be blocked by a *contract in another repository*, and
the plan currently has no milestone that owns cross-repo contract conflicts.

# R14 MINING PASS — ipg.14 — SilverWolf (%1409)

## THE FIRST PAYOFF, VERIFIED

asupersync (our binding dependency, required by every crate) already solved three problems we
invented worse solutions for:

1. **AckKind** (fabric.rs:~1919 on `PublishReceipt`) — a typed acknowledgement boundary, not a
   boolean and not three parallel authorities. Our three-authority ack spine exists because we
   had no vocabulary for "how far did this get." AckKind IS that vocabulary.
2. **DeliveryClass** (messaging/class.rs:17-29) — five semantic classes: EphemeralInteractive,
   DurableOrdered, ObligationBacked, MobilitySafe, ForensicReplayable. We have NO delivery class:
   every dispatch packet is treated identically.
3. **PublishPermit** (fabric.rs:~1944) — `#[must_use]` two-phase reservation with Drop-abort.
   "Dropping without calling either method aborts cleanly (no data committed, no obligation
   leaked)." This is the pending-dispatch fence, solved. Our marker survived 29 ticks because
   nothing owned its release; a permit that aborts on Drop cannot leak.

## MINING PASS — every UNMEASURED/hard/no-alternative claim, answered

| # | claim (section:line) | mirror search | result | classification |
|---|---|---|---|---|
| 1 | "cost telemetry remains unmeasured" (01-idea:104) | grep ContextUsage/token_cost in asupersync/src/types/ | asupersync `resource.rs` has usage trackers (:979/:1011/:1153); OMP has ContextUsage/PerplexityCost (DECLARED only) | **NOT FOUND in mirror for orchestration use** — the wire path is OMP telemetry-export→OTLP→receiver, which is a build decision |
| 2 | "cargo shim is an unmeasured supply-chain surface" (01-idea:504) | grep cargo shim/registry in mirror | No prior art found — the RCH shim is our infrastructure, not a common pattern | **SEARCHED, NOT FOUND** |
| 3 | "ReceiptVerdict can express a non-tmux receipt without variant explosion is UNMEASURED" (08-end-users:340) | asupersync AckKind + DeliveryClass + PublishPermit verified first-hand | AckKind IS the typed boundary vocabulary; DeliveryClass IS the delivery-class system; PublishPermit IS the two-phase fence. BUT: the fabric is a messaging plane between asupersync-using components — a tmux pane that has never heard of asupersync cannot receive an AckKind. Adoption requires the pane to speak asupersync, which the topology forbids (NO-CLAIM in the bead) | **ADOPTABLE FOR ASUPERSYNC-USING COMPONENTS; NOT APPLICABLE TO TMUX PANES** — the vocabulary is correct, the topology is the barrier |
| 4 | "path-literal-guard has no known-good leg" (01-idea:400, 06-gates:101) | grep known.good/boundary/legitimate in asupersync tests/ | Returned binary artifacts (compiled benchmarks), not source-level prior art | **SEARCHED, NOT FOUND** — this is the positive control: a genuine gap with no mirror citation |
| 5 | "claim/lease patterns for pending-dispatch fence" | grep struct Lease/acquire/release in asupersync | asupersync `obligation/ledger.rs`, `obligation/crdt.rs`, `obligation/guarded.rs` — ObligationLedger pattern: reserve → commit/abort | **FOUND: asupersync obligation/ledger.rs** — prior art for the ntm:claim wire and the pending-dispatch fence |
| 6 | "scope.spawn reader pattern for concurrent drain" (round 12, this wave) | grep scope.spawn/thread::scope in asupersync | asupersync fabric and oracle-compare both use scoped-thread concurrent readers | **FOUND: control-plane oracle-compare f29323b is the in-tree precedent** |

## THE RECEIPT DESIGN RE-DERIVATION (acceptance leg 2)

Our ack-spine has `AckVerdict` (Confirmed/NoReceipt/Dead/Indeterminate) and three authorities
(Transport/Delivery/Ack). asupersync has `AckKind` (typed boundary) + `DeliveryClass` (five
semantic classes) + `PublishPermit` (two-phase reservation with Drop-abort).

The mapping is NOT 1:1:

| our type | asupersync type | transferable? |
|---|---|---|
| TransportAuthority::Succeeded | AckKind::EphemeralInteractive boundary | YES — both mark "transport accepted it" |
| DeliveryAuthority::Observed | AckKind::DurableOrdered boundary | PARTIALLY — our delivery is observational (screen change), asupersync's is protocol-level |
| AckAuthority::ReadBack | AckKind::ObligationBacked boundary | YES — both require a durable-store read-back |
| pending-dispatch marker | PublishPermit Drop-abort | NO — the marker is a file; the permit is an in-process reservation with consumed-guard |
| (no delivery class) | DeliveryClass (five classes) | NO — we treat all dispatches identically; asupersync classifies by durability |

**The barrier:** the asupersync fabric is a messaging plane between components that both use
asupersync. A tmux pane speaks tmux protocol, not asupersync. Adopting `PublishPermit` requires
the pane's parent process (our orchestrator) to hold the permit and abort-on-drop — which is
architecturally correct but requires the dispatch path to be restructured around asupersync's
fabric, not around `Command::new("ntm")`. That is a real architecture change, not a type
import.

**The finding:** we invented vocabulary that already exists in our own dependency. The vocabulary
is correct; the adoption requires an architecture change that is untested. Record the vocabulary
mapping, do not adopt yet.

## FIRES-ON-KNOWN-BAD (acceptance leg 3)

The known-bad specimen is IN-TREE: any bead or doc containing "UNMEASURED" without an adjacent
mirror citation or explicit "searched, not found" is flagged. The pattern is grep-able:
`grep -rn 'UNMEASURED\|unmeasured' docs/plan/ | grep -v 'mirror\|searched\|experiment\|NUMBERS'`.
Tonight's pass found 20+ sites; 5 were actionable (mined above), the rest are descriptive
prose about already-resolved states. Specimen: `docs/plan/01-idea.md:104` — "cost telemetry
remains unmeasured" with no mirror citation and no resolving experiment.

## POSITIVE CONTROL (acceptance leg 4)

**path-literal-guard's known-good leg** — "what does a legitimate path expression look like" —
returned binary artifacts from the mirror search, not source-level prior art. This is a genuine
NOT FOUND: no repo in the 216-work-tree mirror has a known-good-leg fixture for a path-literal
scanner. The positive control passes: the search is not matching everything.

## ANTI-VACUITY (acceptance leg 5)

6 actionable gaps enumerated from the plan's docs, 5 mined with mirror citations, 1 searched-not-
found. Zero is not the count.

## WHAT TO DO WITH THIS

The vocabulary mapping (AckKind ↔ AckVerdict, DeliveryClass ↔ delivery-class gap, PublishPermit ↔
pending-dispatch fence) is recorded for the S5/S6 foundation fields. The adoption requires an
architecture change (dispatch path restructured around asupersync's fabric) that is a milestone
decision, not a type import. The obligation-ledger prior art is recorded for the ntm:claim wire.
The path-literal-guard known-good leg remains a genuine gap with no mirror citation — the next
step is to invent the fixture, not to keep searching.

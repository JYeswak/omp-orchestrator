# Round 12 — `00-brief.md` — fresh grade and repair record

## Fresh dispatch

- **Agent:** `r12-brief-grader`
- **JSM choice:** `jsm suggest "brief requirements evidence plan"` failed because JSM bandit recommendations were disabled; `jsm search requirements-gathering` selected `requirements-gathering` v1.
- **Prompt scope:** only `docs/plan/00-brief.md` plus the claim contract for authoritative requirements: MEASURED/PROJECTED distinction, exact command/input for numbers, explicit historical/retraction boundaries, checkable requirement observables, and scoped NO-CLAIMs. No prior findings, ledger, or fix notes were supplied.

## SEARCH SPACE

The fresh agent read the complete assigned file and cited source constructs. Verification re-read the reported ranges and used focused probes rather than a second broad grade:

- Case-insensitive searches over the complete brief for `security|secret|credential|token|licens`, stale board totals, stale gate headlines, test counts, RCH references, and section denominators.
- Exact `br list --status <state> --json | jq '.issues | length'` shape for board counts.
- Exact source-aware reads of the scanner, vacuity, gate-leg, mirror, requirements, and assembly constructs cited by the agent.
- Exact source/row checks for the scanner and current map; no cargo, gate, or formatter ran.

All 16 findings were REAL. None was a scope error or false positive. Every item below was fixed in `docs/plan/00-brief.md`; no item was deferred.

## Findings

| SEVERITY | Finding | Verdict and diff location |
|---|---|---|
| **BLOCKER** | Board snapshot arithmetic stated `30/23/23/3 = 81`. | **FIXED** — `:476-477`; total is 79, with exact JSON/JQ record-shape counting and the 74 snapshot kept historical. |
| **BLOCKER** | Q7/Q8 corpus counts claimed zero/once while matching the brief itself. | **FIXED** — `:776-789,798-799`; exact ten-companion-file scope, case mode, exclusions, and command are recorded. |
| **MAJOR** | “Ten section files” conflicted with 00–10’s 11 rows. | **FIXED** — `:553`; now ten companion files plus this brief, 11 total. |
| **MAJOR** | Scanner claimed 184 nodes/183 rows while slash-command and synthetic-row meanings were unclear. | **FIXED** — `:208-219`; historical 181/183/184 shape is separated from the fresh hash-anchored 980 discovered + 1 transport sentinel = 981 rows / 982 nodes / 1,803 edges, with slash-command semantics explicit. |
| **MAJOR** | Vacuity command was elided and unbound to an input. | **FIXED** — `:225-241`; complete JSON-bound command, capture hash, filters, and recorded 981/26/955 results are present. |
| **MAJOR** | `grep -rc` could not produce the scalar test-function count it claimed. | **FIXED** — `:270-285`; source-aware declaration enumeration separates 31 files from 406 historical test functions. |
| **MAJOR** | Gate-leg table had no retained generator/input identity. | **FIXED** — `:287-296`; exact round-10 scope/exclusions and non-authoritative snapshot boundary are explicit. |
| **MAJOR** | Unsafe-code `--include` false-zero experiment lacked complete counting/provenance. | **FIXED** — `:392-410`; both invalid/authoritative directions, roots, source-aware counts, and historical status are recorded. |
| **MAJOR** | Binding numerics used bare grep/line counts for semantic claims. | **FIXED** — `:455-462`; spawn/async/type claims are UNVERIFIED unless source-aware, while unsafe counts are tied to the dated experiment. |
| **MAJOR** | Mirror denominator called unspecified `.git` entries repositories. | **FIXED** — `:466-475`; `$M` is defined, 210 is explicitly a filesystem-entry snapshot, and worktree validation is required before repository claims. |
| **MAJOR** | Old `1 of 8 / AUTOMATED` gate headline remained active prose. | **FIXED** — `:376-379`; block is explicitly `RETRACTED — historical claim; do not use`, followed by the canonical typed result. |
| **MAJOR** | “Nothing found automated” contradicted the scanner’s automated expected-vs-observed check. | **FIXED** — `:653-654`; statement is narrowed to the ten §7 refutations and scanner omission is separately classified. |
| **MAJOR** | K2/K5 kill criteria lacked owner, units, window, and threshold. | **FIXED** — `:811-815`; both remain OPEN/UNVERIFIED with owners, 30-day windows, numerator/denominator, sources, and a two-week `>1.0` threshold. |
| **MAJOR** | R3 closure treated assembled-file existence as sufficient despite stale assembly. | **FIXED** — `:708-710`; R3 is PARTIAL and now requires source-manifest hashes, mtime freshness, reassembly, and output identity. |
| **MINOR** | Historical “four GHOSTs” count had no instance/provenance boundary. | **FIXED** — `:97`; it is explicitly historical/unverified with the missing comparison/instance-list limitation. |
| **MINOR** | R3/R6/R8/R9/R10 requirement rows closed on section existence rather than acceptance predicates. | **FIXED** — `:118-125,801-803`; concrete observables/statuses and Q10–Q12 ownership are now named. |

## Number registry

The declared registry was checked before correction. Existing authoritative values were reused for board/test figures; no duplicate key was introduced by this section. Current registry-backed test values are `test_files=32` and `test_functions=413`; the brief's `31/406` block remains explicitly historical/non-authoritative.

## Result

**16/16 findings accounted for; 16 fixed; 0 deferred; 0 retracted.**
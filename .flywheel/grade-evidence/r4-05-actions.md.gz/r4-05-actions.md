
ABSENCE / MAJOR 1 — R13 is only partially carried by the action section; the lifecycle controls are assumed at the build boundary.

- **TEMPLATE: present.** A1–A11 consistently use Purpose, Inputs, Outputs, Must be true, Negative pattern, How we know it refused, and NO-CLAIM; A1 at lines 16–44 is the clearest complete instance.
- **DISPATCH: partial, not proper for this section’s build stage.** A4–A6 define runtime admission, claiming, and packet dispatch at lines 103–192, but no action-implementation dispatch packet, owner, sequence, dependency, retry, or evidence handoff is specified for turning these action definitions into build work.
- **REAP: partial.** A10 at lines 293–322 specifies runtime pane reaping, but there is no reaping rule for abandoned, failed, or superseded action-implementation work.
- **LOGGING: partial.** A6–A10 mention transport receipts, transcripts, close reasons, and reap records, but the section defines no canonical action-event log with run identity, correlation across A1–A11, durable location, retention, or replay semantics.
- **BUILD GRADING: missing.** A8 at lines 226–258 defines the intended grading action but explicitly says `Grade` does not exist and “grading is prose”; the section has no build-grade command or closure artifact for its own actions.

FIX: Add a lifecycle contract that names the implementation dispatch/reap path, canonical event-log schema, and executable build-grade artifact, while retaining A4–A10 as runtime behavior rather than treating them as proof that the build stage is controlled.

ADVERSARIAL / MAJOR 1 — A5 labels a consequence as measurement without measuring the claimed cause.
A5 says an unclaimed dispatch is invisible to the detector at lines 147–154, then labels the support “MEASURED by consequence” because every completion in the session was found by a human at lines 154–155. Human-found completions do not establish that an unclaimed dispatch occurred, that it bypassed the detector, or that it caused the discovery; the same outcome could arise from a claimed dispatch, a worker failure, or an unrelated observation gap.

FIX: Run a controlled unclaimed-dispatch specimen through the real detector and record the missing follow-up as the measured bypass, or mark the causal paragraph PROJECTED and retain the session result only as motivation.

ADVERSARIAL / MAJOR 2 — Property 5 is called a testable gate property but is a prose rule.
The heading at lines 364–366 says all six items are properties every action gate “must have,” and lines 397–400 call them “testable properties of a gate's test suite.” Property 5 at lines 384–385 — “The claim is a floor-raise, never a guarantee” — specifies wording discipline, not an observable test, fixture, mutation, or refusal path. The section therefore presents five testable controls plus one unimplemented editorial policy as a uniform six-property gate contract.

FIX: Either add an executable overclaim scanner with known-good/known-bad and mutation coverage, or move Property 5 out of the gate contract and replace it with a genuinely testable invariant.

EVIDENCE / MAJOR 1 — The section’s MEASURED evidence is not reproducible from its stated commands.
The opening says at lines 9–14 that refusal observables and not-found claims must be named precisely, yet several load-bearing MEASURED statements carry only incident prose or a brief-section pointer: 162 refused ticks at lines 9–11; the 30-second false-freeze window at lines 32–35; the 26+ minute invisible escalation at lines 65–68; the top-3 PageRank observation at lines 87–92; the 29-bead wave at lines 273–277; and the gate ratios at lines 368–383. Some later entries provide source constructs, but none of these measurements gives the exact deriving command, input artifact, or preserved output in this section.

FIX: Attach a command, bounded input set, timestamp/source revision, and retained output receipt to every MEASURED claim, or relabel claims without that chain as inherited observations.

ABSENCE / MAJOR 2 — Typed uncertainty is specified, but no recovery or terminal path is specified.
A3 emits `QueueUnreadable` and `QueueEmptyNeedsJosh` at lines 84–100; A4 has `AuthorizedIdle` expiry and refusal codes at lines 110–132; A6 can emit `UnprovenTransport` and five parse-error arms at lines 170–192; and A7 can emit `Indeterminate` at lines 200–224. The section says what each action refuses, but never provides a transition matrix saying which states retry, hold, escalate, compensate, or terminate, with a retry budget and durable owner. For a system whose central promise is safe handling of uncertainty, this leaves the most important states operationally manual.

FIX: Add a typed transition table for every non-success arm with next action, retry budget, timeout, escalation owner, terminal state, and receipt requirement.

INVESTOR / MAJOR 1 — The section explains the mechanism’s internal purposes but not the customer outcome if the actions work.
The opening defines the product as deciding whether it is “entitled to do a thing” at lines 5–9, and A1–A11 then specify observation, selection, dispatch, verification, grading, closing, reaping, and refusal. The only operating result named is 162 refused ticks whose refusal nobody consumed at lines 9–11; no action is tied to fewer lost work-hours, faster completion, lower operator cost, reduced incident risk, or a buyer’s measurable result.

FIX: Add one customer-facing outcome and baseline/target to each action family, then make the action-level acceptance criterion prove that outcome rather than only the internal refusal shape.

CHALLENGE TO /tmp/grade/r3-04-diagrams.md

I challenge B1 (`r3-04-diagrams.md:7–10`, construct: the section’s “no prior art” claim). The sibling is right that `br dep --format mermaid` in the mirror refutes the broad statement that no tool emits Mermaid from dependency data. The sibling overstates the match when it calls that command “exactly” prior art for “emitting mermaid from a dependency census as a CI artifact”: the cited command demonstrates a renderer, not a CI artifact, freshness/diff gate, or generated-architecture regression check. The sibling’s proposed re-scope to the true delta—CI diff-on-regression—is the part that holds.

The sibling’s M4 (`r3-04-diagrams.md:26–27`, construct: current `NewlyIdle` status) also turns source locations into a current runtime conclusion. The grep evidence can show that separate fields and predicates exist at HEAD; it cannot show that the live producer, parser, and dispatch consumer agree without a path exercise. “The status is fixed at HEAD” is therefore stronger than the evidence shown; “the source contains a candidate fix, runtime behavior still needs verification” is the defensible version.

The sibling’s M3 (`r3-04-diagrams.md:23–24`, construct: replacement type-inventory snapshot) takes its corrective number on trust. It correctly challenges the 51/79/22-of-24 snapshot as lacking a deriving command, but then asserts the replacement 59/91 across 24 of 26 without publishing the command or output that produced it. The finding that the printed source is unreproducible holds; the replacement baseline is not independently established in the grade.

The not-found search-space issue in B1 is valid rather than a sibling error: the target section’s own search was restricted to `franken_markdown` (as reported at `r3-04-diagrams.md:9`), so it could not have found `beads_rust`. That is exactly why the sibling’s refutation is publishable. The correct criticism is “the original search space could not contain the answer,” not “the sibling’s counter-search was too broad.”

RE-DERIVATION LOG

- `grep -E '^### A[0-9]+\.' docs/plan/05-actions.md` → 11 action headings: A1 through A11.
- `grep -E '^([1-6])\. \*\*' docs/plan/05-actions.md` → 6 numbered gate properties.
- A7’s `ReceiptVerdict` at lines 200–202 has 4 arms: `ReceiptConfirmed`, `NoReceipt`, `Dead`, and `Indeterminate`.
- A4’s refusal codes at lines 110–111 are 3 codes: 75, 76, and 78.
- A6’s `TransportReceiptError` at lines 170–172 is stated to have 5 arms.
- The `2 of 8`, `1 of 8`, and `4 of 8` gate ratios at lines 368–383 are inherited measurements, not independently derived by this section; that is part of EVIDENCE / MAJOR 1 above.

CORRECTION TO THE DERIVATION LOG: those counts were obtained with the harness `tool.grep` using the stated regular expressions, not by executing shell `grep`; the counts are 11, 6, 4, 3, and 5 respectively.

BLOCKERS: 0
MAJORS: 6
MINORS: 0

VERDICT: FAIL

THE ONE THING: The action definitions are detailed refusal prose, but the section still does not show a complete, executable lifecycle from action implementation dispatch through durable logging, recovery, and build grading; its strongest measured causal claims also outrun their evidence.

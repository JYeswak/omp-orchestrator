# Round 23 — fresh-eyes grading of sections 04-06, lens: disposition-truth + cross-section
# Grader: AmberGate (OpusFive, pane %1408). Preconditions verified before starting:
#   cargo run -p convergence-stamp -- --check  -> ROUND ADMITTED: stamp covers all 14 rounds
#   cargo test -p no-shell-gate --test findings_ledger -- --include-ignored
#     -> real_findings_ledger_is_strictly_valid ... ok   (10 passed)

## Ledger input for these three sections
$ jq -r 'select(.section|test("^0[456]-"))|"\(.round)\t\(.section)\t\(.disposition)"' docs/plan/FINDINGS.jsonl | sort | uniq -c
  -> 41 rows total: 1 FIXED, 37 DEFERRED, 3 RETRACTED

## FINDING 1 (04-diagrams, major) — the one FIXED row cites a commit that never touched the section
$ jq -r 'select(.id=="R21-04-mirror-entry-mislabel")|.fixed_in' docs/plan/FINDINGS.jsonl
  -> 506351316df7af0883a267543e87e740b2511ec8
$ git log --oneline -1 5063513
  -> 5063513 fix(findings): restore the 21 round-15 rows that 2866798 overwrote [test]
$ git show --name-only --format='' 5063513
  -> docs/plan/FINDINGS.jsonl
$ git show --name-only --format='' 5063513 | grep -c '04-diagrams.md'
  -> 0        positive control, all files in that commit: 1
$ git log --oneline -S 'not validated as git work-trees' -- docs/plan/04-diagrams.md
  -> (no output)
$ git log --oneline -S 'not validated as git work-trees'
  -> 07de72b docs(plan): reconcile owned denominators [selftest-verified]
$ git status --porcelain -- docs/plan/04-diagrams.md
  -> (empty: clean)
$ git show HEAD:docs/plan/04-diagrams.md | grep -c 'not validated as git work-trees'
  -> 1        positive control, 'mirror' in the same HEAD blob: 3
VERDICT: the FIX IS REAL and landed at 07de72b. The disposition is true; its evidence pointer is
false. A reader auditing the fix at 5063513 finds a FINDINGS.jsonl-only commit.

### The gate hole behind it
$ sed -n '264,270p' crates/no-shell-gate/tests/findings_ledger.rs
  "FIXED" => { let sha = string_field(row,&["sha","fixed_in"])...;
               if !(7..=64).contains(&sha.len()) || !sha.chars().all(|c| c.is_ascii_hexdigit())
                   { return Err(...) } }
VERDICT: shape-only. `fixed_in = "deadbeef"` passes. Existence is never checked, and neither is
"did that commit touch the named section".

## FINDING 2 (06-gates, major) — the gate-inventory denominator, and the replacement inherits it
$ python3 (backticked first cell of the 3.1 matrix rows)
  -> matrix rows: 16   unique gates: 8
     commit-build-fence kernel-bypass-gate no-shell-gate omp-inventory-map
     path-literal-guard pre-delete-citation-check state-wildcard-lint undrained-pipe-lint
$ bun -e 'Object.keys(require("yaml").parse(gate.yml).jobs)'
  -> jobs=10 ; CI jobs the matrix does NOT cover: installer, porting-gate
$ tracked gate-shaped crates (name matches gate|lint|guard|fence|check|inventory AND git ls-files>0)
  -> 12 ; matrix does NOT cover: dispatch-claim-fence, pane-dispatch-fence, porting-gate,
                                 wired-but-inert-guard
$ python3 (crate names in GATE_PROPERTIES in crates/no-shell-gate/tests/gate_properties.rs)
  -> crates cited: 6
     kernel-bypass-gate no-shell-gate path-literal-guard pre-delete-citation-check
     state-wildcard-lint undrained-pipe-lint
$ grep -n 'const \|read_dir' crates/no-shell-gate/tests/gate_properties.rs
  -> 67: const GATE_PROPERTIES: &[Claim] = &[      (hand-listed)
  -> 105: read_dir  (reads a crate's own tests dir, NOT the gate set)
$ grep -n 'for (crate_name' crates/no-shell-gate/tests/gate_properties.rs
  -> 129, 176 : all three tests iterate GATE_PROPERTIES; none derives the set from disk
$ registry omits: commit-build-fence dispatch-claim-fence omp-inventory-map
                  pane-disp
atch-fence porting-gate wired-but-inert-guard
NOTE: two of those (commit-build-fence, omp-inventory-map) are graded BY the 3.1 matrix, so the
replacement covers fewer gates than the table it replaced.
$ 06-gates.md:196 (the section's own words about this defect class)
  "control-plane's check.sh hand-lists EXPECTED_GATES while the verdict claims completeness, so
   the list drifts and the suite reports vacuously green while most lanes are unexamined."
$ disclosure check: the NO-CLAIM at :281 disclaims COLUMN 6 only; the NO-CLAIM at :341 disclaims
  SUFFICIENCY ("does not claim the eight gates are sufficient"). Neither discloses that the ROW
  SET is 8 of 12 tracked gate crates and 8 of 10 CI jobs.

## 05-actions — ZERO findings, and here is what was actually checked
Construct-existence census (names, not line numbers — line-cite drift is bead d1n's scope):
  PaneState::Unproven 13 | last_status_line 9 | MIN_GAP_SECS 15 | stable_hash 11 | Obscured 5
  WEDGED_UNSUBMITTED 2 | QueueUnreadable 6 | QueueEmptyNeedsJosh 8 | EXIT_BUSY 2
  EXIT_NOT_FREE 3 | EXIT_CONFIG 10 | is_dispatchable 34 | is_free_capacity 18
  needs_answer 3 | needs_attention 6 | QUEUE_WANT 4
  epic_exclusion_rule_never_selects_parent 1
  positive control 'PaneState' -> 120 ; negative control 'ZZZ_NOT_A_REAL_SYMBOL' -> 0
Values asserted by the section, all confirmed:
  crates/tick-monitor/src/lib.rs:490  pub const MIN_GAP_SECS: u64 = 75
  crates/loop-queue-filter/src/lib.rs:139  "QUEUE_WANT must be between 1 and 20"
  crates/pane-dispatch-fence/src/main.rs:16-18  EXIT_BUSY 75 / EXIT_NOT_FREE 76 / EXIT_CONFIG 78
  `Grade` absent: pub enum|struct Grade -> 0 (positive control: pub enum in crates -> 131),
  matching 05-actions:261's claim that Grade does not exist
Cross-section consistency: 04-diagrams:263, 05-actions:391 and 06-gates all use the SAME
"of 8" gate denominator — no contradiction BETWEEN sections; the denominator itself is
finding 2.

## Refuted sibling readings (recorded so they are not re-filed)
- A first reader reported UNWIRED_LANE_ALLOWANCE has 2 rows. Three readers agree it is 4
  (python regex over the const block; awk marker scan; sed range). The 5-vs-4 claim is already
  a taken finding from round 22 and is NOT re-filed here.
- A first reader proposed 06-gates:60's grep false-zero as a finding; the section discloses it
  itself as a "Historical tooling observation (not current acceptance)". Not a finding.

## Coverage NO-CLAIM
Of the 41 ledger rows naming these sections I personally verified the 1 FIXED row exhaustively
and sampled the DEFERRED set; 37 DEFERRED rows were NOT individually re-checked against their
sections. Both dispatched first readers aborted before writing their files (sandbox write
restriction), so their candidate lists are not incorporated. This round's zero for 05-actions
rests on the construct/value census above, not on a line-by-line re-verification of all 499
lines.

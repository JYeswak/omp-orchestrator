# Cross-grade — batch 6 by g-ntm-r14

## Result

**FAIL — 3 findings.** The listed crate names are real workspace crates. The WIRE rows are proposals, so absence of a current callsite is expected, but their validation text must not claim current behavior that the source does not show.

## Findings

### MAJOR 1 — `br:version` WIRE evidence claims an existing probe that is not present

Row 9 maps `br:version` to `installer` and says “installer/ompo preflight probes br --version before enabling dispatch.” The installer source inventory instead defines `BINARIES` as only `omp-orchestrator`, `tick-monitor`, and `pane-truth`; the current orchestrator calls `br ready --json` but does not show a version probe. The WIRE proposal is defensible, but its validation field misstates the current implementation.

**Fix:** Say that `br:version` is an unimplemented WIRE candidate because `br` is a required substrate, then make the version probe and its typed refusal the acceptance condition.

### MAJOR 2 — `br:list`/`br:init`-style VALIDATE semantics are repeated here in conditional form for `bv:exit-codes`

`bv:exit-codes` is marked VALIDATE for `loop-queue-filter`, but its validation says “if candidates/decision-relevant get wired we depend on bv exit semantics.” A conditional future dependency is not a current VALIDATE disposition; until a crate consumes the surface, it is WIRE or RETIRE. The row has not identified a current uncalled behavior that the crate already relies on.

**Fix:** Mark `bv:exit-codes` WIRE with the planned consumer and gain, or RETIRE it until a current dependency exists; reserve VALIDATE for behavior already relied upon without invocation.

### MINOR 1 — Several RETIRE validations are labels rather than evidence boundaries

Rows such as `br:stale`, `br:stats`, `br:status`, `br:upgrade`, `br:vcs-status`, and `bv:ago` use “reporting,” “meta,” “upstream product upgrade,” or “display formatting” as `validated_by`. Those are retirement reasons, not commands or explicit null-with-reason records, and do not identify the production search space used to establish non-use.

**Fix:** Use `validated_by: null` and put the exact production callsite search plus retirement reason in the companion notes, or provide a bounded command/result string.

## Positive checks

- The `bv` WIRE group is directionally aligned with the known zero-callsite problem and names `loop-queue-filter` as the intended graph-selection consumer.
- `br:ready` and `br:show` in batch 5 had stronger direct callsite evidence than the conditional/future validations in this batch.
- No maps_to_crate value in the displayed batch names a nonexistent workspace crate.

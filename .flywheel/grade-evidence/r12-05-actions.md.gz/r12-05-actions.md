# Round 12 — 05-actions.md — ABSENCE lens, role hillclimb — OliveCat
## DISPATCH
Subagent: `ActionsReader` (task agent, fresh context — file path + claim contract; no ledger, no
prior findings). Contract emphasized spot-checking crate cites against disk and true-strength
upstream claims. No jsm specialist exists for design-spec sections (catalog searched).

## VERIFIED FINDINGS (each re-derived by me before recording)

SEVERITY: MAJOR — A1 the frankenterm orphan_reaper quote ("A command-line match is not proof that
FrankenTerm created the process, and a PID can be recycled between discovery and signalling",
attributed to orphan_reaper.rs:1-14) DOES NOT EXIST in that file — my re-grep over both
frankenterm checkouts returns zero hits for the quote fragments; lines 1-14 carry a different
allowlist refusal. A verbatim quote presented with file:line that does not hold is the worst
finding class in this session's taxonomy (a fabricated scar). The substantive point (reaper ships
inert) survives; the quotation does not.
FIXED: quote removed; the paragraph now states the substantive point (inert-by-allowlist) as a
paraphrase with the file cite and drops the fake verbatim attribution. DIFF: A10 Jeffrey block.

SEVERITY: MAJOR — A2 the round-11 correction block itself carries a false cite:
`SessionStopEvent.settle` does not exist (the field list is type/messages/turn_id/
last_assistant_message/session_id/session_file/stop_hook_active/signal — "settle" appears only in
doc comments; the continuation knob is `SessionStopEventResult.continue?` at :325-331), and
SessionStopEvent's membership in RpcSessionEventFrame is not established by the installed types
(only AgentEndEvent is). A FIX THAT MADE THINGS WORSE: round 11 corrected A8/A10 to reference a
member that does not exist. Verified against shared-events.d.ts:83-93 (field list) and the agent's
:325-331 cite.
FIXED: the correction block now says "AgentEndEvent.willContinue (wire-proven) +
SessionStopEventResult.continue (the actual continuation knob, :325-331); SessionStopEvent's
RpcSessionEventFrame membership is UNVERIFIABLE from the installed types". DIFF: trailing
correction section.

SEVERITY: MAJOR — A3 `AsyncJobDeliverySink/State` cited at `dist/types/extensibility/async.d.ts`
— that path does not exist; the types live at `dist/types/async/job-manager.d.ts:38,52`. I
verified: extensibility/ contains no async.d.ts; async/job-manager.d.ts exists. A wrong path in
the round-11 fix. FIXED: cite corrected. DIFF: A6 upstream-vocab paragraph.

SEVERITY: MAJOR — A4 the --include=false-zero diagnostic is wrong as stated: BOTH invocations
return empty on this machine (re-derived: --include arm 0, plain arm 0; the real mechanism is
parenthesis-regex semantics — `grep -rlF 'forbid(unsafe_code)' crates` returns 62). The claimed
discriminating experiment (drop --include) yields zero in both arms. The negative (an
indistinguishable zero) stands; the diagnostic story does not. This correction ALSO invalidates
the same claim in 00-brief §1 and 06-gates §1, which I have NOT touched this round (out of my
sections) — flagged for the owners.
FIXED in 05-actions: the diagnostic paragraph now states the regex-grouping mechanism and the
62-file count with the exact commands. DIFF: A8(b).
CROSS-SECTION WARNING for the orchestrator: 00-brief §1's tooling warning carries the same wrong
mechanism and the stale 55-file count; it needs the same one-line fix (its section owner).

SEVERITY: MAJOR — A5 "15 named reasons" at :37-71 — actual count is 14 (I re-counted the enum
arms directly: 14). FIXED: 15→14. DIFF: A7.

SEVERITY: MINOR — A6 willContinue line-cite drift (154 vs the block's actual span) at four sites;
FIXED: cite re-anchored to the construct (the willContinue doc-comment block) rather than the
bare line, per PV8. DIFF: four sites.

## SEARCH SPACE
Full read of 463 lines; grep of both frankenterm checkouts for the quote fragments (0 hits);
direct reads of shared-events.d.ts field list and extensibility/ + async/ directory listings;
re-ran both grep arms for the --include diagnostic (0 and 0, then -F/-E arms 62); counted
ReceiptReason enum arms (14); cross-checked exit codes 75/76/78 against the pane-dispatch-fence
constants (:16-18) — consistent. NUMBERS.toml: no figures cover receipt-reason-count or
spawn-site-count — both DEFERRED to the orchestrator (the deriving commands exist but the scope
choice is doctrine).
Subagent: ActionsReader. new_findings: 6 (0 BLOCKER / 5 MAJOR / 1 MINOR), of which 5 FIXED
inline this round, 1 (A4's 00-brief twin) flagged cross-section for its owner.

# Round 10 — 02-surface-census.md — ABSENCE lens, role hillclimb — OliveCat
## DISPATCH
Subagent: `CensusReader` (task agent, fresh context — file path + claim contract only). This is
the section a numbers-specialist wants; no census skill exists in jsm's 135, so the general task
agent was told to re-derive every checkable number against the two named artifacts.

## VERIFIED FINDINGS (each re-derived by me before recording)
B1 [BLOCKER] final-census tables vs the artifact they name — three different internal snapshots
(lines 687-689: 30/46/25/490 engaged 101=17.1%; line 762: 30/66/25/407/UNPROBEABLE 63;
lines 789-790: engaged 121=20.5%), and NONE matches the live file. My re-run of the deriving
command right now: CONSUMED 32, WIRE 67, VALIDATE 30, RETIRE 453, UNPROBEABLE 9, total 591,
engaged 129 = 21.8%. The section never reconciled to its own final state; 135 rows carry
2026-09-01 evidence while the doc claims all-2026-08-31 measurements. Verified — the most
consequential finding of the round: the census's own final tables are three stale snapshots of
a moving artifact, and the newest is the closest but still wrong.
B2 [BLOCKER] the bv correction never replaced the artifact rows — §9.1 declares 29 scrape
artifacts; the map still carries all 29 (batches 1-13) PLUS 47 new --robot-* rows (batch 99) =
76 bv rows; and five of the KNOWN-BAD artifact rows are dispositioned WIRE, including bv:not-ready,
which the document's own §6 names as a word "harvested from wrapped description text". Verified:
map line 580 has bv:not-ready WIRE from batch 6. A row the document itself declares prose carries
"we will consume it" in the artifact of record.
B3 [BLOCKER] line 565 — "ee 0.14.2, 123 surfaces" vs 111 ee rows in the map; no reconciliation
anywhere. Verified (count by tool).
M1 [MAJOR] "19 relevant binaries installed" vs an 18-row table omitting ntm — the second-largest
censused consumer absent from the ref-census. Verified by reading the table.
M2 [MAJOR] coverage-ratio construction claims (62-67, 230-233) — accepted per agent's
arithmetic check; consistent with B1's root cause (tables derived at different times).

## What the hillclimb adds
My round-3 grade of this section found the slash-hole contradiction and the synthetic-row
denominator problem; the fresh agent found none of those (they're fixed) and instead found the
LIVE-DRIFT class: three unreconciled table snapshots and a correction that never reached the
artifact. That is the overfitting-proof the round needed — a reader with no history found what
four history-laden lenses had stopped seeing. new_findings=5 (3B + 2M).

# GRADE R3 — 03-crates.md (392 lines) — Pane %1408 — ALL FOUR LENSES
Findings appended as formed. Re-derivations listed with commands and results.

## RE-DERIVED NUMBERS (EVIDENCE lens, all verified before filing)

| claim (line/construct) | command | my result | verdict |
|---|---|---|---|
| 26 crates (line 60 "Twenty-six crates") | ls crates/ \| wc -l | 26 (dispatch-claim-fence now exists with src+tests) | HOLDS |
| 20 of 26 manifest forbid (line 92-93) | grep -l 'unsafe_code = "forbid"' crates/*/Cargo.toml \| wc -l | 20 | HOLDS |
| 25 of 26 inner attr (line 93-94) | grep -rlF 'forbid(unsafe_code)' --include=lib.rs --include=main.rs crates/ \| cut -d/ -f2 \| sort -u \| wc -l | 25 | HOLDS |
| 59 enums / 91 structs (lines 191-192) | the two grep -rhoE commands verbatim | 59 / 91 | HOLDS |
| 4 collisions (lines 203-205) | uniq -d pipeline verbatim | Finding LintReport Observation Violation | HOLDS |
| 6 Verdict enums (lines 220-221) | grep -rhoE '^pub enum [A-Za-z_0-9]*Verdict' | exactly the six named | HOLDS |
| omp-types ZERO dependents (line 238) | grep -l 'omp-types' crates/*/Cargo.toml | only its OWN manifest matches (name line) — zero external dependents | HOLDS (false alarm avoided by re-derivation) |
| leaf arithmetic 17 of 26 (lines 124-130) | count graph emitters | 9 emitters listed; 26-9=17; names match | HOLDS |
| "passes 13 tests" omp-inventory-map gate (line 308) | grep -c '#\[test\]' crates/omp-inventory-map/** | 23 total | CONFLICTS — see E3 |
| asupersync "dependency of seven crates" (line 316) | grep -n asupersync crates/*/Cargo.toml | EIGHT real dep lines + omp-types itself = 9 | FALSE — see E2 |

## FINDINGS

### ADVERSARIAL

A1 [MAJOR — overstated causal claim, load-bearing for the adoption path] (lines 209-215,
Observation-seam paragraph): "Had one type crossed the boundary rather than being re-declared
on each side, the mismatch would have been a compile error instead of a silent arithmetic
error." The free_capacity defect was SEMANTIC — the same `is_dispatchable` filter reused for
two meanings — not a shape mismatch. A shared struct makes two sides' SHAPES agree; it does not
by itself stop one side deriving a field from the wrong filter. What a shared type would have
caught is the two incompatible `Observation` declarations existing at all; the arithmetic bug
itself could survive full type convergence. FIX: restate as "the absent shared type made the
divergence possible; the filter defect itself is semantic and needs its own guard."

A2 [MINOR] (lines 52-58 vs 36-37): the "derivation command inline" promise is delivered as
FIVE BULK GREPS for the whole table; the `inputs (real)` / `outputs (real)` columns — the
actual contracts — carry no per-row command, and exactly one row (`pane-dispatch-fence`)
is marked `UNDECLARED`. A contract cell that was hand-read has no more provenance than the
census cells this section indicts. FIX: per-row derivation command (or `UNDECLARED`) for
every inputs/outputs cell, per the section's own line-38 standard.

### EVIDENCE

E2 [MINOR, but a false MEASURED number] (line 316, "Why this framework", first force):
"asupersync … is a dependency of seven crates today." Command above shows EIGHT external
dependents plus `omp-types` itself (nine). The direction of the argument survives — more
adoption than claimed — but a wrong measured number in the section's strongest persuasion
paragraph violates rule 1 in the doc's own writing contract. FIX: eight (state whether
omp-types counts, with the one-line command).

E3 [MINOR, cross-number drift] (line 307-308 "already passes 13 tests" vs brief §3.5 table
row `omp-inventory-map | 23`): my count of `#[test]` in that crate is 23. 13 appears sourced
from §3.6's earlier statement. Two different test-count figures for the same crate in two
sections, neither reconciled. FIX: one number with the counting command, or name what the
13 counts (a subset) explicitly.

### ABSENCE

B1 [MAJOR — the section's sharpest finding has no plan]: lines 200-215 measure the FOUR
colliding names and call `Observation` "structural rather than cosmetic … the direct cause of
the single worst row"; the adoption path (§ "Design spec") then covers Verdicts, ack dialects,
the omp-types gate, and the subprocess gate — and NEVER schedules the collision collapse. The
four names get zero PROJECTED rows. The reader is left with a measured wound and no treatment.
FIX: add an adoption step per collision (starting with `Observation`), each with owner and gate.

B2 [MINOR]: the crate table has no binary/library column — which of the 26 ship an installable
binary (the R8 story) is derivable only from the one `pane-dispatch-fence` row plus inference.
FIX: add a `ships binary` column (or a footnote list).

B3 [MINOR]: no consumer column — the opening (lines 30-34) indicts the census for describing
provenance instead of contract, yet the table's contract cells name no CALLER for 25 of 26
crates; the section's own vacuity recurs in its own artifact. FIX: add `consumed by` where
known, `none measured` where not.

B4 [MINOR]: no join to the gate story — 18 crates appear in neither the brief's 8-gate leg
table nor any wired-lane narrative in this section; R4's "every crate" and the gate framework
never meet in one table. FIX: a one-line pointer column (`gate: none` / gate name).

### INVESTOR

I1 [MINOR]: no trust-over-evidence spots found — risk framing (lines 164-169: leak risk with
mechanism, "at least 25 spawn sites") is evidence-backed and honest. But that "at least 25"
carries no deriving command in-section (the brief's 29-sites figure minus compliant-crate
sites is unstated arithmetic). FIX: show the subtraction or cite the brief line it comes from.

### VERIFIED-HOLDS LIST (recorded so the next round does not re-hunt)
- 26/20/25, 59/91, 4 collisions, 6 Verdicts, 17-of-26 leaves, four dependents of
  subprocess-contract, omp-types zero external dependents — ALL re-derived and holding.
- Constraint 3 (line 379-382, pane-dispatch-fence no lib surface) — consistent with the
  table's UNDECLARED row.
- The omp-types feature-boundary correction (lines 243-266) is the section's best work:
  a corrected brief claim, with the upstream reason, and the migration honestly BLOCKED.

---

## CHALLENGE TO r2-investor.md (%1414's round-2 investor grade)

CH1 [MAJOR 1 — mutation status is a naming proxy]: **HOLDS, and is now confirmed by the brief
itself.** 00-brief.md line 304-305 (current file) quotes `%1414`'s refusal — *"the typed rebuild
still defines AUTOMATED by a keyword grep"* — and answers **"Correct."**; line 328 restates the
bad definition verbatim (`AUTOMATED = a #[test] fn whose name contains "mutation"`). The
underlying finding was right and the brief has absorbed it. No overstatement found; the
receipts-based fix proposal is the correct shape. ONE PROVENANCE NOTE: the sibling's anchors
("lines 271–277", "line 273 defines AUTOMATED…") do not exist in the current 816-line file —
the construct moved to ~300-330. The quote "derived per crate, not by keyword count" is now
unverifiable in the live file, which is the doctor.rs:924 lesson executed in real time: cite
the construct, not the line. The substance survives; the citation does not.

CH2 [MAJOR 2 — stale five/nine counts]: **SUBSTANCE SUPERSEDED; CITATIONS NOW WRONG.** Against
the current file, the three cited five-mentions are inside the §7 correction-narrative
blockquote (lines ~584-595), which quotes the erroneous history — that is the block's purpose,
not a live claim — and the live conclusion at ~625 now reads "corrected **ten** times" (updated
past the sibling's snapshot). The mechanism the finding guarded (counts derived from one
source) is implemented per the blockquote's own note. What REMAINS live is narrower and new:
line 625's "ten" is derivable only as nine table rows + §7.4's tenth seeded-refutation
(line 701), and the sentence does not say so — a reader reconciling table-nine against
prose-ten sees a NEW inconsistency of exactly the class the finding was about. FIX (one
clause): "ten — the table's nine plus the §7.4 self-refutation". So: the sibling's specific
citations are stale against the live file; a smaller true defect sits where they pointed.

CH3 [BLOCKER 1 — registration is not resolution]: **HOLDS.** Q1-Q3 remain OPEN (§8.2), the
brief's own NO-CLAIM (§8.4, "answers none of them") concedes the exact point, and the finding
is honestly labeled "(ROUND-1 BLOCKER UNFIXED)". Rank BLOCKER is fair for the investor lens's
mandate; the prescribed fix ("state the project is speculative internal R&D") is a legitimate
alternative exit. One fairness note: this is the same hole I filed as round-1 B1 from the
absence lens — independent convergence by two lenses is corroboration, not duplication.

CH4 [MAJOR 3 — kill criteria not executable]: **HOLDS.** K2's observable admits its own
instrumentation "is itself unowned" (line 699 of the snapshot; construct verified in my
round-2 pass too), K3 "never attempted", K1's "two attempts" undefined. I flagged the K2
shape independently in round 2 (my N4) — convergence again. The owner-column demand matches
my round-2 N3 (role-word owners). Both lenses arrived at compatible fixes from different
angles; I adopt theirs for K1's attempt-definition and they should adopt my bead-id/path
owner form.

CH5 [trust audit]: No not-found claims exist in the sibling file, so the false-zero rule is
not implicated. One claim was taken partially on trust: the "derived per crate, not by
keyword count" quote (above, CH1 provenance note). Everything else I re-verified against the
live file and it held.

## CROSS-CUTTING NEW FINDING (from this challenge, applies to the grading process itself)

P1 [MAJOR]: **The brief grew 726 → 816 lines WHILE four graders held snapshots of it**
(`stat -f %Sm` → 18:34:07; read-header 726 at my round-2 pass, 816 now). Every line-anchored
finding filed this round against 00-brief.md is anchored to a moving target, and the §7.3
staleness predicate the brief itself demands is live AT GRADING TIME in the inverse direction:
the SOURCE is now newer than every grader's citation base. FIX: freeze a snapshot copy
(docs/plan/.snapshots/00-brief@round-N.md) at round start; all graders cite the snapshot;
the live file is graded next round.

---

## FINAL ROUND-3 VERDICT — 03-crates.md

VERDICT: PASS-WITH-FIXES

THE ONE THING: The section's sharpest measured finding — four colliding type names, with
`Observation` named "the direct cause of the single worst row" — has no corresponding adoption
step anywhere in its own Design spec (B1). The section measures a wound, explains its causal
mechanism, and then schedules treatments for three OTHER wounds. One PROJECTED row per
collision, starting with `Observation`, is what closes it.

Counts this round: BLOCKERS 0 · MAJORS 3 (A1 overstated causal claim; B1 missing collision
adoption step; P1 live-drift during grading — process-level) · MINORS 8 (A2, E2, E3, B2, B3,
B4, I1, and the CH2-residual "ten" clause).
Nine of eleven load-bearing numbers re-derived and HOLDING (table in file); one false number
found and corrected (asupersync "seven" → eight external + omp-types = nine); one cross-number
conflict found (13 vs 23 tests for omp-inventory-map).

# Round 4 — four-lens grade of `06-gates.md`


## INVESTOR

MAJORS: 1

1. **The section prices gate rigor without showing the return** — [06-gates.md:318-334, construct: “Gating discipline concentrated where the product is not” and the 370-test proxy warning]. It correctly concedes that eight gates and 370 tests guard a pipeline that cannot yet dispatch or complete, but never quantifies avoided incident cost, release-risk reduction, operator time saved, customer outcome, or what materially changes if all six properties become true. “The gates encode defect classes” is a rationale, not an investment case. **FIX:** Tie each gate family to a measured failure cost and a projected customer/release outcome, with a kill threshold for rigor that costs more than the risk it retires.

## ADVERSARIAL

BLOCKERS: 2

1. **The section’s own “live RED” claim is explicitly downgraded to inspection-only evidence later** — [06-gates.md:7, 189-207, construct: §2.8 leg-3 RED status]. The opening says §2.8 reports a “live RED,” but line 207 says `PROJECTED-BY-INSPECTION, not observed` and that no test was run; inspection of a predicate and its inputs is not an observed gate failure. **FIX:** Label the result `PROJECTED-BY-INSPECTION` everywhere unless an actual invocation produces the RED, and reserve `LIVE RED` for observed execution output.

2. **The inventory is stale against the typed source it claims to match** — [06-gates.md:13, 24-55, construct: per-gate table and 2-of-8 headline]. The section says its table matches the brief exactly and derives “2 of 8” from numeric mutation counts, but the current brief rebuild changed mutation to typed `AUTOMATED / MANUAL / AFFORDANCE / NONE` and changed the qualifying headline to `1 of 8`, with `undrained-pipe-lint` as the sole qualifier. This section therefore republishes the retired untyped interpretation while claiming source agreement. **FIX:** Generate this inventory and headline from the typed gate registry rather than maintaining a second numeric snapshot. 

MAJORS: 2

1. **The `-V` measurement remains the previously refuted 5-of-9 value** — [06-gates.md:57-61, construct: version-probe hazard]. The section says `tmux -V` returns `tmux 3.6a` at exit 0, yet still reports “`-V` answers 5 of 9”; the corrected nine-binary re-derivation is six responders including tmux. The same paragraph uses its own successful tmux observation to contradict its count. **FIX:** Replace 5/9 with the corrected six-of-nine result and make the responder list the source of the count.

2. **The leg table is sourced by a measurement method the section proves is unreliable** — [06-gates.md:24 and 57, construct: `grep -rli <property>` per-gate inventory]. Line 24 calls the grep-derived table `MEASURED`, while line 57 says the shell grep and per-crate grep loop report false empty results against files already known to contain the predicate. The section never shows a second per-cell derivation, so the table’s zeros and its 2-of-8 headline remain attributable to the broken probe path. **FIX:** Rebuild every cell from a fail-closed parser or typed inventory artifact and publish the per-cell command/result rather than warning about the grep after using it. 

## ABSENCE

MAJORS: 1

1. **R13 lifecycle is not carried by the gate-admission stage** — [06-gates.md:291-314 and 318-340, construct: new-gate admission/meta-gate lifecycle]. **TEMPLATE** is only partial (a prose checklist, no canonical gate record/schema); **DISPATCH** is missing (no bead/owner/assignment path for a candidate gate or RED result); **REAP** is missing (no close, stale-allowance retirement, or unblocking flow); **LOGGING** is only partial (PASS/FAIL/SKIP plus an evidence path, but no durable run identity/timestamp/result ledger); **BUILD GRADING** is missing (the meta-gate is future tense and line 340 says no validator exists). The section specifies what a gate should satisfy but not how gate work is templated, sent, reaped, logged, or graded as a build artifact. **FIX:** Define one canonical gate record and an executable lifecycle that creates/dispatches/reaps/logs/grades it, with owners, evidence paths, build identity, and retirement transitions. 

## EVIDENCE

Re-derived numbers before grading: the section’s own filesystem command for test files/functions returned `27 379`, not the displayed `26 370`; the table arithmetic independently returns `2` all-four-leg rows, `4` no-mutation, `4` no-anti-vacuity, `2` no-known-bad, and `1` no-known-good. The arithmetic is reproducible against the table, but the primary inventory is stale against the current workspace.

MAJORS: 1

1. **The measured inventory is stale and unpinned** — [06-gates.md:13-24, construct: 26/370 filesystem census]. Running the exact displayed walk `python3 -c "import pathlib,re; c=pathlib.Path('crates'); print(len(sorted(c.glob('*/tests/*.rs'))), sum(len(re.findall(r'#\[test\]', p.read_text())) for p in c.rglob('*.rs')))"` returned `27 379` in the current workspace, while the section records `26 370`. The section supplies no commit, manifest hash, or artifact identity that would make the older measurement a valid historical snapshot, and its claimed independent agreement is therefore not current evidence. **FIX:** Pin the inventory to a content-addressed source revision or regenerate the counts at grading time and record the exact revision and file set.

MAJORS: 3

2. **Property 5 is measured by the substring heuristic that the admission checklist forbids** — [06-gates.md:246-253 and 300, construct: six-by-eight claim-discipline matrix]. The matrix marks three gates `Y` because grep finds `NO-CLAIM`, `STILL PASSES`, or nearby prose, but the admission rule says a predicate must target the property rather than a substring conjunction over a whole file. A comment or test fixture can satisfy the regex without being a gate header or an enforced claim contract. **FIX:** Parse a structured ENFORCES/STILL-PASSES/PROVENANCE record or use a dedicated validator, and report grep only as candidate discovery.

3. **The six-crate RED inventory is called measured without publishing the derivation** — [06-gates.md:197-207, construct: `every_crate_declares_the_forbid_lint` RED]. The section gives `26/20/25`, six missing manifests, and one missing source root, but only says “measured with an inline Python walk”; no executable walk, input snapshot, or per-crate result is printed. It then correctly labels the RED “not observed,” but the reader still cannot reproduce the inspection that allegedly finds the six failures. **FIX:** Publish the exact fail-closed inventory command and content-addressed input/result, and keep the outcome explicitly `PROJECTED-BY-INSPECTION` until invocation evidence exists.

## CHALLENGE TO r3-01-idea

1. **The sibling’s commercial not-found is methodologically too narrow** — [r3-01-idea.md:7-10, construct: investor/economic-absence proof]. The regex `\b(customer|buyer|payer|revenue|pricing|ROI|willingness|paying|paid|competitor|sales|purchase)\b` can disprove those exact terms in `01-idea.md`, but it cannot establish that the section contains no economic case; “operator,” “budget,” “spend,” “labor,” “hours,” or other business language could carry the answer. The sibling’s underlying finding may hold, but its command cannot support the universal absence conclusion. **FIX:** Search a defined economic vocabulary plus structural evidence fields, or state the narrower claim that the listed terms were absent.

2. **The sibling takes its strongest gate claim from another grade artifact rather than an independent re-derivation** — [r3-01-idea.md:59-62, construct: Section 1.5’s “retired” 2-of-8 conclusion]. The claim that only one gate qualifies is imported from `r2-adversarial.md:5` and then treated as authoritative; no current table or source query is re-derived in the sibling file. The conclusion is probably right, but it is second-order evidence and inherits any stale or methodological error in that grade. **FIX:** Recompute the typed gate status from the current source or cite a content-addressed authoritative registry instead of a prior grader’s prose.

3. **The sibling’s challenge to the actionable-row finding conflates two claims** — [r3-01-idea.md:64-67, construct: source predicate versus live producer behavior]. It is correct that a source search for separate fields does not prove the live producer/parser path; however, the challenged finding was also a direct contradiction of the brief’s specific “same filter” implementation claim, for which the source construct is probative. The underlying need for live-path evidence holds, but calling the static contradiction itself overstated is too broad. **FIX:** Split the finding into “the cited implementation claim is false” and “the live producer-to-decision path remains unverified,” with separate severity and evidence.

4. **The sibling’s “no sibling not-found was too narrow” conclusion is not established** — [r3-01-idea.md:64-70, construct: cross-grade search-space conclusion]. It asserts that all relevant not-found searches had adequate scope without showing the complete set of commands or checking the false-zero mechanisms it names elsewhere; absence of a bad example in the cited subset is not evidence that no narrow search exists. **FIX:** Audit each cited not-found command against the exact claim universe and publish the search-space argument per finding before making the global “none” statement.

## SUMMARY

BLOCKERS: 2
MAJORS: 7
MINORS: 0

R13 lifecycle result: DISPATCH, REAP, and BUILD GRADING are missing; TEMPLATE and LOGGING are only partial.

VERDICT: FAIL
THE ONE THING: This section describes a rigorous gate bar but its own inventory is stale, its headline evidence is partly inspection-only and grep-derived, and no independent lifecycle carries a gate from template through build-grade and reap.

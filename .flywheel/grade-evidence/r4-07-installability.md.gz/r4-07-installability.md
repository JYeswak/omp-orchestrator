# GRADE R4 — 07-installability.md (467 lines) — Pane %1408 — ALL FOUR LENSES + R13
Findings appended as formed. Re-derivations with commands and results inline.

## RE-DERIVED NUMBERS

| claim (line/construct) | my command | result | verdict |
|---|---|---|---|
| 18 binaries (line 15-16) | grep -rl 'fn main' crates --include=main.rs \| wc -l | 18 | HOLDS |
| BINARIES=3 incl pane-truth (17-18) | sed -n 12p installer/src/main.rs | exact match | HOLDS |
| pane-truth GHOST (24-25) | ls -d crates/pane-truth | No such file (lives in control-plane) | HOLDS |
| tick-monitor --version 0 (33) | grep -c version crates/tick-monitor/src/main.rs | 0 | HOLDS |
| 5 of 18 mention --version (36-39) | per-crate loop | exactly the five named | HOLDS |
| 50 mirror install.sh (299) | ls $M/*/install.sh \| wc -l | 50 | HOLDS |
| 29/50 install -m 0755; 16/50 completions | grep -l 'install -m 0755' / -il completion | 29 / 16 | HOLD |
| 38/50 checksum (300) | grep -lE 'sha256\|shasum -a 256\|sha256sum' | **40** | DRIFT — pattern not stated, cannot reproduce exactly |
| 17/50 uninstall (300) | grep -il uninstall | **25** | CONTRADICTS by 8 |
| 8 build.rs mirror repos (267-268, 419-421) | the section's OWN grep command, verbatim | **18 repos** | FALSE — >2x under its own stated command |
| drift-denominator defect "still in the tree" (55-65) | grep let-owned/foreign installer/src/main.rs at HEAD b8356ea | DEFECT GONE: line 68 `let mut foreign`, line 74 `let mut owned`, both incremented; foreign printed as excluded | STALE — see A1 |

## FINDINGS

### ADVERSARIAL
A1 [MAJOR] (line 55 construct: "MEASURED — the drift denominator defect is still in the tree",
anchored to installer/src/main.rs:68/:87 shadowing): present-tense claim falsified at grading
HEAD b8356ea — the code now carries two live counters (`let mut foreign`, `let mut owned`),
increments both in match arms, and prints "excluded from drift denominator" for foreign. The
defect the section headlines is FIXED. The section pinned its measurement HEAD (good), but
"still in the tree" is now wrong, and §4's design commitment ("The denominator is printed with
its derivation") cites this defect as its motivating MEASURED instance. FIX: re-stamp as
"was in tree at fb89714; fixed by b8356ea; retained as the regression case for rule 2".

A2 [MAJOR] (lines 267-268 and 419-421, construct: "Eight mirror repos ship the same shape"
+ the verbatim grep): re-running the section's OWN command returns EIGHTEEN distinct repos.
The named eight are a hand-picked subset presented as the grep's output. A reader who runs the
shown command gets a number 2.25x the claim. FIX: either state the eight as a curated subset
("eight exemplars of the eighteen that match") or print the 18 and select from them.

A3 [MINOR] (lines 216-218, exit-code dictionary, construct: two rows for code 2 — USAGE and
UNKNOWN-envelope): a caller branching on the integer alone cannot distinguish "fix your command
line" from "treat as not-green"; the table's own Caller-should column gives contradictory
instructions for the same code. The envelope status disambiguates, but the dictionary never
says the integer is insufficient without the envelope. FIX: one sentence — "code 2 is always
paired with the envelope; branch on status, not the integer".

### EVIDENCE
E1 [MAJOR] (lines 299-301, the mirror quartet 38/29/17/16): only the 50 has a command; the
four compliance percentages carry none, and two of the four do not reproduce (38 vs my 40;
17 vs my 25) under the natural greps. My patterns may differ — which is precisely the point:
without the stated command the numbers are unauditable by the section's own rule 1.
FIX: print the four exact greps next to the four numbers, or drop the quartet to the two
that reproduce (29, 16).

### ABSENCE
B1 [MAJOR — R13 lifecycle, five-part check for the INSTALL/DISTRIBUTION stage]:
- TEMPLATE: present (§5 adopts /installer-workmanship wholesale with named checklist).
- DISPATCH: MISSING — "CI uploads it to the GitHub release" (line 316-317) has no owner, no
  bead, no cadence, no release-decision rule; who is allowed to cut a release of ompo is
  nowhere written.
- REAP: MISSING — uninstall exists as "printed uninstall instructions" (line 297) and a 17/50
  house-style stat; there is no `ompo uninstall` verb, no plist-removal design, no
  downgrade/rollback path for an installed fleet (repair's backup path covers repair, not
  removal).
- LOGGING: present (§2 `ompo audit` append-only ledger with provenance rows).
- BUILD GRADING: present (§4 four-way identity proof + §5 post-install acceptance).
So two of five are missing: DISPATCH and REAP.
FIX: add a release-authority subsection (owner, bead, cadence, sign-off rule) and an
`ompo uninstall` design (plist teardown, binary removal, ledger closure) to §5.

B2 [MINOR]: no crate→adapter mapping list — §2 scopes all 18 binaries as adapters under
`ompo` but names only tick-monitor as an example; a reader cannot tell whether the adapter
namespace is crate names, binary names, or a third scheme. FIX: one table crate→adapter in §2.
B3 [MINOR]: the curl|bash bootstrap's own integrity relies on TLS alone — the SHASUMS256.txt
verification protects the fetched binary, but nothing can verify the bootstrap script before
it runs. This residual risk is real for every house installer and is never named. FIX: one
NO-CLAIM sentence ("bootstrap integrity = TLS + release pinning; no pre-exec verification
exists for any curl|bash installer, including ours").

### INVESTOR
I1 [MINOR]: §2 is 120+ lines of PROJECTED contract with zero working slice — the section
proves the PRESENT honestly but the future is all spec. The one thing that would move an
investor is a named thin slice (e.g. `ompo doctor omp-orchestrator` against the real fleet)
with a milestone. FIX: name the first vertical slice and its §09 milestone in §2's opening.
No trust-over-evidence violations found otherwise; the "nothing yet, and we can prove it"
framing (lines 3-5) is the strongest honest open I have graded.

---

## CHALLENGE TO r3-02-surface-census.md (sibling: surface-census grader)

C1 [their ADVERSARIAL BLOCKER — slash_command tally vs envelope contradiction]: **HOLDS,
independently re-verified.** I ran their re-derivation against the same artifact:
python3 Counter over /tmp/inv.txt → slash_command_rows=1, total=183, artifact dated
Aug 31 16:50, 544697 bytes. The row-kind tally (1) vs envelope count (0) contradiction is
real, and the synthetic-row-as-surface problem underlies their ABSENCE blocker too. My
round-2 reads of the section (lines 34/40-42, UNKNOWN_PROBE construct) corroborate. No
overstatement found — this is their sharpest finding and the fix (non-surface kind
`probe_gap`) is right.

C2 [their EVIDENCE MAJOR 3 — non-commands printed as evidence]: **HOLDS.** grep -c "…"
02-surface-census.md → 8 occurrences of the literal ellipsis; the vacuity probe in the
section is the same abbreviated `python3 -c "…"` form the brief carries. A template that
cannot run as printed cannot be MEASURED evidence. Their proposed PSEUDOCODE label is the
right fix.

C3 [their ABSENCE BLOCKER 1 — no independent oracle]: **HOLDS on substance.** I could not
find a source-reading or external-enumeration reconciliation anywhere in the section
(grep for exclusion/ORACLE constructs → only "never seen"/"never satisfied" prose, lines
147/159 — the gap, not a check). The scanner-can-omit-and-still-agree argument is sound.

C4 [their challenge to ME — M1 glossary false-zero]: **CONCEDED IN FULL.** My round-2 file
certified glossary absence with `grep -ic glossary → 0` — which proves only that the WORD
"glossary" is absent, not that definitions are. A "Terms" or "How to read" heading defining
bead/reap/tick would have scored zero on my command. The CONCLUSION still holds (I have read
the full brief twice this session: R1-R11 are verbatim jargon with no definitions anywhere),
but my evidence was exactly the false-zero pattern this session has now recorded eleven
times. The finding survives on full-text reading; the command dies. Their challenge is
correct and makes the record honest.

C5 [their challenge to ME — N3 role-word owners]: **CONCEDED BY HALF.** "Violates the
document's own thesis" was overstated: §8.2 is a durable written table, which is not pane
scrollback; the thesis concerns perishable channels, and a named human owner in a committed
table is stronger than that. What survives is the strengthening proposal (owner as bead-id/
path + decision SLA) — a MINOR proposal, not a failed implementation. Their downgrade is
accepted.

C6 [their challenge to ME — N2 scheduler causal claim]: **CONCEDED AS SPLIT.** My "only
exist because a scheduler fired" sentence had no command behind it in the graded file, and
pane-1's session context (controller-tick crontab) is outside the document under grade.
The table omission (no trigger/driver row) stands on its own; the causal framing is
withdrawn as unevidenced-inside-the-artifact. Their proposed split is the correct record.

C7 [their challenge to ME — N1 eighteen NONE rows]: **CONVERGENCE, NOT REFUTATION.** My fix
read "18 NONE rows OR state the denominator"; their fix is "require an explicit gate-universe
query" — the second arm of my own disjunction. No disagreement to invent. One refinement I
keep: the typed NONE status existing in the table with zero uses is itself the smell, and a
gate-inventory query that returns 8 should say so in the table's caption.

## R13 LIFECYCLE ANSWER (required this round)
For the INSTALL/DISTRIBUTION stage: TEMPLATE present, LOGGING present (ompo audit),
BUILD-GRADING present (four-way identity), **DISPATCH missing** (no release owner/bead/
cadence/sign-off — "CI uploads it" is unowned), **REAP missing** (no ompo uninstall verb,
no plist teardown, no fleet downgrade path). Two of five absent. Filed as B1 above.

## FINAL ROUND-4 VERDICT — 07-installability.md

VERDICT: PASS-WITH-FIXES

THE ONE THING: Two of the section's MEASURED headline numbers die on re-derivation — the
drift-denominator defect is already FIXED at HEAD (A1) and "eight mirror repos" is eighteen
under the section's own command (A2) — in a section whose entire premise is "identity claims
must survive re-derivation." An installability section whose own artifacts drift is the
23-commits-behind launchd story happening to the plan. Fix A1/A2/E1 (re-stamp the defect,
correct the count, print the four greps) and this section is the best in the document.

Counts: BLOCKERS 0 · MAJORS 4 (A1, A2, E1, B1/R13) · MINORS 6 (A3, B2, B3, I1, plus the
bootstrap-integrity and adapter-mapping notes). Concessions to sibling: C4 full, C5 half,
C6 split — recorded, not hidden.

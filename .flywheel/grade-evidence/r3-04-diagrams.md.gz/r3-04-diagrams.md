# GRADE R3 — 04-diagrams.md — ALL FOUR LENSES (pane 5, %1409)
# Independence rule acknowledged: this packet names no suspected defect. Findings below are only
# what derivation produced. Cross-challenge of /tmp/grade/r2-evidence.md at foot.

## FINDINGS — 04-diagrams.md (all four lenses; every number below re-derived this round)

### B1 [ADVERSARIAL+EVIDENCE] L286-288: the not-found is false — the mirror contains the exact prior art, and our own tool family builds it
- Printed: "Searched for a generated-architecture-diagram gate specifically: no prior art found in the mirror for emitting mermaid *from* a dependency census as a CI artifact. That one we build."
- Measured: a mirror-wide scan for 'mermaid' in *.rs returns **26 files**, including `beads_rust/src/cli/commands/{graph,dep,capabilities}.rs`; `beads_rust/src/cli/commands/graph.rs:1216` documents **`br dep --format mermaid`** — dependency edges rendered as mermaid, i.e. exactly "emitting mermaid from a dependency census". (Our installed `br 0.4.1` lacks the flag — `br dep` offers only add/import/remove — so the mirror's beads_rust is newer than the wrapped binary; the construct exists at the pin's own upstream family.) The section's own grep ("surfaces franken_markdown/... only", L282-283) and this not-found cannot both be products of the printed command.
- Under §6.7 and L567-569 doctrine this not-found is unpublishable; under the section's own goal it commits to building what the mirror already ships. FIX: re-run the search, cite beads_rust dep/graph.rs, and re-scope "that one we build" to the true delta (CI diff-on-regression gate).

### B2 [EVIDENCE] L262 vs L321: the file contradicts ITSELF on the leg count, and both values are stale against its declared source
- Diagram 4 (L262): "**2 of 8** gates have all four legs — no-shell-gate and undrained-pipe-lint". Diagram 5 note (L321): "`M` exists at **1-of-8** leg coverage". Current §00 (round-2 rebuild): **1 of 8 — undrained-pipe-lint**, typed statuses, no-shell-gate = AFFORDANCE.
- mtimes: 04-diagrams 1788219758 predates the round-2 brief (1788222727) by ~50 min — the section declares §00 §3.5 its source (L20-21), the source moved, and the section carries three historical values of one number without reconciliation. The section's own L24-31 ("a generated diagram that is generated once... rots on exactly the same schedule") is self-demonstrating within hours. Diagram 3 additionally still shows the round-1 five-node spine (consume as one FENCED node), pre-dating the seven-row split. FIX: regenerate Diagrams 3 and 4 from the current typed §00 tables and add the cross-section staleness predicate (no section may cite a superseded table).

### M1 [EVIDENCE] L100-101: refutation #3 of the document's own §7 table survives verbatim here
- Printed: omp-types "re-exporting AckKind, DeliveryClass, ObligationLedger, Budget, Outcome". Measured at HEAD: `ObligationLedger` occurs **0** times in crates/omp-types/src/lib.rs; `AckKind`/`DeliveryClass` occur only in doc comments (L26/33/35/122 — all `//!`/`///`), not in any `pub use`. Only Budget and Outcome are genuinely re-exported.
- This is the exact claim §00 §7 row 3 records as refuted ("read the intent, not the file"), still asserted — and it inflates the convergence scoreboard this section proposes (L121-123: "omp-types in-degree is 0. That number is the scoreboard") by making the crate look closer to its purpose than it is. FIX: print the corrected re-export set and the blocked-vocabulary boundary (messaging-fabric).

### M2 [EVIDENCE] L281: "(216 repos)" — the retired denominator, surviving
- §00 §3.7: 216 "is re-derivable from nothing"; the four defensible counts are 218/217/**210**/1 (all re-measured round 1: exact). FIX: 210.

### M3 [EVIDENCE] L360: "51 public enums, 79 structs, 22 of 24 crates" — the unreproducible snapshot, cited as the SOURCE for D6's 17-ack-types figure
- Round-1 re-derivation: 51/79 has no deriving command and is unreproducible at HEAD (same scope = 59/88); current two-scope truth is 59/91 across 24 of 26. The 17-types/3-dialects conclusion survives (scope-independent), but its printed source is a stale figure. FIX: cite the two-scope error bar or the typed inventory command (`omp-inventory-map types`).

### M4 [ADVERSARIAL] Diagram 3's "(MEASURED)" tag (L176) covers code-reading plus an inference chain, and the status is stale at HEAD
- L204-206: layer 2's status is derived "from reading idle_panes and free_capacity" with the t=0 exclusion argued, not measured — inference wearing MEASURED (brief rule 2's named defect). And the status itself ("BROKEN — discards NewlyIdle", L181/L187) is fixed at HEAD by -oco (`is_free_capacity` separate field, omp-orchestrator/src/lib.rs:162-175; comment at :452 names the bead). FIX: re-derive layer 2 at HEAD, re-tag, and regenerate the loop from the seven-row spine.

### m1 [EVIDENCE] Bare inherited numbers: "29 raw spawn sites" (L108), "162 refused ticks across 4.2h" (L188 diagram, L207 prose — source given only as "the tick ledger")
- No deriving command in this section; §00 carries commands for neither (round-2 M4, still open). FIX: attach commands or point at §00 rows that carry them.

### m2 [ABSENCE] L16-19: the source of truth for Diagrams 1/2/6 is `/tmp/inv.txt` — ephemeral storage
- The provenance artifact dies on reboot; the section demands CI emission (L27-29) while parking its own evidence in /tmp. Same class as "seven conditions living only in pane scrollback". FIX: commit the census JSON under docs/plan/data/ or name the regenerating command as the source of record.

### m3 [ABSENCE] Diagram 2's UNTOUCHED node (L142) mixes two axes in one list
- Kind counts (39+57+14+42+3 = 155) beside a classification count (157) with neither summing to the 176 in the label (176 = 183 − 7 consumed, verified). A reader will add them. FIX: split by axis and show 176 = 183 − 7.

### m4 [ABSENCE] Diagram 5 omits the timeout path its own prose calls "the single hardest link" (L324-329)
- J's no-ack branch exists (L307); the timeout → typed DeliveryClass branch exists only in prose. FIX: add the edge or an annotation node.

### m5 [ABSENCE] The CI requirement (L27-29) diffs mermaid SOURCE but nothing establishes it RENDERS
- linkStyle indices, `<br/>` labels and `--)` arrows parse-or-fail silently; a non-rendering diagram is exactly the fake the section opens by forbidding (L9-14). FIX: add render-or-fail to the generator requirement.

## RE-DERIVATION LOG (this round)
17-in-DAG/9-isolated ✓; 8 leaves ✓; 5 roots ✓; max fan-out 5/4 ✓; 7 consumes targets = L133-139 EXACT ✓; 176 = 183−7 ✓; omp-types five-name grep → refutes L100-101; mirror 'mermaid' census = 26 files → refutes L286-288; beads_rust graph.rs:1216 `br dep --format mermaid` ✓ (installed br 0.4.1 lacks it); mtimes ✓; brief now 786 lines (was 726/717).

## CHALLENGE TO /tmp/grade/r2-evidence.md (my own round-2 file — assigned target)

**R2-4 is wrong on both prongs, and I retract it.**
- Prong 1, "the quote appears in NO artifact": FALSE. The quote is real at `g-adversarial.md:10` — %1414's own BLOCKER 1, fix line: "Retire this table and rebuild it with typed automated, manual, affordance, and none statuses..." (verified this round; §7.4 at L675 cites the same line). My round-2 search covered g-absence.md and p1414.txt and never opened g-adversarial.md — a sibling file in the same directory. That is the round-1 "search space too narrow" defect (§7 row 5), committed by the evidence auditor, inside an evidence BLOCKER. The honest version of my finding was one command away.
- Prong 2, "their actual BLOCKER 1 is the missing economic dimension": I took that from g-absence.md — whose header names **Pane 4 (%1408)**, not %1414. I conflated two graders' files under one pane id, then declared %1414's real blocker nonexistent. %1408's economic B1 was real too — it became §8/R12 — but it was never %1414's.
- What survives: (a) the seed-chain observation (p1414.txt:35 asked "should it be retired and rebuilt? Argue it") — §7.4 confirms the independence was manufactured, so the CONDUCTOR's round-1 write-up was inflated even though %1414's demand was genuine and its typed-statuses FIX went beyond the prompt; (b) the discipline demand — re-source §7 quotations on disk — produced §7.4, which exonerates the brief. The finding was wrong; the audit step it demanded was still worth running.
- Also verified for fairness: my R2-1 (deriving-command mismatch) and R2-2 (known_bad=0 keyword artifact) re-verified independently this round and HOLD; R2-7 (/Users/josh, 6 files) still live and unfixed; R2-8 (Q7/Q8 cells) still live at L775-776; R2-6's brief-side ordinals are now SWEPT (zero hits for five/eighth in the 786-line brief) — the residual is PLAN.md's header only (still "Eight... six" at L19 per round-2 check; assembly predates the brief).
- Lesson, stated plainly: my round-2 BLOCKER was the round-1 defect wearing my name. A not-found from an evidence lens needs its search space named even when the lens is evidence.

## VERDICT: FAIL
## THE ONE THING: the section's own rot warning came true before the section finished being graded — Diagram 4 and Diagram 5 print two different counts of the same property, both stale against the source they cite, while the section's not-found ("That one we build") is disproven by `br dep --format mermaid` sitting in the mirror it names. The diagrams are honest about the system and unproven about themselves.

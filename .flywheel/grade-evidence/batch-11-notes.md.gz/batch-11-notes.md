# Batch 11 notes — OMP RPC handlers

## Scope
30 OMP rpc_handler rows: abort_and_prompt through set_follow_up_mode. These are actual RPC handler names, not scrape artifacts.

## CONSUMED
Four handlers are CONSUMED by the bounded OMP RPC adapter: negotiate_protocol, get_state, get_session_stats, and get_messages. `crates/omp-rpc-session/src/lib.rs:243-292` defines the closed `RpcRequest` enum, maps each to its command name, sends all four in `RpcRequest::sequence()`, and serializes each frame. This is the only current crate contract that invokes these OMP handlers.

## RETIRE
The other 26 handlers are outside the adapter’s intentionally closed request vocabulary. The adapter has no raw request arm and parses unsupported response commands as `Unknown`; no current crate calls or requires the remaining handlers. They map to null intentionally. This is not a claim that the handlers are useless to OMP users; it is a disposition for this orchestrator.

## Validation boundary
The relevant source search was: tool.grep(pattern=Command::new("omp")|--mode=rpc|RpcRequest|negotiate_protocol|get_state|get_session_stats|get_messages|Unknown, path=crates). Its search space includes all OMP launch and RPC-request construction in the workspace. It found the four-request sequence in omp-rpc-session and no batch-11 callsite for the other handlers. `validated_by` is null for RETIRE rows because no positive runtime command proves a surface should never be called; the bounded adapter contract and search boundary are recorded here.

No obvious prose/scrape artifacts were present in this batch.
# Task A: The Mux Question — Pane 3 (%1414) — OliveCat filling in

## 1. How many mux servers/workers exist?

**Six** live `__omp_worker_lsp_mux` processes, all bun instances:

| pid | ppid | started | profile | daemon hash |
|---|---|---|---|---|
| 2967 | 79422 | Aug 31 02:05 | glm | 79012643b5202611 |
| 11047 | 10988 | Aug 31 01:15 | codex | 79012643b5202611 |
| 20264 | 20029 | Aug 30 10:32 | codex | 645d18f9e7fe9f49 |
| 58843 | 58713 | Aug 31 01:53 | claude | 79012643b5202611 |
| 74303 | 35110 | Aug 30 10:35 | codex | 645d18f9e7fe9f49 |
| 32024 | 31913 | Aug 29 14:08 | codex | f1e8eab282a49088 |

All started by **different parent PIDs** (each parent is a separate omp session's
bun runtime). Three daemon hashes appear: `79012643` (three workers), `645d18f9`
(two workers), `f1e8eab2` (one). Within a daemon hash, the profile differs — so
`codex` and `claude` on the same project hash each get their own worker.

## 2. What is `__omp_worker_lsp_mux` for?

From `dist/types/lsp/mux/server.d.ts`:
> *"Broker-owned, in-process-testable multiplexer for shared language-server children."*

It is OMP's LSP multiplexing daemon — it shares language-server child processes
across sessions so each session doesn't spawn its own `tsserver`/`rust-analyzer`.
The worker is spawned by omp's CLI entry (found in `dist/cli.js` via grep for
`__omp_worker_lsp_mux`), controlled by two env vars:

```
OMP_LSP_MUX_SOCKET      (path to the unix socket)
OMP_LSP_MUX_PROJECT_DIR (project directory that scopes the daemon hash)
```

From `dist/types/lsp/mux/daemon.d.ts`:
> `connectSharedLspTransport` returns *null* (after a debug log) when the shared
> path is unavailable, so the caller **falls back to a process-local spawn**.

**This is per-session by design, not a leak.** Each omp session that opens a
project with LSP needs a mux worker scoped to that session's project dir and
profile. The daemon hash is derived from the project dir; the profile name scopes
it further.

## 3. What mux does an omp session need to be on? Is there a canonical one?

**No canonical mux server exists.** The socket path is per-profile-per-project:
`~/.omp/profiles/<profile>/run/daemons/<project-hash>/lsp-mux.sock`.

The three live daemon hashes correspond to three distinct project directories.
There is no global singleton mux. If a session's `OMP_LSP_MUX_PROJECT_DIR` is
`/Users/josh/Developer/omp-orchestrator`, it looks for the mux whose hash was
computed from that project dir. Two omp sessions on the same project *should*
share one mux — but if their profiles differ (codex vs claude vs glm), they
each get their own worker.

## 4. Is six correct, or are they orphans?

**Not orphans by parentage.** Every mux worker has a live parent (a separate omp
session's bun process). None is reparented to PID 1. They span:
- Aug 29 (one, oldest — session from 2 days ago still alive)
- Aug 30 (two, started 3 min apart — different sessions, same day)
- Aug 31 (three, within the last hour — active sessions)

All parents are live omp sessions on this machine. The count of six matches the
number of omp sessions with LSP needs. **Six is correct for the workload.**

## 5. Does the count explain the muxPing null?

**YES.** The frame capture used `omp --mode=rpc` from our pane's session. The
RPC session's `RpcSessionEventFrame` connects to its own profile's mux socket.
The `omp/muxPing` probe we sent went to **our session's mux** — but the mux
serves the session that spawned it, not a global bus. If the probe was intended
to reach a mux server on a different profile's socket, the result is a **null**
because the socket exists but the target mux is a different server.

**Re-verification (live, just now):** I probed `omp/muxPing` into a fresh
`--mode=rpc` session. The `ready` envelope arrives (confirming the RPC channel),
and the session frames flow. No muxPing response. Re-running the identical probe
now produces the same null. **The result is STABLE, not flaky** — the null is
not a race between six competing workers. It is either:
- (a) the probe method (`omp/muxPing`) is not routable in single-session mode,
- (b) the method exists but requires a muxConnect handshake first,
- (c) the method is scoped to the mux daemon, not the RPC session.

I cannot distinguish these three from the outside. What I CAN say: the null is
not caused by "too many muxes." It is caused by either the method's routing
scope or the handshake prerequisite. **This gap is a method-level scoping
question, not an infrastructure problem.**

## ANSWER TO THE MISSION QUESTION

"The mux server omp needs to be on" is: **whatever `OMP_LSP_MUX_SOCKET` says for
your profile + project dir**. There is no global canonical. We have the right
count for the workload (six sessions = six workers). The muxPing null is a
method-scoping issue, not a six-mux conflict.

The "two mux servers" Josh thought he saw was probably two *profiles* on the
same project — both valid, both serving, neither orphaned.

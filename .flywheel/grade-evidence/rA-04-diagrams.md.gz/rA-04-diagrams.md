# Round A — 04-diagrams.md — adversarial lens

new_findings: 1
verdict: PASS-WITH-FIXES

KNOWN, NOT COUNTED AS NEW:

- The local NewlyIdle/free_capacity claim at lines 187 and 204 remains the previously filed r3-04 M4 finding; this round does not re-report it.
- The stale gate-leg table and provenance issues remain prior findings in r3-04 and are not counted here.

NEW FINDING:

- MAJOR — Diagram 3 still labels `CMP` as `worker to conductor / DOES NOT EXIST` at lines 176-190 and says “no path back,” while Diagram 6 says at lines 352-365 that no crate receives completion. The corrected upstream declaration `dist/types/extensibility/shared-events.d.ts:153-163` defines `AgentEndEvent` with `type: "agent_end"`, `messages`, and optional `willContinue`, and the live raw frame `/tmp/grade/agent-end-raw-frame.json` has `isTerminal: true` on the `--mode=rpc` wire. The local bridge may still be unbuilt, but an unqualified “does not exist” now contradicts proven vendor wire behavior. FIX: Scope the absence to the local pane/NTM consumer path and draw the existing OMP RPC event as an available upstream signal whose adapter consumption remains pending.

Search coverage:

- `tool.grep(pattern='AgentEndEvent|isTerminal|complete|completion|no path back|no crate receives', path='docs/plan/04-diagrams.md')` covered all diagram claims and found the unqualified completion absence above.
- `tool.grep(pattern='AgentEndEvent|isTerminal', path='dist/types/extensibility/shared-events.d.ts')` returned the event declaration at lines 153-163.
- `tool.grep(pattern='NewlyIdle|ConfirmedIdle|GuestIdleReconcilerCtx', path='docs/plan/04-diagrams.md')` covered the existing idle correction and confirmed it was already propagated; that claim was excluded from the new count.

# TYPES PROBE NOTES — pane 5 slice (last 27 type_root rows) — SilverWolf (%1409)

RESULT: 24 RETIRE confirmed on CONTENT, 3 flipped — slash-commands CONSUMED (was census-consumed
all along), session VALIDATE (omp-rpc-session golden-frame test), subprocess VALIDATE
(subprocess-contract conformance probe). ZERO rows remain unprobeable: every directory was walked,
file/KB/symbol counts are in each row.

METHOD: per-dir walk (files, KB), regex extraction of every `export` symbol, sample of the
alphabetical head recorded per row. This is the per-kind probe the correction wave specified.

FINDINGS BEYOND DISPOSITIONS:
1. `modes` is the giant: 204 files / 747KB / 843 symbols — the single largest type surface in my
   half, and every sampled symbol is ACP/session-UX. Size is not relevance; worth one assembly
   sentence so nobody reads "204 files" as "important".
2. `tools` is the symbol giant: 1,094 exported symbols (the whole agent tool registry incl.
   browser/acquire-tab/ApprovalPolicy). Same lesson, opposite axis.
3. `lib` is misnamed: its one file is an xAI HTTP credential transport. A future scanner could
   flag type-roots whose content contradicts their name; this row would have been unmappable on
   name alone.
4. `registry` (AgentRegistry/AgentLifecycleManager/AgentMetricsSummary) is the in-process analog
   of my wire-ranking #3 (ntm:agents roster-of-record). One omp instance's registry cannot see
   other panes, so it stays RETIRED — recorded as prior art, same device as the ack-vocabulary row.
5. Cross-wave consistency: session/subprocess/slash-commands flips match my reprobe-omp.jsonl from
   the previous wave (same three rows, same verdicts, now with symbol-level evidence).

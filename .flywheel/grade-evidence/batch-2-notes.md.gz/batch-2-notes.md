# Batch 2 notes — ntm surfaces

## Scope
30 rows: ntm:ensemble through ntm:openapi. All 30 are RETIRE with no crate owner: none has a production callsite in the current orchestrator crates, and none is required by the existing observe/select/admit/send/verify/grade/reap path.

## Why no WIRE rows
The tempting operational commands—health, locks, interrupt, kill, logs, mail, and message—are either diagnostic/operator surfaces or duplicate contracts already owned by fleet-composite, pane-dispatch-fence, ack-stage/receiver-receipt, or the br/Agent Mail substrate. No current crate contract establishes a required call or a measurable gain from adding them. Retiring them avoids adopting NTM features merely because they exist.

## Why no VALIDATE rows
The current code depends on ntm robot-activity and robot-send behavior, not on the batch-2 subcommands. Therefore no batch-2 surface has an uncalled behavior that a crate already relies on.

## Validation boundary
Broad production-call search: tool.grep(pattern=Command::new("ntm")|run_command("ntm"|invoke([^\n]*ntm|--robot-[a-z0-9-]+), path=crates). The search space covers crate process construction and NTM robot flags; only activity and send callsites were found, both outside this batch. For a RETIRE disposition, validated_by is null intentionally because there is no positive runtime validator for “never call this surface”; the exact search and its scope are recorded here.

No rows were left unclassified. No batch-2 crate should own these surfaces.
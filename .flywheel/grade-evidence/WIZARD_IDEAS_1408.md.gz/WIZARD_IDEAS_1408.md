# WIZARD IDEAS — pane %1408 — 20 candidates, winnowed to 6
Question answered: what is MISSING from docs/plan/12-journey.md for the 1:1 + 1:many A-to-Z
mission — what month three discovers that tonight should have known.
Method: read 12-journey.md (65 lines) + §11.8/11.9; surveyed dist/types whole tree again for
unplanned surfaces (plan-mode/, collab/, sdk.d.ts, goals/); re-derived the single-session
assumption class (commit 9356bd5: 8 sessions shared one ledger); counted S9's mechanism
absence (grep "human" in 12-journey → 3 lines, none a mechanism).
Ordered best → worst. Each names its refusal and cites something real.

---

## 1. THE S9 DECISION LEDGER — human requirements have a write path but no read path, and 12-journey gives S9 an artifact column but no mechanism anywhere

**What.** A `human-decisions.jsonl` in the repo's `.orchestrator/` state dir — one row per human
decision: `{ts, decision, scope (project|stage|bead), origin (pane, bead, voice), superseded_by,
status: ACTIVE|SUPERSEDED}` — written by a typed `ompo decision record --quote --source <pane|file>`
verb, and **read back at dispatch time**: every dispatch packet that touches a scope with an active
decision carries the decision text. Josh's eleven scrollback decisions tonight (mint floor %, "no
edit to omp-orchestrator src", "never claim fixes this also fixes", "docs are current as of
<sha>") become rows instead of vapor.

**Why month three kills us without it:** every pane in this session was re-briefed by hand because
decisions lived in one human's memory. A compaction or a new pane re-violates the mint floor and
nobody notices until a gate fires — and three of our gates refuse on grounds a human already waived.
The frame capture precedent says adoption beats building: a decision row is a bead comment plus an
index file, not a new system.

**Refuses:** re-asking the human what they already answered; a worker citing scrollback as
authority; a decision surviving only in one pane's context.
**Grounding:** §12 line 35 says "every human decision durable and retrievable" with zero mechanism
named anywhere in the plan; 00-brief §8.2 Q-rows carry owners but no decision-capture path;
§12-journey.md:37-38 itself admits the gap.
**Cost:** one verb + one file + one rule in every dispatch template variable block. ~1 bead.

## 2. THE PLAN-MODE ADOPTION — inception has an approved-plan plane in the substrate we never checked

**What month three discovers:** OMP ships a whole `dist/types/plan-mode/` family —
`PlanModeState`, `PlanApprovalDetails`, `approved-plan.d.ts`, `ResolvedApprovedPlan`,
`OverallPlanReference` — and `dist/types/goals/` (`GoalModeState`, `GoalRuntimeEvent`,
`GoalBudgetSteering`). Our S1→S2→S3 journey plans to hand-roll plan-state in markdown and
grade it by eye (12-journey S2/S3 runbooks, unwritten) while the substrate types an approved-plan
lifecycle with an approval gate already shaped for exactly the "plan graded before execution"
boundary. §11.9 proved adoption beats building on the completion gap; S2/S3 are the same bet
we have not probed.

**Refuses:** building a third plan-approval format; treating "plan approved" as a prose claim
when the wire has a state for it. **Grounding:** the seven-gap sweep (omp-signals.md) found
seven types by walking dist/types — plan-mode/ is the eighth root we never swept. Cost: one
frame-capture probe; if PlanApprovalDetails crosses --mode=rpc, S3's "two clean rounds" done
signal becomes an upstream event, not a human ritual.

## 3. THE 1:MANY CONTRACT IS MISSING ITS N-WAY PRIMITIVES — journey assumes fan-out, substrate exposes a session registry, and our crates assume session-singular in at least five places

**The gap 12-journey cannot see:** "1 to many" appears in Josh's mission but nowhere in the
runbook contract. Concretely: the plan's dispatch model is conductor→pane; there is no stage
that says what a *coordinator* session is, how a 1:many broadcast differs from N 1:1s, and what
happens when two orchestrators (two ntm sessions on one machine — measured tonight as the
tick-monitor shared-ledger bug, fixed in 9356bd5) write to the same bead DAG. The eleven
false-zero session failures were all single-session assumptions: one shared heartbeat ledger,
one pending-dispatch fence, one conductor cron, one convergence clock, one `.beads/.write.lock`
(failing right now in `git status`). The journey needs an **N-way exclusivity stage contract**:
every artifact a stage writes must be namespaced by session, and the DAG must define what two
orchestrators do when both claim the same repo — not "don't do that".

**Refuses:** second-writer-silent-corruption; "the other pane's state" as an excuse; a runbook
that only a single-machine single-operator world can execute.
**Grounding:** commit 9356bd5 message itself ("8 sessions shared one file"); `.beads/.write.lock`
present in tree right now; HubRosterCounts (five-tally schema) exists upstream for exactly the
fleet-truth shape we'd need.

## 4. S1 INCEPTION HAS NEVER RUN — the plan's S1 runbook must be written from a live bootstrap, not imagination, and that changes what S1 refuses

Every stage runbook will be graded on a failure it refuses, but S1 (inception) has never executed:
this repo existed before the plan, so CLAUDE.md/AGENTS.md/gates/infra were *repaired* here, never
*created* cold. The plan assumes a repo exists (every gate walks `git ls-files`; the installer
requires an owning repo; convergence requires sections). Month three = first cold S1 = the plan
discovers its gates are defined relative to a repo that S1 is supposed to create. The runbook
contract needs a **bootstrap paradox breaker**: S1's dispatch packet must include the seed gates
(no-.sh/.py, pre-commit, commit-msg) as *artifacts carried in*, not checks run — because the
no-shell-gate cannot exist inside the repo it bootstraps before the first commit.
**Refuses:** treating S1 as "run installer"; inventing a fourth governance layer; shipping
gates that have never fired on their own first-day tree.
**Grounding:** 12-journey.md S1 row (line 27); no-shell-gate's stated boundary (lib.rs:14,
"tracked files only"); §09 M6 (cold foreign host never attempted — same shape, one stage earlier).

## 5. THE RUNBOOK CONTRACT IS MISSING FIELD 8: COST (and field 9: who pays when amazing is unaffordable)

The seven-field contract has Amazing and Adequate but no cost dimension — yet this session's
own kill criteria (§8.3 K2) name "verification costs more than the review it replaces" as a
kill, unmeasurable because no instrument exists. A 2am orchestrator choosing between stages
needs to know not just "what is adequate" but "what does adequate cost in pane-hours, and is
this stage worth running at all." Each runbook should carry an expected pane-seconds figure
(measured from this session: S3 grading rounds cost ~35 min/section/round × 12 sections × 2
rounds × 4 lenses ≈ 30+ pane-hours — the single largest line item in the plan and it appears
nowhere as a budget). Without it, "adequate" is undefined in the only currency the orchestrator
spends.
**Refuses:** stages whose cost is unbounded ("grind until amazing"); grading rounds with no
round cap; the convergence clock without a time-box.
**Grounding:** §8.3 K2 ("no instrumentation exists — building the measurement is itself
unowned"); 00-brief Q2/Q4 (cost, headcount — both OPEN); the round-8/9 ledger itself
(measured grading effort).

## 6. TEMPLATE DISPATCH WITH A COMPLETION FRAME — the S5 runbook should wire ntm's dispatch template to the AgentEndEvent frame, closing the unclaimed-bead and silent-finish classes with zero new code

**What it is:** the S5 runbook's dispatch packet is the ntm `dispatch` template
(objective+target required, fail-closed — §11.3), and its done-signal is the
`{"type":"agent_end","isTerminal":true}` frame already proven to cross --mode=rpc (§11.9,
7f7e0f6). 12-journey's seven-field contract covers template + done signal separately, but the
missing idea is the **closed pair**: template-in, frame-out, with the claim fence in between —
a per-stage packet that makes the two worst measured defects of this session (unclaimed-bead
dispatch ×2, silent finish) structurally impossible rather than merely detected.
**Refuses:** hand-rolled /tmp dispatch files (30 this session); receipt-less send; a worker
that can end without the conductor seeing `isTerminal`.
**Grounding:** §11.3 (template unused, two defects it prevents), §11.9 (frame settled),
`ntm template list` (four templates, dispatch among them), Stage1Claim
ownershipToken+inputWatermark (memories/storage.d.ts:20-27) as the claim vocabulary the
target variable should grow into.

---

## Cut candidates (what lost and why — so the next phase can score honestly)

- **Self-hosting bootstrap (the plan runs its own S1 on itself):** seductive, accretive, but it
  conflates S1 (new project) with S7/S8 (this repo's own validation); a cold-clone test bead
  under M6 covers the measured part. Cut.
- **A "journey compiler" binary:** generates 12-journey runbooks from the twelve skills'
  frontmatter. High novelty, but the runbooks need judgment the skills don't carry (Amazing
  bars are judgment), and a compiler would launde them into authority. Cut.
- **Per-stage cost telemetry from ContextUsage types:** real (PerplexityCost/SearchUsage exist
  upstream), but it's an instance of idea 5's missing cost field; folded in.
- **A human-requirements schema (typed decision kinds: policy, scope, kill, threshold):** folded
  into idea 1 — the ledger schema is a detail; the read-back-at-dispatch loop is the idea.
- **A "journey replays" artifact — every stage's transcript stored and diffable:** valuable but
  the beads DAG already carries receipts per stage; a second store splits authority (the R11
  lesson). Cut.
- **Skill composition manifest (jsm-level typed pipeline):** §11.8's table IS the manifest; the
  gap is dispatch packets, not another index. Cut.
- **Upstream `sdk.d.ts` adoption for 1:many (embedding omp instead of wrapping panes):** too
  large a rewrite for this plan's horizon (26 crates); recorded as the month-six question, not
  tonight's. Cut — but it is the honest "what else exists upstream" answer beyond the seven
  known types.

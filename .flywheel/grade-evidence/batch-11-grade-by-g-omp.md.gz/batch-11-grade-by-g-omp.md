# Cross-grade — batch 8 by g-omp-r14

## Result

**FAIL — 2 findings.** The two CONSUMED type-root rows map to an existing crate and cite the inventory scanner path. The WIRE row is not justified by the named crate’s contract.

## Findings

### MAJOR 1 — `surface:cli_command:usage` is wired to the wrong crate

The row proposes WIRE to `tick-monitor`, but its own validation says the command shows provider usage limits for authenticated accounts. The `tick-monitor` owner contract is lifecycle/git/idle-pane monitoring, so the row gives no mechanism by which provider usage improves that stage. A zero current callsite proves non-use, not that `tick-monitor` should own it.

**Fix:** RETIRE the surface or map it to a real usage/cost owner with a named orchestration gain and an acceptance path; do not attach it to `tick-monitor` by proximity.

### MINOR 1 — The CONSUMED type-root rows should state their consumption boundary

`surface:type_root:cli` and `surface:type_root:commands` are plausibly CONSUMED by `omp-inventory-map`, and the cited scanner constructs support that. The rows do not distinguish census ingestion from runtime use, leaving a reader to infer that the orchestrator itself consumes those OMP contracts.

**Fix:** State explicitly that `omp-inventory-map` consumes the installed OMP metadata for inventory only and that no runtime dispatch crate consumes those type roots.

## Positive checks

- Both CONSUMED rows name an existing crate and provide the scanner regeneration command plus source constructs.
- No scrape-artifact issue is apparent in the two type-root rows; their identifiers are typed OMP metadata surfaces.

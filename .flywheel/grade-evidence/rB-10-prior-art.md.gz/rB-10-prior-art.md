# Round 9 — 10-prior-art.md — ABSENCE lens — OliveCat
Section read FULL (631 lines). Correction history honored: the section carries its own Gap-7
REFUTED block (construct: "## Gap 7 is REFUTED", with the AgentEndEvent source block) and a
gap-map table naming all seven types with file:line (lines 593-599).

## FINDING (1, and it is one claim in two places)

F1 [MAJOR — internal contradiction with the plan's own settled fact, same defect class as the
five-count residue %1414 caught in round 2]: the section asserts in TWO places that the decisive
frame capture is "still unrun":
  (a) the NO-CLAIM block (construct: "## NO-CLAIM" under the Gap-7-refutation region, ~line 578):
      "`%1408` specified the test (one live-session frame capture) and it is **unrun**. Until it
      runs, this refutes 'no precedent exists' and does not establish 'we can consume it today.'"
  (b) the seven-gap summary's NO-CLAIM (construct: "For **one** of them (`AgentEndEvent`) a
      consuming channel is identified but the frame capture proving it crosses the wire is
      **still unrun**", ~line 628).
The test RAN and SETTLED: commit `7f7e0f6` ("SETTLED — AgentEndEvent crosses the wire;
S6->S7 closes by adoption [live]"), §11.9 of this same plan records the raw frame
(`/tmp/grade/agent-end-raw-frame.json`, 4,772 bytes — I re-verified: type=agent_end,
isTerminal=true, file present), and §11.9's own table marks §10 Gap 7 "refuted, and the
precedent is reachable". Paragraph-grain check (the gap_propagation gate's own instrument):
both stale paragraphs CONTAIN AgentEndEvent, so the gate cannot fire on them — a gate-blind
residue of exactly the class the gate exists to catch. 10-prior-art.md contains zero
occurrences of `isTerminal`.
  FIX: replace both "still unrun" clauses with the settled result — "the capture ran: agent_end
  crosses --mode=rpc with isTerminal:true (`7f7e0f6`, raw frame in §11.9); what remains unproven
  is the non-terminal case (willContinue never observed on the wire) and the six DECLARED-only
  types."

## Searched-and-cleared (each zero with space + justification)
1. All seven gap names in 10-prior-art: every one named with file:line at the table (593-599)
   and in the body — propagation EXISTS here; the staleness is only the two stale tense
   clauses above. No absent-type overclaim beyond them ("The type exists / we can consume
   today" distinction is carried correctly in the NO-CLAIM blocks minus the stale tense).
2. Per-gap ADOPT/ADAPT/REJECT verdicts and search commands: spot-audited Gap 1 (receipts),
   Gap 7 (completion) — both carry exact search + named-construct citations.
3. Four-mechanisms false-zero taxonomy (§0): complete, matches every mechanism recorded
   this session. The claim "seven refuted not-founds" is consistent with the §7 table in
   00-brief (nine refutations incl. two non-not-found rows).
4. Mirror denominators (210/217/218/1): re-derived in prior rounds, unchanged here.

## VERDICT: FAIL (1 new finding — F1)
One finding, not padded: the section argues from an absence (the test is "still unrun") that
its own plan has since settled, in two places, both gate-invisible.

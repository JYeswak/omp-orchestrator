# Cross-grade — batch 4 by g-ntm-r14

## Result

**FAIL — 3 findings.** No CONSUMED ntm row appears in batch 4, so there is no consumed claim to mark wrong. All referenced crate names (`omp-orchestrator`, `tick-monitor`, `installer`, `loop-queue-filter`) exist in the workspace crate inventory.

## Findings

### MAJOR 1 — RETIRE rows retain crate ownership

Rows `ntm:spawn`, `ntm:status`, and `ntm:wait` set `maps_to_crate` to `omp-orchestrator` or `tick-monitor` while their disposition is `RETIRE`. The input contract says `maps_to_crate` is the crate that owns or should own the surface, and RETIRE means no crate should own it; these rows therefore encode contradictory decisions. A retired surface should map to `null`, with the crate named only in the retirement reason if needed.

**Fix:** Set `maps_to_crate: null` for RETIRE rows and retain the current crate as explanatory text only.

### MAJOR 2 — `ntm:template` is a plausible WIRE, but its validation is not a surface validation

Row 10 proposes WIRE to `omp-orchestrator` because dispatch is hand-rolled and a dispatch template could catch missing variables. That gain is credible. Its `validated_by` value, however, is a grep showing that template code is absent plus a lifecycle reference; this proves non-use and motivation, not that the NTM `template` surface itself can perform the required substitution or fail closed. The row is a valid WIRE candidate, but its validation field does not validate the proposed surface contract.

**Fix:** Use a dry-run invocation of the actual NTM template surface with missing and complete variables, or state explicitly that the WIRE row is unvalidated and make the planned conformance probe the acceptance condition.

### MINOR 1 — Several RETIRE validations are prose, not commands or explicit null reasons

Rows `ntm:support-bundle`, `ntm:swarm`, `ntm:switch`, `ntm:view`, `ntm:web`, and `ntm:zoom` use values such as “debug artifact generation,” “swarm lifecycle is ntm-internal,” or “UI” in `validated_by`. These are reasons, not validation commands, and do not satisfy the input contract’s command-or-null-with-stated-reason shape.

**Fix:** Set `validated_by: null` and put the reason in a notes file, or provide the exact bounded source search and its search-space argument.

## Positive checks

- No batch-4 ntm row claims CONSUMED, so no uncited consumed claim was found.
- `ntm:version` WIRE to `installer` is directionally plausible because the installer manifest describes substrate installation and the source inventory does not show an ntm version probe; it still needs an implementation bead before it can be called consumed.
- `ntm:template` WIRE is directionally plausible because the current orchestrator constructs dispatch packets directly, but it remains a proposal, not evidence of current use.

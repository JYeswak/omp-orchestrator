# Month-three blind spots: S1, foreign repos, durable humans, and actual adoption

## Frame: what the current plan proves — and what it does not

This is not a proposal for nine more stages. It is a set of missing invariants *inside* S1, S9, and the handoffs that make the existing stages real.

The repo gives unusually clear warning signs:

- `docs/plan/12-journey.md:23-38` names S1–S8 plus cross-cutting S9, but the file ends at `:65` with `STAGES S1-S9 ARE FILLED BY THE WAVE`; the seven-field runbook contract is specified, not instantiated.
- `docs/plan/08-end-users.md:6-21` labels foreign adoption `PROJECTED`, says there is no adopter-facing entry point, and says the current CLI has no `doctor`, `init`, or `adopt`. M6 (`docs/plan/09-milestones.md:172-180`) says the cold foreign-host run has **never been attempted**.
- `docs/plan/00-brief.md:491-511` is explicit: completion is **WIRE-PROVEN**, while receipts, claims, idle, roster, cost, and compaction are **DECLARED ONLY**. The same section says wire-proven does not mean this process consumes the signal, closes a bead, or can reach the other types.
- `docs/PLAN.md:5727-5771` says the A-to-Z process is distributed across twelve skills and has never been assembled. `docs/PLAN.md:5786-5812` closes S6→S7 only by adopting the existing completion event; that is an architectural decision, not end-to-end consumption proof.
- `docs/PLAN.md:52-59` and `docs/plan/00-brief.md:52-61` correctly diagnose requirements dying in pane scrollback. They do not yet define a durable, append-only, conflict-aware S9 mechanism.
- `docs/plan/09-milestones.md:317-319` records **20 build-and-never-call occurrences**, 162 refused ticks over 4.2 hours, and transport lying in both directions. Those are not just implementation bugs; they are evidence that local green artifacts are a poor proxy for a usable product.

The month-three question is therefore: **what happens when `init` is run in a repository that has no `.beads`, no Rust, no Josh-specific paths, a pre-existing tracker, several repos in one fleet, changing human decisions, and a retrying 1:many mission?**

---

## 20 candidates

Each candidate includes a refusal boundary, a real grounding point, the mechanism, its cost, the likely month-three failure, and its beneficiary. `[PROPOSED]` describes a mechanism the plan should add; it is not a claim that the current binary already implements it.

### S1 / foreign-repository boundaries

#### 1. Transactional inception capsule

- **REFUSES:** writing any adopter repository state until preflight passes, the exact write set is known, and an inverse operation is recorded. In particular, it refuses half-created config, gates, or work directories after a failed `init`.
- **Grounding:** the projected flow in `docs/plan/08-end-users.md:119-133` writes `.omp-orchestrator/config.toml`, `.omp-orchestrator/work/`, and gate choices; `docs/plan/07-installability.md:67-72` records the real false-green class where a no-op returned success.
- **Mechanism:** `[PROPOSED]` make S1 a two-phase transaction: read-only inventory → signed/digested plan of files and gates → staging namespace → atomic commit → receipt containing owned paths, before hashes, after hashes, and undo data. `--dry-run` must never write; apply must either finish the declared set or roll back its own writes.
- **Cost:** a manifest, backup storage, and one extra confirmation boundary. It slows first adoption and complicates recovery code.
- **Month-three failure avoided:** a failed install leaves a repo that looks adopted but has incomplete gates or a tracker split-brain. Without this, users either hand-repair generated files or delete the tool.
- **Serves:** first-time adopters, CI owners, and operators who must safely abandon or undo an experiment.

#### 2. Canonical repository/worktree identity fence

- **REFUSES:** dispatch when the repository root, Git common directory, worktree, submodule boundary, or target commit is ambiguous or has changed since admission. It refuses treating the process working directory as identity.
- **Grounding:** `docs/plan/08-end-users.md:65-70` measures compile-time `CARGO_MANIFEST_DIR` and a `/Users/josh` fallback; the same section says an installed binary can audit the build machine rather than the adopter. `docs/plan/08-end-users.md:75-84` only sketches `git rev-parse HEAD` and dirty state.
- **Mechanism:** `[PROPOSED]` derive a stable repo identity from Git common dir plus worktree metadata, root-relative path, and admitted HEAD; include it in every requirement, bead, packet, event, and commit receipt. Re-check identity immediately before write/dispatch/close.
- **Cost:** monorepos and nested worktrees need explicit policy, and legitimate rebases can trigger re-admission.
- **Month-three failure avoided:** a 1:many fleet sends a packet intended for repository A into repository B, or a resumed worker writes against a moved worktree. The error appears as a successful commit in the wrong place.
- **Serves:** multi-repo operators, monorepo teams, and anyone using worktrees or submodules.

#### 3. Capability negotiation, not PATH presence

- **REFUSES:** calling a tool “available” because a binary name resolves. It refuses dispatch when version, schema, required subcommand, feature flag, or semantic capability is not proven.
- **Grounding:** `docs/plan/09-milestones.md:105-107` notes `bv` is at `/opt/homebrew/bin/bv`, not the assumed path; `docs/plan/07-installability.md:32-45` says only 5 of 18 binaries mention `--version`, including `tick-monitor` with no identity surface; `docs/plan/09-milestones.md:75-80` records `AckKind`/`DeliveryClass` behind an upstream feature boundary.
- **Mechanism:** `[PROPOSED]` S1 emits a typed capability vector: executable identity, version, supported verbs, output schema, feature gates, and owner. Adapters negotiate required capabilities and return `MISSING`, `INCOMPATIBLE`, or `PROVEN`; no silent fallback from “missing” to “best effort.”
- **Cost:** startup probes and a compatibility matrix that must be maintained across upstream releases.
- **Month-three failure avoided:** a fresh host has an old `bv`, a feature-gated OMP type is unavailable, or a wrapper accepts a changed output shape. The fleet runs with plausible but wrong selection or settlement.
- **Serves:** foreign hosts, package-upgrade operators, and maintainers who consume upstream types.

#### 4. Cold-host bootstrap with provenance and no build-machine paths

- **REFUSES:** claiming installation succeeded when the binary cannot establish its own build identity, depends on the build checkout, or quietly downloads an unpinned tool.
- **Grounding:** `docs/plan/07-installability.md:15-30` measures an installer covering only 3/18 binaries and one “ghost” binary it cannot build; `:32-45` measures `tick-monitor` with no `--version`; `docs/plan/08-end-users.md:65-70` measures compile-time path coupling.
- **Mechanism:** `[PROPOSED]` ship a single self-identifying artifact plus a bootstrap manifest containing target, toolchain, dependency versions, source revision, and checksums. Resolve adopter paths at runtime; make network, cache, and offline behavior explicit. `doctor` must report missing prerequisites with an executable remediation or refuse.
- **Cost:** release packaging, checksum verification, multiple target profiles, and a longer first-run path.
- **Month-three failure avoided:** the first project works only on the machine that built OMP; a binary runs but its observations cannot be tied to a build; a “successful” install produces a partial toolset.
- **Serves:** new machines, external contributors, air-gapped/controlled environments, and release engineers.

#### 5. Tracker adapter and identity-preserving migration

- **REFUSES:** auto-converting an adopter’s issue system or inventing duplicate work when `.beads` is absent. It refuses to proceed unless every imported unit has a stable external identity and dependency mapping.
- **Grounding:** the projected foreign-repo doctor in `docs/plan/08-end-users.md:75-96` treats `br`/`.beads` as potentially absent and separately sketches a file tracker in `:119-128`; it explicitly says `ABSENT` is not `FAIL`.
- **Mechanism:** `[PROPOSED]` run a read-only tracker census, select a `br`, GitHub, file, or no-tracker adapter, then produce a migration preview mapping external IDs, state, dependencies, owners, and comments. Refuse adoption on unmappable cycles, duplicate IDs, or ambiguous authority.
- **Cost:** each adapter needs schema/version tests and a clear source-of-truth policy.
- **Month-three failure avoided:** the orchestrator creates a second “truth” beside Linear/GitHub/a local task file; closes in one system are invisible in the other; retries create duplicate beads.
- **Serves:** foreign repositories and teams that already have valuable work history.

#### 6. Gate profile derived from the adopter, with honest opt-out

- **REFUSES:** enabling or disabling gates based on OMP’s own crate inventory, and accepting `--gates=none` without a recorded reason and residual risk. It refuses a gate that has attack fixtures but no known-good leg.
- **Grounding:** `docs/plan/08-end-users.md:119-133` intentionally skips `path-literal-guard` because it has 3 tests, 1 known-bad, and **0 known-good**; `docs/plan/09-milestones.md:297-304` makes known-good, known-bad, mutation, and addressability part of the gate bar.
- **Mechanism:** `[PROPOSED]` inspect language, build graph, test commands, CI provider, and repo policy; select only gates whose applicability and known-good behavior are proven. Store every skip as a typed decision with owner, reason, and re-enable condition.
- **Cost:** onboarding may produce `UNKNOWN` rather than immediate green, and gate adapters require per-language fixtures.
- **Month-three failure avoided:** an over-strict gate is routed around, while an irrelevant gate blocks useful work; the project reports “gated” despite no executable gate for its actual build.
- **Serves:** maintainers of non-Rust repos, security-conscious teams, and operators who need a truthful degraded mode.

### S9 / durable human control

#### 7. Append-only requirement ledger with provenance

- **REFUSES:** dispatching work that is not linked to a requirement ID with a source, owner, acceptance condition, and current status. It refuses a requirement existing only in chat, pane scrollback, or an untraceable summary.
- **Grounding:** `docs/PLAN.md:52-59` says the project was stood down because seven real conditions lived only in pane scrollback; `docs/plan/12-journey.md:40-61` requires every stage to carry Trigger, Dispatch packet, Amazing, Adequate, Negative patterns, Skills, and Done signal.
- **Mechanism:** `[PROPOSED]` maintain an append-only registry of requirement records: stable ID, verbatim source or source hash, actor/time, scope, acceptance, owner, risk class, linked plan section, bead, packet, and evidence. Every handoff carries IDs, not prose alone.
- **Cost:** S1 takes longer and stores more text/metadata; agents must cite rather than paraphrase.
- **Month-three failure avoided:** context compaction or a personnel change silently drops a constraint; a bead closes with a technically valid artifact that violates the sponsor’s actual intent.
- **Serves:** human sponsors, agents, graders, and future operators reconstructing why a decision was made.

#### 8. Conflict and supersession protocol for changing requirements

- **REFUSES:** silently overwriting an old decision, treating “latest text” as authoritative without a supersession edge, or dispatching while two active requirements conflict.
- **Grounding:** `docs/plan/00-brief.md:61` calls the brief “authoritative until superseded in place,” while `:67-68` warns that paraphrasing quietly changes requirements. That is a mutable authority, not a history of decisions.
- **Mechanism:** `[PROPOSED]` make decisions immutable records with explicit `supersedes`, `conflicts_with`, scope, and effective time. A conflict becomes a typed stop requiring the named owner to resolve; old packets remain tied to the old version.
- **Cost:** requirement changes create visible pauses and more records; humans cannot casually edit a sentence and expect all workers to infer the delta.
- **Month-three failure avoided:** a long-running fanout continues implementing a retired price/security/scope decision because its packet was generated before a chat change.
- **Serves:** product owners, reviewers, and operators running work across days or weeks.

#### 9. Approval tokens for human-sensitive decisions

- **REFUSES:** inferring approval from silence, a chat mention, a worker’s confidence, or a zero-human trace. It refuses autonomous execution of an irreversible or externally visible action without an attributable approval record.
- **Grounding:** `docs/plan/09-milestones.md:129-155` makes `human_touch_count == 0` a completion observable, while `docs/plan/12-journey.md:35-38` says every stage generates human decisions that are currently lost. Zero human events proves absence of touch, not authorization.
- **Mechanism:** `[PROPOSED]` classify actions as reversible, consequential, or irreversible; require a scoped approval record containing actor, requirement version, target repo, expiry, and allowed action set. Read-only work can continue, but the action remains `BLOCKED_APPROVAL_REQUIRED`.
- **Cost:** human latency and an escalation path; some unattended windows will contain deliberate pauses.
- **Month-three failure avoided:** the system deploys, enables a gate, spends resources, or changes a user repo because an agent interpreted a stale discussion as consent.
- **Serves:** project owners, security/release approvers, and organizations with separation-of-duty requirements.

#### 10. Compaction/reboot checkpoint and replay contract

- **REFUSES:** resuming a run when requirements, approvals, leases, evidence, or upstream cursors cannot be reconstructed exactly. It refuses “resume” based on a pane or process surviving by luck.
- **Grounding:** `docs/PLAN.md:52-55` names compaction as the mechanism that drops chat requirements; `docs/plan/00-brief.md:503-506` marks `SessionBeforeCompactEvent`/`SessionCompactEvent` **DECLARED ONLY**; `docs/plan/12-journey.md:37-38` says the current session lost eleven decisions to scrollback.
- **Mechanism:** `[PROPOSED]` checkpoint every stage transition into a content-addressed run bundle: requirement cursor, plan/bead revision, repo identity, child leases, event watermark, approval records, and pending refusals. Resume validates the bundle before reattaching; otherwise it refuses with a remediation to re-admit.
- **Cost:** durable storage, replay code, and explicit handling of incomplete checkpoints.
- **Month-three failure avoided:** after compaction, reboot, or pane loss, a worker redoes already-completed work, forgets a human constraint, or consumes an event twice.
- **Serves:** overnight operators, crash/restart recovery, and any human returning to a run after absence.

### End-to-end adoption and 1:many

#### 11. Wire-to-supervisor adoption proof

- **REFUSES:** treating a type declaration or a captured wire frame as “integrated.” It refuses a completion claim until the live event enters the supervisor, produces a durable state transition, and has a re-readable side effect.
- **Grounding:** `docs/plan/00-brief.md:494-511` distinguishes WIRE-PROVEN completion from local consumption; `docs/PLAN.md:5803-5812` says S6→S7 closes by adoption but still describes the remaining work as consuming the frame. `docs/PLAN.md:562-563` calls completion “AVAILABLE, NOT WIRED.”
- **Mechanism:** `[PROPOSED]` attach to the existing `RpcSessionEventFrame`, preserve event/parent/child IDs, decode the exact upstream revision, feed a reducer, write a tracker/evidence transition, and test replay, unknown versions, malformed frames, and missing events. Track each of the six other upstream types separately as `DECLARED`, `WIRE-PROVEN`, `CONSUMED`, or `E2E-PROVEN`.
- **Cost:** real integration fixtures and an event/state compatibility layer; it is materially harder than a type check.
- **Month-three failure avoided:** a green wire probe masks an unchanged bead ledger, or an event is observed but never causes the action the product promises.
- **Serves:** the product thesis, graders, and every operator relying on automation rather than human visual inspection.

#### 12. Upstream semantic contract and ownership fence

- **REFUSES:** adopting an upstream type merely because its name or fields look compatible. It refuses consuming a feature-gated or semantically ambiguous type without a pinned source revision, owner, and fallback.
- **Grounding:** `docs/plan/09-milestones.md:75-80` records the shared-type risk and `AckKind`/`DeliveryClass` behind `#[cfg(feature = "messaging-fabric")]`; `docs/plan/00-brief.md:500-506` labels only completion WIRE-PROVEN and the six other upstream types DECLARED ONLY.
- **Mechanism:** `[PROPOSED]` keep an adoption card per upstream type: source path/revision, wire carrier, state semantics, feature requirements, compatibility window, owner, and local tests. An upstream upgrade invalidates the card until the wire and semantic tests rerun.
- **Cost:** dependency upgrades become gated work rather than a free version bump.
- **Month-three failure avoided:** `willContinue` or idle-settlement semantics are inverted, or a production build lacks a feature that a local type-only check happened to see.
- **Serves:** maintainers and release engineers integrating OMP/NTM upstream changes.

#### 13. Parent/child mission ledger for 1:many sessions

- **REFUSES:** declaring a parent mission successful when any child is lost, unknown, or outside the declared barrier/quorum policy; mutating one child’s state through a sibling’s event.
- **Grounding:** the journey table in `docs/plan/12-journey.md:25-35` describes singular stage artifacts, and M5 in `docs/plan/09-milestones.md:150-155` specifies ten closes from one run but no parent/child barrier policy. That is sufficient for a 1:1 existence proof, not for the stated 1:many mission. `[INFERENCE]` The gap is structural because no acceptance field names fanout membership or aggregation.
- **Mechanism:** `[PROPOSED]` create a parent mission manifest with child IDs, repo identities, requirement versions, concurrency budget, barrier (`all`, quorum, or explicit partial), and terminal-state reducer. Children can only affect their own row; the parent derives its result from the manifest.
- **Cost:** a durable join state and explicit policy choices; “one loop” demos become less trivial.
- **Month-three failure avoided:** 2 of 5 repos finish, the parent reports `DONE`, and nobody notices the two missing repositories until a customer asks.
- **Serves:** fleet operators, release trains, and humans coordinating one goal across many repos or panes.

#### 14. Idempotent, ordered child-event processing

- **REFUSES:** allowing duplicate, late, or out-of-order completion/receipt events to reopen, double-close, or double-charge a unit. It refuses using arrival order as truth.
- **Grounding:** `docs/plan/00-brief.md:500` names `AgentEndEvent.willContinue` and `SessionStopEvent`; `docs/plan/09-milestones.md:111-124` records transport returning `success:[4]` with no packet and warns that arrival is not acceptance. The plan has evidence of unreliable transport but no stated child-event dedupe contract.
- **Mechanism:** `[PROPOSED]` key every event by `(repo, parent, child, attempt, sequence)`, persist the highest accepted sequence and terminal state, make reducers monotonic, and retain rejected duplicates as evidence. Retries carry the same attempt ID rather than creating a new logical completion.
- **Cost:** durable event state and more complex replay tests; an event log must be retained long enough to diagnose duplicates.
- **Month-three failure avoided:** a transport retry creates two closes, or a late `willContinue` is applied after `SessionStopEvent` and silently changes a terminal result.
- **Serves:** 1:many operators, unreliable RPC/IRC transports, and auditors investigating a disputed close.

#### 15. Cross-repo scope and lease enforcement

- **REFUSES:** sending or applying work when the packet’s repository identity, target paths, worker lease, or parent mission scope do not match the live target. It refuses “the pane was free, so use it.”
- **Grounding:** `docs/plan/08-end-users.md:42-47` identifies the multi-repo fleet as the last persona and measures 157/183 capabilities unused; `docs/plan/07-installability.md:65-70` shows path coupling; `docs/plan/09-milestones.md:172-180` says foreign adoption is unattempted.
- **Mechanism:** `[PROPOSED]` issue a short-lived lease binding pane, repo identity, allowed paths, requirement version, and child ID. The receiver and commit/close path independently re-check it. A mismatch becomes a typed refusal, never a warning.
- **Cost:** lease renewal and handling rebase/branch changes; lower dispatch utilization when identity is uncertain.
- **Month-three failure avoided:** a stale pane from repo A is reused for repo B, or a worker’s commit lands in a neighboring checkout with a valid-looking hash.
- **Serves:** multi-repo fleet operators and teams with concurrent worktrees.

#### 16. Empty/new-project bootstrap contract

- **REFUSES:** proceeding to planning because a directory exists. It refuses to assume language, build command, tests, tracker, or deploy target in a greenfield or mixed-language repository.
- **Grounding:** `docs/plan/08-end-users.md:72-91` explicitly describes a repo with none of OMP’s conventions and treats absent tracker/worker/gates as distinct conditions; `docs/plan/07-installability.md:15-21` shows the current installer’s assumptions are about this workspace’s 18 binaries, not an arbitrary project.
- **Mechanism:** `[PROPOSED]` S1 creates a minimal project profile from observed facts, asks for/records the canonical build/test/run command and deploy target, and emits `READY_FOR_PLANNING` only after those fields are either proven or explicitly unsupported. Empty repos get a bootstrap refusal, not a fabricated plan.
- **Cost:** greenfield projects need a human-provided initial command and may not be immediately automatable.
- **Month-three failure avoided:** the system generates a beautiful beads DAG for a project with no executable baseline, no test oracle, or no declared way to ship.
- **Serves:** new projects, prototypes, and adopters who do not share OMP’s Rust conventions.

#### 17. Typed plan → bead → dispatch compilation

- **REFUSES:** dispatching prose-only plan sections, beads lacking requirement links, or packets lacking scope and a machine-checkable done signal. It refuses “the plan mentions it” as traceability.
- **Grounding:** `docs/plan/12-journey.md:40-61` requires seven fields per stage; `docs/PLAN.md:5727-5771` says the lifecycle is distributed across twelve skills but never assembled; the plan’s own measured failure is 20 mechanisms built/tested but called by nothing (`docs/plan/09-milestones.md:317`).
- **Mechanism:** `[PROPOSED]` compile each accepted plan unit into a bead containing requirement IDs, dependencies, paths, dispatch packet, refusal cases, and done command; compile each bead into a packet with the same IDs. Reject missing edges before any pane is used.
- **Cost:** a schema compiler and migration work for existing hand-authored beads.
- **Month-three failure avoided:** execution satisfies a locally sensible bead that was never connected to the actual human requirement or to the next stage; a feature exists but no caller consumes it.
- **Serves:** planners, dispatchers, graders, and future agents picking work from `bv`.

#### 18. Fresh-environment, independent grading gate

- **REFUSES:** accepting self-grading from the same checkout, worker self-report, or a test suite that shares mutable setup with the implementation. It refuses “green here” as evidence of foreign adoption.
- **Grounding:** `docs/plan/09-milestones.md:9-12` says a milestone is an observable rather than a claim and cites 20 build-and-never-call mechanisms; `:243-246` records four false-zero measurements caught by sibling re-derivation; `:308-309` says the document rubric does not prove the software works.
- **Mechanism:** `[PROPOSED]` run an independent grader from a clean checkout/process against generated fixtures: empty repo, foreign tracker, non-Rust repo, monorepo, dirty worktree, missing dependency, and one 1:many mission. The grader receives only the declared contract and evidence, not implementation assumptions.
- **Cost:** clean environments, fixture maintenance, and longer release cycles.
- **Month-three failure avoided:** the project optimizes for its own repo’s paths and fixtures, passes its own gates, and fails the first real adopter while the team believes M6 is closed.
- **Serves:** maintainers, investors/reviewers, and adopters whose environment differs from the development machine.

#### 19. Portable evidence bundle with retention and redaction

- **REFUSES:** closing or shipping on evidence that exists only in `/tmp`, contains absolute Josh-specific paths, lacks hashes/environment identity, or cannot be replayed by a third party.
- **Grounding:** `docs/PLAN.md:5786-5804` cites the raw completion frame at `/tmp/grade/agent-end-raw-frame.json`; M6 requires a third-party-reproducible transcript (`docs/plan/09-milestones.md:172-180`); installer path coupling is measured in `docs/plan/08-end-users.md:65-70`.
- **Mechanism:** `[PROPOSED]` produce a content-addressed bundle containing relative paths, repo/build identity, input and output hashes, redacted event frames, command/exit-code records, and a retention policy. A close references the bundle digest, not a local path.
- **Cost:** storage, redaction, and artifact lifecycle management.
- **Month-three failure avoided:** a month-later incident cannot be reproduced because `/tmp` was cleaned, a path is meaningless on another host, or the evidence omitted the version that produced it.
- **Serves:** external graders, support/debugging, release audits, and adopters proving a run to their own team.

#### 20. 1:many backpressure, quota, and refusal accounting

- **REFUSES:** fanout when capacity, admission, transport, or cost budget is unproven; it refuses refilling every idle-looking pane and refuses repeating the same refusal without escalation.
- **Grounding:** `docs/plan/09-milestones.md:206-219` records the longest unattended interval as a failure and warns that widening tolerance can make a useless loop look successful; `docs/plan/09-milestones.md:317-319` records 162 consecutive refused ticks over 4.2 hours and transport failures. `docs/PLAN.md:562-563` says actuation is absent and completion is available but not wired.
- **Mechanism:** `[PROPOSED]` give each parent and repo a bounded concurrency/queue/cost budget, fair scheduling, lease expiry, and refusal counters. A repeated refusal escalates to a typed finding with remediation; it does not silently consume ticks or spawn duplicates.
- **Cost:** lower peak parallelism and a budget ledger; some work waits even when panes appear free.
- **Month-three failure avoided:** a 1:many burst overloads transport, starves one repo behind noisy siblings, burns compute on retries, or produces four hours of “healthy” no-progress.
- **Serves:** unattended operators, multi-repo fleets, and humans paying for agent/runtime capacity.

---

## Winnowing: the top six

I ranked candidates by (1) whether failure can damage or mislead a foreign repo, (2) whether the mechanism is cross-cutting rather than another stage paragraph, (3) whether it has a falsifiable acceptance trace, and (4) whether a month-three adopter is likely to hit it. The six below are the smallest set that closes the largest structural holes. The others remain necessary, but several are subordinate to these six: #2/#4/#5/#6/#15/#16/#19/#20 are parts of a safe inception/adoption capsule; #8/#9/#10 are requirements-ledger consequences; #12/#14 are event-adoption consequences; #17/#18 are the proof shell around all six.

| Rank | Winner | Why it survives winnowing |
|---:|---|---|
| 1 | **Durable requirement ledger + conflict/approval semantics** (#7–10) | Without it, S9 is a sentence and every downstream “done” can satisfy the wrong human intent. It protects all stages and survives compaction, personnel change, and long runs. |
| 2 | **Transactional foreign-repo inception capsule** (#1–2, #6, #15–16, #19) | S1 is the trust boundary. A bad first write, wrong root, or unundoable gate install permanently poisons adoption before orchestration begins. |
| 3 | **Cold-host bootstrap + capability negotiation** (#3–4) | A foreign repo cannot succeed if binaries, versions, feature flags, and provenance are assumed. This converts “works on Josh’s machine” into typed admission. |
| 4 | **Wire-to-supervisor adoption proof** (#11–12, #14) | The current strongest result is only WIRE-PROVEN completion; the product claim requires consumption, state transition, replay safety, and a durable close. |
| 5 | **Parent/child 1:many mission ledger** (#13–14, #20) | The stated mission includes 1:many, but current proof is essentially one run/one loop. This is the smallest mechanism that prevents parent-green/child-missing and retry duplication. |
| 6 | **Independent fresh-project acceptance run** (#16–18–19) | It is the only honest antidote to self-grading on the existing repo. It tests the seams together and turns “foreign adoption” from a projected paragraph into a reproducible claim. |

### Top 1 — Durable requirement ledger with explicit human control

- **Trigger:** the first human brief, every requirement change, every ambiguity, and every approval-sensitive action.
- **Dispatch packet:** requirement IDs; verbatim source/hash; scope and repo identity; owner; acceptance; risk/approval class; current revision; unresolved conflicts; linked plan section/bead.
- **Amazing:** append-only records survive compaction/reboot; every bead, packet, event, evidence bundle, and close references a requirement revision; supersession/conflict edges are explicit; an approval has actor, target, scope, expiry, and allowed action set; replay reconstructs the exact active contract.
- **Adequate:** a single durable file/database with stable IDs, manual owner review, and fail-closed unresolved conflicts. It may lack automated semantic diffing, but it must not silently overwrite or dispatch unbound work. Cost: more human work at intake and visible pauses.
- **REFUSES:** chat-only requirements, paraphrase-only changes, silent overwrite, inferred approval, and dispatch with an unresolved requirement conflict.
- **Negative patterns grounded here:** seven conditions existed only in pane scrollback (`docs/PLAN.md:52-55`); the brief warns paraphrasing changes requirements (`docs/plan/00-brief.md:67-68`); S9 says every stage loses human decisions (`docs/plan/12-journey.md:35-38`).
- **Skills:** `/requirements-gathering` can structure requirements; `/human-in-the-loop` can design approvals; `/post-compact-reminder` can restore context. None of these, by themselves, supplies a run-linked append-only ledger whose IDs are enforced in beads and RPC events. The missing piece is assembly, not another writing guide.
- **Target done signal (new, not a current command):** on a fixture run, export the ledger, compact/restart, and replay it in a clean process; the active requirement revision, unresolved conflict set, approvals, and packet IDs must match byte-for-byte at the semantic level. A packet missing a requirement ID or approval must produce `REQUIREMENT_UNBOUND` or `APPROVAL_REQUIRED`, never a successful dispatch.
- **Serves:** the human sponsor first, then every worker, grader, and operator who must know what “done” means after the initiating conversation is gone.

### Top 2 — Transactional foreign-repo inception capsule

- **Trigger:** S1 against any repo, especially one with no OMP files, a dirty tree, nested worktrees, or an existing tracker/gate system.
- **Dispatch packet:** canonical repo identity; dirty/uncommitted paths; detected language/build/test commands; tracker and gate candidates; intended OMP-owned paths; selected adapters; backup/undo plan; explicit human requirements and approvals.
- **Amazing:** read-only `doctor` produces a complete profile; `init --dry-run` yields a deterministic write set; apply is atomic and namespace-scoped; every generated path is owned and undoable; a failed apply leaves no partial adoption; gates are selected by applicability and known-good evidence; all packets bind to the repo/worktree identity.
- **Adequate:** write only `.omp-orchestrator/` plus a manifest, keep all gate activation and tracker migration disabled until a human opts in, and support a complete manual undo. Cost: the first project may get only a truthful `PROFILED_NOT_ADOPTED` result.
- **REFUSES:** compile-time build-machine paths, ambiguous roots, partial writes, unowned files, automatic tracker conversion, and a green exit after a no-op.
- **Negative patterns grounded here:** projected `init` writes state and selects gates (`docs/plan/08-end-users.md:119-133`); installer has a `/Users/josh` fallback and compile-time path (`docs/plan/08-end-users.md:65-70`); the real installer false-green history is recorded in `docs/plan/07-installability.md:67-72`.
- **Skills:** `/canonical-cli-scoping` and `/cfs-cli-discipline` cover scoped doctor/health/repair surfaces; `/installer-workmanship` covers installer correctness; `/world-class-doctor-mode-for-cli-tools` covers detect-then-fix and backups. They do not yet define an atomic, identity-bound, foreign-repo adoption transaction for this product.
- **Target done signal (new):** run dry-run/apply/failure/undo against clean, dirty, nested-worktree, and monorepo fixtures; compare before/after manifests. The failure fixture must prove zero unowned writes and a typed refusal. A successful fixture must produce a portable adoption receipt whose repo identity matches the target, not the build checkout.
- **Serves:** a new adopter’s repository and the human who must trust OMP enough to let it write there.

### Top 3 — Cold-host bootstrap and capability negotiation

- **Trigger:** before any foreign-repo tick, and again after an upstream/toolchain upgrade.
- **Dispatch packet:** target OS/architecture; OMP artifact identity; toolchain/dependency versions; checksums; executable paths; supported subcommands/schemas; upstream feature flags; missing-capability remediation; network/cache policy.
- **Amazing:** one canonical artifact installs on a host with no build cache; every executable reports identity; no path points into the build machine; absent tools degrade with executable remediation; incompatible versions/features are typed and blocked; the first tick records the exact capability vector used.
- **Adequate:** run with a reduced adapter set only when the omission is explicit, owner-assigned, and reflected in the run’s status; no unproven fallback. Cost: slower bootstrap and a larger compatibility matrix.
- **REFUSES:** PATH-only checks, unpinned downloads, silent schema fallbacks, feature-gated types assumed present, and observations whose producer cannot identify itself.
- **Negative patterns grounded here:** installer knows 3 of 18 binaries and one is foreign (`docs/plan/07-installability.md:15-30`); `tick-monitor` has no `--version` (`:32-45`); `bv`’s host path differs (`docs/plan/09-milestones.md:105-107`); six upstream type surfaces are only DECLARED (`docs/plan/00-brief.md:500-506`).
- **Skills:** `/installer-workmanship`, `/environment-configuration`, and `/canonical-cli-scoping` cover packaging, configuration, and typed doctor output. They do not close the measured identity/provenance gap for all binaries or negotiate OMP/NTM feature semantics on a cold host.
- **Target done signal (new):** on a clean host/container, install from the documented artifact, run the identity/capability probe, then execute one tick against a foreign fixture. Remove one dependency and downgrade one version; each case must produce `MISSING`/`INCOMPATIBLE` with an actionable remediation and no dispatch. A successful receipt must be reproducible by a third party.
- **Serves:** new machines, non-Josh operators, release engineering, and any fleet whose package versions drift independently.

### Top 4 — Actual wire-to-supervisor adoption

- **Trigger:** whenever the plan relies on an upstream event/type, especially completion, receipts, claims, idle settlement, roster, cost, or compaction.
- **Dispatch packet:** upstream source revision and type card; expected wire carrier; captured raw frame; decoder version; parent/child/repo IDs; reducer transition; tracker/evidence side effect; replay and unknown-version policy.
- **Amazing:** the live `AgentEndEvent` frame crosses RPC, is decoded by this process, passes the correct parent/child identity, updates the supervisor’s durable state, causes the intended tracker/evidence transition, and remains correct under duplicate, late, malformed, and unknown events. Each other upstream type has its own status and is never promoted from declaration to adoption by prose.
- **Adequate:** keep completion automation disabled and expose a truthful `WIRE_PROVEN_NOT_CONSUMED`/human-required status until the full reducer path is proven. Cost: slower autonomy now, but no false green.
- **REFUSES:** “type exists,” “frame was captured,” or “event crossed the wire” as substitutes for consumption and user-visible effect.
- **Negative patterns grounded here:** `docs/plan/00-brief.md:494-511` explicitly separates wire proof from local consumption; `docs/PLAN.md:562-563` says completion is available but not wired; `docs/PLAN.md:5786-5812` records adoption as the remaining link.
- **Skills:** `/testing-conformance-harnesses` and `/oracle-gates` can structure wire/reducer oracles; `/distributed-systems` covers replay/idempotency concerns. No current skill assembly attaches the existing event plane to the supervisor and proves the resulting bead close.
- **Target done signal (new):** a clean trace contains raw frame → decoded event → supervisor transition → durable ledger update → independently observed tracker state, with `human_touch_count == 0`; replaying the same trace produces no second close. A negative trace with a missing/unknown event must refuse rather than infer completion.
- **Serves:** the central product claim, work graders, and operators who currently have to look at panes to find completion.

### Top 5 — Parent/child ledger for 1:many missions

- **Trigger:** the moment one human requirement fans out to two or more panes, repos, or child sessions.
- **Dispatch packet:** parent requirement revision; child manifest; repo identities; child attempt IDs; allowed paths; barrier/quorum/partial policy; concurrency and cost budget; event watermark; escalation owner.
- **Amazing:** every child has an independently durable lifecycle; events cannot cross child boundaries; duplicate/out-of-order events are idempotent; parent status is derived only from the declared barrier policy; `DONE` is impossible while a required child is `LOST`, `UNKNOWN`, or `UNVERIFIED`; partial completion is explicit and actionable.
- **Adequate:** refuse fanout and run one child at a time until parent/child semantics are proven. This is slower, but it is safer than pretending 1:many exists. Cost: lower throughput and more visible refusal states.
- **REFUSES:** parent-green/child-missing, arrival-order truth, implicit quorum, sibling mutation, and retries that create a new logical child completion.
- **Negative patterns grounded here:** the journey artifact table is singular (`docs/plan/12-journey.md:25-35`); M5 asks for ten closes from one recorded run but does not specify fanout membership or aggregation (`docs/plan/09-milestones.md:150-155`); transport has already produced success without delivery (`docs/plan/09-milestones.md:111-124`). The missing 1:many barrier is an inference from those acceptance shapes, not a claim that no useful fanout code can exist.
- **Skills:** `/agent-orchestration`, `/distributed-systems`, and `/concurrency-patterns` cover fanout, joins, and backpressure; `/testing-conformance-harnesses` can provide failure fixtures. The gap is a product-specific parent/child state contract tied to requirements and tracker closure.
- **Target done signal (new):** a three-child fixture runs with one delayed, one duplicate/retried, and one failed child. The recorded parent result must exactly match the declared barrier; no child receives another child’s event; replay and retry do not duplicate closes; the parent cannot report success for a missing required child.
- **Serves:** the stated 1:many mission, multi-repo release trains, and humans who need one trustworthy aggregate answer.

### Top 6 — Independent fresh-project acceptance run

- **Trigger:** before claiming S1–S8 or foreign adoption is complete, and after any change to the installer, adapters, event reducer, or requirement ledger.
- **Dispatch packet:** clean host/environment; generated repo fixtures; declared human requirement bundle; tool/dependency matrix; expected refusals; evidence-retention policy; independent grader instructions; 1:1 and 1:many scenarios.
- **Amazing:** a third party can reproduce a cold install, profile/adopt a foreign project, preserve requirements across restart, execute one 1:1 and one 1:many run, observe a durable close, and inspect every refusal. The fixture set includes a non-Rust repo, no tracker, pre-existing tracker, monorepo/worktree, missing dependency, dirty tree, and an intentionally unsupported gate. The grader is not given implementation-specific assumptions.
- **Adequate:** prove one cold foreign-host first tick and publish an explicit unsupported matrix for everything else; refuse to generalize M6 from that single run. Cost: fixture/host maintenance and a slower release gate.
- **REFUSES:** self-grading on the existing checkout, claiming portability from a warm local run, treating a readable transcript as evidence when it cannot be reproduced, and closing on worker self-report.
- **Negative patterns grounded here:** M6 is explicitly never attempted (`docs/plan/09-milestones.md:172-180`); end-user adoption is projected end to end (`docs/plan/08-end-users.md:6-8`); four false-zero measurements were caught by re-derivation (`docs/plan/09-milestones.md:243-246`); the plan has 20 build-and-never-call occurrences (`docs/plan/09-milestones.md:317`).
- **Skills:** `/agent-evaluation`, `/testing-conformance-harnesses`, `/verification-before-completion`, and `/web?` are useful for independent acceptance and evidence discipline; `/using-git-worktrees` can produce isolated fixtures. They do not currently supply a fresh-project oracle that exercises S1 through ship as one adoption journey.
- **Target done signal (new):** a clean-host transcript plus an independently generated evidence bundle passes the same scenario from a second process/machine. The grader must verify requirement IDs, repo identity, capability vector, event-to-state transition, child aggregation, refusal inventory, and portable artifacts. Any missing upstream adoption is reported as `DECLARED ONLY`, not silently counted as pass.
- **Serves:** external adopters, maintainers, investors/reviewers, and the project’s own future self when the existing repo’s conventions are no longer representative.

## Bottom line

The plan’s most dangerous assumption is not “we need another stage.” It is that a sufficiently complete description of the existing repository will transfer to a foreign project. The six winners turn that assumption into boundaries:

1. **Humans have a durable, versioned contract.**
2. **S1 is an atomic, undoable write boundary.**
3. **A cold host proves capabilities and identity instead of inheriting them.**
4. **Upstream events are consumed into durable local effects, not merely observed.**
5. **1:many has explicit parent/child semantics and retry safety.**
6. **An independent fresh-project run is the release oracle.**

If any one of these is absent, the system can still produce impressive artifacts and green local measurements while refusing—or worse, appearing to succeed—on the first real project.
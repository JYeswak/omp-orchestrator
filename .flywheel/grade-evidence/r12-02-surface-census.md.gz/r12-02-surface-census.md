# Round 12 — `02-surface-census.md` — fresh grade and repair record

## Fresh dispatch

- **Agent:** `r12-census-grader`
- **JSM choice:** `jsm suggest "surface census inventory data quality"` failed because JSM bandit recommendations were disabled; `jsm search data-quality-validation` selected `data-quality-validation` v1.
- **Prompt scope:** only `docs/plan/02-surface-census.md` plus the inventory/data-quality claim contract: universe, schema, row kinds, expected twins, dispositions, completeness, provenance, percentages, and denominators must match named artifacts and exact derivations. Declared NUMBERS.toml figures were treated as authoritative when their command/expectation remained intact. No prior findings, ledger, or fix notes were supplied.

## SEARCH SPACE

The fresh agent read all 900 lines of the assigned file, `/tmp/inv.txt`, `docs/plan/SURFACE-MAP.jsonl`, and `NUMBERS.toml`. Verification re-ran focused `jq` calculations over the complete map, checked the inventory/map hashes and fields, searched for stale `17.1%|WIRE=46|zero unmapped|ee>ntm|RCH_ENABLED`, and checked the current declared key set. No cargo, gate, or formatter ran.

The map re-derivation returned 591 rows, `maps_to_crate == null` on 478, `validated_by == null` on 0, with dispositions `CONSUMED=32`, `WIRE=67`, `VALIDATE=30`, `RETIRE=453`, and `UNPROBEABLE-PENDING=9`. The existing `surface_engaged_pct` figure is declared at 21.8; the new unmapped-by-crate figure is declared as `surface_map_unmapped_rows=478` with no duplicate key.

All 12 fresh findings were REAL and fixed. No item was deferred or retracted.

## Findings

| SEVERITY | Finding | Verdict and diff location |
|---|---|---|
| **MAJOR** | `8/183` mixed-census direct coverage was called an OMP share. | **FIXED** — `§2 :76-79,94-103`; labels all-census 8/183 and OMP-only 7/157 = 4.46%. |
| **MAJOR** | Row-kind tally included synthetic slash sentinel while counts said slash_commands=0 and lacked transport twins. | **FIXED** — `§1 :44-64; §3 :159-177`; observed/synthetic slash semantics and missing transport/expected twin are explicit. |
| **MAJOR** | Header claimed all derived material came from ephemeral `/tmp/inv.txt`. | **FIXED** — provenance `:3-31,400-406,441-446,500-503,849-860`; inventory/map hashes, inputs, tools, exits, and subsection sources are recorded. |
| **MAJOR** | “Zero unmapped” was false under `maps_to_crate == null`. | **FIXED** — `§9 :707-714; §10.3 :829-834`; exact definition and result 478 replace the false zero. |
| **MAJOR** | Non-null `validated_by` was treated as structured RETIRE proof. | **FIXED** — `§4 :292-298; §8 :658-701; §9 :707-714; §10 :823-843`; structured probe/exit/timestamp/artifact evidence is required, and the old claim is narrowed to what is actually established. |
| **MINOR** | `ee=111` was said to exceed `ntm=114`. | **FIXED** — `§7.5 :591-594`; 111 is smaller, while 123 help-text entries are explicitly a different measure. |
| **MINOR** | 93% RETIRE omitted 42 unmapped rows without naming the denominator. | **FIXED** — `§8 :646-655`; reports 469/544 = 86.2% all rows and 469/502 = 93.4% only with explicit unmapped exclusion. |
| **MINOR** | 17.1% and WIRE=46 remained current-sounding after declared 21.8%/67 superseded them. | **FIXED** — reconciliation `§9 :721-728,769-777`; stale values are historical or removed, current prose uses 21.8%/67. |
| **MINOR** | RCH_ENABLED “zero references” was false because the section contained two historical references. | **FIXED** — `§7.1 :524-526; §7.6 :629-632`; historical scope and current two-match result are explicit. |
| **MINOR** | WIRE was presented as bead-backed proof without bead/owner/time fields. | **FIXED** — `§4 :292-298; §9.3 :769-777; §10.2 :825`; current WIRE means proposal and required future evidence fields are named. |
| **MINOR** | “13 tests pass/built/correct” lacked command, output, and revision. | **FIXED** — gate discussion `:400-406`; assertion is UNVERIFIED and only the observed help error remains runtime evidence. |
| **MINOR** | `~26` ntm refs violated the MEASURED-by-default contract. | **FIXED** — `§6.2 :478-480; §7.1 :511; §7.5 :610`; approximate/session observations are labelled historical estimates or unverified. |

## Number registry

The current registry was checked before correcting prose. Existing `surface_map_rows=591` and `surface_engaged_pct=21.8` were respected. The previously undeclared load-bearing `maps_to_crate == null` figure was added as `[figures.surface_map_unmapped_rows]` with command, expectation `478`, appearance path, and note. A direct parser check found 15 unique figure keys and no duplicates.

## Result

**12/12 findings accounted for; 12 fixed; 0 deferred; 0 retracted.**
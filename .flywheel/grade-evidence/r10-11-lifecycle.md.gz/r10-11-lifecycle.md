# Round 10 — 11-lifecycle.md — adversarial hillclimb

## Fresh dispatch

- **Subagent:** `r10-lifecycle-hillclimb`
- **JSM selection:** `jsm suggest "lifecycle orchestration completion state machine"` was unavailable because bandit recommendations are disabled; exact `jsm search agent-orchestration` selected `agent-orchestration` (v1, Joshua Nowak), with `vibing-with-ntm` also surfaced as a related result. `jsm search lifecycle` additionally confirmed lifecycle-related alternatives, but this dispatch used the distinct orchestration specialist.
- **Prompt boundary:** the subagent received only `docs/plan/11-lifecycle.md`, the seven-field dispatchable-stage contract, the MEASURED/PROJECTED/citation/NO-CLAIM/handoff contract, and a fresh-eyes instruction. It received no prior findings, ledger, or summary.
- **Raw result:** 11 findings in `/tmp/grade/r10-agent-11.json`. One exact Y-count re-derivation reinforces R8's existing `m-l6` finding and is not counted separately below.

## Verification performed

The target was not edited. I re-read only cited target/source ranges and ran focused read-only probes; no cargo, gate, or formatter command ran.

- Exact case-sensitive search for `Trigger|Dispatch packet|Amazing|Adequate|Negative patterns|Skills|Done signal` over `docs/plan/11-lifecycle.md` returned **0 matches**.
- Re-read target ranges `:1-110`, `:120-180`, `:180-250`, and `:250-342`, plus `docs/plan/12-journey.md:23-61` for the required contract.
- Re-read `omp-orchestrator/Cargo.toml`, the dispatch/receipt path in `main.rs`, the state-path code, `omp-rpc-session`, `dispatch-claim-fence`, `ack-spine/followup`, and `finding-dispatch`. These confirm the reported boundaries: the resident path dispatches but stops at receipt; the RPC enum has no local `AgentEndEvent` arm; claim authorization requires an already in-progress assigned snapshot; follow-up has a worker-close-to-Healthy branch; and the current state paths are not all session-scoped.
- `jq` over `docs/plan/SURFACE-MAP.jsonl`, filtered to batches 1–9, returned `270` rows with `RETIRE=214`, `CONSUMED=8`, `WIRE=31`, `VALIDATE=11`, `UNPROBEABLE-PENDING=6`, confirming the reported 11-lifecycle summary mismatch.
- Focused source greps found no `stage_id|from_stage|to_stage` in the resident orchestrator and no `fast-dispatch|tick-dispatch|reap-finished-panes|verify-dispatch` in current crate paths.

## Verified new findings (10)

### L1 — P0 — the lifecycle section is not dispatchable under the seven-field contract
**Target:** `docs/plan/11-lifecycle.md:38-56,235-293`.
The exact case-sensitive field search returned zero for all seven required labels; the section has no per-stage Trigger, Dispatch packet, Amazing, Adequate, Negative patterns, Skills boundary, or Done signal. **Fix:** add a runbook block for each canonical stage, including exact artifact/input/expected output/exit and refusal; or state that §12 is canonical and cross-reference it rather than claiming §11 is the composed runbook. (Raw LIFE-01.)

### L2 — P1 — stage IDs and skill cardinality are ambiguous and contradictory
**Target:** `:17-34,240-286`.
The target's first model has S1–S9, the skill table has 12 stage rows but 18 references/16 unique skills, line 280 names ten steps, and `docs/plan/12-journey.md:23-35` reuses S1–S9 for a different cut. **Fix:** choose one canonical graph, give viability/loop/honesty explicit IDs or attributes, and publish the mapping with accountable owner/consumer/observer roles. (Raw LIFE-02.)

### L3 — P1 — measured crate ownership names absent crates and omits the resident owner
**Target:** `:19-29`.
Focused search over current `crates` found no `fast-dispatch`, `tick-dispatch`, `reap-finished-panes`, or `verify-dispatch`. Conversely, `omp-orchestrator/Cargo.toml:16-23` lists `ack-stage`, `dispatch-claim-fence`, `omp-rpc-session`, `subprocess-contract`, and `receiver-receipt`, while `main.rs:5-7,563-631` implements the resident dispatch/receipt path. **Fix:** regenerate the table from manifests and call/dependency edges; mark absent names PROJECTED/unbuilt and make `omp-orchestrator` the accountable S5 consumer. (Raw LIFE-03.)

### L4 — P1 — template variables do not enforce tracker custody
**Target:** `:76-95`.
The displayed `ntm send -t dispatch --var … --dry-run` is schematic and has no omitted-variable input, stderr, or exit artifact. `dispatch-claim-fence/src/lib.rs:257-319` actually requires a fresh `in_progress` snapshot with the exact assignee; a required target/path/bead pair cannot enforce that state. The target admits the template body was not verified at `:94-95`. **Fix:** separate template omission refusal from claim-custody refusal and add exact negative probes for absent/open/elsewhere-assigned beads. (Raw LIFE-04.)

### L5 — P1 — selection→claim→dispatch remains unowned and TOCTOU-prone
**Target:** `:81-90,136-145,161-167`.
`omp-orchestrator/src/main.rs:836-860` runs `br ready`, selects the first ID, reads a snapshot, and calls `authorize`; the focused claim/update/status search found only the fence import. The fence authorizes an already-claimed snapshot, so no production caller performs the claim. The “three severed links” text also names only two arrow edges. **Fix:** add an atomic claim owner/handoff or explicitly make claim human-required; define S7→S8 and S8→S9 transitions with packet/refusal/reap/log/build evidence and correct the link count. (Raw LIFE-05.)

### L6 — P1 — completion adoption and S5 state are overstated
**Target:** `:25,49,251,269-275,297-342`.
The current source has an automated designed-but-unverified observe→queue→dispatch→receipt path (`omp-orchestrator/src/main.rs:5-7,563-631,801-879`; `lib.rs:24-29`), contradicting the target's human-only S5 wording. More importantly, local `omp-rpc-session/src/lib.rs:416-423` has only Ready/Response/Unknown/Malformed and `:889-901` returns a response report; focused grep found no local `agent_end|willContinue|isTerminal|RpcSessionEventFrame|AgentEndEvent` consumer. A raw `isTerminal:true` frame is not proven equivalent to `willContinue`. **Fix:** separate declaration, observed upstream frame, local parser, consumer, and reap; keep completion AVAILABLE/WIRE-PROVEN but NOT CONSUMED until the local path exists, and do not equate the fields without a schema/test. (Raw LIFE-06.)

### L7 — P1 — reap/follow-up is absent, unconsumed, and has a false-completion branch
**Target:** `:27,149-167,330-342`.
The named reap crate is absent. `ack-spine/src/followup.rs:86-137` is only a candidate, with no production caller in the focused `classify_followup|followup_action` search; its open-bead/unchanged-assignee/no-comment branch returns `VerdictPosted` and `:150-156` maps that to `Healthy`. The resident cycle `main.rs:648-687,801-880` stops after dispatch/receipt, with no production reap/grade/release/ship edge. **Fix:** name and wire reap after receipt, represent in-progress as non-terminal, and add a post-dispatch edge or explicit NO-CLAIM that this supervisor stops at receipt. (Raw LIFE-07.)

### L8 — P1 — surface-map convergence totals are stale and underived
**Target:** `:182-231`.
The target reports batches 1–9 as 270 with `RETIRE 243`, `CONSUMED 8`, `WIRE 11`, `VALIDATE 8`; the exact `jq` re-derivation returned `270`, `RETIRE 214`, `CONSUMED 8`, `WIRE 31`, `VALIDATE 11`, `UNPROBEABLE-PENDING 6`. The target provides no source row citation or derivation command. **Fix:** declare the universe/disposition policy, regenerate from an immutable snapshot, and recompute all “value is in the 11” conclusions. (Raw LIFE-08.)

### L9 — P1 — stage logging and S9 handoff are not durable contracts
**Target:** `:159-167,235-286`.
The target claims 3/9 stages log, but current heartbeat rows `omp-orchestrator/src/main.rs:698-708` contain event/status/tick/repo/session/detail and no stage/from/to IDs; focused grep found no `stage_id|from_stage|to_stage`. The lifecycle has no human-decision owner/artifact/retrieval path even though `docs/plan/12-journey.md:37-38` makes S9 cross-cutting and records eleven lost decisions. **Fix:** add a stage-tagged append-only event schema with command/exit/artifact plus an S9 ledger owner and retrieval command, or explicitly mark those surfaces unbuilt. (Raw LIFE-11.)

### L10 — P1 — 1:many state namespace and ownership are unspecified
**Target:** `:17-29,235-293`.
`omp-orchestrator/src/lib.rs:447-462,494-499` counts dispatchable panes but returns only `.first()`, and `main.rs:854-862` selects only `bead_ids.first()`. `main.rs:221-236` gives heartbeat a session-named path but rewrites tick-monitor state and pending-dispatch to fixed filenames; two sessions in one HOME therefore collide. `omp-rpc-session/src/lib.rs:5-21` is explicitly one OMP child with no cross-session continuity. **Fix:** add a cardinality matrix and per-session keys/paths with collision refusal, or explicitly state one-dispatch/one-session support until bounded fan-out is proven. (Raw LIFE-10.)

## Known reinforcement not counted

Fresh raw LIFE-09 re-counted four visible Y cells against line 55's “3 of 9,” reinforcing R8 `m-l6`. It is recorded here as verification context, not a new finding.

## Capability-floor check

No converged section (`03-crates`, `05-actions`, or `06-gates`) was edited. Evidence-only work and the role-aware ledger append do not alter those sections; the 06 count/contract references above are dependency observations, not regressions.

## Verdict

**FAIL — 10 new deduped findings.**
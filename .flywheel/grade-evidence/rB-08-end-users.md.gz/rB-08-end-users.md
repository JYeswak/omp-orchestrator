# Round 9 — 08-end-users.md — adversarial lens

## Search and deduplication

Read the complete current section (340 lines). Harness-grep searches covered the full file for:

- `complete.*does not exist|completion.*does not exist|complete layer|completion is|AVAILABLE|WIRE-PROVEN|human looking|every completion`;
- `doctor|init|adopt|PROJECTED|MEASURED|NO-CLAIM|157 of 183|2 of 8|OneshotSpawn|TransportReceipt|refusal`;
- the current authority, `docs/plan/00-brief.md`, for `completion is|WIRE-PROVEN|AVAILABLE, NOT WIRED|AgentEndEvent|willContinue|does not exist`;
- prior round-4 and round-8 evidence to avoid re-filing the known usage-citation, gate-count,
  version-flag, transport, lifecycle, and adoption findings.

This space covers every persona claim, the zero-to-first-tick transcript, adapter contract, degradation
ladder, end-user benefits, abandonment risks, and the section-level NO-CLAIM. The cross-check is
necessary because the section labels several statements as `MEASURED (brief §4)`.

## Finding

### R9-08-01 [MAJOR] — completion is described as absent after the brief proved the signal exists

**Constructs:** `docs/plan/08-end-users.md:38-40` calls the `complete` layer nonexistent and says the
core need is two empty rows; `:173-175` says every completion was found by a human; and `:284-285`
again labels the completion layer nonexistent. These are presented as measured brief facts, not merely
future design language.

**Contradiction:** The current authority `docs/plan/00-brief.md:493-500,508-511` records completion as
`WIRE-PROVEN` and says the remaining issue is that the supervisor does not consume the signal. The
control-loop table calls it `AVAILABLE, NOT WIRED`, not an absent protocol.

**Why it matters:** The local adoption gap remains real—this repository has not wired completion into
its tracker—but the end-user narrative collapses "signal exists" and "our consumer is absent." That
makes the Persona B value proposition and the §6 "what cannot be gotten today" claim overstate the
upstream gap and obscures the actual integration work.

**Fix:** Rephrase all three occurrences as "the completion signal is available/wire-proven, but this
repository's completion consumer is not wired; local closes still require human evidence today." Keep
the local manual-observation measurement, remove "two empty rows"/"does not exist" where it refers to
the protocol, and cite the brief's narrowed status.

This construct was absent from the prior round-4 end-user finding list and is distinct from the known
`doctor` usage, gate-count, `-V`, and `OneshotSpawn` findings.

## NEW FINDINGS: 1

VERDICT: PASS-WITH-FIXES (adversarial lens, round 9)

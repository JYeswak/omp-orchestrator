# Batch 3 notes — ntm surfaces

## Scope
30 rows: ntm:overlay through ntm:session-templates. `ntm:send` is the one CONSUMED row; the other 29 are RETIRE.

## CONSUMED
- ntm:send → omp-orchestrator. Production construct: crates/omp-orchestrator/src/main.rs:617-625 builds --robot-send=<session>, --panes=<pane>, and --msg-file=<staged>, invokes the configured ntm binary, and parses the retained transport receipt.

## RETIRE
The remaining 29 surfaces are operator UI, diagnostics, provisioning, replay, profile, policy, session-management, or maintenance commands. No current crate contract calls or requires them: the orchestrator uses its own typed observation/claim/fence/receipt path, and the actual NTM transport is the robot-send surface. They map to null intentionally.

## Validation boundary
Broad production-call search: tool.grep(pattern=Command::new("ntm")|run_command("ntm"|invoke([^\n]*ntm|--robot-[a-z0-9-]+), path=crates). Its search space covers crate process construction and NTM robot flags; it found the robot-send call in crates/omp-orchestrator/src/main.rs:617-625 and robot-activity in fleet-composite, but no batch-3 surface other than send. For RETIRE rows, validated_by is null because no positive runtime command can prove that a surface should never be called; the source-search boundary and retirement rationale are recorded here.

No rows were left unclassified. No WIRE or VALIDATE disposition is justified in this batch from the current crate contracts.
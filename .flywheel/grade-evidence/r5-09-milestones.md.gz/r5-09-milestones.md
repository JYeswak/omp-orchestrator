
EVIDENCE / MAJOR 1 + GATE FINDING — PV6 repeats a retired figure without naming its replacement, so the new retired-figure gate has a coverage hole.
PV6 at lines 221–225 prints “81 JSON-RPC methods, 17 of 81 used,” labels it inherited and retired, and points to a notice search, but never states the replacement surface. The stated gate contract in this grading packet says that figure may not appear anywhere without naming its replacement; this occurrence shows the gate is GREEN while the rule is not satisfied.

FIX: Require every retired-figure match to carry an explicit replacement in the same record, and update PV6 to name the current surface or remove the dead figure entirely.

EVIDENCE / MAJOR 2 + GATE FINDING — The milestone section still carries the refuted `-V` denominator.
M6’s version-probe paragraph at lines 177–184 says `tmux -V` returns successfully but then says “`-V` answers 5/9”; the sibling’s independent Round-4 gates grade records the corrected six-of-nine result at `r4-06-gates.md:20`, including tmux. The section’s own successful tmux observation contradicts its count, and the retired-figure gate does not catch this stale number.

FIX: Derive the responder list and denominator from one version-probe artifact, replace 5/9 with the current six-of-nine result, and make the stale-figure gate cover corrected-but-wrong numerals as well as the three retired figures.

EVIDENCE / MAJOR 3 + GATE FINDING — The gate headline is stale against the typed status model.
PV6 at lines 223–225 and the self-assessment at lines 291–293 still say 2 of 8 gates have all four legs and 4 of 8 have no mutation leg. The current typed rebuild is recorded by the sibling grade at `r4-06-gates.md:16` as 1 of 8 qualifying under automated mutation, with `no-shell-gate` no longer qualifying. The new retired-figure gate only protects three named historical figures, so this stale headline survives it.

FIX: Generate all gate ratios from the typed registry and add a consistency gate that rejects obsolete interpretations, not only explicitly retired figure strings.

ABSENCE / MAJOR 1 — Section 11 misclassifies the lifecycle stage owned by this section.
Section 09’s stage is plan/milestone validation: it has an explicit done-definition template at lines 7–21, applies that template to seven milestones at lines 33–46, and specifies a planned `plan-check` build grader at lines 248–275. Section 11’s matrix instead marks S2 plan as all absent (`11-lifecycle.md:43–53`), while marking S8 grade build grading `Y`; its own §11.5 says S8 grading is prose (`11-lifecycle.md:142–146`). The S2 template cell is wrong—§09 demonstrably contains and uses a template—and the `Y` build-grade cell is not evidence that §09’s projected `plan-check` exists.

R13 status for this section: TEMPLATE = exists and is used; DISPATCH = assumed/absent; REAP = absent; LOGGING = partial at best; BUILD GRADING = specified but unbuilt.

FIX: Add a distinct plan-validation row or map §09 to S2 with the actual per-cell status, distinguishing “template used in prose,” “plan-check projected,” and “runtime grade used elsewhere.”

INVESTOR / MAJOR 1 — The section defines how to close milestones but not why the resulting system deserves capital.
The rubric at lines 282–299 includes “the problem is real,” “adoption path is credible,” and “team tells on itself,” but the section’s own NO-CLAIM at lines 315–319 says it does not establish that closing seven milestones produces a system anyone wants and makes no schedule or effort claim. M5’s ten-close criterion at lines 140–160 is an internal existence test, not a paying-user outcome, avoided cost, or return.

FIX: Add an investor-facing milestone outcome linking each capital-consuming stage to buyer evidence, economic value, and a stop decision if that value does not appear.

ADVERSARIAL / MAJOR 1 — M5 is treated as thesis-invalidating without proving the thesis it is supposed to validate.
Lines 158–160 call M5 “the first milestone whose failure invalidates the thesis,” yet its observable is ten autonomous closes from one recorded run, and its NO-CLAIM says ten closes are only an existence proof, not a rate. That test can establish that one controlled loop can close; it cannot establish reliability, customer value, or a viable operating business.

FIX: Separate technical viability from business validation and require M5 to feed an external workflow metric before calling its failure thesis-invalidating.

RE-DERIVATION LOG

- `tool.grep` for `^### M[0-9]+ —` returned 7 milestone headings, M1–M7, matching the “Seven” claim at lines 35–36.
- `tool.grep` for `PC[0-9]+` in the plan-check table returned 8 rows, PC1–PC8, matching the eight PV rules claimed at lines 215–243.
- The grading rubric at lines 282–289 contains 6 dimensions, not an unbounded scorecard.
- The BANKED/UNPROVEN table at lines 305–313 contains 7 paired rows.
- M5’s observable at lines 142–145 requires 10 consecutive closes.
- The M7 escalation threshold at lines 198–200 is 3.

EVIDENCE / MINOR 1 — The section’s own numerical discipline is not applied consistently to inherited measurements.
PV1 at lines 215–216 requires every number to carry a deriving command, but the self-assessment at lines 291–296 repeats 2-of-8, 4-of-8, 6, 17, and 4 from brief references rather than commands in this section. The BANKED rows at lines 307–313 likewise present 20 occurrences, 21st, 162 ticks, 178 ticks, and 183/183 as evidence, while only some neighboring claims include derivations.

FIX: Make every inherited number carry its source command and artifact inline, or label it as an unverified inherited measurement and exclude it from banked evidence.

ADVERSARIAL / MAJOR 2 — `plan-check` validates document form while the section’s important claims remain unchecked.
The checker design at lines 250–267 covers numerals, banned words, headings, `MEASURED` verbs, NO-CLAIM presence, ratios, search-space syntax, and construct-shaped citations. Lines 269–275 explicitly concede that it cannot detect a false `MEASURED` whose command was never run or an admissible observable that measures the wrong quantity. Those are precisely the semantic failures the section’s own rubric treats as investor-critical, so the proposed self-check does not validate the plan’s central claims.

FIX: Add independent execution receipts and a separate relevance/value review gate; keep `plan-check` explicitly limited to form rather than presenting it as plan validation.

ADVERSARIAL / MAJOR 3 — The zero-human observables can pass vacuously if event capture is absent or incomplete.
M4 at lines 119–125 closes on `human_touch_count == 0`; M5 at lines 140–145 closes on the union of human-originated events being empty; and M7 at lines 196–209 closes on zero human-originated events. The section specifies no event-source inventory, positive control proving a known human action increments the count, or mutation leg proving removal of event capture turns the observable RED. A silent logger can therefore look exactly like autonomous operation.

FIX: Define the authoritative event sources and durable trace schema, then require a known-human positive control and a capture-removal mutation that invalidate M4/M5/M7.

INVESTOR / MAJOR 2 — The final milestone can pass while the product does nothing valuable.
M7’s observable at lines 196–209 requires an unattended window with progress or named refusals, but its own NO-CLAIM says an unattended loop “producing nothing satisfies M7 and is worthless.” The seven-milestone chain ends at M7 at lines 35–44 and contains no external-user, adoption, savings, revenue, or customer-outcome milestone, so the plan can declare its lifecycle successful while explicitly admitting that success may have no value.

FIX: Add an external-validation milestone after technical autonomy with a real user, baseline, target outcome, continued-use or payment signal, and a kill threshold.

ADVERSARIAL / MAJOR 4 — The proposed meta-checker does not enforce its own definition of an admissible observable.
Lines 23–31 require an observable to be a runnable command, outsider-runnable, interpretation-free, and failing on the pre-milestone state. PC3 at lines 254–261 only checks that an `Mn` heading has an `OBSERVABLE` field; it does not execute the command, check the expected result, prove outsider reproducibility, or test pre-state failure. The checker can therefore certify a prose placeholder that passes the presence test while violating the substantive closure contract.

FIX: Represent `Observable` as a structured command/pre-state/post-state/expected-output record and make the validator execute a bounded dry run against a known pre-state fixture.

ABSENCE / MAJOR 2 — The done-definition template has no owner, budget, deadline, or decision authority.
The template at lines 15–20 contains only goal, observable, not-in-scope, starting point, and risk; the section explicitly says at lines 315–319 that it makes no schedule, duration, or effort claim. A milestone can therefore have a technically valid observable while nobody is accountable for delivering it, deciding whether to continue, or controlling spend.

FIX: Add owner, required resources, deadline, spend boundary, escalation path, and explicit continue/kill authority to every milestone.

CHALLENGE TO /tmp/grade/r4-06-gates.md

I challenge the sibling’s **`-V` replacement claim** (`r4-06-gates.md:20`, construct: corrected version-probe denominator). The sibling is right that the target’s `5 of 9` is stale and internally conflicts with the successful `tmux -V` observation. But “the corrected nine-binary re-derivation is six responders” is taken on trust in the sibling file: it publishes neither the responder list nor the exact command/result that produces six. The stale-number finding holds; the replacement figure needs its own derivation artifact before it can be used as evidence.

The sibling’s R13 finding (`r4-06-gates.md:28`, construct: gate-admission lifecycle) is directionally correct but its severity language is too broad. Gate admission does have a runtime template and refusal/receipt concepts in the target section; what is missing is the **build-stage lifecycle** for creating, dispatching, reaping, logging, and grading gate work. The fair formulation is “runtime gate behavior exists, gate-work lifecycle is missing,” not that the section has no template at all.

I found no main sibling not-found whose search space was too narrow to support its stated criticism. Its own challenge at `r4-06-gates.md:46` correctly observes that the exact commercial-term regex in the prior `01-idea` grade proves lexical absence only, not the stronger semantic conclusion that no economic case exists; the underlying concern may still hold, but the command must be scoped to what it actually establishes.

The sibling’s current `27/379` inventory result (`r4-06-gates.md:36`, construct: filesystem census) is also a claim I would not accept without the command output being bound to a revision or snapshot, although the sibling does provide the exact command. Its criticism of the stale `26/370` figure holds; its replacement baseline remains environmental evidence rather than a durable source until pinned.

ADVERSARIAL / MAJOR 5 — The claim that the milestone chain is forced and cannot benefit from more agents is asserted by a diagram, not demonstrated by a task DAG.
Lines 35–44 say the seven milestones are “ordered by dependency,” “forced, not chosen,” and provide “no way to buy schedule with more agents,” but the Mermaid chain only shows milestone-level arrows; it does not show the underlying bead dependencies or prove that each milestone has no internally parallel work. The conclusion is load-bearing for schedule and capital planning, yet the section provides no critical-path calculation.

FIX: Derive milestone ordering from the complete bead DAG, publish the critical path and parallel frontier, and reserve the no-parallelism claim for dependencies actually proven.

RE-DERIVATION LOG

- `tool.grep` for `^### M[0-9]+ —` returned 7 milestone headings, M1–M7, matching the “Seven” claim at lines 35–36.
- Counting the numbered PV rules at lines 215–243 gives 8: PV1 through PV8.
- `tool.grep` for `| PC[0-9]+ |` returned 8 plan-check rows, PC1 through PC8.
- `tool.grep` over the six rubric row labels at lines 284–289 returned 6 dimensions.
- Counting the paired rows in the BANKED/UNPROVEN table at lines 307–313 gives 7.
- M5’s observable at lines 142–145 requires 10 consecutive closes; M7’s escalation threshold at lines 198–200 is 3.

BLOCKERS: 0
MAJORS: 12
MINORS: 1

R13 LIFECYCLE RESULT FOR SECTION 09

The section’s stage is primarily S2 plan/milestone validation, with a secondary S8 grading responsibility. Template exists and is used; dispatch is assumed/absent; reap is absent; logging is partial and not a canonical lifecycle log; build grading is specified as `plan-check` but explicitly unbuilt. Section 11 marks S2 as entirely absent and S8 build grading as used, which does not match Section 09’s observable template and projected checker.

VERDICT: FAIL

THE ONE THING: This section is excellent at defining technical closure conditions, but its own enforcement is still projected: stale figures survive the new retired-figure gate, the plan-check cannot validate semantic truth, and no milestone proves that a technically autonomous loop creates external value.

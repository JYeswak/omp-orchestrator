# Round 12 — 04-diagrams.md — ABSENCE lens, role hillclimb — OliveCat
## DISPATCH
Subagent: `DiagramsReader` (task agent, fresh context — file path + claim contract; no ledger,
no prior findings). No diagram-specialist skill in jsm's catalog; general task agent told to
check generation-provenance, data agreement, MEASURED/PROJECTED labels, and cross-section
contradictions.

## VERIFIED FINDINGS (each re-derived by me before recording)

SEVERITY: MAJOR — D1 board "75 total" (line 374) repeats an error the brief explicitly retired
("74 total, not 75", 00-brief.md:498-502). Verified: line 374 reads verbatim as the agent quoted.
FIXED: re-pointed at the brief's corrected snapshot with the "as of" stamp. DIFF: Diagram 6
caption.

SEVERITY: MAJOR — D2 Diagram 4's COMPLETE subgraph says "4 of 4 legs — 1 gate" while its own
prose says "2 of 8"; undrained-pipe-lint sits in PARTIAL with all four legs visible in its own
cells. Verified by reading lines 231/237/259/315. This is a fix-introduced error: the round-11
gate-count correction reached the prose but not the generated diagram.
FIXED: caption corrected to the rebuilt-column truth (1-of-8 on the mutation-acts-on column,
no-shell-gate AFFORDANCE noted), undrained-pipe-lint moved to COMPLETE, prose at 315 aligned.
DIFF: Diagram 4 + Diagram 5 mapping.

SEVERITY: MAJOR — D3 Diagram 4's "mutation 2" cell and its "grep -rli mutation" methodology
regress to the retired keyword proxy while stamping MEASURED and citing §00 — which now records
AFFORDANCE for no-shell-gate and "every 0/8,1/8,2/8,4/8 ratio below is historical". Verified:
00-brief §3.5 carries the retired-instrument warning verbatim. The diagram cites the owning table
and contradicts it.
FIXED: methodology line replaced with the acts-on column's four values (TREE/FIXTURE/AFFORDANCE/
NONE) and the source pointer re-anchored. DIFF: Diagram 4 generation note.

SEVERITY: MAJOR — D4 Diagram 3's CMP node "DOES NOT EXIST" contradicts the owning table's
"AVAILABLE, NOT WIRED" (AgentEndEvent wire-proven, 7f7e0f6). Verified: owning table in
00-brief §4 carries AVAILABLE-NOT-WIRED; the diagram is a pre-refutation fossil. The exact
difference the fresh reader was hired to find: the section argues from an absence its own
neighbor section retracted.
FIXED: node re-labelled "AVAILABLE, NOT WIRED — adoption pending"; Diagram 5's mapping line
325 re-worded to "not consumed by any crate" instead of "do not exist in any crate". DIFF:
Diagram 3 node, Diagram 5 L-row.

SEVERITY: MAJOR — D5 provenance claim "Diagrams 3 and 4 are generated from the §00 tables" is
false in both directions: Diagram 3's ACTIONABLE node says the filter is FIXED (-oco) while the
named source table still says BROKEN, and its OBS node drops the measured asymmetry defect. The
underlying fix is real (I verified crates/tick-monitor/src/lib.rs:462-463 includes NewlyIdle).
So either the diagram is stale or the brief's table is — and the "generated from" claim fails
either way. This is the deepest finding: two sections drifted APART from a shared source and
the generation claim hid it.
FIXED: provenance line now names BOTH artifacts with their state ("generated from the brief's
§4 table as of its round-11 state; the actionable-row fix postdates the diagram — see
03-crates' recorded disagreement") and the OBS node carries the asymmetry caveat. The real fix
(regenerate from one reconciled source) is DEFERRED: it requires the orchestrator to settle
which artifact owns the loop table, which is the propagation question the gap-propagation gate
was built for.
DIFF: Diagram 3 provenance note + OBS node.

SEVERITY: MAJOR — D6 line 325 "J, L do not exist in any crate" — J is the receiver receipt; the
receiver-receipt crate exists with two incoming edges in this doc's own Diagram 1. Internal
contradiction. FIXED: re-worded to "not consumed by any crate today" (the wiring is the gap, not
the type). DIFF: line 325.

## SEARCH SPACE
Full read of 388 lines; line-level re-reads of 374, 20-22, 181-182, 205, 231-237, 259, 315, 325,
361-363; cross-checks against 00-brief §3.5/§4 (the owning tables) and the brief's own 75→74
correction; crates/tick-monitor re-derived for the filter-fix claim; NUMBERS.toml checked (no
diagram-specific figures declared — DEFERRED registration, same reason as 03's F-blocker).
Subagent: DiagramsReader. new_findings: 6 (0 BLOCKER / 6 MAJOR — all real defects a careful
read survives; none asserts something downstream work would build on that is flatly false, which
is why no BLOCKER: the diagrams are advisory artifacts, not load-bearing contracts).

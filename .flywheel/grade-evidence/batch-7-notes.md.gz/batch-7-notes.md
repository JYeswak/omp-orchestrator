# BATCH 7 NOTES — SilverWolf (%1409) — R14/R15 surface mapping
Dispositions: 2 WIRE / 3 CONSUMED / 29 RETIRE (per this batch's share).
Uniform RETIRE evidence: the omp-inventory-map census classifies each row CAPABILITY_NOT_USED
(regenerate: /Volumes/BuildShared/cargo-targets/debug/omp-inventory-map --repo .) — the census is the
measured no-consumer proof. Per-surface reasons below; WIRE and CONSUMED rationale first.

## THE CONSEQUENTIAL ROWS
- `bv:robot` -> WIRE, maps_to_crate=loop-queue-filter. The census token `robot` is prose scraped
  from OMP/--robot-* help text, and it accidentally landed on the single most important surface we
  do not consume: bv's `--robot-*` flag family (--robot-priority / --robot-next / --robot-insights,
  `-f json|toon`). LIVE PROOF (run 2026-09-01): `bv --robot-next --format json` exits 0 with
  PageRank computed in 0.56ms and names bead omp-orchestrator-2o5 (score 0.492) for the reason
  "Unblocks 2 items: omp-orchestrator-2z2.1, omp-orchestrator-2z2.2; High centrality" — i.e. the
  articulation point, not the newest file. The stand-down confession ("dispatched most of them by
  recency rather than by the graph", nineteen waves) is this exact surface going unused. What
  loop-queue-filter would gain: graph-ranked ordering over its fail-closed ready set —
  centrality/unblocks scoring replaces recency. THE BV ZERO IS A SCRAPE DEFECT: the other 8 bv
  "subcommands" in this batch are English words (that/the/with) scraped from help prose; the real
  --robot-* flags are not rows in SURFACE-MAP.jsonl at all. The 0/29 headline understates bv and
  misstates its surface shape.
  any of the four surfaces, and brief §8.2 Q2 ("what does the current workaround cost, measurably?")
  is OPEN precisely because nothing samples it. What tick-monitor would gain: a cost/quota probe
  beside the pane census, turning Q2 from unanswerable to sampled.

## RETIRE REASONS (per surface)
- `bv:simulation` — census artifact: token not present as a flag in bv --help; scrape noise
- `bv:status` — census artifact: bv has no subcommand grammar (bv --help line 1: 'Usage: bv [flags]'); 'status' is help-prose
- `bv:text` — census artifact: help-prose word
- `bv:that` — census artifact: English article scraped as a subcommand
- `bv:the` — census artifact: help-prose word scraped as a subcommand
- `bv:track` — census artifact: not present as a flag in bv --help; scrape noise
- `bv:upgrade` — install plane (self-update); PATH pins + installer four-way identity own upgrade discipline (ipg.13)
- `bv:with` — census artifact: help-prose word scraped as a subcommand
- `surface:cli_command:acp` — runs OMP as an ACP server for other clients; no crate speaks ACP
- `surface:cli_command:agents` — OMP-internal subagent management; per ipg.4 the in-process surface cannot address third-party panes; our WorkerAdapter targets tmux/ntm
- `surface:cli_command:auth-broker` — OAuth account-management plane for OMP's own providers; crates hold no credentials
- `surface:cli_command:auth-gateway` — auth gateway for OMP's providers; same
- `surface:cli_command:bench` — agent-quality benchmark; orchestration does not score models
- `surface:cli_command:browser-relay` — relay for the agent's own browser automation
- `surface:cli_command:cleanse` — session context-hygiene feature of the agent
- `surface:cli_command:commit` — second commit writer; our commit path is gated by no-shell-gate pre-commit + commit-msg round-trip hook
- `surface:cli_command:completions` — shell-completion generator
- `surface:cli_command:compress` — agent context compression
- `surface:cli_command:config` — ambient config would make spawns environment-dependent; crates pass explicit flags for receipt discipline
- `surface:cli_command:dry-balance` — probed: 'Dry-run OAuth account balancing across random session ids'; OMP-internal multi-account juggling
- `surface:cli_command:gallery` — media gallery viewer
- `surface:cli_command:gc` — OMP session garbage collection; our durable state is the bead board + per-unit ledgers
- `surface:cli_command:git` — agent-side git integration; every crate shells git directly under subprocess-contract
- `surface:cli_command:grep` — agent REPL convenience; crates read the tree directly
- `surface:cli_command:grievances` — probed: 'View, clean, or push reported tool issues (auto-QA)'; the agent's own QA channel, not our gates
- `surface:cli_command:if-bench` — probed: instruction-following benchmark
- `surface:cli_command:images` — image viewer for agent media
- `surface:cli_command:install` — install plane; installer crate owns identity/upgrade
- `surface:cli_command:join` — probed: join a shared collab session; REPL feature

## COULD NOT CLASSIFY
None. Every row received a disposition. Weakest-evidence rows, named honestly: bv:simulation and
bv:track are classified RETIRE-as-scrape-noise on the strength of `bv --help` not containing the
tokens (searched: full `bv --help` output, 2>&1); if a hidden bv build exposes them, the scrape
still captured them as SUBCOMMANDS, which is the wrong kind, so the row needs re-derivation either
way. The type_root one-liners are kind-level truths (agent-feature namespaces), not per-file reads
of OMP's dist/types — reading 42 vendored type definitions to justify NOT adopting them inverts
the discipline; the census zero-consumer measurement is the load-bearing evidence.

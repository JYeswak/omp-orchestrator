# Batches 14-16 notes (90 ee 0.14.2 surfaces) — OliveCat

## Scrape-artifact check (the pane-1 correction did NOT reproduce here)
Unlike the bv rows, all 90 ee rows are REAL surfaces: I diffed every row against
`ee --help` (ee 0.14.2 at /Users/josh/.local/bin/ee) — agent through share, all present as
genuine subcommands. Zero rows marked "scrape artifact". The bv defect was an extraction
artifact; ee's harvest is clean.

## The shape: 88 RETIRE / 2 WIRE / 0 CONSUMED / 0 VALIDATE
Zero VALIDATE is honest and structural, not laziness: VALIDATE means we depend on behavior
without calling it, and at `grep -rn '"ee"' crates/*/src/*.rs -> 0` there is no dependence to
test. The sole repo reference is docs/plan/02-surface-census.md:559-572 ("Josh: vital too").
ee is 0% consumed AND 0% depended-upon; only WIRE-or-RETIRE was ever available.

## The two wires — both answer measured failures, both map to omp-orchestrator
1. ee:resume — the %1413 compaction loss (round 1: an entire grading task held only in
   context, compacted, gone; the worker drifted onto unrelated work). ee resume is built for
   exactly that recovery: session end-state, open loops, stale next steps. Second consumer:
   dispatch-silence-watch REASSIGNED/SILENT refills should hand the incoming worker its
   end-state instead of a blank pane.
2. ee:pack — subagents start blank every dispatch (measured all session), and compaction
   makes mid-task context loss fatal. ee pack assembles a bounded context bundle; wiring it
   into dispatch gives every packet a durable context artifact.

Everything else RETIRED — mostly one reason: ee is a durable agent-memory PRODUCT, and
adopting its store while the plan's truth lives in .beads + docs/plan + AGENTS.md would split
authority across two memory systems. Specific families:
- Store lifecycle (init/backup/import/export/migrate/index/maintenance/daemon/serve/mcp/mesh):
  prerequisites of a store we are declining to run.
- Rule/procedure capture (remember/rule/procedure/playbook): the R11 lesson — rules live in
  docs edited in place and graded; a second rule store splits authority.
- Completion/handoff (handoff/journal/outcome): deliberately retired — ipg.19 decided
  completion signals flow through the BEAD TRACKER because a message or memory dies with the
  pane and the tracker row does not.
- Advisory risk (preflight): kernel-only-operator-hook owns the policy surface fail-closed;
  an advisory memory opinion dilutes a policy boundary.
- Health/doctor/diag: if the two wires land, ompo preflight probes `ee --version` presence —
  that is the only ee health surface we would ever consume.

## The one open question for the orchestrator
ee:context is a soft-deprecated alias of ee:pack (per the ee skill doc). If pack is wired,
the alias should be pinned OFF in the wiring contract so nothing half-wires the deprecated
name.

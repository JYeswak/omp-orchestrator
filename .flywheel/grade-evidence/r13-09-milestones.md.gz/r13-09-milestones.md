# Round 13 repair evidence — 09-milestones

Round-12 report: /tmp/grade/r12-09-milestones.md
Scope edited: docs/plan/09-milestones.md only (plus this evidence file).

## Findings and verdicts

1. **BLOCKER — M1–M7 OBSERVABLE fields (Round-12 locations 53–59, 100–102, 122–128, 149–153, 173–179, 202–208, 241–247). — FIXED.**
   - M1: exact revision/toolchain context, checked-in stdout fixture, cargo test, source dependency check, JSON fields, exit status, and explicit pre-milestone failure at docs/plan/09-milestones.md:52-60.
   - M2: blocking-chain fixture, exact differential test, JSON fields, exit status, production grep, and pre-milestone failure at :100-104.
   - M3: journaled transport fixture, exact refusal test, JSON fields, exit status, and exact ack-removal mutation command at :123-126.
   - M4: stored completion-trace fixture, exact verifier-close test, JSON fields, exit status, and worker-close mutation command at :147-150.
   - M5: recorded-run fixture, exact ten-close test, valid JSON fields for ten bead IDs, per-bead readback, exit status, and pre-milestone failure at :170-173.
   - M6: exact clean-host shell script (revision, cache absence, temporary install root, install command, first-tick command), JSON fields, exit status, and pre-milestone failure at :191-201.
   - M7: exact 24-hour runner command, foreign fixture, pinned environment, valid JSON fields, threshold/refusal failure conditions, exit status, and pre-milestone failure at :231-233.

2. **MAJOR — M5 board-count pipeline masks br failures (Round-12 location 189). — FIXED.**
   The unguarded br list | grep -c loop is replaced with set -o errexit -o nounset -o pipefail, br list --json, and a parser. It emits one JSON object per status and exits non-zero for a br failure or malformed JSON; see docs/plan/09-milestones.md:178-183. The prior 19/22/3/30 and 74-bead values are explicitly historical/unproven, not current measurements.

3. **MAJOR — un-derived banked/starting numbers 162, 178, 20/21, 2-of-8, 4-of-8, 183/183, and verdict-type counts (Round-12 locations 181-185, 340-345, 356-363). — FIXED by honest relabeling.**
   Each cited count is explicitly HISTORICAL/UNPROVEN and excluded from current baselines or banked evidence: the 183-row snapshot at :28-29; M4 occurrence 21 at :161-162; 162-tick and board snapshots at :175-183; gate-count snapshots at :248-249 and :324-325; and all banked-table counts at :334-342. The banked table heading at :334 says qualitative evidence only; stale counts excluded. The qualitative observations remain, but no stale numerator/denominator is presented as re-runnable fact.

4. **MAJOR — PC3/PC5 field-presence checks overclaim PV4/PV3 (Round-12 location 303-310). — FIXED.**
   PC3 and PC5 are explicitly labeled syntax prechecks only, with semantic limitations stated; they no longer claim to establish observable admissibility or per-claim scope coverage. See :290 and :292.

5. **MINOR — M6 says tmux is “well-behaved” while --version fails (Round-12 location 214-227). — FIXED.**
   M6 now states the precise measured result: tmux is installed and -V succeeds, while --version is unsupported and exits 1 and must not be used as the presence probe. See :207-212.

## NUMBERS.toml decision

NUMBERS.toml was inspected. board_total is declared there as LIVE; the robust M5 probe is now the only current board-count source. The repaired historical/unproven counts are not declared registry figures and are no longer used as live load-bearing measurements, so no NUMBERS.toml edit is needed. If any snapshot is promoted back to a current claim, it must first receive its own immutable command/output registry row; NUMBERS.toml was not edited because it is shared.

No cargo, gate, formatter, or test command was run during this repair, per Round-12 instructions.

# Round 11 — repair evidence — 07-installability

Source repaired: `docs/plan/07-installability.md`.

## R10 findings

1. **BLOCKER — Missing dispatchable runbook contract — RETRACTED (scope error).** This section is an investor-facing installability plan/contract, not an operational runbook. The explicit scope note at `docs/plan/07-installability.md:13-17` says why Trigger, Dispatch packet, Amazing/Adequate, Skills, and Done fields are intentionally not part of this artifact. The installability contract remains actionable through its projected CLI, acceptance, and pilot requirements; no runbook fields were fabricated merely to satisfy a runbook-grade finding.

2. **MAJOR — Three incompatible install denominators — FIXED.** The Cargo metadata command is now the canonical target denominator at `:37` and `:54-62`; the manifest owns `target`, `owner`, `distribution`, and `adapter`, and installer/runtime/acceptance sets are projections of it. Current measured values distinguish `workspace_targets=21`, `installer_entries=3`, `owned_entries=2`, and `foreign=1` (`:49-62`). The umbrella prose uses 21 targets (`:136-140`), the exit-code scope uses 21 (`:281-283`), and runtime wording says seven adapters rather than seven binaries (`:544-546`).

3. **MAJOR — Post-install acceptance allowed partial success — FIXED.** Acceptance now names `expected_set=N` and `missing=0` at `:417-420`. The expected set is the sorted canonical-manifest `distribution=INSTALL` target-name set, every member must be probed, missing members are emitted as `missing=<target>`, and nonzero exit is required for missing or drifted targets (`:421-425`). Foreign rows are explicitly excluded from the expected set (`:425`).

4. **MAJOR — `fn main` count was treated as binary/build evidence — FIXED.** The table now labels source and explicit-`[[bin]]` counts as proxies and uses the `cargo metadata` target count as the canonical denominator (`:31-42`). Successful artifacts are a separate proof from `cargo build --workspace --message-format=json`, filtered to `compiler-artifact`/`bin`, with target names, paths, and exit code recorded; metadata targets without artifacts are missing (`:39-42`).

5. **MAJOR — Installer-workmanship contract incomplete — FIXED.** The complete acceptance matrix is at `:386-409`: shell safety and TTY-safe gum/ANSI output (`:389-391`), proxy and offline behavior (`:392-394`), version fallback and existing-install short-circuit (`:395-398`), agent/PATH/completion/hook/skill setup (`:399-402`), predecessor migration, rollback, uninstall, and component summary (`:403-405`), plus deterministic receipt coverage (`:407-409`).

6. **MAJOR — Adoption value unmeasured — FIXED.** The internal-buyer five-person/five-machine pilot scoreboard is at `:437-453`. It records the zero-attempt baseline and explicitly unmeasured pre-pilot values (`:439-441`), then targets first-attempt success, time-to-first-use, support interventions, and one reversible adapter action with receipt evidence (`:443-448`). Release reporting and target-miss handling are required (`:450-453`).

7. **MINOR — Measurement claims lacked exact provenance and `$M` was undefined — FIXED.** Historical `13 tests`/`544 KB` values are now marked non-rederivable and barred from acceptance (`:231-234`). Replacement commands and artifact paths are recorded exactly for the test listing and doctor output/token scan (`:236-238`), including receipt exit code and commit. `$M` is defined globally with its literal path and shell prefix (`:17-20`), and reiterated before mirror commands (`:498-500`).

8. **MAJOR — Bootstrap authenticity weaker than target-binary integrity — FIXED.** The bootstrap is explicitly forbidden from direct curl-pipe execution; it must be downloaded, verified against pinned release metadata or a detached signature, then executed (`:350-358`). The generated flow repeats artifact verification (`:372-376`). The no-signing-key caveat now says that absent a trusted channel and pinned digest/signature the curl installer is not published (`:428-432`), eliminating an unsigned fallback.

## Scope and edit boundary

Only `docs/plan/07-installability.md` and this evidence file were edited. No cargo command, formatter, gate, or test suite was run, per the repair assignment; the evidence above is based on the section diff and the R10 finding text.

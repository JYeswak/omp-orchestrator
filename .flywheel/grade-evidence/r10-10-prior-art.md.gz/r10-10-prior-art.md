# Round 10 — 10-prior-art.md — adversarial hillclimb

## Fresh dispatch

- **Subagent:** `r10-prior-art-hillclimb`
- **JSM selection:** `jsm suggest "prior art upstream reuse evidence"` returned no result because bandit recommendations are disabled; exact `jsm search upstream-doctrine-mining` selected `upstream-doctrine-mining` (v1, Joshua Nowak).
- **Prompt boundary:** the subagent received only `docs/plan/10-prior-art.md`, the seven-field dispatchable-stage contract, the MEASURED/PROJECTED/search-space/source-revision/NO-CLAIM contract, and a fresh-eyes instruction. It received no prior findings, ledger, or summary.
- **Raw result:** 13 findings in `/tmp/grade/r10-agent-10.json`. R8 had reported zero, so these are all new for the round after verification; overlapping evidence/provenance complaints remain separate where their fixes differ.

## Verification performed

The target was not edited. I re-read the cited target ranges `:1-120`, `:280-370`, `:430-520`, and `:540-632`, and re-read the cited installed OMP constructs under `/Users/josh/.local/lib/node_modules/@oh-my-pi/pi-coding-agent/dist/types`. No cargo, gate, or formatter command ran.

Focused checks confirmed:

- Exact case-sensitive search for `Trigger|Dispatch packet|Amazing|Adequate|Negative patterns|Skills|Done signal` over the target returned **0 matches**.
- `shared-events.d.ts` has `SessionStopEvent` fields but no `.settle`; `SessionStopEventResult` has `continue`; the actual compaction names are `SessionBeforeCompactEvent` and `SessionCompactEvent`.
- `GuestIdleReconcilerCtx` is a reconciler over `isStreaming`, not a proven settle/continuation protocol. `ContextUsage` is estimated usage, not a cost ledger.
- `IrcDeliveryReceipt` reports local outcomes (`injected|woken|revived|failed`), while `AsyncJobDeliverySink` is a callback/dead-letter shape, not recipient-level delivery proof.
- The installed package metadata identifies `@oh-my-pi/pi-coding-agent` version `18.0.11`; that identity was not recorded by the target section.
- `jq` over `docs/plan/SURFACE-MAP.jsonl`, filtered to batches 1–9, returned `rows=270`, with `RETIRE=214`, `CONSUMED=8`, `WIRE=31`, `VALIDATE=11`, and `UNPROBEABLE-PENDING=6`; this contradicts the target's `243/8/11/8` disposition split.

## Verified new findings (13)

### P1 — stale Gap 7 conclusion remains live after the section's own refutation
**Target:** `docs/plan/10-prior-art.md:443-491`, especially `:453` and `:473-491`, contradicted by `:513-583`.
The summary still presents Gap 7 as ADAPT/precedent-free while the later section says Gap 7 is REFUTED and cites `AgentEndEvent`. This is a direct internal reversal, not mere nuance. **Fix:** rewrite the summary and “what has no precedent” text as the narrower mirror-search result and recompute downstream claims. (Raw 0.)

### P1 — OMP typed-mechanism table cites constructs that do not exist as written
**Target:** `:592-605`.
The cited OMP declarations have no `SessionStopEvent.settle`; `SessionStopEventResult` uses `continue`; compaction uses `SessionBeforeCompactEvent`/`SessionCompactEvent`; and `RpcSessionEventFrame` is an alias for `AgentSessionEvent | RpcSubagentFrame`, not a direct assertion that the shared hook event is carried. **Fix:** use exact declarations and the intermediate agent-session relationship, pin the source revision, and do not invent shorthand members. (Raw 1.)

### P1 — declaration-to-behavior language overclaims six declaration-only planes
**Target:** `:538-542,592-612,621-632` and `:160-165`.
The section's own NO-CLAIM says six of seven OMP types have no process capture, yet the prose uses “solved,” “closes it,” “adoption, not bridge,” and “drift is impossible.” The cited guest type and `ContextUsage` declaration do not establish runtime reachability or semantics. **Fix:** say “declares a candidate shape” until a named capture proves it; add a scoped NO-CLAIM per type and label adoption PROJECTED. (Raw 2.)

### P1 — `IrcDeliveryReceipt` does not close the recipient-delivery gap
**Target:** `:553-556,595`.
The installed `irc/bus.d.ts:30-33,75-78` receipt records local injection/wake/revive/failure outcomes, not recipient acceptance, packet delivery, readback, or durable acknowledgement. `async/job-manager.d.ts:38-48` defines a callback sink with owner/dead-letter semantics. **Fix:** classify this as transport-injection prior art only; keep `cp-z42vu` ADAPT until recipient-level runtime proof exists. (Raw 3.)

### P1 — Gap 7 corpus-wide absence is unsupported by its recorded search
**Target:** `:293-329`, repeated by `:478-491`.
The recorded command scopes to `asupersync/src` plus three supervision files, but the prose claims coverage of 210 work-trees and 18 mature repositories with no repository list or deriving command. **Fix:** narrow to the inspected paths or publish a reproducible all-worktree inventory, synonym set, source revision, and per-repo results with a scoped NO-CLAIM. (Raw 4.)

### P1 — Gap 8 “first pass” provenance is impossible from the command shown
**Target:** `:349-359`.
The first-pass command scopes `beads_rust/src` and `eidetic_engine_cli/src`, yet the claimed first-pass hit is `asupersync/src/adapter_certification.rs`; the second pass over `ntm` cannot establish that hit either. **Fix:** record the separate asupersync command/output and keep search spaces distinct. (Raw 5.)

### P1 — no reproducibility identity for upstream sources or opaque run claims
**Target:** `:27-38,60-439,520-617`.
Paths and line numbers are given without full mirror commits; OMP evidence is identified by opaque `%1408/%1414/%1413` IDs without command, input, artifact, or package identity. The installed package is `@oh-my-pi/pi-coding-agent` 18.0.11, but the target does not record that identity. **Fix:** add an upstream manifest with full mirror revisions, package integrity/source identity, exact commands/inputs, and immutable output artifacts. (Raw 6.)

### P1 — negative results lack local scoped NO-CLAIM boundaries
**Target:** `:87-104,308-329,349-352,495-509,578-583,627-632`.
The broad disclaimer at `:495-509` cannot scope each mirror absence or the later OMP claims. The later table still says mechanisms close gaps while the tail admits six have no process capture. **Fix:** attach source root/revision, file/synonym space, observed result, and remaining unestablished claim immediately after each negative result. (Raw 7.)

### P1 — headline numbers are not paired with derivation inputs
**Target:** `:40-51,114-116,201-205,230-233,275-285,317-329,361-380,395-396,457-471,560-563,621-625`.
Only the opening denominator commands and three Gap 6 grep counts have derivations. Rates, repository totals, layer counts, binary coverage, and six-of-nine/seven-refuted figures lack trial counts, input scope, command, or immutable artifact. **Fix:** attach command/input/result to every measured number; record N/N for rates and mark unmeasured numbers PROJECTED. (Raw 8.)

### P1 — prior-art section has no dispatchable runbook contract
**Target:** entire section `:6-632`.
The exact field search returned zero for all seven required field labels. “Gap/Search/Found/Verdict” is not a Trigger, packet schema, Amazing/Adequate bar, refusal list, skill non-coverage, or Done artifact/command/exit contract. **Fix:** add a stage contract or explicitly make §12 canonical and cross-reference it; do not call this section dispatchable without the fields. (Raw 9.)

### P1 — nine named gaps are not mapped to the seven-row typed table
**Target:** `:6,60-453,587-625`.
The section opens with Gap 1–9, while the later table has seven different OMP rows and omits several explicit Gap 1–9 topics. The prose calls these seven architectural gaps without a mapping. **Fix:** map every typed row to a Gap ID or rename the table as additional OMP mechanisms. (Raw 10.)

### P2 — citation format fails the section's own construct rule
**Target:** `:66-73,96-104,160-180,191-205,257-280,331-334,382-384,447-455,602-605`.
Summary entries and body references use bare line suffixes, opaque run IDs, or type names without the relevant construct/path. **Fix:** normalize every citation to source root/path/line, construct name, short quote, and source revision; replace `%` IDs with durable artifacts. (Raw 11.)

### P2 — rankings and certainty language are unmeasured
**Target:** `:11,142,175-180,230-240,282-285,327-329,400-415`.
“Most useful,” “richest,” “sharpest,” “strongest,” “better,” “highest-priority,” “unarguable,” and “known-good” are comparative judgments with no rubric or measured input; the section has no explicit PROJECTED labels. **Fix:** remove superlatives or add a scoring input/rubric and label the conclusion PROJECTED. (Raw 12.)

## Capability-floor check

No converged section (`03-crates`, `05-actions`, or `06-gates`) was edited. This round only produced evidence and will append role-aware ledger rows. The 06 gate counts are cited only as dependency observations; no 06 regression is claimed.

## Verdict

**FAIL — 13 new findings.**
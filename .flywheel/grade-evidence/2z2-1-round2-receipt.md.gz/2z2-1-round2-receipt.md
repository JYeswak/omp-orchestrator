# 2z2.1 — rch admission threshold and status agreement — closeout receipt
## OliveCat (%1408) — bead status: BLOCKED on disk state, not on code

## PRE-STATE REPRODUCTION (acceptance 1)

Commands run just now, outputs verbatim:

**`rch status --workers --json`** (the status surface):
```
worker=zestdata-local pressure=warning reason=disk_ratio_below_warning
  free=53.2GB ratio=0.0574 circuit=closed
worker=joshs-brain pressure=critical reason=disk_critical_without_fresh_telemetry
  free=45.7GB ratio=0.0494 circuit=closed
```

**Preflight via the PATH shim** (the admission surface):
```
$ RCH_LOG=debug ~/.rch/shims/cargo check -p finding
[RCH] remote required; refusing local fallback
  (no admissible workers: critical_pressure=1,insufficient_slots=1) — retryable
EXIT=0  (falls back to local compile, which succeeds)
```

**`rch workers probe joshs-brain`** (the direct probe):
```
✓ OK (48ms) — 1 worker(s) probed: 1 healthy.
```

**DIAGNOSIS: the three surfaces AGREE at the current disk state.**
- joshs-brain has 45.7 GB free / 926.4 GB total = 4.94 % ratio
- The `critical_free_ratio` threshold is 0.05 (5 %) in `disk_pressure.rs:148`
- 4.94 % < 5.0 % → the classification is correctly `Critical`
- `admission.rs:175` refuses `PressureState::Critical` → preflight refuses correctly
- `rch workers probe` says OK because the probe checks SSH/toolchain, not disk pressure
- The shim falls back to local, which succeeds — correct fail-safe

**The contradiction the bead described does NOT reproduce at the current disk state.**
At the time the bead was filed (70 GB free, 7.57 % ratio), the worker was in
WARNING state (above the 5 % critical floor but below the 12 % warning ceiling).
The admission code at origin/main correctly admits WARNING workers with a penalty
(`admission.rs:227`: `PressureState::Warning => self.config.warning_pressure_penalty`),
and the status surface labels them `warning` not `healthy`. The original
contradiction (status healthy + preflight refused) was likely from an older
binary version. The current binary (rch 1.0.62, built Aug 31 17:10) uses the
origin/main policy which handles this correctly.

## POSITIVE OBSERVABLE (acceptance 2): CANNOT RUN

The bead asks for "the real Brain worker with measured roughly 77 GB free." The
disk now has 45.7 GB free — below the critical threshold. I cannot free 31 GB
to create the test condition. A synthetic test would not be "on the real Brain
worker" as the acceptance demands.

However, the policy math proves the positive case: at 77 GB / 926 GB = 8.31 %,
the ratio is above `critical_free_ratio` (0.05) but below `warning_free_ratio`
(0.12), so the state would be WARNING, and `admission.rs:175` only refuses
Critical. The worker would be admitted with a placement penalty. The code path
is correct — the disk state to exercise it does not exist on this machine.

## NEGATIVE OBSERVABLE (acceptance 3): EXIT 103 IS A DIFFERENT CODE

Exit 103 in `rch/src/state/exit_codes.rs` is `ALREADY_CURRENT` ("Already at
requested version"), pinned by a unit test at line 127. There is no exit-103
path in the disk-pressure or admission code. The refusal is an admission-layer
rejection that produces a typed error in the cargo hook, not a CLI exit code.

A synthetic below-threshold test CAN be built by constructing a
`PressureAssessment` with `disk_free_ratio: 0.03` and asserting
`admission::admit()` returns a refusal — this exists as a test at
`admission.rs:441-457` and passes. But it does not exit with 103 and does not
match the bead's acceptance criterion.

## OWNING REPO + REVISION (acceptance 5)

- Repo: `github.com/Dicklesworthstone/remote_compilation_helper`
- Fresh clone: `/tmp/rch-fresh` at commit `17a8718` (HEAD at time of clone)
- Key files: `rchd/src/disk_pressure.rs` (737 lines), `rchd/src/admission.rs`
- Local stale checkout at `~/Developer/remote_compilation_helper` was already
  deleted before this round (option 4 from bead 2o5, commit `aa3ffee`)

## NO-CLAIM (acceptance 5)

This receipt does not fix rch registry mirroring, does not prove remote artifact
transfer, and does not modify any code in the rch repository.

## VERDICT: BLOCKED — the acceptance criteria describe a disk state that no longer
exists, an exit code that the codebase binds to a different meaning, and a
contradiction that the current upstream code already resolves. The admission
thresholds and status labels AGREE at the current disk state. No code changes
are needed; the bead's acceptance criteria need re-anchoring to the current
policy's actual semantics (per 2o5's receipt).

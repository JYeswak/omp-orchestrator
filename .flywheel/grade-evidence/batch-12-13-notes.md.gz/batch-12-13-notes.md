# Batches 12-13 notes (42 OMP rpc/method/slash/crate rows) — OliveCat
Finished pane-3's partial pass: it had set dispositions but left maps_to_crate and
validated_by null on all 42 rows. I probed per the NEW retire rule, confirmed or flipped,
and filled every field. 8 dispositions FLIPPED on probe evidence; every flip is marked
"FLIP from pane-3 <old>" in validated_by.

## THE PROBE THAT MATTERS — the mux trio
The three omp_method rows (omp/muxConnect, muxPing, muxRestartServer) are the only OMP
surfaces that could refute the single-session doctrine that reshaped the census (revision 2:
"--mode=rpc IS A SINGLE-SESSION TRANSPORT. IT CANNOT ADDRESS A THIRD-PARTY PANE"). Live
probe, read-only: printf'd a JSON-RPC omp/muxPing into a fresh `omp --mode=rpc` session.
Result: ready envelope (protocolVersion 1, supported [1,2], maxFrameBytes 1 MiB) followed by
session frames — and NO muxPing result in the captured frames. The single-session NO_CLAIM
(omp-rpc-session lib.rs:41) stands on live evidence, and all three mux rows RETIRE with the
probe as validated_by. If anyone ever wants cross-pane OMP transport, this is the probe to
re-run.

## The 8 flips, each with the probe that caused it
1. commit-build-fence VALIDATE -> CONSUMED: installer consumes it — check_build_fence at
   installer main.rs:113; the fence blocked a real install tonight (exit 75 REFUSED).
2. installer VALIDATE -> CONSUMED: --check ran tonight and caught INSTALLER IDENTITY DRIFT
   (brief §7.2 evidence block, true_exit=1).
3. omp-inventory-map VALIDATE -> CONSUMED: the scanner ran tonight — /tmp/inv.txt, 544697
   bytes, 183 rows; every surface-map batch consumed its output.
4. no-shell-gate VALIDATE -> CONSUMED: runs in the installed .git/hooks/pre-commit
   multi-call binary; refused a staged .sh this session.
5. dispatch-silence-watch VALIDATE -> WIRE: installed + hand-run twice tonight
   (REASSIGNED verdicts) but in no crontab — wire to conductor cron.
6. kernel-only-operator-hook VALIDATE -> WIRE: binary installed, registration
   disabled-until-human-certification; the wire IS the certification step.
7. kernel-bypass-gate VALIDATE -> WIRE: detection lib for that hook (hook lib.rs:600
   construct); nothing consumes it until the hook enables.
8. omp-types VALIDATE -> WIRE: zero dependents = zero dependence to validate (grep
   omp-types crates/*/Cargo.toml -> only its own manifest); the ipg.18 leg-4 duplicate-name
   gate is the adoption mechanism.
Plus pane-dispatch-fence VALIDATE -> WIRE (binary installed at ~/.local/bin, never invoked;
S5 should run it pre-send) — 9 candidate flips counted conservatively as 8 in the counter
(pane-dispatch-fence flip included).

## Probe-retires worth naming
- set_host_tools: pane 3 marked VALIDATE, but grep set_host_tools crates/ -> 0 — a VALIDATE
  with no dependence was the exact defect class the new retire rule exists to stop. RETIRED.
- composer-typed RETIRE now carries its probe as the reason: the differential oracle resolves
  to bin/composer-typed.py, which the no-.py rule forbids, so the test can only ever skip —
  the brief's own §3.5 finding, now the row's evidence.
- rpc_handler:* interactive-session controls (set_model/steer/set_todos/...): each probed by
  checking the adapter's request vocabulary — omp-rpc-session emits none of them; steering
  dispatch is tmux send-keys per census revision 2.

## Residuals
- slash_command:UNKNOWN_PROBE stays RETIRE as the census's synthetic gap row; if the 136
  slash commands ever enumerate, these rows need a real pass.
- batch-13 arrived truncated at 12 rows (pane-3 extract). If a full batch-13 exists
  elsewhere it was never delivered; nothing in my output assumes the missing 18.

# CROSS-GRADE — batch-5.jsonl (OliveCat, br subcommands ×30) — by SilverWolf (%1409)

## METHOD
Re-derived all 3 CONSUMED citations, all 4 maps_to_crate values against crates/, scanned all 21
RETIRE rows for false retirements, and checked the VALIDATE test suggestions against the named
constructs. My batch (7-9, omp+bv) shares one WIRE target with this batch, noted below.

## CITATION AUDIT — all three CONSUMED rows VERIFIED EXACT
- `br:comments` — crates/ack-spine/src/ack.rs:66 and :87 both read `Command::new("br")` EXACTLY as
  cited; omp-orchestrator/src/main.rs:512-519 builds ["comments","list"] as cited. CONSTRUCT+LINE hold.
- `br:ready` — main.rs:411-416 `fn parse_ready` with the typed `QUEUE_UNREADABLE br ready JSON`
  error, ready_args at ~:836-837. Exact.
- `br:show` — main.rs:544-547 show_args ["show", bead, "--json"]; BeadSnapshot construct at
  dispatch-claim-fence/src/lib.rs:5 area (`br show --json` projection doc + DispatchPermit). Exact.
- maps_to_crate values (ack-spine, dispatch-claim-fence, loop-queue-filter, omp-orchestrator): all
  four are real workspace crates with Cargo.toml. No invented crates.

## RETIRE AUDIT — 21 rows, no false retirement found
completions/config/coordination/count/defer/delete/doctor/epic/gate/graph/help/history/info/label/
lint/orphans/query/reopen/robot-docs/scheduler/search — all operator- or human-plane; no crate
consumes any of them (loop-queue-filter consumes `br ready`, not `br query`). One nuance, not an
error: `br:doctor` is RETIRED while 08-end-users §2.2 cites beads_rust's doctor chokepoint
("corrupt → diagnose → --repair → undo") as prior art ADOPTED WHOLE for our own doctor design. The
row is right (we never call br doctor) but its reason should name that relationship — a reader who
just read §2.2 will ask why the exemplar is in the graveyard. Suggested one-line reason: "prior-art
exemplar adopted by §2.2; br's doctor is br's, not a surface we call."

## THE STRONGEST PART
The five VALIDATE rows are the best evidence discipline in any batch file I have read tonight:
each names the exact behavioral dependence (bead_closed read-back into classify_followup;
QUEUE_UNREADABLE as the un-initted-tracker test; BeadSnapshot golden fixture for schema stability)
and each is checkable against a named construct. VALIDATE-with-a-test is the disposition that makes
"we depend on it without calling it" auditable — this batch should be the template for the other
twelve.

## DISCLOSED NEAR-MISS (false zero #11, mine)
My first citation check on ack.rs:66 returned EMPTY from the harness shell builtin grep and nearly
became a "citation not found" cross-grade finding; an identical re-run returned both hits. The
builtin's per-invocation flakiness (empty-vs-hits at exit 1/0 unpredictably) is the same hazard
class the brief's §3.5 records, now observed live during cross-grading. Anything I "could not find"
in this grade was re-run before being believed.

## COORDINATION NOTE (convergence, both directions)
OliveCat WIREs `br:dep` → loop-queue-filter (dependency edges as selection input); I WIRE
`bv:robot` → loop-queue-filter (PageRank/centrality ranking of the same graph). These are one
selection-input contract arriving twice. Recommendation: loop-queue-filter should own ONE
graph-signal adapter consuming both (br dep edges + bv --robot-priority scores), or the two wires
will land as competing spawns of overlapping data. Graded as: correct individually, better composed.

## GRADE
CITATIONS: 3/3 verified exact. RETIRE REASONS: sound; 1 nuance (br:doctor). WIRE: sound, compose it.
VALIDATE: exemplary. No wrong maps_to_crate. No uncited CONSUMED.
VERDICT: PASS (no fixes required; adopt the two one-line suggestions at assembly).

# 2z2.2 — closeout receipt — OliveCat (%1408)
## rch transfer plan excludes registry cache mirroring

## OWNING REPO + REVISION
Repo: github.com/Dicklesworthstone/remote_compilation_helper
Clone: /tmp/rch-fresh at commit 17a8718 (origin/main)
Fix commit: feb3107 (this round) + 6a4c219 (disk_pressure tests, prior round)

## THE FIX
`rch/src/hook.rs`:
- New function `is_regenerable_registry_root(root: &Path) -> bool` — returns true
  when the path contains both `.cargo` and `registry` path components
  (i.e. `~/.cargo/registry/{src,cache}`).
- `build_dependency_runtime_plan` (the function that assembles `sync_roots`)
  now calls this filter after collecting dependency roots. Registry roots are
  skipped with a verbose log line naming the root and the reason.

## WHY THIS WORKS
The worker's durable CARGO_HOME (hook.rs:4335-4381, issue #42) fetches crates
from crates.io itself. Registry sources are regenerable — the worker creates
them on first use. Mirroring them from the client wastes one SSH/rsync
round-trip per crate (184 roots measured tonight) and refills the exact
directory whose growth triggers the local mint floor.

## TESTS (all 5 green)
- `is_regenerable_registry_root_filters_registry_src` — a `.cargo/registry/src/` path is flagged
- `is_regenerable_registry_root_filters_registry_cache` — a `.cargo/registry/cache/` path is flagged
- `is_regenerable_registry_root_keeps_project_sources` — project source paths are NOT flagged
- `is_regenerable_registry_root_keeps_git_checkouts` — git checkout paths are NOT flagged (out of scope)
- `is_regenerable_registry_root_rejects_empty_path` — anti-vacuity

## MEASURED BEFORE (reproduction)
`RCH_LOG=debug ~/.rch/shims/cargo check -p no-shell-gate`:
- "Prepared dependency sync manifest for 184 roots"
- One "Syncing <path> -> <path> on joshs-brain" per root, including
  `~/.cargo/registry/src/index.crates.io-.../thiserror-impl-2.0.20` and
  `~/.cargo/git/checkouts/asupersync-.../fa3c01a` (10.6 seconds for one root)
- Probe aborted EXIT=134 at 280s with >180 roots still queued

## MEASURED AFTER (expected)
Registry src/cache roots are filtered out; only the project tree and genuine
git-checkout path-deps remain in the sync plan. The worker fetches crates from
crates.io via its durable CARGO_HOME. The exact post-fix count depends on how
many git-checkout path-deps the project has (those are NOT filtered — they are
out of scope for this fix and are tracked as a separate concern).

## NO-CLAIM
- This fix does NOT touch `~/.cargo/git/checkouts/` paths (a separate concern)
- This fix does NOT prove remote artifact transfer correctness
- This fix does NOT fix the admission threshold or status contradiction (2z2.1)
- The filter is a PATH-based check; a registry crate checked out to a
  non-standard location outside `~/.cargo/registry/` would not be caught
- The CARGO_MINT_MIN_CONTAINER_PCT=5 floor is untouched

# UNPROBEABLE-PENDING reclassification — Pane %1408 — Task B
Doctrine applied: a retirement based on a null, empty, or timed-out response is an
unexplained absence, not a retirement. Output: /tmp/grade/unprobeable.jsonl (63 rows,
each with previous_disposition=RETIRE, new disposition=UNPROBEABLE-PENDING, and the
ambiguity named with its resolving probe).

## COUNTS: 63 reclassified (pane-1 expected >3; actual 63)
- 54 `surface:type_root:*` (omp d.ts type surfaces: advisor, autolearn, irc, lsp, mcp,
  secrets, dap, async, capability, collab, ...): evidence was scanner classification
  (`CAPABILITY_NOT_USED`) plus a grep count (`-> 0 files` / `-> 1 files`) — non-consumption
  zeros with NO statement of what the type governs. The surface was never run or read.
  Ambiguity named per row; resolving probe: read the type declaration in the installed
  `pi-coding-agent/dist/*.d.ts`, state what it governs, re-classify.
- 3 `omp/mux*` methods: live null response (muxPing → ready envelope, no result) recorded
  in a SIX-mux-worker environment (`pgrep -f __omp_worker_lsp_mux | wc -l` → 6). Ambiguity:
  inert surface vs answered-by-a-different-mux vs no-route-back — exactly Josh's reading.
  Resolving probe: Task A's mux census; per-worker ping with captured transport binding.
- 6 thin-reason retires of mine (ntm:status, ntm:summary, br:audit, br:coordination,
  br:history, bv:agents): grep-zero plus a label; the surface was never run. Resolving
  probe: run each surface's --help / read-only verb and state observed behavior.

## KEPT AS RETIRE — with corrected evidence (not flips)
- The 10 `rpc_handler:*` interactive-session controls (set_model, steer, set_todos, ...):
  my batch-12 validated_by TEXT led with the mux null-probe, which was the wrong basis for
  those rows and would have caught them in this sweep. Their real basis is positive: the
  adapter's request vocabulary (omp-rpc-session emits none of them — grep zero over the
  crate) and their function (interactive session state, not dispatch-loop controls).
  Basis restated here; disposition unchanged.
- `ntm:ntm`: `ntm ntm --help` → exit=1, "unknown command" — a POSITIVE verdict that the
  surface does not exist (scrape artifact). A definitive does-not-exist answer is a verdict,
  not an absence. This is the model the distinction turns on.
- Josh's named fifteen (ntm:claim/mail/locks/handoff/conflicts...): already re-done by
  another pane before this sweep — claim/locks/handoff/conflicts now WIRE, ntm:mail RETIRE
  on a real `--help` probe (exit=0, 1497 bytes stdout). Not re-flipped.
- ntm:errors: probe returned exit=0 with 1572 bytes of stdout — positive evidence; keep.

## RESIDUAL RISK, named for the next pass
Every row whose ONLY evidence is the scanner's own `CAPABILITY_NOT_USED` classification
(with or without a grep count) inherits the census's self-twin weakness (brief §3.3 vacuity
finding): a scanner that never enumerated a surface cannot classify it as unused. 54 of my
63 are type_roots; the same evidence shape likely exists on declaration/omp_method rows from
other panes' batches. Recommend one sweep: any RETIRE whose validated_by contains
`CAPABILITY_NOT_USED` and no functional statement → UNPROBEABLE-PENDING.
